<?php
   class Formula {
    public $CI = NULL;
      public $ago = '7';
      public $xaxis;
      public $fromdat;
      public $todat;
      public $begindate;
      public $start_3month;
      public $start_6month;
      
       function __construct()
      {
          // Call the Model constructor
          $this->CI =& get_instance();
      }
       public function curweek()
       {
          return " DATE_SUB(DATE(NOW()), INTERVAL 7 DAY)  AND CURDATE()  ";
       }
       public function getFormula($term,$back)
       {
           if ( $back == '1week' )       $this->ago = 7;
               
           else if ( $back == '2week' )  $this->ago = 14;
               
           else if ( $back == '1month' )  $this->ago = 1;
               
           else if ( $back == '3month' )  $this->ago  = 3;
               
               
           if ( $term == 'week' )
           {
                $query = "SELECT DATE_FORMAT( DATE_SUB( CURDATE( ) , INTERVAL ".$this->ago. 
"DAY ) ,  '%e.%b.%Y' ) AS start , DATE_FORMAT( DATE_SUB( CURDATE( ) , INTERVAL ".$this->ago."DAY ) 
,  '%e.%b.%Y' ) AS startdate ,DATE_FORMAT( CURDATE( ) ,  '%e.%b.%Y' ) AS enddate";                
                $query = mysql_query($query);             
                $get = mysql_fetch_array($query);               
                $this->fromdat   = $get['start'];
                $this->todat     = $get['enddate'];
                $this->begindate = $get['startdate'];
               
                $cmd =  ' DATE_SUB(CURDATE(), INTERVAL '.$this->ago.' DAY)  AND CURDATE() ';
           }                          
           return $cmd;   
       }
          
          
   }
       
       