<?php

   include 'Utility.php';   

  class Hightchart extends Utility 
	{  
         
        public $company = 'SILALAI';
        
        public $topic_label='';
        public $seriesX = array();
        public $seriesY = array();
        public $topicX;
        public $topicY;
        public $rangeSelector= array();
        public $title = array();
        public $subtitle;
        public $tooltip= array();
        public $yAxis= array();
        public $total=0;
        public $total_leads = 0;
        public $total_custs = 0;
        //public $detail;
        var $xAxi='';
        var $data='';
        
        //function api_Single line Series       
        
        //function api_Two panes, candlestick and volume        
        public $series= array();
        //function api_Compare multiple series
        public $serie_option;
         //$yAxis,
        //function api_52,000 points with data grouping
        public $button= array();
        public $selected;
        //function api_1.7 million points with async loading
        public $chart= array();
        public $navigator= array();
        public $scrollbar=false;
        //function api_Intraday area
        public $fillColor= array();
        public $threshold;
        //function api_Intraday candlestick
        //function api_Flags marking events
        public $onSeries;
        public $shape;
        public $width;
        public $query;
        public $dats=array();
        //function api_Dynamically updated data
        //function api_Line with markers and shadow
        //function api_Spline
        //function api_Step_line
        //function api_Area
        //function api_Area_spline
        //function api_Area_range    
        //function api_Area_spline_range;
        //function api_Candlestick;
        //function api_OHLC;
        //function api_Column;
        //function api_Column range;
        //function api_Plot_lines_on_Y_axis;
        //function 
          public $lang_day_eng_full = array('SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY');
          public $lang_day_eng_abbreviation = array("SUN","MON","TUE","WED","THUR","FRI","SAT");
          public $lang_day_thai_full = array("อาทิตย์","จันทร์","อังคาร","พุธ","พฤหัสบดี","ศุกร์","เสาร์");
          public $lang_day_thai_abbreviation = array("อา.","จ.","อ.","พ.","พฤ.","ศ.","ส.");
          public $lang_month_eng_full = array("JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER");
          public $lang_month_eng_abbreviation = array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
          public $lang_month_thai_full = array("มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฏาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม");
          public $lang_month_thai_abbreviation = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
       
        /*public function __construct() {            
          $this->DbConnection();   
       } 
       function DbConnection() { 
       global $connection;
       $connection = @mysql_connect('localhost','root','tracking1972') or die('Connection could not be made to the SQL Server. Please        report this system error at <font color="blue">info@servername.com</font>');
       @mysql_select_db('condo_common',$connection) or die('Connection could not be made to the database. Please report this system error at <font            color="blue">info@servername.com</font>');	
        mysql_query("SET NAMES UTF8");
       }
       */
       function convertDay($ondate)
       {
           return date("N",strtotime("0 days",strtotime($ondate)));
       }
       function format_Back7day($ondat,$total)
       {
           //echo $this->backdate; 
           
           while ($dat = current($dats)) 
           {
              if (key($dat) == $ondat) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }
      function format_Back14day($ondat,$total)
      {
           
           while ($dat = current($dats)) 
           {
              if (  $ondat <= key($dat) ) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }
       
      function format_Back1month($ondat,$total)
      {
           while ($dat = current($dats)) 
           {
              if (  $ondat <= key($dat) ) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }
      function format_Back3month($ondat,$total)
      {
           while ($dat = current($dats)) 
           {
              if (  $ondat <= key($dat) ) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }
      function format_Back6month($ondat,$total)
      {
           while ($dat = current($dats)) 
           {
              if (  $ondat <= key($dat) ) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }    
      function format_Back1year($ondat,$total)
      {
           while ($dat = current($dats)) 
           {
              if (  $ondat <= key($dat) ) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }
      function format_Back3year($ondat,$total)
      {
           while ($dat = current($dats)) 
           {
              if (  $ondat <= key($dat) ) {
                  $dats[key($dat)] = $total;
                  break;
               }
              next($dat);
           }         
      }    
       public function api_Opportunitystage()
        {
              
             $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
             if ( $this->total > 0 )
             {
             $query = mysql_query($this->opportunity);
             while(	$get = mysql_fetch_array($query)	){  
                 if ( $get['cus_stages_id'] == 1 )        $data .= !empty($get['total_cust'])?"['FIRST TIME 3%',".$get['total_cust']."],":"";
                 else if ( $get['cus_stages_id'] == 2 )   $data .= !empty($get['total_cust'])?"['APPROACH 10%',".$get['total_cust']."],":"";
                 else if ( $get['cus_stages_id'] == 3 )   $data .= !empty($get['total_cust'])?"['DISCUSSION 50%',".$get['total_cust']."],":"";
                 else if ( $get['cus_stages_id'] == 4 )   $data .= !empty($get['total_cust'])?"['NEGOTIATION 70%',".$get['total_cust']."],":"";
                 else if ( $get['cus_stages_id'] == 5 )   $data .= !empty($get['total_cust'])?"['COMMITMENT 90%',".$get['total_cust']."],":"";
                 else if ( $get['cus_stages_id'] == 6 )   $data .= !empty($get['total_cust'])?"['SUCCESS 100%',".$get['total_cust']."],":"";
             }
            $data = substr($data, 0, -1);
             }
           $api = "<script type='text/javascript'>
$(function () {

    $(document).ready(function () {

        // Build the chart
        $('#chart_opportutinity').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: null
            },
            exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> Opportunitystage Lead ',
                        fontSize:15
                    }
                }
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        distance: -50,
                        format: ' {point.percentage:.1f} % ',
                        style: {
                        fontWeight: 'normal',
                        color: '#000000',
                        textShadow: '0px 1px 2px black'
                    }
                    },
                    showInLegend: true
                }
            },
            series: [{
                type: 'pie',
                name: 'Browser share',
                data: [
                    $data
                ]
            }]

        });
    });
});
		</script>";        
                      return $api;
       }
       public function api_Type()
      {
             
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
          
           if ( $this->total > 0 )
           {
           $query = mysql_query($this->sourcetype);
           
             while(	$get = mysql_fetch_array($query)	){  
                $data .= !empty($data)?",['".$get['cus_group_type']."',".$get['total_cust']."]":"['".$get['cus_group_type']."',".$get['total_cust']."]";
                
             }            
           }
           
           $api = "
<script>
$(function () {
    
    Highcharts.setOptions({
     colors: ['#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263',      '#6AF9C4']
    });
    var chart;

    $(document).ready(function() {
     
        chart = new Highcharts.Chart({

            chart: {

                renderTo: 'chart_type',

                plotBackgroundColor: null,

                plotBorderWidth: null,

                plotShadow: false

            },

            title: {

                text: null

            },
            exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  Type Lead ',
                        fontSize:15
                    }
                }
            },
            tooltip: {

                formatter: function() {

                    return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';

                }

            },

            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        distance: -50,
                        format: ' {point.percentage:.1f} % ',
                        style: {
                        fontWeight: 'normal',
                        color: '#000000',
                        textShadow: '0px 1px 2px black'
                    }
                    },
                    showInLegend: true
                }
            },
            series: [{

                type: 'pie',

                name: 'Browser share',

                data: [

                    $data

                ]

            }]

        });

    });
});

</script>"; 
           return $api;
       }
       
       
       
       public function api_Leads($longday='',$searchby='ago',$ago='week',$back='1week')
       {            
        
            
           $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
             $this->total = 0;
             $this->longtime = $longday;           
             //echo "by =".$searchby."=".$ago.":".$back;
             $query = mysql_query($this->Leads($searchby,$ago,$back));
             //echo 'sql='.$quer;
           //echo "start day ".$this->startdate;
          
           //echo "when= ".$t->when;
            
             $this->dats= array( 
	                    date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))),
             			date("Y-m-d",strtotime("+7 days",strtotime($this->startdate))));                 
           
             if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
         else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
         else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
         else if ( $searchby == 'ago') 
             $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
             $mon = 0;
             $tue = 0;
             $wed = 0;
             $thurs = 0;
             $fri  = 0;
             $sat = 0;
             $sun = 0;
             $total = 0;
           
             $week1=0;
             $week2=0;
             $week3=0;
             $week4=0;
             $week5=0;
           
             $mon1 = 0;
             $mon2 = 0;
             $mon3 = 0;
             $mon4 = 0;
             $mon5 = 0;
             $mon6 = 0;
             $mon7 = 0;
             $mon8 = 0;
             $mon9 = 0;
             $mon10 = 0;
             $mon11 = 0;
             $mon12 = 0;
           
             $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
                       
             $no = 0;$skip1=true;$skip2=true;
             while(	$get = mysql_fetch_array($query)	)
             {
                 if ( $searchby == 'day')
                 {                    
                    //$this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                     if ( strtoupper($get['dayname']) == 'MONDAY' ) $mon = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) $tue = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) $wed = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) $thurs = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' ) $fri = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) $sat = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) $sun = $get['total_cust'];   
                 }
                 else if ( $searchby == 'week')
                 {
                     //$this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     if ( $get['weekno'] == 1 ) $week1  = $get['total_cust']; 
                     else if ( $get['weekno'] == 2 ) $week2  = $get['total_cust']; 
                     else if ( $get['weekno'] == 3 ) $week3  = $get['total_cust']; 
                     else if ( $get['weekno'] == 4 ) $week4  = $get['total_cust']; 
                     else if ( $get['weekno'] == 5 ) $week5  = $get['total_cust']; 
                     /*$data  .= !empty($data)?','.$get['total_cust']:$get['total_cust']; 
                     $xAxis .= !empty($xAxis)?",'".$get['dat'].".(".$get['year'].")'":
                     "'".$get['dat'].".(".$get['year'].")'";  
                     */
                 }
                 else if ( $searchby == 'month')
                 {
                    //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                    
                    if ( $get[$searchby] == 1 ) $mon1 = $get['total_cust'];
                    else if ( $get[$searchby] == 2 )  $mon2 = $get['total_cust'];
                    else if ( $get[$searchby] == 3 )  $mon3 = $get['total_cust'];
                    else if ( $get[$searchby] == 4 )  $mon4 = $get['total_cust'];
                    else if ( $get[$searchby] == 5 )  $mon5 = $get['total_cust'];
                    else if ( $get[$searchby] == 6 )  $mon6 = $get['total_cust'];
                    else if ( $get[$searchby] == 7 )  $mon7 = $get['total_cust'];
                    else if ( $get[$searchby] == 8 )  $mon8 = $get['total_cust'];
                    else if ( $get[$searchby] == 9 )  $mon9 = $get['total_cust'];
                    else if ( $get[$searchby] == 10 )  $mon10 = $get['total_cust'];
                    else if ( $get[$searchby] == 11 ) $mon11 = $get['total_cust'];
                    else if ( $get[$searchby] == 12 ) $mon12 = $get['total_cust'];
                 }
                 else if ( $searchby == 'ago') 
                 {
                    //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' TO '.date('d-m-Y');
                                          
                    if ( $back=='1week' )
                    {
                        $months[] = $get['created'];
                        $custs[]  = $get['total_cust'];                        
                     }
                    else 
                    {
                       // week y-m-d/weekno/total  1 month
                       //  // week Y-m-d/total 3 month
                        $this->series_column[$get['week']] = $get['total_cust'];
                    }
                    
                     
                 }                 
                 $this->total +=  $get['total_cust'];
             }
             
         if ( $this->total > 0 )
         {
          // echo 'TOTAL = '.$this->total;
           if ( $searchby == 'day')
           {
              
               //$ttd = date("dd.M.y",strtotime($this->dats[1])); 
               //echo 'date = '.$ttd;
               //echo $tt . " <> ".date("M",$tt)." = ".$ttd;
               $j=0;                
               foreach ( $this->lang_day_eng_abbreviation as  $value) 
                {
                  
                    $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($this->dats[$j]))."'":"'".date('d-M-y',strtotime($this->dats[$j]))."'";   
                    ++$j;
                }
               $data = $sun.','.$mon.','.$tue.','.$wed.','.$thurs.','.$fri.','.$sat;
           }
           
           else if ( $searchby == 'week' )
             {               
               $xAxis .= "'1-7','8-14','15-21','22-28','29+'";
                
               $data = $week1.','.$week2.','.$week3.','.$week4.','.$week5;
             }
           else if ( $searchby == 'month')
           {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $data = $mon1.','.$mon2.','.$mon3.','.$mon4.','.$mon5.','.$mon6.','.$mon7.','.$mon8.','.$mon9.','.$mon10.','.$mon11.','.$mon12;
           }
           else if ( $searchby == 'ago')
           {
               //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                    $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      //echo $month.',';
                      if ( sizeof($months) > 0 )
                      {
                        foreach ( $months  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                       //  echo $value.",";
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data != ''?",$custs[$m]":"$custs[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
               }
               
               
               else 
               {
                   
                    $this->setArrangeSeriestoPlotChart($interval=$back,'line');
                   
                    $xAxis = $this->xAxis;
                    $data  = $this->deta;     
               }       
           }
         }
           // echo $xAxis;
           //    echo "<p>".$data;
        
            
           // unset($this->xAxis);
            //unset($this->deta);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
            
           
            $api = "<script> $(function () {
    $('#chart_lead').highcharts({
        chart: {
            borderColor: '#ffffff',
            borderWidth: 1,
            type: 'line',
            plotBackgroundColor: '#FFFFFF',
            plotShadow: true,
             zoomType: 'x',
             style: {
                fontFamily: 'serif',
	fontSize: '6px'
             }
        },
        title: {
            text: null,
            x: -20 //center
        },        
        subtitle: {
            text: null,
            x: -20
        }, 
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  Lead Total ',
                        fontSize:15
                    }
                }
            },
        xAxis: {
            categories: [$xAxis],
            labels: {
                style: {
                    color: 'black'
                },
                rotation: 270,
            }
        },
        yAxis: {
            alternateGridColor: '#ffffff',
            floor:0,
            
            title: {
                text: 'Leads '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            pointFormat: 'Leads : <b>{point.y}</b><br/>',
            shadow:true,
            crosshairs: true,
            valueSuffix: ' person'
        },

        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{y} '
                },
                marker: {
                    fillColor: '#cccccc',
                    lineWidth: 5,
                    lineColor: '#FF4500' // inherit from series
                }
            }
        },
        
        legend: {
            enabled: false
        },
        series: [{
            data: [$data]
        }]
    });
});
</script>";
           
            
             return $api;
       }
       public function api_Customers($longday='',$searchby='ago',$ago='week',$back='1week')
       {            
        
            
           $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
             $this->total = 0;
             $this->longtime = $longday;           
             //echo "by =".$searchby."=".$ago.":".$back;
             $query = mysql_query($this->Customers($searchby,$ago,$back));
             //echo 'sql='.$quer;
           //echo "start day ".$this->startdate;
          
           //echo "when= ".$t->when;
            
             $this->dats= array( 
	                    date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
	                    date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))),
             			date("Y-m-d",strtotime("+7 days",strtotime($this->startdate))));                 
           
             if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
         else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
         else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
         else if ( $searchby == 'ago') 
             $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
             $mon = 0;
             $tue = 0;
             $wed = 0;
             $thurs = 0;
             $fri  = 0;
             $sat = 0;
             $sun = 0;
             $total = 0;
           
             $week1=0;
             $week2=0;
             $week3=0;
             $week4=0;
             $week5=0;
           
             $mon1 = 0;
             $mon2 = 0;
             $mon3 = 0;
             $mon4 = 0;
             $mon5 = 0;
             $mon6 = 0;
             $mon7 = 0;
             $mon8 = 0;
             $mon9 = 0;
             $mon10 = 0;
             $mon11 = 0;
             $mon12 = 0;
           
             $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
                       
             $no = 0;$skip1=true;$skip2=true;
             while(	$get = mysql_fetch_array($query)	)
             {
                 if ( $searchby == 'day')
                 {                    
                    //$this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                     if ( strtoupper($get['dayname']) == 'MONDAY' ) $mon = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) $tue = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) $wed = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) $thurs = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' ) $fri = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) $sat = $get['total_cust'];
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) $sun = $get['total_cust'];   
                 }
                 else if ( $searchby == 'week')
                 {
                     //$this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     if ( $get['weekno'] == 1 ) $week1  = $get['total_cust']; 
                     else if ( $get['weekno'] == 2 ) $week2  = $get['total_cust']; 
                     else if ( $get['weekno'] == 3 ) $week3  = $get['total_cust']; 
                     else if ( $get['weekno'] == 4 ) $week4  = $get['total_cust']; 
                     else if ( $get['weekno'] == 5 ) $week5  = $get['total_cust']; 
                     /*$data  .= !empty($data)?','.$get['total_cust']:$get['total_cust']; 
                     $xAxis .= !empty($xAxis)?",'".$get['dat'].".(".$get['year'].")'":
                     "'".$get['dat'].".(".$get['year'].")'";  
                     */
                 }
                 else if ( $searchby == 'month')
                 {
                    //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                    
                    if ( $get[$searchby] == 1 ) $mon1 = $get['total_cust'];
                    else if ( $get[$searchby] == 2 )  $mon2 = $get['total_cust'];
                    else if ( $get[$searchby] == 3 )  $mon3 = $get['total_cust'];
                    else if ( $get[$searchby] == 4 )  $mon4 = $get['total_cust'];
                    else if ( $get[$searchby] == 5 )  $mon5 = $get['total_cust'];
                    else if ( $get[$searchby] == 6 )  $mon6 = $get['total_cust'];
                    else if ( $get[$searchby] == 7 )  $mon7 = $get['total_cust'];
                    else if ( $get[$searchby] == 8 )  $mon8 = $get['total_cust'];
                    else if ( $get[$searchby] == 9 )  $mon9 = $get['total_cust'];
                    else if ( $get[$searchby] == 10 )  $mon10 = $get['total_cust'];
                    else if ( $get[$searchby] == 11 ) $mon11 = $get['total_cust'];
                    else if ( $get[$searchby] == 12 ) $mon12 = $get['total_cust'];
                 }
                 else if ( $searchby == 'ago') 
                 {
                    //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' TO '.date('d-m-Y');
                                          
                    if ( $back=='1week' )
                    {
                        $months[] = $get['created'];
                        $custs[]  = $get['total_cust'];                        
                     }
                    else 
                    {
                       // week y-m-d/weekno/total  1 month
                       //  // week Y-m-d/total 3 month
                        $this->series_column[$get['week']] = $get['total_cust'];
                    }
                    
                     
                 }                 
                 $this->total +=  $get['total_cust'];
             }
             
         if ( $this->total > 0 )
         {
          // echo 'TOTAL = '.$this->total;
           if ( $searchby == 'day')
           {
              
               //$ttd = date("dd.M.y",strtotime($this->dats[1])); 
               //echo 'date = '.$ttd;
               //echo $tt . " <> ".date("M",$tt)." = ".$ttd;
               $j=0;                
               foreach ( $this->lang_day_eng_abbreviation as  $value) 
                {
                  
                    $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($this->dats[$j]))."'":"'".date('d-M-y',strtotime($this->dats[$j]))."'";   
                    ++$j;
                }
               $data = $sun.','.$mon.','.$tue.','.$wed.','.$thurs.','.$fri.','.$sat;
           }
           
           else if ( $searchby == 'week' )
             {               
               $xAxis .= "'1-7','8-14','15-21','22-28','29+'";
                
               $data = $week1.','.$week2.','.$week3.','.$week4.','.$week5;
             }
           else if ( $searchby == 'month')
           {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $data = $mon1.','.$mon2.','.$mon3.','.$mon4.','.$mon5.','.$mon6.','.$mon7.','.$mon8.','.$mon9.','.$mon10.','.$mon11.','.$mon12;
           }
           else if ( $searchby == 'ago')
           {
               //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                    $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      //echo $month.',';
                      if ( sizeof($months) > 0 )
                      {
                        foreach ( $months  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                       //  echo $value.",";
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data != ''?",$custs[$m]":"$custs[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
               }
               
               
               else 
               {
                   
                    $this->setArrangeSeriestoPlotChart($interval=$back,'line');
                   
                    $xAxis = $this->xAxis;
                    $data  = $this->deta;     
               }       
           }
         }
           // echo $xAxis;
           //    echo "<p>".$data;
        
            
           // unset($this->xAxis);
            //unset($this->deta);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
            
           
            $api = "<script> $(function () {
    $('#chart_customer').highcharts({
        chart: {
            borderColor: '#ffffff',
            borderWidth: 1,
            type: 'line',
            plotBackgroundColor: '#FFFFFF',
            plotShadow: true,
             zoomType: 'x',
             style: {
                fontFamily: 'serif',
	fontSize: '6px'
             }
        },
        title: {
            text: null,
            x: -20 //center
        },        
        subtitle: {
            text: null,
            x: -20
        }, 
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  Customer Total ',
                        fontSize:15
                    }
                }
            },
        xAxis: {
            categories: [$xAxis],
            labels: {
                style: {
                    color: 'black'
                },
                rotation: 270,
            }
        },
        yAxis: {
            alternateGridColor: '#ffffff',
            floor:0,
            
            title: {
                text: 'Customers '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            pointFormat: 'Customers : <b>{point.y}</b><br/>',
            shadow:true,
            crosshairs: true,
            valueSuffix: ' person'
        },

        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{y} '
                },
                marker: {
                    fillColor: '#cccccc',
                    lineWidth: 5,
                    lineColor: '#FF4500' // inherit from series
                }
            }
        },
        
        legend: {
            enabled: false
        },
        series: [{
            data: [$data]
        }]
    });
});
</script>";
           
            
             return $api;
       }
       public function api_Proportion_CustomersAndLeads($longday='',$searchby,$ago,$back)
       {
             
             $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
             $this->longtime = !empty($longday)?$longday:'';           
             $ax[] = $this->proportion($searchby,$ago,$back);
             
             $this->total_leads = 0;
             $this->total_custs = 0;
             //echo $ax[0]['sum'];
              $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+7 days",strtotime($this->startdate))) );
          if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
          else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
          else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
          else if ( $searchby == 'ago') 
             $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
             
             $query = mysql_query($ax[0]['sum']);            
             $mon_lead = 0;
             $tue_lead = 0;
             $wed_lead = 0;
             $thurs_lead = 0;
             $fri_lead  = 0;
             $sat_lead = 0;
             $sun_lead = 0;           
             $mon_cust = 0;
             $tue_cust = 0;
             $wed_cust = 0;
             $thurs_cust = 0;
             $fri_cust  = 0;
             $sat_cust  = 0;
             $sun_cust  = 0;
             $old_week  ='';
             $old_month ='';           
             if ( $searchby == 'week' )
             {
             $total_leads1 = 0;
             $total_custs1 = 0;
             $total_leads2 = 0;
             $total_custs2 = 0;
             $total_leads3 = 0;
             $total_custs3 = 0;
             $total_leads4 = 0;
             $total_custs4 = 0;
             $total_leads5 = 0;
             $total_custs5 = 0;
             }
           
             if ( $searchby == 'month' )
             {
             $leads_month1 = 0;
             $custs_month1 = 0;
             $leads_month2 = 0;
             $custs_month2 = 0;
             $leads_month3 = 0;
             $custs_month3 = 0;
             $leads_month4 = 0;
             $custs_month4 = 0;
             $leads_month5 = 0;
             $custs_month5 = 0;
             $leads_month6 = 0;
             $custs_month6 = 0;
             $leads_month7 = 0;
             $custs_month7 = 0;
             $leads_month8 = 0;
             $custs_month8 = 0;
             $leads_month9 = 0;
             $custs_month9 = 0;
             $leads_month10 = 0;
             $custs_month10 = 0;
             $leads_month11 = 0;
             $custs_month11 = 0;
             $leads_month12 = 0;
             $custs_month12 = 0;
           
             }            
             $total_leads = 0;
             $total_custs = 0;
             $xAxis = '';
             $data  = '';
             $olddate = '';
             //echo $query;
             while(	$get = mysql_fetch_array($query)	)
             {                 
                 
                 
                 
                 if (  $searchby == 'day' )
                 {                    
                     //$this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                     
                     if ( $olddate != $get['created'] ) 
                     {                         
                         $xAxis .= !empty($xAxis)?",'".$get['created']."'":"'".$get['created']."'";
                         $olddate = $get['created'];
                     }
                     $old_week=$old_week !== $get['week']?$get['week']:$old_week;
                    if ( empty($longday) )
                    {
                        if ( strtoupper($get['dayname']) == 'MONDAY' ) 
                         {
                             if (  $get['leads']=='lead' ) {
                                 $mon_lead = $get['total_cust']; 
                                 $this->total_leads += $get['total_cust'];      
                             }
                             if (  $get['leads']=='cust' ) { 
                                 $mon_cust = $get['total_cust']; 
                                 $this->total_custs += $get['total_cust'];      
                             }
                         
                         }
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) 
                         {
                             if (  $get['leads']=='lead' )  {
                                 $tue_lead = $get['total_cust'];
                                 $this->total_leads += $get['total_cust'];      
                             }
                             if (  $get['leads']=='cust' )  {
                                 $tue_cust = $get['total_cust'];
                                 $this->total_custs += $get['total_cust'];      
                             }
                         }
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) 
                         {
                             if (  $get['leads']=='lead' ) {
                                 $wed_lead = $get['total_cust'];
                                 $this->total_leads += $get['total_cust'];      
                             }
                             if (  $get['leads']=='cust' ) {
                                 $wed_cust = $get['total_cust'];
                                 $this->total_custs += $get['total_cust'];      
                             }
                         }
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) 
                         {
                             if (  $get['leads']=='lead' )  {
                                 $thurs_lead = $get['total_cust'];
                                 $this->total_leads += $get['total_cust'];      
                             }
                             if (  $get['leads']=='cust' )  {
                                 $thurs_cust = $get['total_cust'];
                                 $this->total_custs += $get['total_cust'];      
                             }
                         }
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' )
                         {
                            if (  $get['leads']=='lead' )  {
                                $fri_lead = $get['total_cust'];
                                $this->total_leads += $get['total_cust'];      
                            }
                            if (  $get['leads']=='cust' )  {
                                $fri_cust = $get['total_cust'];
                                $this->total_custs += $get['total_cust'];      
                            }
                         }
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) 
                         {
                             if (  $get['leads']=='lead' )  {
                                 $sat_lead = $get['total_cust'];
                                 $this->total_leads += $get['total_cust'];      
                             }
                             if (  $get['leads']=='cust' )  {
                                 $sat_cust = $get['total_cust'];
                                 $this->total_custs += $get['total_cust'];      
                             }
                         }
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) 
                         {
                             if (  $get['leads']=='lead' )  {
                                 $sun_lead = $get['total_cust'];
                                 $this->total_leads += $get['total_cust'];      
                             }
                             if (  $get['leads']=='cust' )  {
                                 $sun_cust = $get['total_cust'];
                                 $this->total_custs += $get['total_cust'];      
                             }
                          }
                    }                    
                 }
                 else if ( $searchby == 'week' )
                 {
                     //$this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     $old_week=$old_week !== $get['week']?$get['week']:$old_week;
                    if ( $get['weekno'] ==  1 )
                    {
                        if (  $get['leads']=='lead' ) {
                           $total_leads1 = $get['total_cust'];                                
                           $this->total_leads += $get['total_cust'];                                
                        }
                        else if ( $get['leads']=='cust' ) 
                        {
                           $total_custs1 = $get['total_cust'];      
                           $this->total_custs += $get['total_cust'];          
                        }
                        
                    }
                    else if ( $get['weekno'] ==  2 )
                    {
                        if (  $get['leads']=='lead' ) {
                           $total_leads2 = $get['total_cust'];                                
                           $this->total_leads += $get['total_cust'];                                
                        }
                        else if ( $get['leads']=='cust' ) 
                        {
                           $total_custs2 = $get['total_cust'];      
                           $this->total_custs += $get['total_cust'];          
                        }
                        
                    } 
                    else if ( $get['weekno'] ==  3 )
                    {
                        if (  $get['leads']=='lead' ) {
                           $total_leads3 = $get['total_cust'];                                
                           $this->total_leads += $get['total_cust'];                                
                        }
                        else if ( $get['leads']=='cust' ) 
                        {
                           $total_custs3 = $get['total_cust'];      
                           $this->total_custs += $get['total_cust'];          
                        }
                        
                    }
                    else if ( $get['weekno'] ==  4  ) 
                    {
                        if (  $get['leads']=='lead' ) {
                           $total_leads4 = $get['total_cust'];                                
                           $this->total_leads += $get['total_cust'];                                
                        }
                        else if ( $get['leads']=='cust' ) 
                        {
                           $total_custs4 = $get['total_cust'];      
                           $this->total_custs += $get['total_cust'];          
                        }
                        
                    }
                    else if ( $get['weekno'] ==  5 )
                    {
                        if (  $get['leads']=='lead' ) {
                           $total_leads5 = $get['total_cust'];                                
                           $this->total_leads += $get['total_cust'];                                
                        }
                        else if ( $get['leads']=='cust' ) 
                        {
                           $total_custs5 = $get['total_cust'];      
                           $this->total_custs += $get['total_cust'];          
                        }
                        
                    }                 
                 }
                 else if ( $searchby == 'month' )
                 {
                     //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                     if ( strtoupper($get[$searchby]) == 'JANUARY' ) 
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month1 = $get['total_cust'];                                
                            $this->total_leads  += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month1 = $get['total_cust'];                                
                            $this->total_custs  += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'FEBRUARY' )
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month2 = $get['total_cust'];                                
                            $this->total_leads  += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month2 = $get['total_cust'];                                
                            $this->total_custs  += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'MARCH' ) 
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month3 = $get['total_cust'];                                
                            $this->total_leads  += $get['total_cust'];                                
                         }
                         else if ( strtoupper($get[$searchby]) == '' ) 
                         {
                            $custs_month3 = $get['total_cust'];                                
                            $this->total_custs  += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'APRIL' ) 
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month4 = $get['total_cust'];                                
                            $this->total_leads  += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month4 = $get['total_cust'];                                
                            $this->total_custs  += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'MAY' )
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month5 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month5 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'JUNE' )
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month6 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month6 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'JULY' )
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month7 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month7 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'AUGUST' ) 
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month8 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month8 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'SEPTEMBER' )
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month9 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month9 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'OCTOBER' )
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month10 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month10 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get[$searchby]) == 'NOVEMBER' ) 
                     {
                         if (  $get['leads']=='lead' ) {
                            $leads_month11 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month11 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                     else if ( strtoupper($get['month']) == 'DECEMBER' ) 
                     {
                        
                         if (  $get['leads']=='lead' ) {                             
                            $leads_month12 = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $custs_month12 = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                     }
                    
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                     //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                   
                    if ( $back=='1week' )
                    {
                          
                          
                        if (  $get['leads']=='lead' ) {    
                            $month_lead[] = $get['created'];
                            $arr_lead[] = $get['total_cust'];                                
                            $this->total_leads += $get['total_cust'];                                
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $month_cust[] = $get['created'];
                            $arr_cust[]  = $get['total_cust'];                                
                            $this->total_custs += $get['total_cust'];                                
                         }
                        
                     }
                    else 
                    {                       
                        if (  $get['leads']=='lead' ) {                             
                            $this->total_leads += $get['total_cust'];                                
                            $this->series_lead[$get['week']] = $get['total_cust'];
                         }
                         else if ( $get['leads']=='cust' ) 
                         {
                            $this->total_custs += $get['total_cust'];                                
                            $this->series_cust[$get['week']] = $get['total_cust'];
                         }
                    }
                 }
                 
                 
             }
           //echo 'xbar ='.$xAxis; 
        if ( $this->total_custs > 0 || $this->total_leads > 0 )
        {
           if ( $searchby == 'day' )
           {
               //foreach ( $this->lang_day_eng_full as  $value)            
                 // $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
                  $lead_column = $mon_lead.','.$tue_lead.','.$wed_lead.','.$thurs_lead.','.$fri_lead.','.$sat_lead.','.$sun_lead;
                  $cust_column = $mon_cust.','.$tue_cust.','.$wed_cust.','.$thurs_cust.','.$fri_cust.','.$sat_cust.','.$sun_cust;
           }
           else if ( $searchby == 'week' )
           {            
                $xAxis .= "'1-7','8-14','15-21','22-28','29+'";
                
                $lead_column = $total_leads1.','.$total_leads2.','.$total_leads3.','.$total_leads4.','.$total_leads5;
                $cust_column = $total_custs1.','.$total_custs2.','.$total_custs3.','.$total_custs4.','.$total_custs5;
               
           }
           else if ( $searchby == 'month')
           {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $lead_column = $leads_month1.','.$leads_month2.','.$leads_month3.','.$leads_month4.','.$leads_month5.','.$leads_month6.','.$leads_month7.','.$leads_month8.','.$leads_month9.','.$leads_month10.','.$leads_month11.','.$leads_month12;
               $cust_column = $custs_month1.','.$custs_month2.','.$custs_month3.','.$custs_month4.','.$custs_month5.','.$custs_month6.','.$custs_month7.','.$custs_month8.','.$custs_month9.','.$custs_month10.','.$custs_month11.','.$custs_month12;
           }
           else if ( $searchby == 'ago')
             {
               //echo 'back = '.$back;
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                   $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      
                      if ( sizeof($month_cust) > 0 )
                      {
                        foreach ( $month_cust  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                       
                         $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'"; 
                         $data  .= $data != ''?",$arr_lead[$m]":"$arr_lead[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
                   
                   $lead_column  = $data;
                   
                   $xAxis='';
                   $data = '';
                   
                   $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      
                      if ( sizeof($month_cust) > 0 )
                      {
                        foreach ( $month_cust  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                       
                         $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'"; 
                         $data  .= $data != ''?",$arr_cust[$m]":"$arr_cust[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
                   
                   
                   
                   $cust_column  = $data;
               }
               
               
               else 
               {                                                        
                    
                   $this->setArrangeSeriesCustomer_LeadtoPlotChart($interval=$back,'line');
                   $xAxis = $this->xAxis_cust;
                   $lead_column  = $this->deta_lead; 
                   $cust_column  = $this->deta_cust;     
                   
                   /*$xAxis = $this->xAxis;
                   $data  = $this->deta;     
                   */
               }       
           
             }
        }
           //echo 'lead = '.$lead_column;
           //unset($this->deta_lead);
           //unset($this->deta_lead);
           //unset($this->deta_cust);
           unset($this->series_lead);
           unset($this->series_cust);
           unset($arr_cust);
           unset($arr_lead);
           
           $api = "<script>
$(function () {
    $('#chart_proportion').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: null
        },
        subtitle: {
            text: 'Customers = $this->total_custs' 
        },
        xAxis: {
            categories: [
                $xAxis
            ],
            labels: {
                rotation: 270,
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: ' Customers'
            }
        },
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> Customers ',
                        fontSize:15
                    }
                }
            },
        tooltip: {
            headerFormat: '<span >{point.key}</span><table>',
            pointFormat: '<tr><td >{series.name}: </td>' +
                '<td ><b>{point.y:.1f} person</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true,
            shadow:true
        },
        plotOptions: {
            column: {
                pointPadding: 0,
                borderWidth: 0
            }
        },
        series: [{
            /*name: 'Leads',
            color:'#00CD00',
             dataLabels: {
                enabled: true,
                rotation: 0,
                color: '#000000',
                align: 'center',
                x: 4,
                y: -1,
                style: {
                    fontSize: '8px',
                    fontFamily: 'Verdana, sans-serif'
                    
                }
            },
            data: [$lead_column]

        }, {*/
            name: 'Customers',
             color:'#FF69B4',
              dataLabels: {
                enabled: true,
                rotation: 0,
                color: '#000000',
                align: 'center',
                x: 4,
                y: -1,
                style: {
                    fontSize: '8px',
                    fontFamily: 'Verdana, sans-serif'
                   
                }
            },
            data: [$cust_column]

        }]
    });
});
		</script>";
           
           //$s  = $ax[0]['detail']; 
           return $api;
       
       }
       public function api_CustomerData_Ages()
       {            
           
           $this->longtime = $longday;  
           $total1 = 0;
           $total2 = 0;
           $total3 = 0;
           $total4 = 0;
           $total5 = 0;
           $total6 = 0;
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
          // echo $this->ages;
         if ( $this->total > 0 )
         {
           $query = mysql_query($this->ages);             
             while(	$get = mysql_fetch_array($query)	)
             {
                 if ( $get['ages'] >= 18 && $get['ages'] <= 24 )
                     $total1 +=  $get['total_cust'];
                 else if ( $get['ages'] >= 25 && $get['ages'] <= 34 )
                     $total2 +=  $get['total_cust'];
                 else if ( $get['ages'] >= 35 && $get['ages'] <= 44 )
                     $total3 +=  $get['total_cust'];
                 else if ( $get['ages'] >= 45 && $get['ages'] <= 54 )
                     $total4 +=  $get['total_cust'];
                 else if ( $get['ages'] >= 55 && $get['ages'] <= 64 )
                    $total5 +=  $get['total_cust'];
                 else if ( $get['ages'] >= 65 )
                    $total6 +=  $get['total_cust'];
                 //$total += $get['total_cust'];
             }
          
           $age = "['18-24',".$total1."],['25-34',".$total2."],['35-44',".$total3."],['45-54',".$total4."],['55-64',".$total5."],['65+',".$total6."]";
         }
           $api = "<script type='text/javascript'>
                    $(function () {
                    
                      $('#chart_age').highcharts({
        chart: {
            type: 'column',
            plotBackgroundColor: '#FFFFFF',
            plotShadow: true
        },
        title: {
            text: null
        },
        subtitle: {
            text: null
        },
        
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> Range Age Customers ',
                        fontSize:15
                    }
                }
            },
        xAxis: {
            type: 'category',
            labels: {
                rotation: 270,
                color: 'red',
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Customers'
            }
            
        },
        legend: {
            enabled: false
        },
        tooltip: {
            shadow:true,
            pointFormat: 'Total Customers: <b>{point.y:.0f} person</b>'
        },
        series: [{
             color: '#008B00',
             pointWidth: 30,
            name: 'Population',
            data: [$age],
            dataLabels: {
                enabled: true,
                rotation: 0,
                color: '#ffffff',
                align: 'center',
                x: 1,
                y: 25,
                style: {
                    fontSize: '10px',
                    fontFamily: 'Verdana, sans-serif'                   
                }
            }
        }]
    });
});
		</script>";
           return $api;
               
       }
       public function api_CustomerData_Nationality()
       {
                 
             $xAxis = '';
             $data  = '';
             $this->xAxis = '';
             $this->deta  = '';
           if ( $this->total > 0 )
           {
             $query = mysql_query($this->nationality);             
             while(	$get = mysql_fetch_array($query)	)
             {
                 
                 $data .= 
     !empty($data)?",['".$get['nt_nationality']."',".$get['total_cust']."]":"['".$get['nt_nationality']."',".$get['total_cust']."]";         
                 $cust .= !empty($cust)?',['.$get['total_cust'].']':'['.$get['total_cust'].']';
             }
           }
           $api = "
<script>
$(function () {
    
    Highcharts.setOptions({
     colors: ['#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263',      '#6AF9C4']
    });
    var chart;

    $(document).ready(function() {
     
        chart = new Highcharts.Chart({

            chart: {

                renderTo: 'chart_location',

                plotBackgroundColor: null,

                plotBorderWidth: null,

                plotShadow: false

            },

            title: {

                text: null

            },
            exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname <br> Locations Customers ',
                        fontSize:15
                    }
                }
            },
            tooltip: {

                formatter: function() {

                    return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';

                }

            },

            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        distance: -50,
                        format: ' {point.percentage:.1f} % ',
                        style: {
                        fontWeight: 'normal',
                        color: '#000000',
                        textShadow: '0px 1px 2px black'
                    }
                    },
                    showInLegend: true
                }
            },
            series: [{

                type: 'pie',

                name: 'Browser share',

                data: [

                    $data

                ]

            }]

        });

    });
});

</script>"; 
           return $api;
               
       }
       public function api_Quatations($project,$longday,$searchby,$ago,$back)
       {
            
           
           $this->longtime = !empty($longday)?$longday:'';
           $query = mysql_query($this->Quatations($searchby,$ago,$back));             
           $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
           if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
         else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
         else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
         else if ( $searchby == 'ago') 
             $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
           $mon = 0;
           $tue = 0;
           $wed = 0;
           $thurs = 0;
           $fri  = 0;
           $sat = 0;
           $sun = 0;
           $total = 0;
           if ( $searchby == 'week' )
           {
           $week1=0;
           $week2=0;
           $week3=0;
           $week4=0;
           $week5=0;
           }
           if ( $searchby == 'month' )  
           {
             $mon1 = 0;
             $mon2 = 0;
             $mon3 = 0;
             $mon4 = 0;
             $mon5 = 0;
             $mon6 = 0;
             $mon7 = 0;
             $mon8 = 0;
             $mon9 = 0;
             $mon10 = 0;
             $mon11 = 0;
             $mon12 = 0;
           }
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
           $this->total = 0;
           while(	$get = mysql_fetch_array($query)	)
             {

             if ( $searchby == 'day' )
                 {
                     //$this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                     if ( !empty($longday) )
                     {
                     $data .= !empty($data)?','.$get['total_qt']:$get['total_qt'];
                     $xAxis .= !empty($xAxis)?",'".$get['day'].".(".$get['dats'].")'": 
                     "'".$get['day'].".(".$get['dats'].")'"; 
                     }
                     else 
                     {
                         if ( strtoupper($get['dayname']) == 'MONDAY' ) $mon = $get['total_qt'];
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) $tue = $get['total_qt'];
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) $wed = $get['total_qt'];
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) $thurs = $get['total_qt'];
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' ) $fri = $get['total_qt'];
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) $sat = $get['total_qt'];
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) $sun = $get['total_qt'];   
                     }
                 }
                 else if ( $searchby == 'week')
                 {
                     //$this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     if ( $get['weekno'] == 1 ) $week1  = $get['total_qt']; 
                     else if ( $get['weekno'] == 2 ) $week2  = $get['total_qt']; 
                     else if ( $get['weekno'] == 3 ) $week3  = $get['total_qt']; 
                     else if ( $get['weekno'] == 4 ) $week4  = $get['total_qt']; 
                     else if ( $get['weekno'] == 5 ) $week5  = $get['total_qt']; 
                     /*$data  = !empty($data)?','.$get['total_qt']:$get['total_qt']; 
                    $xAxis .= !empty($xAxis)?",'".$get['week'].".(".$get['month'].$get['year'].")'":
                     "'".$get['week'].".(".$get['month'].$get['year'].")'";  
                     */
                 }
                 else if ( $searchby == 'month')
                 {
                     //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                     if ( $get[$searchby] == 1 ) $mon1 = $get['total_qt'];
                     else if ( $get[$searchby] == 2 )  $mon2 = $get['total_qt'];
                     else if ( $get[$searchby] == 3 )  $mon3 = $get['total_qt'];
                     else if ( $get[$searchby] == 4 )  $mon4 = $get['total_qt'];
                     else if ( $get[$searchby] == 5 )  $mon5 = $get['total_qt'];
                     else if ( $get[$searchby] == 6 )  $mon6 = $get['total_qt'];
                     else if ( $get[$searchby] == 7 )  $mon7 = $get['total_qt'];
                     else if ( $get[$searchby] == 8 )  $mon8 = $get['total_qt'];
                     else if ( $get[$searchby] == 9 )  $mon9 = $get['total_qt'];
                     else if ( $get[$searchby] == 10 )  $mon10 = $get['total_qt'];
                     else if ( $get[$searchby] == 11 ) $mon11 =  $get['total_qt'];
                     else if ( $get[$searchby] == 12 ) $mon12 =  $get['total_qt'];
                         
                     /*$data  = !empty($data)?','.$get['total_qt']:$get['total_qt']; 
                     $xAxis = !empty($xAxis)?',"'.$get['month']."'":"'".$get['month']."'";  
                     */
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                     //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                    if ( $back=='1week' )
                    {                        
                        $months[] = $get['created'];
                        $custs[]  = $get['total_qt'];                        
                     }
                    else 
                    {                       
                        $this->series_column[$get['week']] = $get['total_qt'];
                    }
                 }
                 $this->total += $get['total_qt'];
             }
             
           if ( $this->total > 0 )
           {
             if ( $searchby == 'day' )
             {
                $j=0;
                foreach ( $this->lang_day_eng_abbreviation as  $value) 
                {
                  
                    $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($this->dats[$j]))."'":"'".date('d-M-y',strtotime($this->dats[$j]))."'";   
                    ++$j;
                }
               $data = $sun.','.$mon.','.$tue.','.$wed.','.$thurs.','.$fri.','.$sat;
             }
             else if ( $searchby == 'week' )
             {
               $xAxis .= "'1-7','8-14','15-21','22-28','29+'";
                
               $data = $week1.','.$week2.','.$week3.','.$week4.','.$week5;
             }
             else if ( $searchby == 'month')
             {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $data = $mon1.','.$mon2.','.$mon3.','.$mon4.','.$mon5.','.$mon6.','.$mon7.','.$mon8.','.$mon9.','.$mon10.','.$mon11.','.$mon12;
             }
             else if ( $searchby == 'ago')
             {
               //echo 'back = '.$back;
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                       $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      //echo $month.',';\
                      if ( sizeof($month) > 0 )
                      {
                        foreach ( $months  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data != ''?",$custs[$m]":"$custs[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
               }
               
               
               else 
               {                                                        
                    
                   $this->setArrangeSeriestoPlotChart($interval=$back,'line');
                   $xAxis = $this->xAxis;
                   $data  = $this->deta;     
               }       
           
             }
           }
            //unset($this->deta);
            //unset($this->xAxis);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
           
           //echo $this->cmd;
            $api = "<script>$(function () {
    $('#chart_quatation').highcharts({
         chart: {
            type: 'line',
            zoomType: 'x'
        },
        title: {
            text: null          
        },
        subtitle: {
            text: null,
            x: -20 //center
        },
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> Quotations ',
                        fontSize:15
                    }
                }
            },
        tooltip: {
            pointFormat: 'Count Quotation : <b>{point.y}</b><br/>',
            shadow:true,
            crosshairs: true,
            valueSuffix: ''
        },
        
        xAxis: {
            categories: [$xAxis],
            labels:{
            rotation:270
            }
        },
        
        yAxis: {
            floor:0,
            alternateGridColor: '#ffffff',
            title: {
                text: 'Quotation '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{y}'
                },
                marker: {
                    states: {
                        hover: {
                            fillColor: 'white',
                            lineColor: 'red',
                            radiusPlus: 5,
                            lineWidthPlus: 4
                        }
                    }
                },
                states: {
                    hover: {
                        lineWidthPlus: 5
                    }
                }
            }
        },
         legend: {
            enabled: false
        },
        series: [{
            data: [$data],
            lineWidth: 4,
            marker: {
                lineWidth: 4,
                radius: 6
            }
        }]
    });
});</script>";
             return $api;
       }
       public function api_Bookings($projectid,$longday,$searchby,$ago,$back)
       {
            
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
           $this->total = 0;
           $this->longtime = !empty($longday)?$longday:'';
           $query = mysql_query($this->Bookings($searchby,$ago,$back));         
           $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
           if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
         else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
         else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
         else if ( $searchby == 'ago') 
             $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
           $mon = 0;
           $tue = 0;
           $wed = 0;
           $thurs = 0;
           $fri  = 0;
           $sat = 0;
           $sun = 0;
           $total = 0;
           if ( $searchby == 'week' )
           {
             $week1=0;
             $week2=0;
             $week3=0;
             $week4=0;
             $week5=0;
           }
           if ( $searchby == 'month' )
           {
             $mon1 = 0;
             $mon2 = 0;
             $mon3 = 0;
             $mon4 = 0;
             $mon5 = 0;
             $mon6 = 0;
             $mon7 = 0;
             $mon8 = 0;
             $mon9 = 0;
             $mon10 = 0;
             $mon11 = 0;
             $mon12 = 0;   
           }
           
           while( $get = mysql_fetch_array($query) )
             {

             if ( $searchby == 'day' )
                 {
                    //$this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                    if ( !empty($longday) )
                     {
                     $data .= !empty($data)?','.$get['total_booking']:$get['total_booking'];
                     $xAxis .= !empty($xAxis)?",'".$get['day'].".(".$get['dats'].")'": 
                     "'".$get['day'].".(".$get['dats'].")'"; 
                     }
                     else 
                     {
                         if ( strtoupper($get['dayname']) == 'MONDAY' ) $mon = $get['total_booking'];
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) $tue = $get['total_booking'];
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) $wed = $get['total_booking'];
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) $thurs = $get['total_booking'];
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' ) $fri = $get['total_booking'];
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) $sat = $get['total_booking'];
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) $sun = $get['total_booking'];   
                     }
                 }
                 else if ( $searchby == 'week')
                 {
                     //$this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     if ( $get['weekno'] == 1 ) $week1  = $get['total_booking']; 
                     else if ( $get['weekno'] == 2 ) $week2  = $get['total_booking']; 
                     else if ( $get['weekno'] == 3 ) $week3  = $get['total_booking']; 
                     else if ( $get['weekno'] == 4 ) $week4  = $get['total_booking']; 
                     else if ( $get['weekno'] == 5 ) $week5  = $get['total_booking']; 
                     /*$data  = !empty($data)?','.$get['total_booking']:$get['total_booking']; 
                    $xAxis .= !empty($xAxis)?",'".$get['week'].".(".$get['month'].$get['year'].")'":
                     "'".$get['week'].".(".$get['month'].$get['year'].")'";  
                     */
                 }
                 else if ( $searchby == 'month')
                 {
                   //  $this->topic_label = "Year = ".(intval(date("Y"))-1);
                     if ( $get[$searchby] == 1 ) $mon1 = $get['total_booking'];
                     else if ( $get[$searchby] == 2 )  $mon2 = $get['total_booking'];
                     else if ( $get[$searchby] == 3 )  $mon3 = $get['total_booking'];
                     else if ( $get[$searchby] == 4 )  $mon4 = $get['total_booking'];
                     else if ( $get[$searchby] == 5 )  $mon5 = $get['total_booking'];
                     else if ( $get[$searchby] == 6 )  $mon6 = $get['total_booking'];
                     else if ( $get[$searchby] == 7 )  $mon7 = $get['total_booking'];
                     else if ( $get[$searchby] == 8 )  $mon8 = $get['total_booking'];
                     else if ( $get[$searchby] == 9 )  $mon9 = $get['total_booking'];
                     else if ( $get[$searchby] == 10 )  $mon10 = $get['total_booking'];
                     else if ( $get[$searchby] == 11 ) $mon11 = $get['total_booking'];
                     else if ( $get[$searchby] == 12 ) $mon12 = $get['total_booking'];
                     /*$data  = !empty($data)?','.$get['total_booking']:$get['total_booking']; 
                     $xAxis = !empty($xAxis)?',"'.$get['month']."'":"'".$get['month']."'";  
                     */
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                     $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                    if ( $back=='1week' )
                    {
                        $months[] = $get['created'];
                        $custs[]  = $get['total_booking'];                        
                     }
                    else 
                    {                       
                        $this->series_column[$get['week']] = $get['total_booking'];
                    }
                 }
                 
                 $this->total += $get['total_booking'];
             }
         if ( $this->total > 0 )
         {
             if ( $searchby == 'day' && empty($longday) )
             {
               $j=0;
                foreach ( $this->lang_day_eng_abbreviation as  $value) 
                {
                  
                  $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($this->dats[$j]))."'":"'".date('d-M-y',strtotime($this->dats[$j]))."'";   
                    ++$j;
                }
               $data = $sun.','.$mon.','.$tue.','.$wed.','.$thurs.','.$fri.','.$sat;
             }
             else if ( $searchby == 'week' )
             {
               $xAxis .= "'1-7','8-14','15-21','22-28','29+'";                
               $data = $week1.','.$week2.','.$week3.','.$week4.','.$week5;
             }
             else if ( $searchby == 'month')
             {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $data = $mon1.','.$mon2.','.$mon3.','.$mon4.','.$mon5.','.$mon6.','.$mon7.','.$mon8.','.$mon9.','.$mon10.','.$mon11.','.$mon12;
            }
            else if ( $searchby == 'ago')
             {
               //echo 'back = '.$back;
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                       $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      //echo $month.',';\
                      if ( sizeof($months) > 0 )
                      {
                        foreach ( $months  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data != ''?",$custs[$m]":"$custs[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
               }
               
               
               else 
               {                                                        
                    
                   $this->setArrangeSeriestoPlotChart($interval=$back,'line');
                   $xAxis = $this->xAxis;
                   $data  = $this->deta;     
               }       
           
             }
         }
            //unset($this->deta);
            //unset($this->xAxis);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
           //echo $this->cmd;
           //echo $data;
            $api = "<script>$(function () {
    $('#chart_booking').highcharts({
         chart: {
            type: 'line',
            zoomType: 'x'
        },
        title: {
            text: null,
        
        },
        subtitle: {
            text: null,
            x: -20 //center
        },
        
        tooltip: {
            pointFormat: 'Count Bookings : <b>{point.y}</b><br/>',
            shadow:true,
            crosshairs: true,
            valueSuffix: ' Booking'
        },
        subtitle: {
            text: null,
            x: -20
        },
        xAxis: {
            categories: [$xAxis], 
            labels: {
                rotation: 270,
            }
        },
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> BOOKING ',
                        fontSize:15
                    }
                }
            },
        yAxis: {
            floor:0,
            alternateGridColor: '#ffffff',
            title: {
                text: 'Count Bills '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        plotOptions: {
            series: {
               dataLabels: {
                    enabled: true,
                    format: '{y}'
                },
               marker: {
                    states: {
                        hover: {
                            fillColor: 'white',
                            lineColor: 'red',
                            radiusPlus: 5,
                            lineWidthPlus: 4
                        }
                    }
                },
                states: {
                    hover: {
                        lineWidthPlus: 5
                    }
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            data: [$data],
            lineWidth: 4,
            marker: {
                lineWidth: 4,
                radius: 6
            }
        }]
    });
});</script>";
             return $api;
                //AND `bk_project_id` = '".$projectid."'"
           
        }
      public function api_Receipts($projectid,$billstatus,$longday='',$searchby,$ago,$back)
        {
           
           
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
           $this->total = 0;
           $this->longtime = !empty($longday)?$longday:'';        
          
           $query = mysql_query($this->Receipts($searchby,$billstatus,$ago,$back));    
           //$p=new Termago();
           //$curweek = $p->getTermCurweek();
           //$this->startdate = $p->weekstart;
          
           $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
          
        
        if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
         else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
         else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
         else if ( $searchby == 'ago') 
             $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
           $mon = 0;
           $tue = 0;
           $wed = 0;
           $thurs = 0;
           $fri  = 0;
           $sat = 0;
           $sun = 0;
           $total = 0;
           
           if ( $searchby == 'week' )
           {
             $week1=0;
             $week2=0;
             $week3=0;
             $week4=0;
             $week5=0;
           }
           if ( $searchby == 'month' )
           {
             $mon1 = 0;
             $mon2 = 0;
             $mon3 = 0;
             $mon4 = 0;
             $mon5 = 0;
             $mon6 = 0;
             $mon7 = 0;
             $mon8 = 0;
             $mon9 = 0;
             $mon10 = 0;
             $mon11 = 0;
             $mon12 = 0;   
           }
           
           while( $get = mysql_fetch_array($query) )
             {

             if ( $searchby == 'day' )
                 {
                     //$this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                     if ( !empty($longday) )
                     {
                     $data .= !empty($data)?','.$get['total_rct']:$get['total_rct'];
                     $xAxis .= !empty($xAxis)?",'".$get['day'].".(".$get['dats'].")'": 
                     "'".$get['day'].".(".$get['dats'].")'"; 
                     }
                     else 
                     {
                         if ( strtoupper($get['dayname']) == 'MONDAY' ) $mon = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) $tue = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) $wed = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) $thurs = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' ) $fri = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) $sat = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) $sun = $get['total_rct'];   
                     }
                 }
                 else if ( $searchby == 'week')
                 {
                     //$this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     if ( $get['weekno'] == 1 ) $week1  = $get['total_rct']; 
                     else if ( $get['weekno'] == 2 ) $week2  = $get['total_rct']; 
                     else if ( $get['weekno'] == 3 ) $week3  = $get['total_rct']; 
                     else if ( $get['weekno'] == 4 ) $week4  = $get['total_rct']; 
                     else if ( $get['weekno'] == 5 ) $week5  = $get['total_rct']; 
                     
                    /*$data  = !empty($data)?','.$get['total_rct']:$get['total_rct']; 
                    $xAxis .= !empty($xAxis)?",'".$get['week'].".(".$get['month'].$get['year'].")'":
                     "'".$get['week'].".(".$get['month'].$get['year'].")'";  
                     */

                 }
                 else if ( $searchby == 'month')
                 {
                     //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                     if ( $get[$searchby] == 1 ) $mon1 = $get['total_rct'];
                     else if ( $get[$searchby] == 2 )  $mon2 = $get['total_rct'];
                     else if ( $get[$searchby] == 3 )  $mon3 = $get['total_rct'];
                     else if ( $get[$searchby] == 4 )  $mon4 = $get['total_rct'];
                     else if ( $get[$searchby] == 5 )  $mon5 = $get['total_rct'];
                     else if ( $get[$searchby] == 6 )  $mon6 = $get['total_rct'];
                     else if ( $get[$searchby] == 7 )  $mon7 = $get['total_rct'];
                     else if ( $get[$searchby] == 8 )  $mon8 = $get['total_rct'];
                     else if ( $get[$searchby] == 9 )  $mon9 = $get['total_rct'];
                     else if ( $get[$searchby] == 10 )  $mon10 = $get['total_rct'];
                     else if ( $get[$searchby] == 11 ) $mon11 = $get['total_rct'];
                     else if ( $get[$searchby] == 12 ) $mon12 = $get['total_rct'];
                     /*$data  = !empty($data)?','.$get['total_rct']:$get['total_rct']; 
                     $xAxis = !empty($xAxis)?',"'.$get['month']."'":"'".$get['month']."'";  
                     */
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                   // $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                     if ( $back=='1week' )
                     {
                        $months[] = $get['created'];
                        $custs[]  = $get['total_rct'];                        
                     }
                     else 
                     {                       
                        $this->series_column[$get['week']] = $get['total_rct'];
                     }
                 }
                 $this->total += $get['total_rct'];
             }
          
          if ( $this->total > 0 )
          {
             if ( $searchby == 'day' && empty($longday) )
             {
               $j=0;
                foreach ( $this->lang_day_eng_abbreviation as  $value) 
                {
                  
                    $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($this->dats[$j]))."'":"'".date('d-M-y',strtotime($this->dats[$j]))."'";   
                    ++$j;
                }
               $data = $sun.','.$mon.','.$tue.','.$wed.','.$thurs.','.$fri.','.$sat;
             }
             else if ( $searchby == 'week' )
             {
               $xAxis .= "'1-7','8-14','15-21','22-28','29+'";                
               $data = $week1.','.$week2.','.$week3.','.$week4.','.$week5;
             }
             else if ( $searchby == 'month')
             {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $data = $mon1.','.$mon2.','.$mon3.','.$mon4.','.$mon5.','.$mon6.','.$mon7.','.$mon8.','.$mon9.','.$mon10.','.$mon11.','.$mon12;
             }
             else if ( $searchby == 'ago')
             {
               //echo 'back = '.$back;
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                       $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      //echo $month.',';\
                      if ( sizeof($months) > 0 )
                      {
                        foreach ( $months  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                         
                         $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'"; 
                         $data  .= $data != ''?",$custs[$m]":"$custs[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
               }
               
               
               else 
               {                                                        
                    
                   $this->setArrangeSeriestoPlotChart($interval=$back,'line');
                   $xAxis = $this->xAxis;
                   $data  = $this->deta;     
               }       
           
             }
          }
            //unset($this->deta);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
            //echo $this->cmd;
            $tab='1week';
            $api = "<script>$(function () {
    $('#chart_receipt').highcharts({
         chart: {
            type: 'line',
            zoomType: 'x'
        },
        title: {
            text: null,          
        },
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> Receipt ',
                        fontSize:15
                    }
                }
            },
        tooltip: {
            pointFormat: 'Count Receipt : <b>{point.y}</b><br/>',
            shadow:true,
            crosshairs: true,
            valueSuffix: ' receipt'
        },
        subtitle: {
            text: null,
            x: -20
        },
        xAxis: {
            categories: [$xAxis],
            labels:{rotation:270,}
        },
        
        yAxis: {
            floor:0,
            alternateGridColor: '#ffffff',
            title: {
                text: 'Count Bills '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{y}'
                },
                marker: {
                    states: {
                        hover: {
                            fillColor: 'white',
                            lineColor: 'red',
                            radiusPlus: 5,
                            lineWidthPlus: 4
                        }
                    }
                },
                states: {
                    hover: {
                        lineWidthPlus: 5
                    }
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            data: [$data],
            lineWidth: 4,
            marker: {
                lineWidth: 4,
                radius: 6
            }
        }]
    });
});</script>";
             
    //echo $this->cmd;
    //Table Detail
    //rc_date_receipt,
    //rc_receipt_code,
    //rc_payfor_type,
    //rc_money_amount,
    //pers_fname,
    //pers_lname,
    //pers_tel,
    //pers_email
       
    $query = mysql_query($this->detail);    
          //<td>".$get['building_name']."</td>
         //<td>.$get['un_name']."</td>
          //<th>Building</th>
         //<th>Unit Number</th>
          
    $ck1 = $billstatus == ''?'checked':'';
    $ck2 = $billstatus == 'print'?'checked':'';      
    $ck3 = $billstatus == 'wait%'?'checked':'';  
          
    $active1 = $back == '1week'?"class='active'":"";
    $active2 = $back == '1month'?"class='active'":"";
    $active3 = $back == '3month'?"class='active'":"";
    $active4 = $searchby == 'day'?"class='active'":"";
    $active5 = $searchby == 'week'?"class='active'":"";
    $active6 = $searchby == 'month'?"class='active'":"";
        
    echo 
       "<div id='content'>
       
        
         
            <div class='innerAll text-center'>
              <ul class='nav nav-pills strong display-block-inline'>		
                <li  $active1 >
                <a href='#' onclick='TimeReceipt_Ago(1)'>
                7 Day Ago </a></li>
				<li $active2 >
                <a href='#' onclick='TimeReceipt_Ago(2)'>1 Month Ago </a></li>
				<li $active3 >
                <a href='#' onclick='TimeReceipt_Ago(3)'>3 Month Ago </a></li>			
                <li $active4 ><a href='#' onclick='Receipt_Chart(1)'> Last Week</a></li>
                <li $active5 ><a href='#' onclick='Receipt_Chart(2)'>Last Month</a></li>
                <li $active6 ><a href='#' onclick='Receipt_Chart(3)'>Last Year</a></li>
			  </ul>
		    </div>
            <div align='center'>
       <input type='radio' name = 'rdbudget' id='rdbudget' value='' $ck1 >All
       <input type='radio' name = 'rdbudget' id='rdbudget' value='' $ck2 >Printing
       <input type='radio' name = 'rdbudget' id='rdbudget' value='Wait%' $ck3 >Waiting
       </div>
   
 <div class='widget widget-inverse'>
		
        <div class='widget-head'>
			<h4 class='heading'>Receipt</h4><span style='float:right;right:10px;color:#ffffff'> $chart->topic_label</span>
		</div>
		
		<div class='widget-body'>		            	       
            <div id='chart_receipt' style='min-width: 300px; max-width:100%;height: 350px; margin:3px 0 auto'></div>  
		
                        <table class='dynamicTable tableTools table table-striped checkboxs'> 
	        <thead>
	          <tr>
	             <th>dd-mm-yyy</th>
                 <th>Receipt Number</th>
                 <th>Type</th>
                 <th>Customer</th>                 
                 <th>Mobile</th>   
                 <th>SMS</th>   
                 <th>Amount</th></tr>
	            </thead>	
	          <tbody>	";

           while( $get = mysql_fetch_array($query) )
             {
           ?>
              <tr class='gradeC'>
			    <td class='text-center'><?php echo $get['created']?></td>			
			    <td><?php echo $get['rc_receipt_code']?></td>
                <td><?php echo $get['rc_payfor_type']?></td>
                <td><?php echo $get['pers_fname']."  ". $get['pers_lname']?></td>
                <td><?php echo $get['pers_mobile']?></td>                
                <td><a href='#' onclick="sendSMS('<?php echo $get['pers_mobile']?>')">SMS</a></td>                
                <td><?php echo $get['amount']?></td>
                </tr>
            <?php
             }
				
	echo "</tbody></table> </div>							
                                

    
   
 </div>";

        
        
        
        
        
        
        
        
        
          return $api;
          
             
            
          
                //AND `bk_project_id` = '".$projectid."'"          
        }
       public function api_SentMessageBirtday_Cutomers($dob,$searchby)
        {                      
          
            
        //    echo 'by:'.$searchby;
            $query =  $this->MessageToCustom($dob,$searchby);       
            //echo $query;
            $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
            $query = mysql_query($query);              
            
            $active1 = '';
            $active2 = '';
            $active3 = '';
            if ( $searchby == 'today' ) {      $this->topic_label = date("d-m-Y");
                                         $active1 = "class='active'";
                                        }
            else if ( $searchby == 'week' ) {  $this->topic_label = $this->startdate; 
                                          $active2 = "class='active'";     
                                            }
            else if ( $searchby == 'month' ) { $this->topic_label = date('M-Y'); 
                                          $active3 = "class='active'";
                                             }
             
            
           
            echo "<div id='content'>   
                 
                       <div class='innerAll text-center'>
                            <ul class='nav nav-pills strong display-block-inline'>		
                                <li $active1 >
                         <a href='#' onclick='Message_Report(1)'>Today</a></li>
                         <li $active2 >
                         <a href='#' onclick='Message_Report(2)'>This Week </a></li>
                         <li $active3 >
                         <a href='#' onclick='Message_Report(3)'>This Month</a></li>
			                   </ul>              
		                </div>
	          
    
	<div class='widget widget-inverse'>
		
        <div class='widget-head'>
			<h4 class='heading'>Happy Birthday Date: ( $this->topic_label )</h4><span style='float:right;right:10px;color:#ffffff'>      Total ".mysql_num_rows($query)." Customers</span>
		</div>
		
		<div class='widget-body'>		            	       
           <table class='dynamicTable tableTools table table-striped checkboxs'>
	               <thead>
		             <tr>			           
			           <th>Names - Surname</th>                       
			          
                       <th>Email</th>			           
			           <th>Mobile</th>			           
                       <th>Birthday</th>
                       <th>Nationality</th>
                        <th>Send SMS</th>
                       </tr>
	               </thead>   <tbody>";
            while(	$get = mysql_fetch_array($query)	)
            {
            ?>
                <tr>
                    <td><?php echo $get['pers_fname'].'  '.$get['pers_lname']?></td>
                    
                    <td><?php echo $get['pers_email']?></td>
                    <td><?php echo $get['pers_mobile']?></td>
                    <td><?php echo $get['hbd']?></td>
                    <td><?php echo $get['nt_nationality']?></td>
                    <td><a href="#" onclick="sendSMS('<?php echo $get['pers_fname'].'  '.$get['pers_lname']?>','<?php echo $get['pers_mobile']?>')"><img src='report/icon/sms.png'></a></td>
</tr>
            <?php
            }
           echo "</table>

		</div>
	</div>";
           
                
          
           //AND `bk_project_id` = '".$projectid."'"
           
       }
       
       public function api_Top_OffenQuatations_Cutomers($projectid,$longday,$top,$searchby,$ago,$back)
       {                          
               
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
           $this->total = 0;
           $this->longtime = $longday;
           $query = mysql_query($this->topUnits($searchby,$top,$ago,$back));             
           $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
           
           /*if ( $searchby == 'day' )     $this->topic_label = $this->dats[0].'-'.$this->dats[6];
           else if ( $searchby == 'week' )  $this->topic_label = date('m-Y',strtotime($date . " - 1 month")); 
           else if ( $searchby == 'month' ) $this->topic_label = "Year = ".(intval(date("Y"))-1);
             */
         if ( $searchby == 'day' )
            $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
         else if ( $searchby == 'week')
            $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
         else if ( $searchby == 'month')
             $this->topic_label = "Year = ".(intval(date("Y"))-1);     
         else if ( $searchby == 'ago') 
            $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');     
             
              $tab = '1week';
            $active1 = $back == '1week'?"class='active'":"";
            $active2 = $back == '1month'?"class='active'":"";
            $active3 = $back == '3month'?"class='active'":"";
            $active4 = $searchby == 'day'?"class='active'":"";
            $active5 = $searchby == 'week'?"class='active'":"";
            $active6 = $searchby == 'month'?"class='active'":"";
    echo "<div id='content'>   
            
                 <div class='innerAll text-center'>
                    <ul class='nav nav-pills strong display-block-inline'>		
                         <li $active1 >
                         <a href='#' onclick='TimeTopUnit_Ago(1)'>7 Day Ago </a></li>
				         <li $active2 >
                         <a href='#' onclick='TimeTopUnit_Ago(2)'>1 Month Ago </a></li>
				         <li $active3 >
                         <a href='#' onclick='TimeTopUnit_Ago(3)'>3 Month Ago </a></li>			
                         <li $active4 >
                         <a href='#' onclick='Top_Quatations(1)'> Last Week</a></li>
                         <li $active5 >
                         <a href='#' onclick='Top_Quatations(2)'>Last Month</a></li>
                         <li $active6 >
                         <a href='#' onclick='Top_Quatations(3)'>Last Year</a></li>
			</ul>
		</div>
     
		<div class='widget widget-inverse'>
		
        <div class='widget-head'>
			<h4 class='heading'>Receipt</h4><span style='float:right;right:10px;color:#ffffff'> $chart->topic_label</span>
		</div>
		
		<div class='widget-body'>		            	       
 
            <div id='chart_topunit' style='min-width: 300px; max-width:100%;height: 350px; margin:3px 0 auto'></div>  
		
		
 <table class='dynamicTable tableTools table table-striped checkboxs'>
	               <thead>
		             <tr>			           
			           <th>Building</th>
			           <th>Floor</th>
			           <th>Unit Type</th>
			           <th>Unit Number</th>
			           <th>Area SQM.</th>                       
                       <th>Direction</th>
                       <th>View</th>
                       <th>Total</th>
                       </tr>
	               </thead>   <tbody>";
            
            while(	$get = mysql_fetch_array($query)	)
             {                 
                 //$s .=   $get['Total_Quatations'].",";
                
                 echo "                                
		         <tr class='gradeX'>			
			      <td>".$get['building_name']."</td>
			      <td>".$get['fl_name']."</td>
			      <td>".$get['unit_type_name']."</td>
			      <td class='center'>".$get['un_name']."</td>
                  <td>".$get['unit_type_area_sqm']."</td>                
                  <td>".$get['un_direction']."</td>
                  <td>".$get['un_view']."</td>
                  <td>".$get['total_qt']."</td></tr> ";
               
               if ( $searchby == 'day' )
                 {
                   //  $this->topic_label = date('d-M-Y',strtotime($this->dats[0])).' To '.date('d-M-Y',strtotime($this->dats[6]));
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];
                 }
                 else if ( $searchby == 'week')
                 {
                   //  $this->topic_label = date('M-Y',strtotime($date . " - 1 month")); 
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];                   
                 }
                 else if ( $searchby == 'month')
                 {
                     //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];
                     
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                    //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                    $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                    $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];                   
                 }
                 $this->total += $get['total_qt'];
             }
             
             
              //unset($this->deta);            
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
          
           echo "</tbody></table>
           
           </div>
	</div>
    ";
       
     
           $api = "<script>$(function () {
               $('#chart_topunit').highcharts({
                chart: {
                  type: 'line',
                  zoomType: 'x'
                },
                title: {
                   text: null,
        
                },
                
                subtitle: {
                   text: 'Total Booking',
                   x: -20 //center
                },
                exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> TOP 5 UNIT ',
                        fontSize:15
                    }
                }
            },
                tooltip: {
                   pointFormat: 'Count Bookings : <b>{point.y}</b><br/>',
                   shadow:true,
                   crosshairs: true,
                   valueSuffix: ' Quotation'
                },
                subtitle: {
                   text: 'Top 5 Unit = $total Quotations',
                   x: -20
                },
                xAxis: {
                   categories: [$xAxis],
                   labels: {
                
                rotation: 270,
            }
                },        
                yAxis: {
                   floor:0,
                   alternateGridColor: '#ffffff',
                   title: {
                       text: 'Quotation '
                   },
                   plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                   }]
                },
                plotOptions: {
                   series: {
                      dataLabels: {
                         enabled: true,
                         format: '{y}'
                      },
                      marker: {
                       states: {
                          hover: {
                            fillColor: 'white',
                            lineColor: 'red',
                            radiusPlus: 5,
                            lineWidthPlus: 4
                          }
                      }
                },
                states: {
                    hover: {
                        lineWidthPlus: 5
                    }
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            data: [$data],
            lineWidth: 4,
            marker: {
                lineWidth: 4,
                radius: 6
            }
        }]
    });
});</script>";
return $api;
           
       }
      
       
       public function api_Receipts_Dashboard($projectid,$billstatus,$longday='',$searchby,$ago,$back)
        {
             
           $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';
           $this->total = 0;
           $this->longtime = !empty($longday)?$longday:'';        
           $query = mysql_query($this->Receipts($searchby,$billstatus,$ago,$back));    
           
          
           $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
          
           $mon = 0;
           $tue = 0;
           $wed = 0;
           $thurs = 0;
           $fri  = 0;
           $sat = 0;
           $sun = 0;
           $total = 0;
           
           if ( $searchby == 'week' )
           {
             $week1=0;
             $week2=0;
             $week3=0;
             $week4=0;
             $week5=0;
           }
           if ( $searchby == 'month' )
           {
             $mon1 = 0;
             $mon2 = 0;
             $mon3 = 0;
             $mon4 = 0;
             $mon5 = 0;
             $mon6 = 0;
             $mon7 = 0;
             $mon8 = 0;
             $mon9 = 0;
             $mon10 = 0;
             $mon11 = 0;
             $mon12 = 0;   
           }
           
           while( $get = mysql_fetch_array($query) )
             {

             if ( $searchby == 'day' )
                 {
                    // $this->topic_label = $this->dats[0].'-'.$this->dats[6];
                     if ( !empty($longday) )
                     {
                     $data .= !empty($data)?','.$get['total_rct']:$get['total_rct'];
                     $xAxis .= !empty($xAxis)?",'".$get['day'].".(".$get['dats'].")'": 
                     "'".$get['day'].".(".$get['dats'].")'"; 
                     }
                     else 
                     {
                         if ( strtoupper($get['dayname']) == 'MONDAY' ) $mon = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'TUESDAY' ) $tue = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'WEDNESDAY' ) $wed = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'THURSDAY' ) $thurs = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'FRIDAY' ) $fri = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'SATURDAY' ) $sat = $get['total_rct'];
                         else if ( strtoupper($get['dayname']) == 'SUNDAY' ) $sun = $get['total_rct'];   
                     }
                 }
                 else if ( $searchby == 'week')
                 {
                   //  $this->topic_label = date('m-Y',strtotime($date . " - 1 month")); 
                     if ( $get['weekno'] == 1 ) $week1  = $get['total_rct']; 
                     else if ( $get['weekno'] == 2 ) $week2  = $get['total_rct']; 
                     else if ( $get['weekno'] == 3 ) $week3  = $get['total_rct']; 
                     else if ( $get['weekno'] == 4 ) $week4  = $get['total_rct']; 
                     else if ( $get['weekno'] == 5 ) $week5  = $get['total_rct']; 
                     
                    /*$data  = !empty($data)?','.$get['total_rct']:$get['total_rct']; 
                    $xAxis .= !empty($xAxis)?",'".$get['week'].".(".$get['month'].$get['year'].")'":
                     "'".$get['week'].".(".$get['month'].$get['year'].")'";  
                     */

                 }
                 else if ( $searchby == 'month')
                 {
                    // $this->topic_label = "Year = ".(intval(date("Y"))-1);
                     if ( $get[$searchby] == 1 ) $mon1 = $get['total_rct'];
                     else if ( $get[$searchby] == 2 )  $mon2 = $get['total_rct'];
                     else if ( $get[$searchby] == 3 )  $mon3 = $get['total_rct'];
                     else if ( $get[$searchby] == 4 )  $mon4 = $get['total_rct'];
                     else if ( $get[$searchby] == 5 )  $mon5 = $get['total_rct'];
                     else if ( $get[$searchby] == 6 )  $mon6 = $get['total_rct'];
                     else if ( $get[$searchby] == 7 )  $mon7 = $get['total_rct'];
                     else if ( $get[$searchby] == 8 )  $mon8 = $get['total_rct'];
                     else if ( $get[$searchby] == 9 )  $mon9 = $get['total_rct'];
                     else if ( $get[$searchby] == 10 )  $mon10 = $get['total_rct'];
                     else if ( $get[$searchby] == 11 ) $mon11 = $get['total_rct'];
                     else if ( $get[$searchby] == 12 ) $mon12 = $get['total_rct'];
                     /*$data  = !empty($data)?','.$get['total_rct']:$get['total_rct']; 
                     $xAxis = !empty($xAxis)?',"'.$get['month']."'":"'".$get['month']."'";  
                     */
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                   //  $this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                     if ( $back=='1week' )
                    {
                        $months[] = $get['created'];
                        $custs[]  = $get['total_rct'];                        
                     }
                    else 
                    {                       
                        $this->series_column[$get['week']] = $get['total_rct'];
                    }
                 }
                 $this->total += $get['total_rct'];
             }
           
          if ( $this->total > 0 )
          {
            if ( $searchby == 'day' && empty($longday) )
             {
               $j=0;
                foreach ( $this->lang_day_eng_abbreviation as  $value) 
                {
                  
                 $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($this->dats[$j]))."'":"'".date('d-M-y',strtotime($this->dats[$j]))."'";   
                    ++$j;
                }
               $data = $sun.','.$mon.','.$tue.','.$wed.','.$thurs.','.$fri.','.$sat;
             }
             else if ( $searchby == 'week' )
             {
               $xAxis .= "'1-7','8-14','15-21','22-28','29+'";
                
               $data = $week1.','.$week2.','.$week3.','.$week4.','.$week5;
             }
             else if ( $searchby == 'month')
             {
               foreach ( $this->lang_month_eng_abbreviation as  $value) {             
               $xAxis .= !empty($xAxis)?",'".$value."'":"'".$value."'";         
               }
               $data = $mon1.','.$mon2.','.$mon3.','.$mon4.','.$mon5.','.$mon6.','.$mon7.','.$mon8.','.$mon9.','.$mon10.','.$mon11.','.$mon12;
             }
             else if ( $searchby == 'ago')
             {
               //echo 'back = '.$back;
               if ( $back=='1week' )
               {                   
                   $xAxis='';
                   $data = '';
                   
                       $k=0;
                   foreach ($this->dats as $value  )
                   {
                      $m=0;$flag=false;
                      //echo $month.',';\
                      if ( sizeof($months) > 0 )
                      {
                        foreach ( $months  as $month )
                        {
                         
                         if ( $value == $month )  
                         {
                            $flag=true;break;
                         }
                          ++$m;                             
                        }                      
                      }
                      if ( $flag ) {
                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data != ''?",$custs[$m]":"$custs[$m]";
                      }
                      else 
                      {                         
                         $xAxis .= !empty($xAxis)?",'".date('d-M-y',strtotime($value))."'":"'".date('d-M-y',strtotime($value))."'"; 
                         $data  .= $data !=''?",0":"0";                                                
                      }
                       
                        ++$k;
                   }
               }
               
               
               else 
               {                                                        
                    
                   $this->setArrangeSeriestoPlotChart($interval=$back,'line');
                   $xAxis = $this->xAxis;
                   $data  = $this->deta;     
               }       
           
             }
          }
            //unset($this->deta);
            //unset($this->xAxis);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
            //echo $this->cmd;
            
            $api = "<script>$(function () {
    $('#chart_receipt').highcharts({
         chart: {
            type: 'line',
            zoomType: 'x'
        },
        title: {
            text: null,          
        },
        exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname <br> RECEIPT ',
                        fontSize:15
                    }
                }
            },
        tooltip: {
            pointFormat: 'Count Receipt : <b>{point.y}</b><br/>',
            shadow:true,
            crosshairs: true,
            valueSuffix: ' receipt'
        },
        subtitle: {
            text: null,
            x: -20
        },
        xAxis: {
            categories: [$xAxis],
            labels: {
                rotation: 270,
            }
        },
        
        yAxis: {
            floor:0,
            alternateGridColor: '#ffffff',
            title: {
                text: 'Count Bills '
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{y}'
                },
                marker: {
                    states: {
                        hover: {
                            fillColor: 'white',
                            lineColor: 'red',
                            radiusPlus: 5,
                            lineWidthPlus: 4
                        }
                    }
                },
                states: {
                    hover: {
                        lineWidthPlus: 5
                    }
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            data: [$data],
            lineWidth: 4,
            marker: {
                lineWidth: 4,
                radius: 6
            }
        }]
    });
});</script>";
             
    //Table Detail
    //rc_date_receipt,
    //rc_receipt_code,
    //rc_payfor_type,
    //rc_money_amount,
    //pers_fname,
    //pers_lname,
    //pers_tel,
    //pers_email
                      
    $query = mysql_query($this->detail);    
          //<td>".$get['building_name']."</td>
         //<td>.$get['un_name']."</td>
          //<th>Building</th>
         //<th>Unit Number</th>
    /*echo 
       "<div id='content'>
    
    <div class='heading-buttons bg-white border-bottom innerAll'>
	    <select name='cbbudget' id='cbbudget'  aria-controls='DataTables_Table_0' class='form-control'>
              <option value=''>--All billing--</option>
              <option value='wait%'>Waiting</option>
              <option value=''>Printing</option>
           </select>  
	
<div class='innerAll spacing-x2'>
<div class='row'>
	<div class='col-md-2'>

		<div class='widget'>

			<h4 class='innerAll half bg-inverse margin-none'>Search</h4>
			<ul class='list-group list-group-1 margin-none borders-none'>
				<li class='list-group-item animated fadeInUp'>
                <a href='#' onclick='TimeReceipt_Ago(1)'>
                <span class='badge pull-right badge-default hidden-md'>7</span> 7 Day Ago </a></li>
				<li class='list-group-item animated fadeInUp'>
                <a href='#' onclick='TimeReceipt_Ago(2)'><span class='badge pull-right badge-default hidden-md'>1</span> 1 Month Ago </a></li>
				<li class='list-group-item animated fadeInUp'>
                <a href='#' onclick='TimeReceipt_Ago(3)'><span class='badge pull-right badge-default hidden-md'>3</span> 3 Month Ago </a></li>			
                <li class='list-group-item border-bottom-none animated fadeInUp'><a href='#' onclick='Receipt_Chart(1)'> Last Week</a></li>
                <li class='list-group-item border-bottom-none animated fadeInUp'><a href='#' onclick='Receipt_Chart(2)'>Last Month</a></li>
                <li class='list-group-item border-bottom-none animated fadeInUp'><a href='#' onclick='Receipt_Chart(3)'>Last Year</a></li>
			</ul>
		</div>
		<div class='widget'>			
			<form role='form'>
				<div class='innerAll half'>
					<div class='form-group'>
				  		<div class='input-group'>
							<span class='input-group-addon'>
                            <i class='fa fa-question-circle text-faded'></i></span>
				        	<input class='form-control' id='dob_from' name='dob_from' type='date'  
                            required='required'  title='Please enter your date of birth' 
                                   aria-controls='DataTables_Table_0' class='form-control'/>
                            <input class='form-control' id='dob_to' name='dob_to' type='date'  
                            required='required'  title='Please enter your date of birth' 
                            class='form-control'/>
						</div>
					</div>
					
				</div>
			  	<div class='text-center border-top innerTB half'>
                <a href='support_questions.html?lang=en' 
                class='btn btn-primary'><i class='fa fa-fw fa-search'></i> Search</a></div>
			</form>

		</div>
	</div>
	<div class='col-md-9'>
		<div class='widget'>
			<div class='widget widget-inverse'>
	
		<div class='widget-head'>
			<h4 class='heading'>RECEIPTS DATE   :  $this->topic_label</h4>
		</div>
		<div class='widget-body'>		
            <div id='chart_receipt' style='min-width: 300px; max-width:610px;height: 400px; margin:3px 0 auto'></div>  
		</div>

						
			<div class='innerAll half border-bottom tickets'>
				<ul class='media-list'>
					<li class='media'>
					    <div class='media-body'>					    	
					    	<small>Detail Receipted </small>					    	
					    	<div class='clearfix'></div>

					    						 <div class='media'>							   
                                                 
							    <div class='media-body' > 
                                <table class='dynamicTable tableTools table table-striped checkboxs'> 
	        <thead>
	          <tr>
	             <th>dd-mm-yyy</th>
                 <th>Receipt Number</th>
                 <th>Type</th>
                 <th>Customer</th>
                 <th>Contact</th>                 
                 <th>Amount</th></tr>
	            </thead>	
	          <tbody>	";
           while( $get = mysql_fetch_array($query) )
             {
         
              echo "<tr class='gradeC'>
			    <td class='text-center'>".$get['created']."</td>			
			    <td>".$get['rc_receipt_code']."</td>
                <td>".$get['rc_payfor_type']."</td>
                <td>".$get['pers_fname']."  ". $get['pers_lname']."</td>
                <td>".$get['pers_mobile']."</td>                
                <td>".$get['rc_money_amount']."</td>
                </tr>";
             }
				
	echo "</tbody></table> </div>							
                                
												 </div>
					</li>
				</ul>
				
			</div>
			
			
			
			
		</div>

	</div>

</div>

    
   
 </div>";

        
      */  
        
        
        
        
        
        
        
          return $api;
          
             
            
          
                //AND `bk_project_id` = '".$projectid."'"          
        }
       
        public function api_topunit_Dashboard($projectid,$longday,$top,$searchby,$ago,$back)
       {
           
            
            $xAxis = '';
           $data  = '';
           $this->xAxis = '';
           $this->deta  = '';    
           $this->total =0;   
           $this->longtime = $longday;
           $query = mysql_query($this->topUnits($searchby,$top,$ago,$back));             
           $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
           
           /*if ( $searchby == 'day' )     $this->topic_label = $this->dats[0].'-'.$this->dats[6];
           else if ( $searchby == 'week' )  $this->topic_label = date('m-Y',strtotime($date . " - 1 month")); 
           else if ( $searchby == 'month' ) $this->topic_label = "Year = ".(intval(date("Y"))-1);
           */
            //echo "sql = ".$query;
            while(	$get = mysql_fetch_array($query)	)
             {                 
               
                if ( $searchby == 'day' )
                 {
                    // $this->topic_label = $this->dats[0].'-'.$this->dats[6];
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];
                 }
                 else if ( $searchby == 'week')
                 {
                    // $this->topic_label = date('m-Y',strtotime($date . " - 1 month")); 
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];
                     
                    /*$data  = !empty($data)?','.$get['total_rct']:$get['total_rct']; 
                    $xAxis .= !empty($xAxis)?",'".$get['week'].".(".$get['month'].$get['year'].")'":
                     "'".$get['week'].".(".$get['month'].$get['year'].")'";  
                     */

                 }
                 else if ( $searchby == 'month')
                 {
                     //$this->topic_label = "Year = ".(intval(date("Y"))-1);
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];
                     /*$data  = !empty($data)?','.$get['total_rct']:$get['total_rct']; 
                     $xAxis = !empty($xAxis)?',"'.$get['month']."'":"'".$get['month']."'";  
                     */
                 }
                 else if ( $searchby == 'ago') 
                 {                                                              
                      //$this->topic_label = date('d-M-Y',strtotime($this->startdate)).' To '.date('d-M-Y');
                     $xAxis .=  !empty($xAxis)?",'".$get['un_name']."'":"'".$get['un_name']."'";
                     $data  .=  !empty($data)?','.$get['total_qt']:$get['total_qt'];
                 }
                 $this->total += $get['total_qt'];
             }
             
            // echo $this->cmd;
            //unset($this->deta);
            //unset($this->xAxis);
            unset($this->series_column);
            unset($months);
            unset($custs);
            unset($this->dats);
           $api = "<script>$(function () {
               $('#chart_topunit').highcharts({
                chart: {
                  type: 'line',
                  zoomType: 'x'
                },
                title: {
                   text: null,
        
                },
                subtitle: {
                   text: 'Total Booking',
                   x: -20 //center
                },
                exporting:{
                chartOptions:{
                    title: {
                        text:'SILALAI '
                    },
                    subtitle: {
                        text:'$pjname  <br> TOP 5 UNITs ',
                        fontSize:15
                    }
                }
            },
                tooltip: {
                   pointFormat: 'Count Bookings : <b>{point.y}</b><br/>',
                   shadow:true,
                   crosshairs: true,
                   valueSuffix: ' Quotation'
                },
                subtitle: {
                   text: 'Top 5 Unit = $total Quotations',
                   x: -20
                },
                xAxis: {
                   categories: [$xAxis],
                   labels: {
                     rotation: 270,
                   }
                },        
                yAxis: {
                   floor:0,
                   alternateGridColor: '#ffffff',
                   title: {
                       text: 'Quotation '
                   },
                   plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                   }]
                },
                plotOptions: {
                   series: {
                      dataLabels: {
                         enabled: true,
                         format: '{y}'
                      },
                      marker: {
                       states: {
                          hover: {
                            fillColor: 'white',
                            lineColor: 'red',
                            radiusPlus: 5,
                            lineWidthPlus: 4
                          }
                      }
                },
                states: {
                    hover: {
                        lineWidthPlus: 5
                    }
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            data: [$data],
            lineWidth: 4,
            marker: {
                lineWidth: 4,
                radius: 6
            }
        }]
    });
});</script>";
return $api;
           
       }
       
       public function api_HbdDashboard($dob,$searchby)
        {                      
          
            
        //    echo 'by:'.$searchby;
            $query =  $this->MessageToCustom($dob,$searchby);       
            echo $query;
            $this->dats= array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->startdate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->startdate))) );
            $query = mysql_query($query);              
            
            /*if ( $searchby == 'today' )      $this->topic_label = date("d-M-y");
            else if ( $searchby == 'week' )  $this->topic_label = date('m-Y',strtotime($date . " - 1 month")); 
            else if ( $searchby == 'month' ) $this->topic_label = "Year = ".(intval(date("Y"))-1);
              */ 
            /*$st = "
 
 <table class='dynamicTable tableTools table table-striped checkboxs'  id='dvhbd' style='display:none'>
	               <thead>
		             <tr>			           
			           <th>Names</th>
			           <th>Surename</th>
			           <th>Email</th>
			           <th>Mobile</th>
			           <th>Tel</th>
                       <th>Birthday</th>
                       <th>Nationality</th></tr>
	               </thead>   <tbody>";
            while(	$get = mysql_fetch_array($query)	)
            {
                echo "<tr>
                    <td>".$get['pers_fname']."</td>
                    <td>".$get['pers_lname']."</td>
                    <td>".$get['pers_email']."</td>
                    <td>".$get['pers_mobile']."</td>
                    <td>".$get['pers_tel']."</td>
                    <td>".$get['pers_dob']."</td>
                    <td>".$get['nt_nationality']."</td></tr>";
            }
           echo "</table>";
           
           return $st;  
              */  
          
           //AND `bk_project_id` = '".$projectid."'"
           
       }
       
		
    }
  
?>
