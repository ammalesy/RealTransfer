<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Creditlog extends NZ_Controller {
    public function update($data, $cus) {
		date_default_timezone_set('Asia/Bangkok');
        $data = array(
            'cc_cus_id'  => $cus,
            'cc_holder'  => $data['pm_cr_holder'],
            'cc_number'  => $data['pm_cr_number'],
            'cc_bank'    => $data['pm_cr_bank'],
            'cc_type'    => $data['pm_cr_type'],
            'cc_expire'  => $data['pm_cr_expire']
        );
        
        $this->load->model('log_customer_credit');
        $detail = $this->log_customer_credit->on($cus);
        if(empty($detail->cc_number)) {
            $this->log_customer_credit->record($data);
        }else {
            $data['cc_last_update'] = date('Y-m-d H:i:s');
            $this->log_customer_credit->update($data, $detail->cc_id); 
        }
    }
}
?>