<?php if ( ! defined('BASEPATH') ) exit('No direct script access allowed');

class Booking extends NZ_Controller {
	/**
	* $title_page  :: text on your browser tabbar.
	*/
    var $title_page = 'Admin System';
    var $page_var = 'Booking';
    /**
	*
		*/
	function __construct()
    {
        parent::__construct();
    }
	public function index()
	{

		$this->view();

		// $data['script'] = "javascript: window.open('".BASE_URL."/quotation/view');";
		// $this->load->view('Quotation/redirect',$data);
	}
	public function view()
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_booking'] = $this->processFetchBooking($this->project_id_sel);
        
        $this->load->model('tb_receipt_temporary');
		
        $this->LoadView('Booking/booking',$data);
	}
	public function record($qid)
    {
		date_default_timezone_set('Asia/Bangkok');
		$quoCode = $qid;
		$cusid  = $this->input->post('cusid');
		$payDay  = $this->input->post('payDay');
	
		if ($cusid!=0 && !empty($cusid)) {
            $this->load->database();
            $this->db->trans_begin();
            $this->pdb->trans_begin();
            
            $this->load->model('tb_quotation');
            $quotationDetail = $this->tb_quotation->getDetail_by_id($quoCode);
            $Number = $quotationDetail->qt_unit_number_id;
            $Building = $quotationDetail->qt_buliding_id;
            
            $this->load->model('tb_price');
			$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
			$pr_asking_price = $getPrice->pr_asking_price;
            
            $pr_bottom_line	= floatval(str_replace(',', '', $getPrice->pr_bottom_line_for_internal));		
			$valueAllGift = 0;
            
            $this->load->model('tb_promotion');
            $getPromotion = $this->tb_promotion->fetchBySearchQuotation(implode(',', $this->input->post('pro')));
            foreach ($getPromotion as $promotion) {
                $valueAllGift += $promotion->pm_value;
            }
            
            $pr_asking_price1 = str_replace( ',', '', $pr_asking_price);
			$pricedisc = (float)intval($pr_asking_price1) -(float)$valueAllGift;
			if (strpos($this->get_user_permission()->pm_quotation,'3') === false && $pricedisc < $pr_bottom_line) {
			 	echo "<script> alert('Can not create booking, please remove some promotion');  history.back(); </script>";
                exit;
			}
            
            $this->load->model('tb_customer_project');
            if(empty($this->tb_customer_project->get_id_by_cus($cusid))) {
                $data = array(
                    'cp_cus_id' => $cusid,
                    'cp_project_id' => $this->project_id_sel
                );
                $this->tb_customer_project->record($data);
            }
            
            //$this->load->model('tb_project');
			//$get1 = $this->tb_project->get_detail_project_ignoreStatusActive($projectid);
            $unitnumberid = $this->input->post('unitnumberid'); 
			$buildingid = $this->input->post('buildingid');  
			$unitnumber = $this->input->post('unitnumber');
            $remark         = $this->input->post('Remark');
            
            $this->load->model('tb_unit_number');
            
            $unitDetail = $this->tb_unit_number->get_detail_unit_by_un_id($unitnumberid);
            if($unitDetail->un_status_room != 'Available') {
                alert_redirect('This room is unavailable.','/booking/view');
                exit;
            }
			
            try {
                $data_unit_number = array(
				    'un_status_room' => 'Booked'
                );
                $this->tb_unit_number->update_where($data_unit_number,"un_id = '".$unitnumberid."' AND un_name = '".$unitnumber."' AND un_build_id = '".$buildingid."' AND un_status_room = 'Available'");         
            } catch (Exception $e) {
                alert_redirect('This room is unavailable.','/booking/view');
                exit;
            }
            
			$projectid = $this->input->post('projectid');
			$Type  = $this->input->post('Type');
			$MoneyAmount  =	$this->input->post('unitreserv');
			$cardBank  =	'';
			$cardno   =	'';
			$cardDate   =	'';
			$OtherBy  =	'';

			//Muti paid waiting Booking fee
      
	        $bk_type_payment = '';
	        $bk_pay_crcard   = '';
	        $bk_pay_other    = '';              
	              
	       	if(!empty($Type))
	       	{
	         	foreach($Type as $checkbox):
		          	if ( trim($checkbox) == 'Cash' )   $bk_type_payment = 'yes';
		          	if ( trim($checkbox) == 'CrCard' ) $bk_pay_crcard = 'yes';
		          	if ( trim($checkbox) == 'Other' )  $bk_pay_other  = 'yes';              
	         	endforeach;
	       	}
            $receiptID         =    implode(',', $this->input->post('receiptID'));
	        $bk_cash_amount    =	$this->input->post('Cashamount');
	        $bk_crcard_bank    =	$this->input->post('CardBank');
	        $BankName          =	$this->input->post('BankName');
	        $bk_credit_type_credit    =	$this->input->post('CardType');
	        $bk_credit_approve_code    =	$this->input->post('ApproveCode');
	        $bk_crcard_no      =	$this->input->post('Cardno');
	        $expiremonth_ = $this->input->post('expiremonth');
	        $expireyear_ = $this->input->post('expireyear');
	        
	        
	        $bk_crcard_amount  =	$this->input->post('Cardamount');
	        $bk_crcard_fname   =	$this->input->post('CardHolder');
	        $bk_other_by       =	$this->input->post('OtherBy');
	        $bk_other_amount   =	$this->input->post('Otheramount');
            $pm_check_number   =    $this->input->post('CheckNo');
            $pm_check_date     =    $this->input->post('CheckDate');
            $pm_check_bank     =    $this->input->post('CheckBank');

			$today = date("Y-m-d H:i:s"); 
		
			$this->load->model('tb_booking');
			$newid= $this->tb_booking->get_new_booking_id($projectid);
			$tmp = strlen($newid);
			$tmpID = '';
			for ($i=$tmp; $i < 5 ; $i++) { 
				$tmpID .= '0';
			}
			$tmptmp = strlen($projectid);
			$tmpIDP = '';
			for ($i=$tmptmp; $i < 2 ; $i++) { 
				$tmpIDP .= '0';
			}
			$dateQuo = date("ymd"); 
			
			$newbid ='B'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid; 
			
			$sale = $this->user_id;
		
			$time = strtotime($today);
			$contract_date = date("Y-m-d", strtotime("+2week", $time));	

			$data_booking = array(
				'bk_booking_code' => $newbid,
				'bk_quotation_code' => $quoCode,
				'bk_leads_id' => $cusid,
				'bk_project_id' => $projectid,
				'bk_money_amount' => $MoneyAmount,
				'bk_date_booking' => $today,
				'bk_contract_date' => $contract_date,
				'bk_pay_day' => $payDay,
                'bk_remark' => $remark,
				'bk_staff_id' => $sale
			);
			$this->tb_booking->record($data_booking);
			
			
			$data_quotation = array(
				'qt_status' => 'off'
			);
			$this->tb_quotation->update($data_quotation,$quoCode);

			$this->load->model('tb_contract_promotion');
			foreach ($this->input->post('pro') as $key => $value) {
				$data_promotion = array(
					'cp_booking_code' => $newbid,
					'cp_promotion_id' => $value
				);
				$this->tb_contract_promotion->record($data_promotion);
			}
		      
            //////////////////////////////////////////////////////////
            $this->load->model('tb_receipt_temporary');
            $newid = $this->tb_receipt_temporary->get_next_id();
			$tmp = strlen($newid);
			$tmpID = '';
			for ($i=$tmp; $i < 5 ; $i++) {
				$tmpID .= '0';
			}
			$newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid;

			$data_receipt = array(
				'rc_code' => $newrcv,
                'rc_refer_form' => $receiptID,
				'rc_customer_id' => $cusid,
				'rc_payfor' => 'Booking Fee',
				'rc_booking_code' => $newbid,
				'rc_total_amount' => $MoneyAmount,
				'rc_staff_temporary' => $sale,
                'rc_temporary_date' => date('Y-m-d H:i:s'),
                'rc_un_name' => $unitnumber
			);
			$this->tb_receipt_temporary->record($data_receipt);

            if(!empty($receiptID)) {
                $this->load->model('tb_receipt_offical');
                $update = array('rc_status'=>'off');
                foreach(explode(',', $receiptID) as $receipt) {
                    $this->tb_receipt_offical->update($update, $receipt);
                }
            }
            
			$data_room = array(
				'rs_unit_number' => $unitnumberid,
				'rs_cus_id' => $cusid,
				'rs_status' => 'Booking',
				'rs_staff_id' => $sale
			);
			$this->load->model('tb_room_status');
			$this->tb_room_status->record($data_room);
            
			$this->load->model('tb_payment');
			$this->load->model('tb_bank');
	        if($bk_type_payment == 'yes') {
	            $data_payment = array(
	                'pm_temp_code' => $newrcv,
	                'pm_date' => $today,
	                'pm_type' => 'Cash',
	                'pm_amount' => $bk_cash_amount
	            );
	            $this->tb_payment->record($data_payment);
	        }
	        if($bk_pay_crcard == 'yes') {
                $this->load->library('encrypt');
                $bankCount = 0;
                for($i=0;$i<count($bk_crcard_amount);$i++) {
                    $bk_crcard_date = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";
                    
                    if($bk_crcard_bank[$i] == 0) {
                        $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
                        echo $b_id;
                        if(empty($b_id)) {
                            $b_id = $this->tb_bank->get_next_id();
                            $data = array(
                                'b_id' => $b_id,
                                'bank_name_th' => $BankName[$bankCount]
                            );
                            $this->tb_bank->record($data);
                        }
                        $bankCount++;
                    }else $b_id = $bk_crcard_bank[$i];
                    
                    $data_payment = array(
	                    'pm_temp_code' => $newrcv,
                        'pm_date' => $today,
                        'pm_type' => 'Credit',
                        'pm_amount' => $bk_crcard_amount[$i],
                        'pm_cr_bank' => $b_id,
	                    'pm_cr_type' => $bk_credit_type_credit[$i],
                        'pm_cr_holder' => $bk_crcard_fname[$i],
                        'pm_cr_number' => $this->encrypt->encode($bk_crcard_no[$i]),
                        'pm_cr_approve_code' => $bk_credit_approve_code[$i],
                        'pm_cr_expire' => $bk_crcard_date
                    );
                    $this->tb_payment->record($data_payment);
                      
                    if($i == 0) {
                        $this->load->library('creditlog');
                        $this->creditlog->update($data_payment, $cusid);
                    }
                }
	        }
	        if($bk_pay_other == 'yes') {
	            if($bk_other_by == 'Check'){
	                $data_payment = array(
	                    'pm_temp_code' => $newrcv,
	                    'pm_date' => $today,
	                    'pm_type' => 'Check',
	                    'pm_amount' => $bk_other_amount,
	                    'pm_check_number' => $pm_check_number,
                        'pm_check_date' => $pm_check_date,
                        'pm_check_bank' => $pm_check_bank
	                );
	        	}else
	                $data_payment = array(
	                    'pm_temp_code' => $newrcv,
	                    'pm_date' => $today,
	                    'pm_type' => $bk_other_by,
	                    'pm_amount' => $bk_other_amount
	                );
	           $this->tb_payment->record($data_payment);
	        }
            
//            $getTempReceipt = $this->tb_receipt_temporary->get_by_booking($newbid);
            
            if ($this->pdb->trans_status() === FALSE || $this->db->trans_status() === FALSE){
                $this->db->trans_rollback();
                $this->pdb->trans_rollback();
                alert_redirect('Booking Fail','/booking/view');
            }
            else{
                $this->db->trans_commit();
                $this->pdb->trans_commit();
                echo "<script>  window.open('".BASE_DOMAIN."booking/report/$newbid/TH','_blank');";
                echo "window.open('".BASE_DOMAIN."receipt/report/th/$newrcv','_blank');";
                echo "window.location.href = '".BASE_DOMAIN."booking/view';</script>";
//                redirect('/booking/view');
            }
		}else{
			redirect("/booking/adding/".$quoCode);
		}
	}
	public function adding($qid)
    {
		
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
        if(strpos($this->get_user_permission()->pm_receipt,'4') !== false) {
            $this->load->model('tb_receipt_offical');
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled();
        }
		///
		$quoCode = $qid;
		$this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$leads  =	$getQuo->qt_leads_id;
		$Project = 	$getQuo->qt_project_id;
		$Building =$getQuo->qt_buliding_id;
		$Floor =$getQuo->qt_floor_id;
		$Number =$getQuo->qt_unit_number_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$dateQuo =$getQuo->qt_date;
		$promotiomQuo =$getQuo->qt_promotion;
		$TotalDownMonth = $getQuo->qt_total_months;
		$InstallmentFee = $getQuo->qt_avg_installment;
	
		$this->load->model('tb_project');
		$get = $this->tb_project->get_detail_project_ignoreStatusActive($Project);
		$databasenameQuo = $get->pj_datebase_name;
		$pj_name = $get->pj_name;

		$this->load->model('tb_customer');
		$getLeads = $this->tb_customer->get_detail_leads_withOut_oppotunityStage($leads);
		$leadsname 	= $getLeads->pers_fname.' '.$getLeads->pers_lname;
		$ld_mail 	= $getLeads->pers_email;
		$ld_tel		= $getLeads->pers_tel;
		
		$this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
		$unit_type_name 	= $getRoom->unit_type_name;
		$un_name 			= $getRoom->un_name;
		$unit_type_area_sqm 	= $getRoom->unit_type_area_sqm;
		$un_direction		= $getRoom->un_direction;
		$room_type_name		= $getRoom->room_type_name;
            
//        $unitDetail = $this->tb_unit_number->get_detail_unit_by_un_id($Number);
        if($getRoom->un_status_room != 'Available') {
            alert_redirect('This room is unavailable.','/booking/view');
            exit;
        }

		$this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_selling_sqm = $getPrice->pr_asking_sqm;
		$pr_asking_price = str_replace( ',', '', $getPrice->pr_asking_price);
		
		$today = $dateQuo;   
		$this->load->model('tb_promotion');
		$getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotiomQuo);
		$promotionID = $getPromotion->pm_id;
		$pm_name = $getPromotion->pm_name;
		$pm_value = $getPromotion->pm_value;

		
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value;
		
		$htmlGift = '';
		$list_gift = $this->tb_promotion->fetchGiftBySearchQuotation($promotiomQuo);
		foreach($list_gift as $getGift):
			$htmlGift .= '<tr>
    						<td ><font size="2"><b> Name : '.$getGift->pm_name.'</b></font></td>
    						<td ><font size="2"><b> Type : '.$getGift->pm_type.'</b></font></td>
    						<td ><font size="2"><b> Detail : '.$getGift->pm_detail.'</b></font></td>
  			</tr>';
		endforeach;
		
		$this->load->model('tb_payment_terms');
		$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($PaymentTerms);
		$Percent = $getPaymentTerms->pt_total_down_percent;
		
		$todayQuo = $dateQuo;   
		$CondoPrice = $pr_asking_price;
		
		
		//$TotalDownMonth = $getPaymentTerms->pt_down_payment_month;
		$BookingFee 	= $getPaymentTerms->pt_booking;
		$ContractFee 	= $getPaymentTerms->pt_contract;
		$MarketPrice 	= $getPaymentTerms->pt_ballon_market_installment;
		$BalloonMonth 	= $getPaymentTerms->pt_ballon_installment_month;
		$BalloonMonthText 	= $getPaymentTerms->pt_ballon_month;
		$TotalDownPayment = ($CondoPrice * $Percent) / 100;
		$TotalInstallmentFee = $InstallmentFee*$TotalDownMonth;
	  	$NormalMonth = $TotalDownMonth - $BalloonMonth;
		$Balloon 	= $getPaymentTerms->pt_ballon_payment;
		if ($Balloon ==0 )
         {
                $TotalNormalFee =  $TotalInstallmentFee;
                $TotalBalloonFee = 0;
               	$BalloonFee = 0;
                $InstallmentFee = $TotalInstallmentFee / $TotalDownMonth;
        }
        else
        {
                $TotalNormalFee = $NormalMonth * $MarketPrice;
                $TotalBalloonFee = $TotalInstallmentFee - $TotalNormalFee;
                $BalloonFee = $TotalBalloonFee / $BalloonMonth;
                $InstallmentFee = $MarketPrice;
        }

        $TotalDownPayment = ceil($TotalDownPayment);
		
	 	//$TotalNormalFee = ceil( $InstallmentFee) *  $NormalMonth;
       // $TotalBalloonFee = ceil( $BalloonFee) *  $BalloonMonth;
        //$TotalDownPayment =  $TotalNormalFee +  $TotalBalloonFee +  $BookingFee +  $ContractFee;
        //$TotalInstallmentFee = $TotalDownPayment - $BookingFee -  $ContractFee;
        //$InstallmentFee = ceil($InstallmentFee);
        $BalloonFee = ceil($BalloonFee);
        $TransferPayment = $CondoPrice - $TotalDownPayment;
        
        $this->load->model('tb_promotion');
        $pm_value = 0;
		$pm_value = $this->tb_promotion->getPromotionBySearchQuotation_Discount($promotionid);
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value - (float)$qtDetail->qt_total_down_payment;
//        $getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotionid);
		
		$allCredit = $this->tb_promotion->fetchAllCredit();
        
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
             
		///
        $this->load->model('tb_customer_personal_info');
        $this->load->model('log_customer_credit');
        $this->load->library('encrypt');
        
        $data['getPromotion'] = $getPromotion;
        $data['credit'] = $this->log_customer_credit->on($leads);
        $data['promotion'] = $promotiomQuo;
        $data['action'] = "/booking/record/".$qid;
        $data['head'] = "Booking";
        $data['list_leads'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['quoCode'] = $qid;
        $data['Balloon'] = $Balloon;
		$data['TotalDownMonth'] = $TotalDownMonth;//
		$data['InstallmentFee'] = $InstallmentFee;//
		$data['TotalInstallmentFee'] = $TotalInstallmentFee;//
		$data['TotalDownPayment'] = $TotalDownPayment;//
		$data['NormalMonth'] = $NormalMonth;//
		$data['BalloonMonth'] = $BalloonMonth;//
		$data['BalloonMonthText'] = $BalloonMonthText;//
		$data['BalloonFee'] = $BalloonFee;//
		$data['pj_name'] = $pj_name;
		$data['todayQuo'] = $todayQuo;
		$data['leads'] = $leads;
		$data['leadsname'] = $leadsname;
		$data['ld_tel'] = $ld_tel;
		$data['ld_mail'] = $ld_mail;
		$data['un_name'] = $un_name;
		$data['building_name'] = $building_name;
		$data['unit_type_name'] = $unit_type_name;
		$data['unit_type_area_sqm'] = $unit_type_area_sqm;//
		$data['room_type_name'] = $room_type_name;
		$data['pr_selling_sqm'] = $pr_selling_sqm;//
		$data['un_direction'] = $un_direction;
		$data['pr_asking_price'] = $pr_asking_price;//
		$data['CondoPrice'] = $CondoPrice;//
		$data['pm_value'] = $pm_value;
		$data['htmlGift'] = $htmlGift;
		$data['BookingFee'] = $BookingFee;//
		$data['ContractFee'] = $ContractFee;//
		$data['TransferPayment'] = $TransferPayment;//
		$data['Project'] = $Project;
		$data['Building'] = $Building;
		$data['un_name'] = $un_name;
		$data['Number'] = $Number;
		$data['mobile'] = $getLeads->pers_mobile;
		$data['project_database_sel'] = $this->project_database_sel;
        $data['allCredit'] = $allCredit;
		//$this->load->view('pay',$data);
		
       
        $this->LoadView('Booking/booking_adding',$data);
	}
	public function report($bk_booking_code,$language)
    {
		$this->load->library('currency');
		$this->load->library('dateformat');

		$bid = $bk_booking_code;
        
		$this->load->model('tb_booking');
		$getbooking = $this->tb_booking->getBookingInfo_byBookingCode($bid);
		$dateBooking = $getbooking->bk_date_booking;
		$pers_prefix = $getbooking->pers_prefix;
		$pers_fname = $getbooking->pers_fname;
		$pers_lname = $getbooking->pers_lname;
		$cid = $getbooking->cus_id;
		$quoCode = $getbooking->bk_quotation_code;
		$rid = $getbooking->rc_code;
        $dateContract = $getbooking->bk_contract_date;
        
        $this->load->model('tb_project');
        $getProject = $this->tb_project->get_detail_project_ignoreStatusActive($getbooking->bk_project_id);
        $projectImage = $getProject->pj_image;
        $getProject = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($getbooking->bk_project_id);
        $pj_name = $language=='TH'?$getProject->pj_name_th.' '.$getProject->pj_location_th:$getProject->pj_name.' '.$getProject->pj_location;
        
        
        $this->load->model('tb_user_personal_info');
        $user = $this->tb_user_personal_info->get_detail_personal($getbooking->bk_staff_id);
        $nameSale = $language=='TH'?$user->user_pers_fname." ".$user->user_pers_lname : $user->user_pers_fname_en." ".$user->user_pers_lname_en;

		$this->load->model('tb_customer');
		$getaddress = $this->tb_customer->get_small_detail_customer($cid);
		$getaddresscur = $this->tb_customer->get_small_detail_customer_cur($cid);
        $dateOfBirth = $getaddress->pers_dob;
        
        $yearOfBirth = intval(date('Y',strtotime($dateOfBirth)));
        $yearToday = intval(date('Y'));
        $age = !empty($dateOfBirth)?$yearToday - $yearOfBirth:'-';
        
        $this->load->model('tb_nationality');
        
        if($getaddress->pers_nationality == 171 && $language == 'TH'){
            $nationality = 'ไทย';
            $country = 'ไทย';
        }else {
            $nationalityDetail = $this->tb_nationality->get_nationality_by_id($getaddress->pers_nationality);
            $nationality = $nationalityDetail->nt_nationality;
            $country = $nationalityDetail->nt_nationality;
        }

		$this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$Number =$getQuo->qt_unit_number_id;
		$Floor =$getQuo->qt_floor_id;
		$Building =$getQuo->qt_buliding_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$TotalDownMonth = $getQuo->qt_total_months;
		$InstallmentFee = $getQuo->qt_avg_installment;
		$promotiomQuo =$getQuo->qt_promotion;
        $qt_booking_fee = $getQuo->qt_booking_fee;
        $qt_contract_fee = $getQuo->qt_contract_fee;
        $qt_unit_price = $getQuo->qt_unit_price;
        $qt_total_down_payment = $getQuo->qt_total_down_payment;
        $totalTransfer = $qt_unit_price - $qt_total_down_payment;
        $TotalInstallmentFee = $qt_total_down_payment - ($qt_booking_fee + $qt_contract_fee);
        $balloonDownMonth = $getQuo->qt_total_months;
        $maxLoop = 20;
        foreach($getQuo as $key=>$value) $Arr[$key] = $value;
        for($i=1;$i<($maxLoop+1);$i++) $balloon[$i] = $Arr['qt_months_installment'.$i];
        for($i=1;$i<($maxLoop+1);$i++) $balloonTemp[$i] = split("-", $balloon[$i]);
        for($i=1;$i<($maxLoop+1);$i++) $balloon[$i] = $balloonTemp[$i][0]." - ".$balloonTemp[$i][1];
        for($i=1;$i<($maxLoop+1);$i++) $balloonAmount[$i] = $Arr['qt_installment'.$i];
        for($i=1;$i<($maxLoop+1);$i++) $num[$i] = $balloonTemp[$i][1] - $balloonTemp[$i][0] + 1;
        for($i=1;$i<($maxLoop+1);$i++) $installmentBall[$i] = $balloonAmount[$i] * $num[$i];
        for($i=1;$i<($maxLoop+1);$i++) $lastBalloon[$i] = $balloonTemp[$i][0];
        $totalInstallmentBall = 0;
        for($i=1;$i<($maxLoop+1);$i++) $totalInstallmentBall += $installmentBall[$i];
        
        for($i=1;$i<($maxLoop+1);$i++)
        {
            if($language == 'TH'){
                if($balloon[$i] != ' - ' && ($num[$i]) != 1)
                    $balloonDetail .= '
                        <div>งวดที่ '.$balloon[$i].'</div>
                        <div align="right">ชำระงวดละ '.number_format($balloonAmount[$i] ,2).' บาท</div>
                    ';
                else
                {
                    $balloonDetail .=  '
                        <div>งวดที่ '.$lastBalloon[$i].'</div>
                        <div align="right">ชำระงวดละ '.number_format($balloonAmount[$i] ,2).' บาท</div>
                    ';
                    break;
                }
            }
            else{
                if($balloon[$i] != ' - ' && ($num[$i]) != 1)
                    $balloonDetail .= '
                        <div>Installment of '.$balloon[$i].'</div>
                        <div align="right">For baht '.number_format($balloonAmount[$i] ,2).' per month</div>
                    ';
                else
                {
                    $balloonDetail .=  '
                        <div>Installment of '.$lastBalloon[$i].'</div>
                        <div align="right">For baht '.number_format($balloonAmount[$i] ,2).' per month</div>
                    ';
                    break;
                }
            }
            
        }

		$this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$this->load->model('tb_floor');
		$getFloor = $this->tb_floor->get_detail_by_id($Floor);
		$Floorname 	= $getFloor->fl_name;
		
		$this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
		$un_name = $getRoom->un_name;
		$unit_type_name = $getRoom->unit_type_name;
		$unit_type_area_sqm = $getRoom->unit_type_area_sqm;

		$this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_asking_price = str_replace( ',', '', $getPrice->pr_asking_price);
		$pr_selling_sqm = $getPrice->pr_asking_sqm;

		$this->load->model('tb_payment_terms');
		$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($PaymentTerms);
		$BookingFee = $getPaymentTerms->pt_booking;
		$ContractFee = $getPaymentTerms->pt_contract;
		$percent = $getPaymentTerms->pt_total_down_percent;
		$Balloon = $getPaymentTerms->pt_ballon_payment;
		$BalloonMonthText = $getPaymentTerms->pt_ballon_month;
		$BalloonMonth = $getPaymentTerms->pt_ballon_installment_month;
		$MarketPrice = $getPaymentTerms->pt_ballon_market_installment;

		$this->load->model('tb_promotion');
		$getPromotion = $this->tb_promotion->getPromotionBySearchQuotation_statusON($promotiomQuo);
		$pm_name = $getPromotion->pm_name;
		$pm_value = $getPromotion->pm_value;

		$this->load->model('tb_payment');
		$payment_list = $this->tb_payment->get_by_temp_receipt($rid);


		$moneyCash= '';
		$moneyCrCard= '';
		$moneyOther= '';
		$flagCash= '';
		$flagCrCard= '';
		$flagOther= '';
		
        foreach($payment_list as $payment){
            if ($payment->pm_type == 'Cash') {
                $moneyCash= $payment->pm_amount;
                $flagCash ='checked="checked"';
            } else if ($payment->pm_type == 'Credit') {
                $moneyCrCard[] = $payment->pm_amount;
                $flagCrCard ='checked="checked"';
                if($language == 'TH')
                	$credit_bank[] = $payment->bank_name_th;
                else
                	$credit_bank[] = $payment->bank_name_en;
                $credit_no[] = $payment->pm_cr_number;
		        $credit_holder[] = $payment->pm_cr_holder;
                $crdate[] = $payment->pm_cr_expire;
                $credit_type[] = $payment->ct_name;
            } else {
                $moneyOther= $payment->pm_amount;
                $flagOther ='checked="checked"';
                $other_by = $payment->pm_type;
                $checkNumber = $payment->pm_check_number;
                $checkDate = date('d/m/Y',strtotime($payment->pm_check_date));
                $checkBankID = $payment->pm_check_bank;
                $checkBranch = '';
            }  
        }
        
        $this->load->model('tb_bank');
        $getCheckBank = $this->tb_bank->get_bank_from_id($checkBankID);
        
        if($language == 'TH'){
            if($getCheckBank->bank_name_th == 'Other')
                $checkBank = '';
            else
                $checkBank = $getCheckBank->bank_name_th;
            if($other_by == 'Check' || $other_by == ''){
                $htmlPaymentOther = '
                <table width="750px" border="0" cellspacing="5">
                    <tr>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="35px"><input name="input" type="checkbox" value="" '.$flagOther.' /></td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="60px">เช็คธนาคาร</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($checkBank)?$checkBank:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">สาขา</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center" width="80px">'.(!empty($checkBranch)?$checkBranch:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">เลขที่</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($checkNumber)?$checkNumber:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">ลงวันที่</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($checkDate)?$checkDate:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">จำนวน</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty(number_format($moneyOther,2))?number_format($moneyOther,2):'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">บาท</td>
                    </tr>
                </table>
                ';
            }else if($other_by == 'Transfer' || $other_by == 'Other'){
                $htmlPaymentOther = '
                <table border="0" cellspacing="5">
                    <tr>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="35px"><input name="input" type="checkbox" value="" '.$flagOther.' /></td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px" align="center">'.$other_by.'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">จำนวน</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="200px" align="center" align="center">'.(!empty($moneyOther)?number_format($moneyOther,2):"").'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">บาท</td>
                    </tr>
                </table>
                ';
            }
        }
        else
        {
            if($getCheckBank->bank_name_th == 'Other')
                $checkBank = '';
            else
                $checkBank = $getCheckBank->bank_name_th;
            if($other_by == 'Check' || $other_by == ''){
                $htmlPaymentOther = '
                <table width="750px" border="0" cellspacing="5">
                    <tr>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="35px"><input name="input" type="checkbox" value="" '.$flagOther.' /></td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="125px">Cheque of the Bank</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($checkBank)?$checkBank:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">Branch</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center" width="80px">'.(!empty($checkBranch)?$checkBranch:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="73px">Cheque No.</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($checkNumber)?$checkNumber:'').'</td>
                    </tr>
                </table>
                <table width="750px" border="0" cellspacing="5">
                    <tr>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="35px"></td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="59px">Dated on</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($checkDate)?$checkDate:'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="109px">for the amount of</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty(number_format($moneyOther,2))?number_format($moneyOther,2):'').'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">Baht</td>
                    </tr>
                </table>
                ';
            }else {
                $htmlPaymentOther = '
                <table width="750px" border="0" cellspacing="5">
                    <tr>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px"><input name="input" type="checkbox" value="" '.$flagOther.' /></td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="68px">Other type</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$other_by.'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="110px">for the amount of</td>
                        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($moneyOther)?number_format($moneyOther,2):"").'</td>
                        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">Baht</td>
                    </tr>
                </table>
                ';
            }
        }
        
        
        
		///////////////////////date////////////////////////////////
		if($dateContracttmp == "0000-00-00"){
			$dateContractpay = "0000-00-00";
			$dateDownpay =date('Y-m-d', strtotime($getProject->pj_start_downpayment. '+'.(36-$TotalDownMonth).'month'));
			$dateDownLast =date('Y-m-'.$getbooking->bk_pay_day, strtotime($dateDownpay. ' + '.($TotalDownMonth-24).' month'));
		}else{
			$dateContractpay =date('Y-m-d', strtotime("2018-03-30"/*. ' + '.$TotalDownMonth.' month'*/));
			$dateDownpay =date('Y-m-d', strtotime($getProject->pj_start_downpayment.'+'.(36-$TotalDownMonth).'month'));
			$dateDownLast =date('Y-m-'.$getbooking->bk_pay_day, strtotime($dateDownpay. ' + '.($TotalDownMonth-24).' month'));
		}

        $this->load->model('tb_contract_promotion');
        $getListPromotion = $this->tb_contract_promotion->get_promotion_by_bk_code($bid);
        $listPromotion = $getListPromotion->cp_promotion_id;
        
		$htmlGift = '';
        foreach($getListPromotion as $getGift):
            $htmlGift .= '							
                        <tr>
                            <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px" height="20px"><ul style="list-style-type:disc"> <li>   '.($language=='TH'?$getGift->pm_name:$getGift->pm_name_en).'</li></ul></td>
                        </tr>
                        <tr>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px" >&nbsp;</td>
                        </tr>
                        ';
        endforeach;

		if($language == 'TH'){
			//use
			
			 /////////////////////////////////////////////////////////////////////////////
			 
			if ($Balloon == 'no' )
            {
				$installmentFeeDetail =  '
				<div>&nbsp;รวม'.$pm_type[0].' <span class="under">'.$TotalDownMonth.'</span> งวด</div>
				<div>&nbsp;ชำระทุกวันที่ <span class="under">'.$getbooking->bk_pay_day.'</span> ของทุกเดือน</div>
				<div>&nbsp;เริ่มชำระงวดที่ 1 วันที่ <span class="under">'.$this->dateformat->thaiDate($dateDownpay).'</span></div>
				<!--<div>&nbsp;อัตราเดือนละ <span class="under">'.number_format($InstallmentFee,2).'</span> บาท</div>-->
				
				<!--(<u>'.$this->currency->bahtThai($InstallmentFee).'</u>)-->
				';

				$installmentFeeDetailMore = '
				<div>แบ่งชำระดังนี้</div>
				<div>งวดที่ 1 - '.$TotalDownMonth.'</div>
				<div align="right">ชำระงวดละ '.number_format($InstallmentFee,2).' บาท</div>
				';
            }
            else
            {
				$installmentFeeDetail =  '
				<div>&nbsp;รวม'.$pm_type[0].' <span class="under">'.$TotalDownMonth.'</span> งวด</div>
				<div>&nbsp;ชำระทุกวันที่ <span class="under">'.$getbooking->bk_pay_day.'</span> ของทุกเดือน</div>
				<div>&nbsp;เริ่มชำระงวดที่ 1 วันที่ <span class="under">'.$this->dateformat->thaiDate($dateDownpay).'</span></div>
                ';

         		$installmentFeeDetailMore = '
				<div>แบ่งชำระดังนี้</div>
				'.$balloonDetail.'
				';
            }
        }else{
        	if ($Balloon == 'no' )
        	{
				$installmentFeeDetail =  '
				<div>&nbsp;Total'.$pm_type[0].' <span class="under">'.$TotalDownMonth.'</span> installments</div>
				<div>&nbsp;Paid on every date of <span class="under">'.$getbooking->bk_pay_day.'</span> each month</div>
				<div>&nbsp;The first installment payment date. at <span class="under">'.date('d F Y',strtotime($dateDownpay)).'</span></div>
				
				';
                
				$installmentFeeDetailMore = '
				<div>Installment of 1 - '.$TotalDownMonth.'</div>
				<div align="right">For baht '.number_format($InstallmentFee,2).' per month</div>
				';
        	}
        	else
        	{
                $installmentFeeDetail =  '
				<div>&nbsp;Total'.$pm_type[0].' <span class="under">'.$TotalDownMonth.'</span> installments</div>
				<div>&nbsp;Paid on every date of <span class="under">'.$getbooking->bk_pay_day.'</span> each month</div>
				<div>&nbsp;The first installment payment date. at <span class="under">'.date('d F Y',strtotime($dateDownpay)).'</span></div>
				
				';
                
                $installmentFeeDetailMore = '
				'.$balloonDetail.'
				';
        	}
        }
        
        //list installment
        $htmlTotalDownMonth = '<table border="1" class="oneLine" width="260px">';
        $htmlTotalDownMonth2 = '<table border="1" class="oneLine" width="260px">';
        if ($Balloon == 'no' )
        {
            if($language == 'TH'){
                $halfTotalDownMonth=ceil($TotalDownMonth/2);
                for($i=1;$i<=$TotalDownMonth;$i++){
                    if($i<=$halfTotalDownMonth)
                        $htmlTotalDownMonth .= '<tr><td class="no-line">
                                    <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ </b></pre></td><td align="right" class="no-line"><pre class="tab"><b> '.number_format($InstallmentFee,2).' บาท </b></pre></td></tr>
                        ';
                    else if(($i>$halfTotalDownMonth))
                        $htmlTotalDownMonth2 .= '<tr><td class="no-line">
                                    <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ </b></pre></td><td align="right" class="no-line"><pre class="tab"><b> '.number_format($InstallmentFee,2).' บาท </b></pre></td></tr>
                        ';
                }
//            else{
//                for($i=1;$i<=$TotalDownMonth;$i++){
//                    $htmlTotalDownMonth .= '
//                                <pre>4.2.'.$i.' Installment of '.$i.' in a sum of '.number_format($InstallmentFee,2).' Baht ('.$this->currency->bahtEng($InstallmentFee).') payable  within '.date('d F Y', strtotime($dateDownpay. '+' .($i-1). 'month')).'<br></pre>
//                    ';
//                    if($i == $TotalDownMonth){
//                        $htmlTotalDownMonth .= '
//                            <td >
//                                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.2.'.($i+1).' Final installment in a sum of '.number_format(($qt_unit_price-($BookingFee+$ContractFee))-($InstallmentFee*$TotalDownMonth),2).' Baht ('.$this->currency->bahtEng(($qt_unit_price-($BookingFee+$ContractFee))-($InstallmentFee*$TotalDownMonth)).')<br></p>
//                            </td>
//                        ';
//                    }
//                }
            }
        }
        else
        {
            $this->load->library('payment');
            if($language == 'TH'){
               $halfTotalDownMonth=ceil($TotalDownMonth/2);
                for($i=1;$i<=$TotalDownMonth;$i++){
                    if($i<=$halfTotalDownMonth)
                        $htmlTotalDownMonth .= '<tr><td class="no-line">
                                    <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ </b></pre></td><td align="right" class="no-line"><pre class="tab"><b> '.number_format($this->payment->getDefinefee($i,$Arr),2).' บาท </b></pre>
                        </td></tr>';
                    else if(($i>$halfTotalDownMonth))
                        $htmlTotalDownMonth2 .= '<tr><td class="no-line">
                                    <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ </b></pre></td><td align="right" class="no-line"><pre class="tab"><b> '.number_format($this->payment->getDefinefee($i,$Arr),2).' บาท </b></pre>
                        </td></tr>';
                }
            }
//            else{
//                for($i=0;$i<5;$i++)
//                {
//                    if($balloon[$i] != ' - ' && ($num[$i]) != 1)
//                        $htmlTotalDownMonth .=  '
//                            <td >
//                                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.2.'.($i+1).' Total '.$TotalDownMonth.' installments.  Installment '.$balloon[$i].' For baht <u>'.number_format($balloonAmount[$i],2).'</u> per month(<u>'.$this->currency->bahtEng($balloonAmount[$i]).'</u>)
//                            </td>
//                            ';
//                    else if($balloon[$i] != ' - ' && ($num[$i]) == 1)
//                        $htmlTotalDownMonth .=  '
//                        <td >
//                            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.2.'.($i+1).' Total '.$TotalDownMonth.' installments.  Installment '.$lastBalloon[$i].' For baht <u>'.number_format($balloonAmount[$i],2).'</u> per month(<u>'.$this->currency->bahtEng($balloonAmount[$i]).'</u>)
//                        </td>
//                        ';
//                    else
//                    {
//                        $htmlTotalDownMonth .= '
//                            <td >
//                                <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.2.'.($i+1).' Last installment '.number_format(($qt_unit_price-($BookingFee+$ContractFee))-($totalInstallmentBall),2).' Baht ('.$this->currency->bahtEng(($qt_unit_price-($BookingFee+$ContractFee))-($totalInstallmentBall)).')<br></p>
//                            </td>
//                        ';
//                        break;
//                    }
//                }
//            }
        }
        $htmlTotalDownMonth .= '</table>';
        $htmlTotalDownMonth2 .= '</table>';
//        echo $htmlTotalDownMonth.$htmlTotalDownMonth2;exit;

		$data['bid'] = $bid;
		$data['getProject'] = $getProject;
		$data['pj_name'] = $pj_name;
		$data['project'] = $getProject;
		$data['projectImage'] = $projectImage;
		$data['dateBooking'] = $dateBooking;
		$data['pers_prefix'] = $pers_prefix;
		$data['pers_fname'] = $pers_fname;
		$data['pers_lname'] = $pers_lname;
		$data['getaddress'] = $getaddress;
		$data['getaddresscur'] = $getaddresscur;
		$data['un_name'] = $un_name;
		$data['unit_type_name'] = $unit_type_name;
		$data['Floorname'] = $Floorname;
		$data['building_name'] = $building_name;
		$data['unit_type_area_sqm'] = $unit_type_area_sqm;
		$data['qt_unit_price'] = $qt_unit_price;
		$data['BookingFee'] = $BookingFee;
		$data['flagCash'] = $flagCash;
		$data['flagCrCard'] = $flagCrCard;
		$data['flagOther'] = $flagOther;
		$data['moneyCash'] = $moneyCash;
		$data['moneyCrCard'] = $moneyCrCard;
		$data['moneyOther'] = $moneyOther;
		$data['credit_bank'] = $credit_bank;
		$data['credit_no'] = $credit_no;
		$data['crdate'] = $crdate;
        $data['credit_holder'] = $credit_holder;
		$data['ContractFee'] = $ContractFee;
		$data['TotalInstallmentFee'] = $TotalInstallmentFee;
		$data['installmentFeeDetail'] = $installmentFeeDetail;
		$data['installmentFeeDetailMore'] = $installmentFeeDetailMore;
		$data['dateContractpay'] = $dateContractpay;
		$data['totalTransfer'] = $totalTransfer;
		$data['pr_selling_sqm'] = $pr_selling_sqm;
		$data['htmlGift'] = $htmlGift;
		$data['htmlDiscount'] = $htmlDiscount;
		$data['getbooking'] = $getbooking;
		$data['dateDownLast'] = $dateDownLast;
        $data['dateContract'] = $dateContract;
        $data['dateDownpay'] = $dateDownpay;
        $data['TotalDownMonth'] = $TotalDownMonth;
        $data['dateBooking'] = $dateBooking;
        $data['htmlTotalDownMonth'] = $htmlTotalDownMonth;
        $data['htmlTotalDownMonth2'] = $htmlTotalDownMonth2;
        $data['nationality'] = $nationality;
        $data['country'] = $country;
        $data['age'] = $age;
        $data['credit_type'] = $credit_type;
        $data['nameSale'] = $nameSale;
        $data['htmlPaymentOther'] = $htmlPaymentOther;
        $data['other_by'] = $other_by;
        
        

		

		$data['Currency'] = $this->currency;
		$data['DateFormat'] = $this->dateformat;


		if($language == "TH"){
			$this->load->view('Booking/booking_reportTH',$data);
		}else{
			$this->load->view('Booking/booking_reportEN',$data);
		}

	}
	////////// BOOKING /////////
	////////////////////////////
	private function processFetchBooking($pj_id)
    {
		$this->load->model('tb_booking');
		$list_booking = $this->tb_booking->fetch_all_BookingInfo_byProjectID($pj_id);
		foreach($list_booking as $booking):
			if ( trim($booking->bk_transfer_from) == 'book' ){
				$this->load->model('tb_transfer_booking');
				$booking->letter = $this->tb_transfer_booking->get_detail_by_tf_code($booking->bk_transfer_letter);
			}else if ( trim($booking->bk_transfer_from) == 'contract' ){
				$this->load->model('tb_transfer_contract');
				$booking->letter = $this->tb_transfer_contract->get_detail_by_tf_code($booking->bk_transfer_letter);
			}
			

			$booking->transferdate =  !empty($booking->letter->tf_timestamp)?date('d/m/Y',strtotime($booking->letter->tf_timestamp)):'';

			$this->load->model('tb_customer_personal_info');
			$booking->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($booking->tf_to_cus);

			$this->load->model('tb_contract');
			$booking->contact =$this->tb_contract->get_detail_by_ct_booking_code($booking->bk_booking_code);

			$this->load->model('tb_quotation');
			$quotation = $this->tb_quotation->getDetail_by_id_withProjectTable($booking->bk_quotation_code);
			$booking->quotation = $quotation;

			$this->load->model('tb_building');
			$building = $this->tb_building->get_detail_building_by_building_id($quotation->qt_buliding_id);
			$booking->building_name = $building->building_name;

			$this->load->model('tb_unit_number');
			$room = $this->tb_unit_number->get_detail_unit_by_un_id($quotation->qt_unit_number_id);
			$booking->un_name = $room->un_name;
		endforeach;
		return $list_booking;
	}
    
    public function test($cus) {
        $CardHolder  =	$this->input->post('CardHolder')[0];
        $Cardno      =	$this->input->post('Cardno')[0];
        $CardBank    =	$this->input->post('CardBank')[0];
        $CardType    =	$this->input->post('CardType')[0];
        $ApproveCode =	$this->input->post('ApproveCode')[0];
        $expiremonth = $this->input->post('expiremonth')[0];
        $expireyear  = $this->input->post('expireyear')[0];
        $expire      = $expiremonth.'/'.$expireyear;
        
        $data = array(
            'cc_cus_id'  => $cus,
            'cc_holder'  => $CardHolder,
            'cc_number'  => $Cardno,
            'cc_bank'    => $CardBank,
            'cc_type'    => $CardType,
            'cc_approve' => $ApproveCode,
            'cc_expire'  => $expire
        );
        
        $this->load->model('log_customer_credit');
        $detail = $this->log_customer_credit->on($cus);
        if(empty($detail->cc_number)) {
            $this->log_customer_credit->record($data);
        }else {
            $data['cc_last_update'] = date('Y-m-d H:i:s');
            $this->log_customer_credit->update($data, $detail->cc_id); 
        }
    }
}

/* End of file booking.php */
/* Location: ./application/controllers/booking.php */