<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reportsystem extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Report System';
    var $page_var = 'reportSystem';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
    
    function view()
    {
        $this->load->model('tb_report');
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['reportList'] = $this->tb_report->get_all();
        $this->load->view('ReportSystem/report_view',$data);
    }
    
    public function adding()
    {
        $this->load->model('tb_report');
        $TBList = $this->tb_report->get_all_tables();
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['TBList'] = $TBList;
        $data['db_name'] = $this->project_database_sel;
        $this->load->view('ReportSystem/report_form',$data);
    }
    
    public function record()
    {
        $nameTH = $this->input->post('nameTH');
        $nameEN = $this->input->post('nameEN');
        $select = $this->input->post('select');
        $from   = $this->input->post('from');
        $where  = $this->input->post('where');
        
        $this->load->model('tb_report');
        
        $data = array(
            'rp_name_th' => $nameTH,
            'rp_name_en' => $nameEN,
            'rp_select' => $select,
            'rp_from' => $from,
            'rp_where' => $where
        );
        $this->tb_report->record($data);
        echo '<script>window.location.href = "'.BASE_DOMAIN.'reportsystem/view"</script>';
    }
    
    public function editing($id)
    {
        $this->load->model('tb_report');
        $TBList = $this->tb_report->get_all_tables();
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['TBList'] = $TBList;
        $data['db_name'] = $this->project_database_sel;
        $data['rpDetail'] = $this->tb_report->get_by_id($id);
        $this->load->view('ReportSystem/report_form',$data);
    }
    
    public function update()
    {
        $id     = $this->input->post('rpID');
        $nameTH = $this->input->post('nameTH');
        $nameEN = $this->input->post('nameEN');
        $select = $this->input->post('select');
        $from   = $this->input->post('from');
        $where  = $this->input->post('where');
        
        $this->load->model('tb_report');
        
        $data = array(
            'rp_name_th' => $nameTH,
            'rp_name_en' => $nameEN,
            'rp_select' => $select,
            'rp_from' => $from,
            'rp_where' => $where
        );
        $this->tb_report->update($data,$id);
        echo '<script>window.location.href = "'.BASE_DOMAIN.'reportsystem/view"</script>';
    }
}
?>