<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Promotion extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'update';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
	public function index()
	{
		$this->editing();
	}
    public function editing()
    {
        $this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        $this->load->model('tb_building');
        $this->load->model('tb_update_promotion');
        
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var.'Promotion';
		$data['permission'] = $this->get_user_permission();
        $data['buildinglist'] = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['history'] = $this->tb_update_promotion->getAllDetail();
		$this->LoadView('Promotion/update_promotion',$data);
	}
    public function update()
    {
        $this->load->model('tb_contract_promotion');
        $this->load->model('tb_update_promotion');
        $this->load->model('tb_room_status');
        $this->load->model('tb_contract');
        $this->load->model('tb_booking');
        
        $bkCode     = $this->input->post('bookingViewModal');
        $ctCode     = $this->input->post('contractViewModal');
        $proList    = $this->input->post('pro');
        $remark     = $this->input->post('remark');
        
        if(!empty($ctCode)) {
            $detail = $this->tb_contract->get_unit_name_by_contract($ctCode);
            $cus    = $detail->ct_cus_id;
            $unid   = $detail->un_id;
        }else {
            $detail = $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bkCode);
            $cus    = $detail->bk_leads_id;
            $unid   = $detail->qt_unit_number_id;
        }
        
        $data_status = array(
			'rs_unit_number' => $unid, 
			'rs_cus_id' => $cus, 
			'rs_status' => 'Update Promotion',
            'rs_staff_id' => $this->user_id
		);
		$this->tb_room_status->record($data_status);
        
        foreach($this->tb_contract_promotion->get_detail_by_bk_code($bkCode) as $proRow) {
            $proArr[] = $proRow->cp_promotion_id;
        }
        $oldPro     = implode(',', $proArr);
        $newPro     = implode(',', $proList);
        
        $this->load->database();
	 	$this->pdb->trans_begin();
        
        $data = array(
            'up_booking_code' => $bkCode,
            'up_contract_code' => $ctCode,
            'up_old_promotion' => $oldPro,
            'up_new_promotion' => $newPro,
            'up_remark' => $remark,
            'up_staff_id' => $this->user_id
        );
        $this->tb_update_promotion->record($data);
        
        foreach($this->tb_contract_promotion->get_detail_by_bk_code($bkCode) as $cp) {
            $check = true;
            foreach($proList as $key=>$pro) {
                if($pro == $cp->cp_promotion_id) {
                    if($cp->cp_status == 'off') {
                        $data = array(
                            'cp_status' => 'on'
                        );
                        $this->tb_contract_promotion->update($data, $cp->cp_id);
                    }
                    $proList[$key] = 0;
                    $check = false;
                    break;
                }
            }
            if($check) {
                $data = array(
                    'cp_status' => 'off'
                );
                $this->tb_contract_promotion->update($data, $cp->cp_id);
            }
        }
        foreach($proList as $pro) {
            if($pro !== 0) {
                $data = array(
                    'cp_booking_code' => $bkCode,
					'cp_promotion_id' => $pro,
                    'cp_status' => 'on'
                );
                $this->tb_contract_promotion->record($data);
            }
        }
        
        if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Update Promotion Fail',"/promotion/editing/");
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Update Promotion success',"/promotion/editing/");
		}
    }
}
?>