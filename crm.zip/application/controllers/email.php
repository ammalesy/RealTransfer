<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->booking();
	}
	public function booking()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        $this->load->model('tb_contract');
        $this->load->model('tb_transfer_booking');
        $this->load->model('tb_transfer_contract');
        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_quotation');
        $this->load->model('tb_building');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_booking');
        
        $list_booking = $this->tb_booking->fetch_all_BookingInfoEmail_byProjectID($this->project_id_sel);
        
		$data['title'] = "Email Booking";
		$data['page'] = "EmailBooking";
		$data['permission'] = $this->get_user_permission();
		$data['list_booking'] = $list_booking;
		$this->LoadView('Email/email_booking_view',$data);
	}
	public function installment()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        $this->load->model('tb_contract');
        $this->load->model('tb_transfer_booking');
        $this->load->model('tb_transfer_contract');
        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_quotation');
        $this->load->model('tb_building');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_booking');
        $this->load->model('tb_installment');
        $list_installment = $this->tb_installment->fetch_all_Email_byProjectID($this->project_id_sel);
		$data['title'] = "Email Installment";
		$data['page'] = "EmailInstallment";
		$data['permission'] = $this->get_user_permission();
		$data['list_installment'] = $list_installment;
		$this->LoadView('Email/email_installment_view',$data);
	}
	public function preview(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = "Preview Email";
		$data['permission'] = $this->get_user_permission();

		$customers_post = $this->input->post('customers');
		$doctype_post = $this->input->post('doctype');
		$msg_post = $this->input->post('msg');

		$data['contentcustomers'] = isset($customers_post)?$customers_post:'';
     	$data['doctype'] = isset($doctype_post)?$doctype_post:'';
     	$data['msgtype'] = isset($msg_post)?$msg_post:'';
     	$data['page'] = trim($data['doctype']) == 'booking'?'EmailBooking':'EmailInstallment';

		$this->load->view('Email/email_preview',$data);
	}
//	public function send_multiple_mobile(){
//
//	   $staffid = $this->user_id;
//	   $msgtype_post = $this->input->post('msgtype');
//	   $doctype_post = $this->input->post('doctype');
//	   $contentCusts_post = $this->input->post('contentCusts');
//
//	   $msgtype = isset($msgtype_post)?$msgtype_post:'';
//	   $doctype = isset($doctype_post)?$doctype_post:'';
//	   $contentCustomers  = isset($contentCusts_post)?$contentCusts_post:'';
//	   $Docnos  = explode(";",$contentCustomers);
//	       
//		// sent multi mobile no.
//   
//		if ( $doctype=='booking' )
//	    {
//	       foreach ($Docnos as $Doc):           
//	                $this->load->model('tb_booking');
//	                $Lines = $this->tb_booking->getBookingInfo_byBookingCode_andProjectID_overload1($Doc,$this->project_id_sel);            
//	                $customer      = $Lines->bk_leads_id;
//	                
//	                $defaultmsg = "เนื่องจากท่านได้จองห้อง".$Lines->qt_unit_number_id  ."โครงการ ".  $this->project_name_sel."ไว้ 
//	 กรุณามาทำสัญญา ภายในวันที่ ".date('d/m/Y',strtotime($Lines->bk_contract_date))."
//	 \n หากเลยกำหนด จะถือว่าท่านสละสิทธิ์";
//	                    
//	                $mobileorEmail   = trim($msgtype)=='sms'?$Lines->pers_mobile:$Lines->pers_email;  
//	                
//	        
//	                if ( !empty($Lines->pers_mobile)  )
//	                {       
//	                   $construc = array(
//		              	(trim($msgtype)=='email'?1:2),
//		              	$defaultmsg,
//		              	$customer,
//		              	$Doc,
//		              	$doctype,
//		              	$mobileorEmail,
//		              	$staffid,''
//		              ); 
//	              		$this->load->library('Transfermsg',$construc);             
//	              		$p = $this->Transfermsg;                         
//	                }
//	              //Progressbar      
//	       	endforeach;
//	        redirect('/email/booking');
//	    }
//		else if ( $doctype=='installment' )
//		{
//	       foreach ($Docnos as $Doc):           
//	                $this->load->model('tb_installment');
//	                $Lines = $this->tb_installment->get_full_detail_in_id($Doc);              
//	                $customer      = $Lines->in_cus_id;
//	                $Docno = $Lines->in_contract_id;
//	                $feetime  = $Lines->in_installment_time;
//	           
//	               $defaultmsg = " กรุณามาชาระค่างวด ที่ ".$feetime." เลขที่สัญญา ".$Lines->in_contract_id.
//	                             " ภายในวันที่ ".date('d/m/Y',strtotime($Lines->in_due_date)).
//	                             " \n ขออภัย หากท่านชำระแล้ว ";
//	                          
//	                $mobileorEmail   = trim($msgtype)=='sms'?$Lines->pers_mobile:$Lines->pers_email; 
//	                if ( !empty($Lines->pers_mobile)  )
//	                {      
//	                	$construc = array(
//			              	(trim($msgtype)=='email'?1:2),
//			              	$defaultmsg,
//			              	$customer,
//			              	$Docno,
//			              	$doctype,
//			              	$mobileorEmail,
//			              	$staffid,
//			              	$feetime
//			              ); 
//	              		$this->load->library('Transfermsg',$construc);             
//	              		$p = $this->Transfermsg;                              
//	                }
//	              //Progressbar
//	       endforeach;
//	       redirect('/email/installment');
//	   	}
//   
//	}
	public function sendmessage(){
		
		$staffid   = $this->user_id;
	    $msgtype   = $this->input->post('msgtype');
	    $doctype   = $this->input->post('doctype');
	    $bkCode    = $this->input->post('bkCode');
	    $ctCode    = $this->input->post('ctCode');
	    $imCode    = $this->input->post('imCode');
	    $message = $this->input->post('message');
	    $cusID = $this->input->post('cusID');
	    $contact = $this->input->post('contact');
	    // sent one mobile no.
	    if ( $doctype=='booking' )
	    {
//	        $this->load->model('tb_booking');
//			$Lines = $this->tb_booking->getBookingInfo_byBookingCode_andProjectID($Doc,$this->project_id_sel);            
//	        $customer      = $Lines->bk_leads_id;
//			$mobileorEmail   = trim($msgtype)=='sms'?$Lines->pers_mobile:$Lines->pers_email;  
//            if ( !empty($Lines->pers_mobile)  )
//            {    
            $arr = array(
              	'msgType' => (trim($msgtype)=='email'?1:2),
                'message' => $message,
               	'cusID' => $cusID,
                'bkCode' => $bkCode,
                'type' => $doctype,
              	'contact' => $contact,
              	'staffID' => $staffid,
                'imCode' => NULL,
                'ctCode' => NULL
            );
//            foreach($arr as $key=>$value) $obj->$key = $value;
            $this->load->library('Transfermsg',$arr);             
//            $this->Transfermsg; 
//            }
//              //Progressbar
//            redirect('/email/booking');
            echo '<script>window.location.href = "'.BASE_DOMAIN.'email/booking"</script>';
            exit;       
	   	}
	   	else if ( $doctype=='installment' )
	   	{
//	        $this->load->model('tb_installment');
//	        $Lines = $this->tb_installment->get_full_detail_in_id($Doc);             
//	        $customer      = $Lines->in_cus_id;
//	        $Docno =  $Lines->in_contract_id;
//	        $feetime  = $Lines->in_installment_time;
//	        $mobileorEmail   = trim($msgtype)=='sms'?$Lines->pers_mobile:$Lines->pers_email; 
//	        if ( !empty($Lines->pers_mobile) )
//	        {         
            $arr = array(
              	'msgType' => (trim($msgtype)=='email'?1:2),
                'message' => $message,
               	'cusID' => $cusID,
                'bkCode' => $bkCode,
                'type' => $doctype,
              	'contact' => $contact,
              	'staffID' => $staffid,
                'imCode' => $imCode,
                'ctCode' => $ctCode
            );
//            foreach($arr as $key=>$value) $obj->$key = $value;
            $this->load->library('Transfermsg',$arr);                    
//	        }
//	              //Progressbar
//	        redirect('/email/installment');
            echo '<script>window.location.href = "'.BASE_DOMAIN.'email/installment"</script>';
            exit; 
	   	}
	   	
	}
}

/* End of file room.php */
/* Location: ./application/controllers/email.php */