<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fgf extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'updateFGF';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
    
	public function view(){
		
        $this->load->model('tb_user_personal_info');
        
        $this->load->model('tb_customer_personal_info');
        
        
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		
		$data['list_friend'] = $this->fetch_all_friend();
        $data['project_name_sel'] = $this->project_name_sel;
		$data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
		$this->LoadView('Fgf/fgf',$data);
	}
    
    public function confirm_approver(){
        $prj = $this->project_name_sel;
	    $fgf_id =  '';
	    $fgf_id = $this->input->post('id');
        $fgf_unit_cus2 = trim($this->input->post('unit-cus2'));
        $one_sale = $this->input->post('one');
        $two_sale = $this->input->post('two');
        $building = $this->input->post('building-confirm');
        $today = date('Y-m-d');
        $user_id = $this->user_id;
        
        $this->load->model('tb_contract_promotion');
        $this->load->model('tb_fgf');
        $getFgf = $this->tb_fgf->get_friend_by_id($fgf_id);
        $cusid2_by_fgf = $getFgf->fgf_cus_id2;
        $oldConCus = $getFgf->fgf_contract_code1;
        $unit_type1 = $getFgf->un_unit_type_id;
        $unitId1 = $getFgf->un_id;
        $cusid1 = $getFgf->fgf_cus_id1;
        
        //check date
        if($getFgf->fgf_last_date < $getFgf->fgf_date){
            echo "<script> alert('ไม่สามารถเพิ่มโปรโมชั่นได้ เนื่องจากเลยกำหนดแล้ว');   history.back(); </script>";
            exit;    
        }
        //check date//
        
        $this->load->model('tb_contract');
        $getNewCon = $this->tb_contract->get_contract_by_unit_name($fgf_unit_cus2);
        $getOldCon = $this->tb_contract->get_contract_by_unit_name($getFgf->un_name);
        $newConCus = $getNewCon->ct_code;
        $cusid2_by_contract = $getNewCon->ct_cus_id;
        $unit_type2 = $getNewCon->un_unit_type_id;
        $unitId2 = $getNewCon->un_id;
        $buildingTemp = $getNewCon->qt_buliding_id;
        
        $this->load->model('tb_quotation');
        $getQuo1 = $this->tb_quotation->getDetail_by_ct_code_withContractTable($oldConCus);
        $getQuo2 = $this->tb_quotation->getDetail_by_ct_code_withContractTable($newConCus);
        $promotion1 = $getQuo1->qt_promotion;
        $promotion2 = $getQuo2->qt_promotion;
        $quoId1 = $getQuo1->qt_code;
        $quoId2 = $getQuo2->qt_code;
        
        $this->load->model('tb_unit_type');
        $getUnitType1 = $this->tb_unit_type->get_detail_by_unit_type_id($unit_type1);
        $getUnitType2 = $this->tb_unit_type->get_detail_by_unit_type_id($unit_type2);
        $room_type_id1 = $getUnitType1->unit_type_room_type_id;
        $room_type_id2 = $getUnitType2->unit_type_room_type_id;
        
        $this->load->model('tb_room_status');
            
        //แยกโปรโมชั่น
        $proArr1 = explode(",",$promotion1);
        $proArr2 = explode(",",$promotion2);
        
        $this->load->database();
        $this->pdb->trans_begin();
        
         
        //Add fgf
        if ( $fgf_id != '' && $cusid2_by_fgf == $cusid2_by_contract && $building == $buildingTemp)
        {
            //Add Promotion
            if($one_sale != null && $two_sale == null){
                $pro_permission = 0;
                //customer1 get promotion
                
                if($room_type_id1 == 1)
                    $promotion1 = '42';
                else if($room_type_id1 == 2)
                    $promotion1 = '28';
                else if($room_type_id1 == 4)
                    $promotion1 = '28';
                else
                    echo "<script> alert('Can not add promotion Friend Give Friend, Room type not have promotion');   history.back(); </script>";
                
                $data = array(
                    'cp_contract_code'=> $oldConCus,
                    'cp_booking_code' => $getOldCon->ct_booking_code,
                    'cp_promotion_id' => $promotion1,
                    'cp_status' => 'on'
                );
                echo '<script>alert("Mission Complete")</script>';
                $this->tb_contract_promotion->record($data);
         
                $data_room_sts = array(
                    'rs_unit_number' => $unitId1,
                    'rs_cus_id' => $cusid1,
                    'rs_status' => 'Get Promotion FGF',
                    'rs_staff_id' => $this->user_id
                );
                $this->tb_room_status->record($data_room_sts);
            }
            else if($two_sale != null && $one_sale == null){
                $pro_permission = 1;
                //customer2 get promotion
                if($room_type_id2 == 1)
                    $promotion2 = '42';
                else if($room_type_id2 == 2)
                    $promotion2 = '28';
                else if($room_type_id2 == 4)
                    $promotion2 = '28';
                else
                    echo "<script> alert('Can not add promotion Friend Give Friend, Room type not have promotion');   history.back(); </script>";

                $data = array(
                    'cp_contract_code'=> $newConCus,
                    'cp_booking_code' => $getNewCon->ct_booking_code,
                    'cp_promotion_id' => $promotion2,
                    'cp_status' => 'on'
                );
                echo '<script>alert("'.$room_type_id2.'")</script>';
                $this->tb_contract_promotion->record($data);
                
                $data_room_sts = array(
                    'rs_unit_number' => $unitId2,
                    'rs_cus_id' => $cusid2_by_fgf,
                    'rs_status' => 'Get Promotion FGF',
                    'rs_staff_id' => $this->user_id
                );
                $this->tb_room_status->record($data_room_sts);
            }
            else if($one_sale != null && $two_sale != null){
                $pro_permission = 2;
                //customer1 get promotion
                if($room_type_id1 == 1)
                    $promotion1 = '42';
                else if($room_type_id1 == 2)
                    $promotion1 = '28';
                else if($room_type_id1 == 4)
                    $promotion1 = '28';
                else
                    echo "<script> alert('Can not add promotion Friend Give Friend, Room type not have promotion');   history.back(); </script>";
                
                    $data = array(
                    'cp_contract_code'=> $oldConCus,
                    'cp_booking_code' => $getOldCon->ct_booking_code,
                    'cp_promotion_id' => $promotion1,
                    'cp_status' => 'on'
                );
                $this->tb_contract_promotion->record($data);
                
                //customer2 get promotion
                if($room_type_id2 == 1)
                    $promotion2 = '42';
                else if($room_type_id2 == 2)
                    $promotion2 = '28';
                else if($room_type_id2 == 4)
                    $promotion2 = '28';
                    else {
                    echo "<script> alert('Can not add promotion Friend Give Friend, Room type not have promotion');   history.back(); </script>";
                    exit;
                }

               $data = array(
                    'cp_contract_code'=> $newConCus,
                    'cp_booking_code' => $getNewCon->ct_booking_code,
                    'cp_promotion_id' => $promotion2,
                    'cp_status' => 'on'
                );
                $this->tb_contract_promotion->record($data);
                
                $data_room_sts = array(
                    'rs_unit_number' => $unitId1,
                    'rs_cus_id' => $cusid1,
                    'rs_status' => 'Get Promotion FGF',
                    'rs_staff_id' => $this->user_id
                );
                $this->tb_room_status->record($data_room_sts);
                
                $data_room_sts = array(
                    'rs_unit_number' => $unitId2,
                    'rs_cus_id' => $cusid2_by_fgf,
                    'rs_status' => 'Get Promotion FGF',
                    'rs_staff_id' => $this->user_id
                );
                $this->tb_room_status->record($data_room_sts);
            }
            else{
                echo "<script> alert('Can not add promotion Friend Give Friend, Please select customer');   history.back(); </script>";
                exit;
            }
            //End Add Promotion
            
        	$data = array(
        		'fgf_contract_code2' => $newConCus,
                'fgf_permission' => $pro_permission,
                'fgf_date_approver' => $today,
        		'fgf_approver' => $user_id,
                'fgf_status' => 'Confirmed'
        	);
        	
        	$this->tb_fgf->update_where($data,"fgf_id = '".$fgf_id."'");
            
            if ($this->pdb->trans_status() === FALSE){
                $this->pdb->trans_rollback();
                alert_redirect('FGF Fail','/fgf/view');
            }
            else{
                $this->pdb->trans_commit();
                echo "<script>window.location.href = '".BASE_URL."/fgf/view';</script>";
//                  redirect('/contract/view');
            }
//            redirect('/fgf/view');
        }else if($cusid2_by_fgf != $cusid2_by_contract){
            echo "<script> alert('Unit number is not match');   history.back(); </script>";
        }else if($one_sale == null && $two_sale == null){
            echo "<script> alert('Can not add promotion Friend Give Friend, Room type not have promotion');   history.back(); </script>";
        }else if($building != $buildingTemp){
            echo "<script> alert('Building is not macth, Please check Building');   history.back(); </script>";
        }
        //End fgf
    }
    
	public function adding(){
		
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_unit_number');
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		
		$data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo();
		$data['list_unit'] = $this->tb_unit_number->fetch_full_unit_number();
		$data['project_name_sel'] = $this->project_name_sel;
		$data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
        //////////////// modal new lead //////////////////////
        $data['list_budget'] = $this->fetch_all_budget();
		$data['list_visit_type'] = $this->fetch_all_visit_type();
		$data['list_media_type'] = $this->fetch_all_media_type();
		$data['list_opportunity_stages'] = $this->fetch_opportunity_stages();
        $data['list_nationality'] = $this->fetch_all_nationality();
        //////////////////////////////////////////////////////
		$this->LoadView('Fgf/fgf_adding',$data);
	}
     
	public function record(){
        $customer = $this->input->post('leadsid');
        $customer2 = $this->input->post('leadsid2');
        $issueDate = date('Y-m-d');
        $project = 	$this->project_id_sel;
        $endDate = $this->input->post('end');
        $unit = trim($this->input->post('unit'));
//        $building = $this->input->post('building');
        
        //check date
        if($endDate <= $issueDate){
            echo "<script> alert('วันสิ้นสุดโปรโมชั่นต้องมากกว่าวันเริ่มโปรโมชั่น');   history.back(); </script>";
            exit;
        }
        //check date//

        $this->load->model('tb_contract');
        $getNewCon = $this->tb_contract->get_contract_by_unit_id($unit);
        $ct_code1 = $getNewCon->ct_code;
        $ct_cus_id = explode(',',$getNewCon->ct_cus_id);
//        $buildingTemp = $getNewCon->qt_buliding_id;
        
        if ($this->input->post('leadsid') != 0 && in_array($customer, $ct_cus_id)
//            && $building == $buildingTemp
           ) {
            $data_fgf = array(
                'fgf_contract_code1' => $ct_code1,
                'fgf_cus_id1' => $customer,
                'fgf_cus_id2' => $customer2,
                'fgf_date' => $issueDate,
                'fgf_last_date' => $endDate,
                'fgf_sale' => $this->user_id,
                'fgf_project_id' => $project,
                'fgf_status' => 'Approver Confirm'
            );
            
            $this->load->model('tb_fgf');
            $this->tb_fgf->record($data_fgf);

            if ($this->pdb->trans_status() === FALSE){
                $this->pdb->trans_rollback();
                alert_redirect('Add customer detail Fail','/fgf/view');
            }
            else
            {
                $this->pdb->trans_commit();
                alert_redirect('Add customer detail success', '/fgf/view');
            }
        }else if(!in_array($customer, $ct_cus_id)){
            echo "<script> alert('Unit number is not macth, Please check Unit number');   history.back(); </script>";
//        }else if($building != $buildingTemp){
//            echo "<script> alert('Building is not macth, Please check Building');   history.back(); </script>";
        }else{
	 		echo "<script> alert('Can not create Friend Give Friend, Please check customer');   history.back(); </script>";	
		}
	}

	public function report($id){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->library('currency');
		$this->load->library('DateFormat');
        
        $fgfId = $id;
        
        $this->load->model('tb_fgf');
        $getFriend = $this->tb_fgf->get_friend_by_id($fgfId);
        $issueDate = $getFriend->fgf_date;
        $lastDate = $getFriend->fgf_last_date;
        $project = $getFriend->fgf_project_id;
        $cusid1 = $getFriend->fgf_cus_id1;
        $unitName1 = $getFriend->un_name;
        $cusid2 = $getFriend->fgf_cus_id2;
        $saleid = $getFriend->fgf_sale;
        $dateApprove = $getFriend->fgf_date_approver;
        $unitType1 = $getFriend->un_unit_type_id;
        $asking_price = $getFriend->qt_unit_price;
        $approverID = $getFriend->fgf_approver;
        
        $this->load->model('tb_unit_type');
        $getUnitType = $this->tb_unit_type->get_detail_by_unit_type_id($unitType1);
        $unitTypeName1 = $getUnitType->unit_type_name;
        $roomTypeID1 = $getUnitType->unit_type_room_type_id;
        //check room type for get promotion
        if($roomTypeID1 == 1){
            $cb1 = 'checked="checked"';
            $cb2 = '';
            $cb3 = '';
            $discount1 = 13580;
            $discount2 = '';
            $discount3 = '';
        }
        else if($roomTypeID1 == 2){
            $cb1 = '';
            $cb2 = 'checked="checked"';
            $cb3 = '';
            $discount1 = '';
            $discount2 = 29100;
            $discount3 = '';
        }
        else{
            $cb1 = '';
            $cb2 = '';
            $cb3 = 'checked="checked"';
            $discount1 = '';
            $discount2 = '';
            $discount3 = 29100;
        }
        
        
        $this->load->model('tb_customer_personal_info');
        $getCus1 = $this->tb_customer_personal_info->get_detail_by_id($cusid1);
        $getCus2 = $this->tb_customer_personal_info->get_detail_by_id($cusid2);
        $fnameCus1 = $getCus1->pers_prefix." ".$getCus1->pers_fname;
        $lnameCus1 = $getCus1->pers_lname;
        $fnameCus2 = $getCus2->pers_prefix." ".$getCus2->pers_fname;
        $lnameCus2 = $getCus2->pers_lname;
        //mobile custoemr1
        if($getCus1->pers_mobile != null)
            $mobile1 = $getCus1->pers_mobile;
        else
            $mobile1 = '-';
        //tel custoemr1
        if($getCus1->pers_tel != null)
            $tel1 = $getCus1->pers_tel;
        else
            $tel1 = '-';
        //email custoemr1
        if($getCus1->pers_email)
            $email1 = $getCus1->pers_email;
        else
            $email1 = '-';
        //mobile custoemr2
        if($getCus2->pers_mobile != null)
            $mobile2 = $getCus2->pers_mobile;
        else
            $mobile2 = '-';
        //email custoemr2
        if($getCus2->pers_email)
            $email2 = $getCus2->pers_email;
        else
            $email2 = '-';
        
        $this->load->model('tb_customer_address_current_info');
        $getAddress = $this->tb_customer_address_current_info->get_detail_by_customerID($cusid1);
        $addr = $getAddress->addr_cur_address;
        
        if($getAddress->addr_cur_sub_district != null)
            $subDistrict = $getAddress->addr_cur_sub_district;
        else
            $subDistrict = ' ';
        
        if($getAddress->addr_cur_district = null)
            $district = $getAddress->addr_cur_district;
        else
            $district = ' ';
        
        if($getAddress->addr_cur_province)
            $province = $getAddress->addr_cur_province;
        else
            $province = ' ';
        
        if($getAddress->addr_cur_post_code)
            $postCode = $getAddress->addr_cur_post_code;
        else
            $postCode = ' ';
        
        $address = $addr.' '.$subDistrict.' '.$district.' '.$province.' '.$postCode;
        
        $this->load->model('tb_project');
		$get = $this->tb_project->get_detail_project_ignoreStatusActive($project);
        $pj_name = $get->pj_name;
        
        $this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($qid);
        
        $this->load->model('tb_user_personal_info');
        $getSale = $this->tb_user_personal_info->get_detail_personal($saleid);
        $saleFullname = $getSale->user_pers_fname.' '.$getSale->user_pers_lname;
        $getApprover = $this->tb_user_personal_info->get_detail_personal($approverID);
        $approverFullname = $getApprover->user_pers_fname.' '.$getApprover->user_pers_lname;
        
        $this->load->model('tb_user_working_info');
        $getPosApp = $this->tb_user_working_info->get_user_company($approverID);
        $posApprover = $getPosApp->user_work_position;
        
        $data['pj_name'] = $pj_name;
        $data['issueDate'] = $issueDate;
        $data['fnameCus1'] = $fnameCus1;
        $data['lnameCus1'] = $lnameCus1;
        $data['mobile1'] = $mobile1;
        $data['tel1'] = $tel1;
        $data['email1'] = $email1;
        $data['address'] = $address;
        $data['unitName1'] = $unitName1;
        $data['fnameCus2'] = $fnameCus2;
        $data['lnameCus2'] = $lnameCus2;
        $data['mobile2'] = $mobile2;
        $data['email2'] = $email2;
        $data['saleFullname'] = $saleFullname;
        $data['dateApprove'] = $dateApprove;
        $data['unitTypeName1'] = $unitTypeName1;
        $data['lastDate'] = $lastDate;
        $data['cb1'] = $cb1;
        $data['cb2'] = $cb2;
        $data['cb3'] = $cb3;
        $data['asking_price'] = $asking_price;
        $data['discount1'] = $discount1;
        $data['discount2'] = $discount2;
        $data['discount3'] = $discount3;
        $data['approverFullname'] = $approverFullname;
        $data['posApprover'] = $posApprover;
        

		$this->load->view('Fgf/fgf_report',$data);
	}
    
    public function fetch_all_friend(){
        $this->load->model('tb_fgf');
        $list_friend = $this->tb_fgf->fetch_all_friend($this->project_id_sel);
        
		return $list_friend;
    }
    
    private function fetch_all_budget(){
		$this->load->model('tb_budget');
		return $this->tb_budget->fetch_all();
	}
	private function fetch_all_visit_type(){
		$this->load->model('tb_visit_type');
		return $this->tb_visit_type->fetch_all();
	}
    private function fetch_all_media_type(){
		$this->load->model('tb_media_type');
		return $this->tb_media_type->fetch_all();
	}
	private function fetch_opportunity_stages(){
		$this->load->model('tb_opportunity_stages');
		return $this->tb_opportunity_stages->fetch_opportunity_stages();
	}
    private function fetch_all_nationality(){
		$this->load->model('tb_nationality');
		return $this->tb_nationality->fetch_all_nationality();
	}
}

?>