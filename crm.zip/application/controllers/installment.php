<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Installment extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Installment';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{

		$this->view();

		// $data['script'] = "javascript: window.open('".BASE_DOMAIN."quotation/view');";
		// $this->load->view('Quotation/redirect',$data);
	}
	public function view()
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_installment'] = $this->fetch_installment();
        $this->load->model('tb_receipt_temporary');
		$this->LoadView('Installment/installment',$data);
	}
	public function confirmInstallmentFee(){
		$prj = $this->project_name_sel;
	    $ctcode = '';
	    $installment = '';
	    $ctcode = $this->input->post('contactcode');
	    $installment = $this->input->post('installmentno');
	    $reason      = $this->input->post('reason');
	    $uri      = $this->input->post('uri');

	    if ( $ctcode != '' )
	    {
	    	$data = array(
	    		'im_confirm' => 'yes',
	    		'im_remark' => $reason
	    	);
	    	$this->load->model('tb_installment');
	    	$this->tb_installment->update_where($data,"im_contract_code = '".$ctcode."' AND im_installment_time = '".$installment."'");
	    }
	    //echo $uri;

	    $uri = '/'.$uri;
	    redirect($uri);
	    //redirect($uri);
	}
	public function listInstallment($cid){

		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['conid'] = $cid;
		$data['uri'] = uri_string();

        $this->load->model('tb_contract');
        $installment_detail = $this->tb_contract->get_installment_detail_by_code($cid);
        $ctStatus = $installment_detail->ct_active;
        $this->load->model('tb_building');
        $building = $this->tb_building->get_detail_building_by_building_id($installment_detail->qt_buliding_id)->building_name;
        $this->load->model('tb_unit_number');
        $unit = $this->tb_unit_number->get_detail_unit_by_un_id($installment_detail->qt_unit_number_id)->un_name;

        $this->load->model('tb_installment');
        $this->load->model('tb_transfer_ownership');

        $data['ctStatus'] = $ctStatus;
        $data['getTransOwner'] = $this->tb_transfer_ownership->get_by_ct_code($cid);
        $data['disabled'] = $this->CheckTransfers($cid);
        $data['building'] = $building;
        $data['unitname'] = $unit;
		$data['list_installment'] = $this->tb_installment->fetch_installment_by_in_contract_id($cid);
		$data['aInstallment'] = $data['list_installment'][0];
        $data['installment_detail'] = $this->tb_contract->get_installment_detail_by_code($cid);
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_receipt_temporary');
		$this->LoadView('Installment/installment_list',$data);
	}
	public function filtering_list(){

		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();

		$this->load->model('tb_installment');
		$data['list_installment'] = $this->tb_installment->fetch_filtering_installment();
		$this->LoadView('Installment/installment_filtering_list',$data);
	}
	private function fetch_installment(){
		$this->load->model('installment_');
		$this->load->model('tb_quotation');
		$this->load->model('tb_building');
		$this->load->model('tb_unit_number');
		$this->load->model('tb_customer_personal_info');
		$list_installment = $this->installment_->fetch_all_installment($this->project_id_sel);

		foreach($list_installment as $installment):
			$installment->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($installment->tf_to_cus);
			$installment->quotation = $this->tb_quotation->getDetail_by_id_withProjectTable($installment->bk_quotation_code);
			$installment->building = $this->tb_building->get_detail_building_by_building_id($installment->quotation->qt_buliding_id);

			$un_id= $installment->quotation->qt_unit_number_id;
			$building_id = $installment->building->building_id;
			$installment->unit_number = $this->tb_unit_number->get_detail_unit_by_un_id_andBuildingID($un_id,$building_id);

		endforeach;
		return $list_installment;
	}
    public function adding($id, $overdue) {

        $data['title'] = $this->title_page;

        $this->load->model('tb_installment');
        $getpmid 	   = $this->tb_installment->get_full_detail_by_id($id);
        $conid  	   = $getpmid->im_contract_code;
        $installment   = $getpmid->im_installment_time;
        $installment_code = $getpmid->im_code;
        $definefee     = $getpmid->im_fee_define;
        $amount     = $getpmid->im_amount;
        $customer_name = $getpmid->pers_fname.' '.$getpmid->pers_lname;
        $cusid         = $getpmid->cus_id;

        $this->load->model('tb_contract');
        $ctDetail = $this->tb_contract->get_detail_by_ct_code($conid);

        $this->load->model('tb_customer_personal_info');
        $cusList = $this->tb_customer_personal_info->list_customer($ctDetail->ct_cus_id);
        $cusFullName = array();
        foreach($cusList as $cus) {
            $cusFullName[] = $cus->pers_fname.' '.$cus->pers_lname;
        }
        
        //$projectid = $this->project_id_sel;
        if ($getpmid->im_paid !== 'no') {
            if(!empty($overdue))
                alert_redirect('This installment had temp receipt.',"/overdue/installment");
            else
                alert_redirect('This installment had temp receipt.',"/installment/listInstallment/".$conid);
            exit;
        }
        $this->load->model('tb_contract');
        $installment_detail = $this->tb_contract->get_installment_detail_by_code($conid);
        $getcontract = $this->tb_contract->get_detail_by_ct_code($conid);

        $this->load->model('tb_building');
        $building = $this->tb_building->get_detail_building_by_building_id($installment_detail->qt_buliding_id)->building_name;
        $this->load->model('tb_unit_number');
        $unit = $this->tb_unit_number->get_detail_unit_by_un_id($installment_detail->qt_unit_number_id)->un_name;

        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();

        $this->load->model('tb_customer_personal_info');
		$list_customer = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();

        $this->load->model('log_customer_credit');
        $this->load->library('encrypt');
        $data['credit'] = $this->log_customer_credit->on($cusid);
        $data['cusList']= $cusFullName;
        $data['building'] = $building;
        $data['unitname'] = $unit;
        $data['list_customer'] = $list_customer;
        $data['getpmid'] = $getpmid;
        $data['customer_name'] = $customer_name;
        $data['con_code'] = $conid;
        $data['installmentid'] = $id;
        $data['installment'] = $installment;
        $data['installment_code'] = $installment_code;
        $data['definefee'] =  $definefee;
        $data['amount'] =  $amount;
        $data['bookcode'] = $getcontract->ct_booking_code;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        $data['overdue'] = $overdue;
        $data['permission'] = $this->get_user_permission();
        if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $this->load->model('tb_receipt_offical');
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled();
        }

        $this->LoadView("Installment/installment_adding", $data);
    }
    public function record() {
        
	 	$this->load->database();
	 	$this->db->trans_begin();
	 	$this->pdb->trans_begin();

		$cusid            =	$this->input->post('cusid');
		$Type             =	$this->input->post('Type');
		$payfor           =	$this->input->post('Payfor');
		$contract         =	$this->input->post('conid');
		$Booking          =	$this->input->post('bookcode');
		$InstallmentTime  =	$this->input->post('instime');
        $inscode          = $this->input->post('inscode');
		$usersignature	  =	$this->input->post('authorize');
        $unitname         = $this->input->post('unitname');
        $building         = $this->input->post('building');
        $divide           = $this->input->post('divide');
        $MoneyAmount      =	$this->input->post('definefee');
		$sale = $this->user_id;
        
        $paid_receipt = 0;
        $paid_cash = 0;
        $paid_card = 0;
        $paid_other = 0;
        $paid_amount = 0;
        if(!empty($this->input->post('Receiptamount'))){
        $paid_receipt      = $this->input->post('Receiptamount');
        $paid_type        = 'Receiptamount';
        }
        if(!empty($this->input->post('Cashamount'))){
        $paid_cash      = $this->input->post('Cashamount');
        $paid_type        = 'Cashamount';
        }
        if(!empty($this->input->post('Cardamount'))){
        $paid_card      = $this->input->post('Cardamount');
        $paid_type        = 'Cardamount';
        }
        if(!empty($this->input->post('Otheramount'))){
        $paid_other      = $this->input->post('Otheramount');
        $paid_type        = 'Otheramount';
        }
        $paid_amount = $paid_receipt+$paid_cash+$paid_card+$paid_other;
        $balance = split("-", $this->input->post('balance'));
        $money_balance = $balance[1];
//        echo "amount_paid : ".$paid_amount." : ".$paid_type." : ".$money_balance." : ".$this->input->post('balance'); exit();
        
//        echo ("cusid :".$cusid." / ");
//		echo ("Type :".$Type." / ");
//		echo ("payfor :".$payfor." / ");
//		echo ("contract :".$contract." / ");
//		echo ("Booking :".$Booking." / ");
//		echo ("InstallmentTime :".$InstallmentTime." / ");
//        echo ("inscode :".$inscode." / ");
//		echo ("usersignature :".$usersignature." / ");
//        echo ("unitname :".$cusid." / ");
//        echo ("building :".$building." / ");
//        exit();
        

        $this->load->model('tb_installment');
        $getpmid = $this->tb_installment->get_by_code($inscode, $contract);
        if ($getpmid->im_paid !== 'no') {
            if(!empty($this->input->post('overdue')))
                alert_redirect('This installment had temp receipt.',"/overdue/installment");
            else
                alert_redirect('This installment had temp receipt.',"/installment/listInstallment/".$contract);
            exit;
        }

        $this->load->model('tb_unit_number');
        $unid = $this->tb_unit_number->get_id_by_name($unitname);
        $data_status = array(
			'rs_unit_number' => $unid,
			'rs_cus_id' => $cusid,
			'rs_status' => 'Installment '.$InstallmentTime,
            'rs_staff_id' => $sale
		);
        $this->load->model('tb_room_status');
		$this->tb_room_status->record($data_status);

		$Remark = $this->input->post('Remark');
		//Last Update Multi Paid//
        $rc_type_payment = '';
        $rc_pay_crcard   = '';
        $rc_pay_other    = '';

        if(!empty($Type))
        {
            foreach($Type as $check)
            {
                if ( trim($check) == 'Cash' )   $rc_type_payment = 'yes';
                if ( trim($check) == 'CrCard' ) $rc_pay_crcard = 'yes';
                if ( trim($check) == 'Other' )  $rc_pay_other  = 'yes';
            }
        }

        $rc_cash_amount    =	$this->input->post('Cashamount');
        $rc_crcard_bank    =	$this->input->post('CardBank');
        $BankName          =    $this->input->post('BankName');
        $rc_crcard_no      =	$this->input->post('Cardno');
        $pm_cr_type        =    $this->input->post('CardType');
        $pm_cr_approve_code=    $this->input->post('ApproveCode');
        $expiremonth_      =    $this->input->post('expiremonth');
        $expireyear_       =	$this->input->post('expireyear');
        $rc_crcard_amount  =	$this->input->post('Cardamount');
        $rc_crcard_fname   =	$this->input->post('CardHolder');
        $rc_other_by       =	$this->input->post('OtherBy');
        $rc_other_amount   =	$this->input->post('Otheramount');
        $pm_check_number   =    $this->input->post('CheckNo');
        $pm_check_date     =    $this->input->post('CheckDate');
        $pm_check_bank     =    $this->input->post('CheckBank');
//	    $MoneyAmount  =	'';
//        $MoneyAmount  =	$this->input->post('definefee');
		$today = date("Y-m-d");
        $paymentid = $this->input->post('installmentid');
//        $unit_name = '';
//        for($i = strlen($unitname);$i<4;$i++){
//            $unit_name .= '0';
//        }
//        $unit_name .= $unitname;
//        $newid = 'im-'.$unit_name.'-'.$InstallmentTime;

        if($divide = "divide") {
            if($money_balance == 0){
                $data_payment = array(
                    'im_received_date' => $today,
                    'im_fee_define' => $money_balance,
                    'im_paid' => 'yes',
                    'im_remark' => $Remark
                ); 
            } else{
                $data_payment = array(
                    'im_received_date' => $today,
                    'im_fee_define' => $money_balance,
                    'im_remark' => $Remark
                ); 
            }
        }else{
            $data_payment = array(
                'im_received_date' => $today,
                'im_paid' => 'yes',
                'im_remark' => $Remark
            );
        } 
        
        
        $this->tb_installment->update($data_payment,$paymentid);

        //////////////////////////////////////////////////////////
        $this->load->model('tb_receipt_temporary');
        $projectid = $this->project_id_sel;
        $newid = $this->tb_receipt_temporary->get_next_id();
        $tmp = strlen($newid);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) {
            $tmpID .= '0';
        }
        $tmptmp = strlen($projectid);
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) {
			$tmpIDP .= '0';
		}
        $dateQuo = date('ymd');
        $newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid;
        $receiptID = implode(',', $this->input->post('receiptID'));
        $data_receipt = array(
            'rc_code' => $newrcv,
            'rc_refer_form' => $receiptID,
            'rc_customer_id' => $cusid,
            'rc_payfor' => $payfor,
            'rc_booking_code' => $Booking,
            'rc_contract_code' => $contract,
            'rc_installment_code' => $inscode,
            'rc_installment_time' => $InstallmentTime,
            'rc_total_amount' => $paid_amount,
            'rc_temporary_date' => date('Y-m-d h:i:s'),
            'rc_staff_temporary' => $sale,
            'rc_un_name' => $unitname
        );
        $this->tb_receipt_temporary->record($data_receipt);

        if(!empty($receiptID)) {
            $this->load->model('tb_receipt_offical');
            $update = array('rc_status'=>'off');
            foreach(explode(',', $receiptID) as $receipt) {
                $this->tb_receipt_offical->update($update, $receipt);
            }
        }

        $this->load->model('tb_payment');
        $this->load->model('tb_bank');
        if($rc_type_payment == 'yes') {
            $data = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $rc_cash_amount
            );
            $this->tb_payment->record($data);
        }
        if($rc_pay_crcard == 'yes') {
            $this->load->library('encrypt');
            $bankCount = 0;
            for($i=0;$i<count($rc_crcard_amount);$i++) {
                $rc_crcard_date = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";

                if($rc_crcard_bank[$i] == 0) {
                    $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
                    echo $b_id;
                    if(empty($b_id)) {
                        $b_id = $this->tb_bank->get_next_id();
                        $data = array(
                            'b_id' => $b_id,
                            'bank_name_th' => $BankName[$bankCount]
                        );
                        $this->tb_bank->record($data);
                    }
                    $bankCount++;
                }else $b_id = $rc_crcard_bank[$i];

                $data = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Credit',
                    'pm_amount' => $rc_crcard_amount[$i],
                    'pm_cr_bank' => $b_id,
                    'pm_cr_type' => $pm_cr_type[$i],
                    'pm_cr_holder' => $rc_crcard_fname[$i],
                    'pm_cr_number' => $this->encrypt->encode($rc_crcard_no[$i]),
                    'pm_cr_approve_code' => $pm_cr_approve_code[$i],
                    'pm_cr_expire' => $rc_crcard_date
                );
                $this->tb_payment->record($data);
                if($i == 0) {
                    $this->load->library('creditlog');
                    $this->creditlog->update($data, explode(',', $cusid)[0]);
                }
            }
        }
        if($rc_pay_other == 'yes') {
            if($rc_other_by == 'Check')
                $data = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Check',
                    'pm_amount' => $rc_other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank
                );
            else
                $data = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $rc_other_by,
                    'pm_amount' => $rc_other_amount
                );
            $this->tb_payment->record($data);
        }


		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->db->trans_status() === FALSE && $this->pdb->trans_status() === FALSE){
     		$this->db->trans_rollback();
     		$this->pdb->trans_rollback();
            if(!empty($this->input->post('overdue'))) {
 			    alert_redirect('Add receipt Fail',"/overdue/installment");
            }else {
                alert_redirect('Add receipt Fail',"/installment/listInstallment/$contract");
            }
		}else {
		  	$this->db->trans_commit();
		  	$this->pdb->trans_commit();
            if(!empty($this->input->post('overdue'))) {
                echo "<script>  window.open('".BASE_DOMAIN."receipt/report/th/$newrcv','_blank');";
                echo "window.location.href = '".BASE_DOMAIN."overdue/installment';</script>";
            }else {
                echo "<script>  window.open('".BASE_DOMAIN."receipt/report/th/$newrcv','_blank');";
                echo "window.location.href = '".BASE_DOMAIN."installment/listInstallment/$contract';</script>";
//		   	    alert_redirect('Add receipt Success',"/installment/listInstallment/$contract");
            }
		}
    }
    public function receipt($imid){

		$this->load->library('currency');

        $this->load->model('tb_installment');
        $getim = $this->tb_installment->get_full_detail_im_id($imid);
        $conid = $getim->im_contract_code;
        $in_time = $getim->im_installment_time;
        $remark = $getim->im_remark;
        if($remark != null)
            $htmlRemark = '<td colspan="3" height="50" valign="top">หมายเหตุ : '.$remark.'</td>';

		$this->load->model('tb_contract');
		$getbooking= $this->tb_contract->get_detail_by_ct_code($conid);
		$bookCode = $getbooking->ct_booking_code;
		$Cusid = $getbooking->ct_cus_id;


		$this->load->model('tb_customer');
		$getBookingName_arr = $this->tb_customer->get_detail_by_id_joinInfo_AddressInfo($Cusid);
		$count = 0;
		$customers = '';
		foreach ($getBookingName_arr as $value) {
			if($count == 0)
                            $getBookingName = $value;
			else
                            $customers .= ' และ ';
        	$customers .= $value->pers_prefix.$value->pers_fname.' '.$value->pers_lname;
			$count++;
		}

		$addr_booking = $getbooking->cus_addr_default;
        echo "hello it's me : ".$addr_booking;
        exit();
        if ( $addr_booking == 1 )
        {
            $this->load->model('tb_customer_address_info');
            $getaddrCur= $this->tb_customer_address_info->get_detail_by_cus_id($Cusid);

            $doc_addr = $getaddrCur->addr_address;
            $doc_sub_district = $getaddrCur->addr_sub_district;
            $doc_district = $getaddrCur->addr_district;
            $doc_province = $getaddrCur->addr_province;
            $doc_zipcode = $getaddrCur->addr_post_code;
        }
        else if ( $addr_booking == 3 )
        {
            $this->load->model('tb_customer_address_lastest');
            $getaddrCur= $this->tb_customer_address_lastest->get_detail_by_cus_id($Cusid);

            $doc_addr = $getaddrCur->addr_lastest_address;
            $doc_sub_district = $getaddrCur->addr_lastest_sub_district;
            $doc_district = $getaddrCur->addr_lastest_district;
            $doc_province = $getaddrCur->addr_lastest_province;
            $doc_zipcode = $getaddrCur->addr_lastest_post_code;
        }
        else
        {
            $this->load->model('tb_customer_address_current_info');
            $getaddrCur= $this->tb_customer_address_current_info->get_detail_by_customerID($Cusid);

            $doc_addr = $getaddrCur->addr_cur_address;
            $doc_sub_district = $getaddrCur->addr_cur_sub_district;
            $doc_district = $getaddrCur->addr_cur_district;
            $doc_province = $getaddrCur->addr_cur_province;
            $doc_zipcode = $getaddrCur->addr_cur_post_code;
        }

		$this->load->model('tb_booking');
		$getQuocode= $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bookCode);
		$quoCode = $getQuocode->bk_quotation_code;

		$this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$Project = $getQuo->qt_project_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$Building =$getQuo->qt_buliding_id;
		$Number =$getQuo->qt_unit_number_id;

		$this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
		$un_name = $getRoom->un_name;

		$this->load->model('tb_project');
		$get = $this->tb_project->get_detail_project_ignoreStatusActive($Project);
        $projectImage = $get->pj_image;
        $getProjectPdb = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($Project);
        $pj_name =$getProjectPdb->pj_name_th.' '.$getProjectPdb->pj_location_th;

		$type_receipt = 'ใบเสร็จรับเงินชั่วคราว';
		$id = $getim->im_code;
		$prefix = $value->pers_prefix;
		$fname = $value->pers_fname;
		$lname = $value->pers_lname;
		$receiptText = 'Installment Fee : '.$id.'';
		$total_price = $getQuo->qt_avg_installment;
		$flagCash= '';
        $flagCrCard= '';
        $flagOther= '';
        $other_by= '';
        $moneyOther= '';
        $moneyCash= '';

        $this->load->model('tb_receipt_temporary');
        $getReceipt= $this->tb_receipt_temporary->get_installmentTime_by_contract($conid , $in_time);
        $rid = $getReceipt->rc_code;
        $date_receipt = $getReceipt->rc_temporary_date;
        $nameSale = $getReceipt->rc_staff_temporary;
        if(!empty($getReceipt->rc_refer_form)) {
            $this->load->model('tb_receipt_offical');
            $data['refer'] = $this->tb_receipt_offical->get_by_ids($getReceipt->rc_refer_form);
        }

        $this->load->model('tb_user_personal_info');
        $user = $this->tb_user_personal_info->get_detail_personal($nameSale);
        $loginname = $user->user_pers_fname." ".$user->user_pers_lname;

        $this->load->model('tb_payment');
        $payment_list = $this->tb_payment->get_by_temp_receipt($rid);

        foreach($payment_list as $payment) {
            if ($payment->pm_type == 'Cash') {
                $moneyCash[] = $payment->pm_amount;
                $flagCash ='checked="checked"';
            } else if ($payment->pm_type == 'Credit') {
                $moneyCrCard[] = $payment->pm_amount;
                $flagCrCard ='checked="checked"';
                $credit_bank[] = $payment->bank_name_th;
                $credit_no[] = $payment->pm_cr_number;
        $credit_holder[] = $payment->pm_cr_holder;
                $crdate[] = $payment->pm_cr_expire;
            } else {
                $moneyOther= $payment->pm_amount;
                $flagOther ='checked="checked"';
                $other_by = $payment->pm_type;
            }
        }

		$type_licence = '
<br>
<table border="0" width="100%" style="font-size:12">
	<tr>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">ผู้ซื้อ</td>
		<td width="10%"></td>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">ผู้รับเงิน</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$prefix.' '.$fname.' '.$lname.'</td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$loginname.'</td>
		<td align="left">)</td>
	</tr>
</table>
		';
		$payee = array('สำหรับลูกค้า / Customer Copy','สำหรับบัญชี / Accounting Department Copy','สำหรับฝ่ายขาย / Sales and Leasing Department Copy');
                $cash_amount = $moneyCash;
                $credit_amount = $moneyCrCard;
		$other_amount = $moneyOther;

		$data['building_name'] = $building_name;
		$data['un_name'] = $un_name;
		$data['type_receipt'] = $type_receipt;
		$data['pj_name'] = $pj_name;
		$data['id'] = $getReceipt->rc_code;
		$data['prefix'] = $prefix;
		$data['fname'] = $fname;
		$data['lname'] = $lname;
		$data['doc_addr'] = $doc_addr;
		$data['doc_sub_district'] = $doc_sub_district;
		$data['doc_district'] = $doc_district;
		$data['doc_province'] = $doc_province;
		$data['doc_zipcode'] = $doc_zipcode;
		$data['receiptText'] = $receiptText;
		$data['total_price'] = $total_price;
		$data['flagCash'] = $flagCash;
		$data['flagCrCard'] = $flagCrCard;
		$data['flagOther'] = $flagOther;
		$data['cash_amount'] = $cash_amount;
		$data['other_amount'] = $other_amount;
		$data['credit_amount'] = $credit_amount;
		$data['credit_bank'] = $credit_bank;
		$data['credit_no'] = $credit_no;
		$data['credit_holder'] = $credit_holder;
		$data['other_by'] = $other_by;
		$data['crdate'] =  !empty($crdate)?$crdate:'';
		$data['type_licence'] = $type_licence;
		$data['payee'] = $payee;
		$data['Currency'] = $this->currency;
		$data['date_receipt'] = $date_receipt;
        $data['htmlRemark'] = $htmlRemark;
        $data['projectImage'] = $projectImage;


		$this->LoadView('Receipt/receipt_report',$data);
	}
    private function CheckTransfers ($cid) {

        $this->load->model('tb_installment');
        $tempPaid = 0;
        $getInstallment = $this->tb_installment->checkPaidForTransferOwnership($cid);
        $getTotalInstallment = $this->tb_installment->totalInstallmentByContractCode($cid);

        if ($getInstallment->allPaid == $getTotalInstallment->totalInstallment) {
            $disabled = null;
        } else {

            $disabled = 'disabled';
        }

        return $disabled;
    }
}

/* End of file installment.php */
/* Location: ./application/controllers/installment.php */
