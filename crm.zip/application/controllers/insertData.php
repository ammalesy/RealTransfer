<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class InsertData extends NZ_Controller {
    
    var $title_page = 'Insert Data';
    var $page_var = 'insertData';
    
    function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $this->view();
    }
    
    public function view()
    {
        $this->checkSessionTimeout();
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        
        $this->load->view('InsertData/insertData_view',$data);
    }
    
    function record()
    {
//        header('Content-type: text/plain; charset=utf-8');
        $this->load->model('tb_bank');
        $this->load->model('tb_building');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_credit_type');
        $this->load->model('tb_payment_terms');
        $this->load->model('tb_user_personal_info');
        $this->load->model('tb_customer_personal_info');
        $cusList = $this->tb_customer_personal_info->get_all();
        $userList = $this->tb_user_personal_info->fetch_all_personal_infoNormal();
        ///////////// OPEN FIRE //////////////
        $fire = $_FILES['import'];
        $csv_mimetypes = array(
            'text/csv',
            'text/plain',
            'application/csv',
            'text/comma-separated-values',
            'application/excel',
            'application/vnd.ms-excel',
            'application/vnd.msexcel',
            'text/anytext',
            'application/octet-stream',
            'application/txt',
        );
        if (!in_array($fire['type'], $csv_mimetypes)) {
            alert_redirect('Format File Invalid','/insertData');
        }
        $flagInsert = TRUE;
        $strCSV[] = "";
        $tmpdate = date("Y_m_d_H_i_s");
        $Str_file = explode(".",$fire['name']);  
        $new_name="data_".$tmpdate.".".$Str_file['1'];
        if(move_uploaded_file($fire["tmp_name"],"csv/".$new_name)) {
            
            $count = 0;
            $length = 0;
            $fail = false;
            $objCSV = fopen("csv/".$new_name, "r");
            while (($objArr = fgetcsv($objCSV, 500000, ",")) !== FALSE) {
                if ($count>1 && !empty($objArr[0])) {
                    $building       = trim($objArr[0]);
//                    $floor          = trim($objArr[1]);
                    $number         = trim($objArr[2]);
                    $cusFname1      = trim($objArr[3]);
                    $cusLname1      = trim($objArr[4]);
                    $cusFname2      = trim($objArr[5]);
                    $cusLname2      = trim($objArr[6]);
                    $cusFname3      = trim($objArr[7]);
                    $cusLname3      = trim($objArr[8]);
                    $cusFname4      = trim($objArr[9]);
                    $cusLname4      = trim($objArr[10]);
                    $paymentTerms   = trim($objArr[11]);
                    $promotion      = trim($objArr[12]);
                    $remark         = trim($objArr[13]);
                    $saleFname      = trim($objArr[14]);
                    $saleLname      = trim($objArr[15]);
                    $payDate        = trim($objArr[16]);
                    $quotationDate        = trim($objArr[17]);
                    $totalMonth     = trim($objArr[18]);
                    $downPercent    = trim($objArr[19]);
                    $unitPrice      = trim($objArr[20]);
                    $downPayment    = trim($objArr[21]);
                    $bookingFee     = trim($objArr[22]);
                    $contractFee    = trim($objArr[23]);
                    $avgInstallment = trim($objArr[24]);
                    $j = 0;
                    for($i=25;$i<35;$i++):
                        $installmentFee[$j] = trim($objArr[$i++]);
                        $installmentMonth[$j] = trim($objArr[$i]);
                        $j++;
                    endfor;
                    $bkDate           = trim($objArr[$i++]);
                    $bkCashAmount     = trim($objArr[$i++]);
                    $bkCreditAmount   = trim($objArr[$i++]);
                    $bkCreditBank     = trim($objArr[$i++]);
                    $bkCreditType     = trim($objArr[$i++]);
                    $bkCreditOwner    = trim($objArr[$i++]);
                    $bkCreditNumber   = trim($objArr[$i++]);
                    $bkCreditApprove  = trim($objArr[$i++]);
                    $bkCreditEXP      = trim($objArr[$i++]);
                    $bkCreditAmount2  = trim($objArr[$i++]);
                    $bkCreditBank2    = trim($objArr[$i++]);
                    $bkCreditType2    = trim($objArr[$i++]);
                    $bkCreditOwner2   = trim($objArr[$i++]);
                    $bkCreditNumber2  = trim($objArr[$i++]);
                    $bkCreditApprove2 = trim($objArr[$i++]);
                    $bkCreditEXP2     = trim($objArr[$i++]);
                    $bkOtherAmount    = trim($objArr[$i++]);
                    $bkOtherType      = trim($objArr[$i++]);
                    $bkCheckNumber    = trim($objArr[$i++]);
                    $bkCheckDate      = trim($objArr[$i++]);
                    $bkCheckBank      = trim($objArr[$i++]);
                    $ctDate           = trim($objArr[$i++]); // 56
                    $ctCashAmount     = trim($objArr[$i++]);
                    $ctCreditAmount   = trim($objArr[$i++]);
                    $ctCreditBank     = trim($objArr[$i++]);
                    $ctCreditType     = trim($objArr[$i++]);
                    $ctCreditOwner    = trim($objArr[$i++]);
                    $ctCreditNumber   = trim($objArr[$i++]);
                    $ctCreditApprove  = trim($objArr[$i++]);
                    $ctCreditEXP      = trim($objArr[$i++]);
                    $ctCreditAmount2  = trim($objArr[$i++]);
                    $ctCreditBank2    = trim($objArr[$i++]);
                    $ctCreditType2    = trim($objArr[$i++]);
                    $ctCreditOwner2   = trim($objArr[$i++]);
                    $ctCreditNumber2  = trim($objArr[$i++]);
                    $ctCreditApprove2 = trim($objArr[$i++]);
                    $ctCreditEXP2     = trim($objArr[$i++]);
                    $ctOtherAmount    = trim($objArr[$i++]);
                    $ctOtherType      = trim($objArr[$i++]);
                    $ctCheckNumber    = trim($objArr[$i++]);
                    $ctCheckDate      = trim($objArr[$i++]);
                    $ctCheckBank      = trim($objArr[$i++]);
                    
                    $building      = $this->tb_building->get_by_name($building)->building_id;
                    $unit          = $this->tb_unit_number->get_detail_by_idAndName($building,$number);
                    $floor         = $unit->un_floor_id;
                    $number        = $unit->un_id;
                    $paymentTerms  = $this->tb_payment_terms->get_by_name($paymentTerms)->pt_id;
//                    $arr           = explode('/',$quotationDate);
//                    $quotationDate = $arr[2].'-'.$arr[1].'-'.$arr[0];
//                    $arr           = explode('/',$bkDate);
//                    $bkDate        = $arr[2].'-'.$arr[1].'-'.$arr[0];
//                    $arr           = explode('/',$ctDate);
//                    $ctDate        = $arr[2].'-'.$arr[1].'-'.$arr[0];
                    
                    if(!empty($bkCreditBank))  {
                        $log = 'Row '.($count+1).' Bank '.$bkCreditBank.' is not data.';
                        $bkCreditBank  = $this->tb_bank->get_id_by_abbreviation($bkCreditBank);
                        if(empty($bkCreditBank)) {
                            $fail = true;
                            break;
                        }
                    }
                    if(!empty($bkCreditBank2)) {
                        $log = 'Row '.($count+1).' Bank '.$bkCreditBank2.' is not data.';
                        $bkCreditBank2  = $this->tb_bank->get_id_by_abbreviation($bkCreditBank2);
                        if(empty($bkCreditBank2)) {
                            $fail = true;
                            break;
                        }
                    }
                    if(!empty($ctCreditBank))  {
                        $log = 'Row '.($count+1).' Bank '.$ctCreditBank.' is not data.';
                        $ctCreditBank  = $this->tb_bank->get_id_by_abbreviation($ctCreditBank);
                        if(empty($ctCreditBank)) {
                            $fail = true;
                            break;
                        }
                    }
                    if(!empty($ctCreditBank2)) {
                        $log = 'Row '.($count+1).' Bank '.$ctCreditBank2.' is not data.';
                        $ctCreditBank2  = $this->tb_bank->get_id_by_abbreviation($ctCreditBank2);
                        if(empty($ctCreditBank2)) {
                            $fail = true;
                            break;
                        }
                    }
                    
                    if(!empty($bkCreditType))  {
                        $log = 'Row '.($count+1).' Credit Type '.$bkCreditType.' is not data.';
                        $bkCreditType  = $this->tb_credit_type->get_by_abbreviation($bkCreditType)->ct_id;
                        if(empty($bkCreditType)) {
                            $fail = true;
                            break;
                        }
                    }
                    if(!empty($bkCreditType2)) {
                        $log = 'Row '.($count+1).' Credit Type '.$bkCreditType2.' is not data.';
                        $bkCreditType2  = $this->tb_credit_type->get_by_abbreviation($bkCreditType2)->ct_id;
                        if(empty($bkCreditType2)) {
                            $fail = true;
                            break;
                        }
                    }
                    if(!empty($ctCreditType))  {
                        $log = 'Row '.($count+1).' Credit Type '.$ctCreditType.' is not data.';
                        $ctCreditType  = $this->tb_credit_type->get_by_abbreviation($ctCreditType)->ct_id;
                        if(empty($ctCreditType)) {
                            $fail = true;
                            break;
                        }
                    }
                    if(!empty($ctCreditType2)) {
                        $log = 'Row '.($count+1).' Credit Type '.$ctCreditType2.' is not data.';
                        $ctCreditType2  = $this->tb_credit_type->get_by_abbreviation($ctCreditType2)->ct_id;
                        if(empty($ctCreditType2)) {
                            $fail = true;
                            break;
                        }
                    }
                    
                    $customer  = NULL;
                    $customer2 = NULL;
                    $customer3 = NULL;
                    $customer4 = NULL;
                    foreach($cusList as $val)
                    {
                        if($cusFname1 == $val->pers_fname && $cusLname1 == $val->pers_lname)
                            $customer = $val->pers_id_cus;
                        else if($cusFname2 == $val->pers_fname && $cusLname2 == $val->pers_lname)
                            $customer2 = $val->pers_id_cus;
                        else if($cusFname3 == $val->pers_fname && $cusLname3 == $val->pers_lname)
                            $customer3 = $val->pers_id_cus;
                        else if($cusFname4 == $val->pers_fname && $cusLname4 == $val->pers_lname)
                            $customer4 = $val->pers_id_cus;
                    }
                    $sale = $this->tb_user_personal_info->get_by_name($saleFname, $saleLname)->user_pers_user_id;
                    
                    ///////////////////  unit Available  //////////////////
                    if($unit->un_status_room != 'Available')
                    {
                        $fail = true;
                        $log = "Row ".($count+1)." Unit: $unit->un_name is not Available.";
                        break;
                    }
                    /////////////////////  Quotation  /////////////////////
                    if(empty($building)||empty($number)||empty($paymentTerms)
                       ||empty($customer)||empty($sale)||empty($quotationDate)
                       ||empty($payDate))
                    {
                        $fail = true;
                        if(empty($customer))
                            $log = "Row ".($count+1)." customer: $cusFname1 $cusLname1 is not data.";
                        else if(empty($sale))
                            $log = "Row ".($count+1)." sale: $cusFname1 $cusLname1 is not data.";
                        else
                            $log = 'Row '.($count+1).' Data invalid. (Tag Gray)';
//                        echo "<script>console.log('$building:$number:$paymentTerms:$cusFname1, $cusLname1,$customer:$saleFname,$saleLname,$sale');</script>";
                        break;
                    }
                    /////////////////////  Payment  //////////////////////
                    if(empty($totalMonth)||empty($downPercent)||empty($unitPrice)||empty($downPayment)
                       ||empty($bookingFee)||empty($contractFee))
                    {
                        $fail = true;
                        $log = 'Row '.($count+1).' Data invalid. (Tag Green)';
                        break;
                    }
                    //////////////////////////////////////////////////////
                    
                    $data[$length]->Building     = $building;
                    $data[$length]->Floor        = $floor;
                    $data[$length]->Unit         = $number;
                    $data[$length]->PaymentTerms = $paymentTerms;
                    $data[$length]->Promotion    = $promotion;
                    $data[$length]->Remark       = $remark;
                    $data[$length]->Customer     = $customer;
                    $data[$length]->Sale         = $sale;
                    $data[$length]->PayDate      = $payDate;
                    $data[$length]->QuotationDate      = $quotationDate;
                    $data[$length]->TotalMonth   = $totalMonth;
                    $data[$length]->DownPercent  = $downPercent;
                    $data[$length]->UnitPrice    = $unitPrice;
                    $data[$length]->DownPayment  = $downPayment;
                    $data[$length]->BookingFee   = $bookingFee;
                    $data[$length]->ContractFee  = $contractFee;
                    $data[$length]->AvgInstallment  = $avgInstallment;
                    foreach($installmentFee as $index=>$val):
                        $data[$length]->InstallmentFee[$index]   = $installmentFee[$index];
                        $data[$length]->InstallmentMonth[$index] = $installmentMonth[$index];
                    endforeach;
                    ////////////  Booking  ///////////////
                    $data[$length]->BookingDate                      = $bkDate;
                    $data[$length]->BookingPayment['CashAmount']     = $bkCashAmount;
                    $data[$length]->BookingPayment['CreditAmount']   = $bkCreditAmount;
                    $data[$length]->BookingPayment['CreditBank']     = $bkCreditBank;
                    $data[$length]->BookingPayment['CreditType']     = $bkCreditType;
                    $data[$length]->BookingPayment['CreditOwner']    = $bkCreditOwner;
                    $data[$length]->BookingPayment['CreditNumber']   = $bkCreditNumber;
                    $data[$length]->BookingPayment['CreditApprove']  = $bkCreditApprove;
                    $data[$length]->BookingPayment['CreditEXP']      = $bkCreditEXP;
                    $data[$length]->BookingPayment['CreditAmount2']  = $bkCreditAmount2;
                    $data[$length]->BookingPayment['CreditBank2']    = $bkCreditBank2;
                    $data[$length]->BookingPayment['CreditType2']    = $bkCreditType2;
                    $data[$length]->BookingPayment['CreditOwner2']   = $bkCreditOwner2;
                    $data[$length]->BookingPayment['CreditNumber2']  = $bkCreditNumber2;
                    $data[$length]->BookingPayment['CreditApprove2'] = $bkCreditApprove2;
                    $data[$length]->BookingPayment['CreditEXP2']     = $bkCreditEXP2;
                    $data[$length]->BookingPayment['OtherAmount']    = $bkOtherAmount;
                    $data[$length]->BookingPayment['OtherType']      = $bkOtherType;
                    $data[$length]->BookingPayment['CheckNumber']    = $bkCheckNumber;
                    $data[$length]->BookingPayment['CheckDate']      = $bkCheckDate;
                    $data[$length]->BookingPayment['CheckBank']      = $bkCheckBank;
                    //////////////////////////////////////
                    
                    ////////////  Contract  //////////////
                    $data[$length]->ContractDate                      = $ctDate;
                    $data[$length]->ContractPayment['CashAmount']     = $ctCashAmount;
                    $data[$length]->ContractPayment['CreditAmount']   = $ctCreditAmount;
                    $data[$length]->ContractPayment['CreditBank']     = $ctCreditBank;
                    $data[$length]->ContractPayment['CreditType']     = $ctCreditType;
                    $data[$length]->ContractPayment['CreditOwner']    = $ctCreditOwner;
                    $data[$length]->ContractPayment['CreditNumber']   = $ctCreditNumber;
                    $data[$length]->ContractPayment['CreditApprove']  = $ctCreditApprove;
                    $data[$length]->ContractPayment['CreditEXP']      = $ctCreditEXP;
                    $data[$length]->ContractPayment['CreditAmount2']  = $ctCreditAmount2;
                    $data[$length]->ContractPayment['CreditBank2']    = $ctCreditBank2;
                    $data[$length]->ContractPayment['CreditType2']    = $ctCreditType2;
                    $data[$length]->ContractPayment['CreditOwner2']   = $ctCreditOwner2;
                    $data[$length]->ContractPayment['CreditNumber2']  = $ctCreditNumber2;
                    $data[$length]->ContractPayment['CreditApprove2'] = $ctCreditApprove2;
                    $data[$length]->ContractPayment['CreditEXP2']     = $ctCreditEXP2;
                    $data[$length]->ContractPayment['OtherAmount']    = $ctOtherAmount;
                    $data[$length]->ContractPayment['OtherType']      = $ctOtherType;
                    $data[$length]->ContractPayment['CheckNumber']    = $ctCheckNumber;
                    $data[$length]->ContractPayment['CheckDate']      = $ctCheckDate;
                    $data[$length]->ContractPayment['CheckBank']      = $ctCheckBank;
                    //////////////////////////////////////
                    
                    $length++;
                }
                $count++;
            }
        }
        //////////////////////////////////////
        if($fail) {
            echo "
                <script>
                    alert('$log');
                    history.back();
                </script>
            ";
            exit;
        }
        
        foreach($data as $val) {
            $qtCode = $this->insertQuotation($val);
            if(!empty($val->BookingDate) && (!empty($val->BookingPayment['CashAmount'])
               ||!empty($val->BookingPayment['CreditAmount'])
               ||!empty($val->BookingPayment['OtherAmount'])))
            {
                $bkCode = $this->insertBooking($val, $qtCode);
                if(!empty($val->ContractDate)&&(!empty($val->ContractPayment['CashAmount'])
                   ||!empty($val->ContractPayment['CreditAmount'])
                   ||!empty($val->ContractPayment['OtherAmount'])))
                {
                    $this->insertContract($val, $bkCode);
                }
            }
        }
        
        echo "
            <script>
                alert('Insert Data Success.');
                window.location.href = '".BASE_DOMAIN."insertData'
            </script>";
    }
    
    function insertQuotation($data)
    {
        date_default_timezone_set('Asia/Bangkok');
        ///////////  input  /////////////////
        $leads            = $data->Customer;
        $Building         = $data->Building;
        $Floor            = $data->Floor;
        $Number           = $data->Unit;
        $PaymentTerms     = $data->PaymentTerms;
        $qremark          = $data->Remark;
        $promotiomQuo     = $data->Promotion;
        $sale             = $data->Sale;
        $unitPrice        = $data->UnitPrice;
        $totalDownPayment = $data->DownPayment;
        $percent          = $data->DownPercent;
        $booking          = $data->BookingFee;
        $contract         = $data->ContractFee;
        $avgInstallment   = $data->AvgInstallment;
        $totalMonth       = $data->TotalMonth;
        $installmentFee   = $data->InstallmentFee;
        $installmentMonth = $data->InstallmentMonth;
        $today            = $data->QuotationDate;
        $Project          = $this->project_id_sel;
        $pj_name          = $this->project_name_sel;
        /////////////////////////////////////
        
        ///////////  modal  /////////////////
        $this->load->model('tb_quotation');
        $this->load->model('tb_room_status');
        ////////////////////////////////////
        
        ///////////  code  /////////////////
        $newid = $this->tb_quotation->get_new_id($Project);
        $tmp = strlen($newid);
        $tmpProjectid = strlen($Project);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) { 
            $tmpID .= '0';
        }
        $tmptmp = strlen($newid);
        $tmpIDP = '';
        for ($i=$tmpProjectid; $i < 2 ; $i++) { 
            $tmpIDP .= '0';
        }
        $dateQuo = date("ymd"); 
        $newid ='Q'.$tmpIDP.$Project.'-'.$dateQuo.'-'.$tmpID.''.$newid;
        ////////////////////////////////////
        
        ///////////// record ///////////////
        $maxLoop = 20;
        if(!empty($avgInstallment)) {
            $data_quotation = array(
                'qt_code' => $newid,
                'qt_leads_id' => $leads,
                'qt_project_id' => $Project,
                'qt_buliding_id' => $Building,
                'qt_floor_id' => $Floor,
                'qt_unit_number_id' => $Number,
                'qt_sale_id' => $sale,
                'qt_payment_terms' => $PaymentTerms,
                'qt_date' => $today,
                'qt_promotion' => $promotiomQuo,
                'qt_remark' => $qremark,
                'qt_unit_price' => $unitPrice,
                'qt_total_down_payment' => $totalDownPayment,
                'qt_total_down_percent' => $percent,
                'qt_booking_fee' => $booking,
                'qt_contract_fee' => $contract,
                'qt_avg_installment' => $avgInstallment,
                'qt_total_months' => $totalMonth
            );
        }else {
            $data_quotation = array(
                'qt_code' => $newid,
                'qt_leads_id' => $leads,
                'qt_project_id' => $Project,
                'qt_buliding_id' => $Building,
                'qt_floor_id' => $Floor,
                'qt_unit_number_id' => $Number,
                'qt_sale_id' => $sale,
                'qt_payment_terms' => $PaymentTerms,
                'qt_date' => $today,
                'qt_promotion' => $promotiomQuo,
                'qt_remark' => $qremark,
                'qt_unit_price' => $unitPrice,
                'qt_total_down_payment' => $totalDownPayment,
                'qt_total_down_percent' => $percent,
                'qt_booking_fee' => $booking,
                'qt_contract_fee' => $contract,
                'qt_total_months' => $totalMonth
            );
            for($i=1;$i<=$maxLoop;$i++):
                $data_quotation['qt_installment'.$i] = $installmentFee[$i-1];
                $data_quotation['qt_months_installment'.$i] = $installmentMonth[$i-1];
            endfor;
        }
        $this->tb_quotation->record($data_quotation);

        $data_room_sts = array(
            'rs_unit_number' => $Number,
            'rs_cus_id' => $leads,
            'rs_status' => 'Quotation',
            'rs_staff_id' => $sale
        );
        $this->tb_room_status->record($data_room_sts);
        ////////////////////////////////////
        
        return $newid;
    }
    
    function insertBooking($data, $qtCode)
    {
        date_default_timezone_set('Asia/Bangkok');
        ///////////////////  input  ///////////////////
        $payDay                 = $data->PayDate;
        $buildingid             = $data->Building;
        $unitnumberid           = $data->Unit;
        $cusid                  = $data->Customer;
        $remark                 = $data->Remark;
        $sale                   = $data->Sale;
        $MoneyAmount            = $data->BookingFee;
        $bk_cash_amount         = $data->BookingPayment['CashAmount'];
        $bk_crcard_amount       = $data->BookingPayment['CreditAmount'];
        $b_id                   = $data->BookingPayment['CreditBank'];
        $bk_credit_type_credit  = $data->BookingPayment['CreditType'];
        $bk_crcard_fname        = $data->BookingPayment['CreditOwner'];
        $bk_crcard_no           = $data->BookingPayment['CreditNumber'];
        $bk_credit_approve_code = $data->BookingPayment['CreditApprove'];
        $bk_crcard_date         = $data->BookingPayment['CreditEXP'];
        $bk_crcard_amount2       = $data->BookingPayment['CreditAmount2'];
        $b_id2                   = $data->BookingPayment['CreditBank2'];
        $bk_credit_type_credit2  = $data->BookingPayment['CreditType2'];
        $bk_crcard_fname2        = $data->BookingPayment['CreditOwner2'];
        $bk_crcard_no2           = $data->BookingPayment['CreditNumber2'];
        $bk_credit_approve_code2 = $data->BookingPayment['CreditApprove2'];
        $bk_crcard_date2         = $data->BookingPayment['CreditEXP2'];
        $bk_other_amount        = $data->BookingPayment['OtherAmount'];
        $bk_other_by            = $data->BookingPayment['OtherType'];
        $pm_check_number        = $data->BookingPayment['CheckNumber'];
        $pm_check_date          = $data->BookingPayment['CheckDate'];
        $pm_check_bank          = $data->BookingPayment['CheckBank'];
        $today                  = $data->BookingDate;
        $quoCode                = $qtCode;
        $contract_date          = date("Y-m-d", strtotime("+2week", strtotime($today)));
        $projectid              = $this->project_id_sel;
        ///////////////////////////////////////////////
        
        //////////////////  modal  ////////////////////
        $this->load->model('tb_quotation');
        $this->load->model('tb_booking');
        $this->load->model('tb_receipt_temporary');
        $this->load->model('tb_contract_promotion');
        $this->load->model('tb_room_status');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_customer_project');
        $this->load->model('tb_payment');
        $this->load->model('tb_bank');
        ///////////////////////////////////////////////
        
        //////////////////  code  /////////////////////
        $newid= $this->tb_booking->get_new_booking_id($projectid);
        $tmp = strlen($newid);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) { 
            $tmpID .= '0';
        }
        $tmptmp = strlen($projectid);
        $tmpIDP = '';
        for ($i=$tmptmp; $i < 2 ; $i++) { 
            $tmpIDP .= '0';
        }
        $dateQuo = date("ymd"); 

        $newbid ='B'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid;
        ///////////////////////////////////////////////
        
        //////////////////  customer  /////////////////
        if(empty($this->tb_customer_project->get_id_by_cus($cusid))) 
        {
            $data = array(
                'cp_cus_id' => $cusid,
                'cp_project_id' => $projectid
            );
            $this->tb_customer_project->record($data);
        }
        ///////////////////////////////////////////////
        
        ////////////////  room status  ////////////////
        $unitnumber = $this->tb_unit_number->get_detail_unit_by_un_id($unitnumberid)->un_name;
        $data = array(
            'un_status_room' => 'Booked'
        );
        $this->tb_unit_number->update_where($data,"un_id = '$unitnumberid' AND un_name = '$unitnumber' AND un_build_id = '$buildingid' AND un_status_room = 'Available'");  
        ///////////////////////////////////////////////

        /////////////////  quotation  /////////////////
        $data = array(
            'qt_status' => 'off'
        );
        $this->tb_quotation->update($data,$quoCode);
        ///////////////////////////////////////////////
        
        /////////////////  booking  ///////////////////
        $data = array(
            'bk_booking_code' => $newbid,
            'bk_quotation_code' => $quoCode,
            'bk_leads_id' => $cusid,
            'bk_project_id' => $projectid,
            'bk_money_amount' => $MoneyAmount,
            'bk_date_booking' => $today,
            'bk_contract_date' => $contract_date,
            'bk_pay_day' => $payDay,
            'bk_remark' => $remark,
            'bk_staff_id' => $sale
        );
        $this->tb_booking->record($data);
        ///////////////////////////////////////////////
        
        //////////////////  receipt  //////////////////
        $newid = $this->tb_receipt_temporary->get_next_id();
        $tmp = strlen($newid);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) {
            $tmpID .= '0';
        }
        $newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid;

        $data_receipt = array(
            'rc_code' => $newrcv,
            'rc_customer_id' => $cusid,
            'rc_payfor' => 'Booking Fee',
            'rc_booking_code' => $newbid,
            'rc_total_amount' => $MoneyAmount,
            'rc_staff_temporary' => $sale,
            'rc_temporary_date' => date('Y-m-d H:i:s'),
            'rc_un_name' => $unitnumber
        );
        $this->tb_receipt_temporary->record($data_receipt);
        ///////////////////////////////////////////////
        
        /////////////////  promotion  /////////////////
        foreach ($this->input->post('pro') as $key => $value) {
            $data_promotion = array(
                'cp_booking_code' => $newbid,
                'cp_promotion_id' => $value
            );
            $this->tb_contract_promotion->record($data_promotion);
        }
        ///////////////////////////////////////////////
        
        ////////////////  room status  ////////////////
        $data_room = array(
            'rs_unit_number' => $unitnumberid,
            'rs_cus_id' => $cusid,
            'rs_status' => 'Booking',
            'rs_staff_id' => $sale
        );
        $this->tb_room_status->record($data_room);
        ///////////////////////////////////////////////
        
        //////////////////  payment  //////////////////
        if(!empty($bk_cash_amount)) {
            $data = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $bk_cash_amount
            );
            $this->tb_payment->record($data);
        }
        $this->load->library('encrypt');
        if(!empty($bk_crcard_amount)) {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Credit',
                'pm_amount' => $bk_crcard_amount,
                'pm_cr_bank' => $b_id,
                'pm_cr_type' => $bk_credit_type_credit,
                'pm_cr_holder' => $bk_crcard_fname,
                'pm_cr_number' => $this->encrypt->encode($bk_crcard_no),
                'pm_cr_approve_code' => $bk_credit_approve_code,
                'pm_cr_expire' => $bk_crcard_date
            );
           $this->tb_payment->record($data_payment);
        }if(!empty($bk_crcard_amount2)) {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Credit',
                'pm_amount' => $bk_crcard_amount2,
                'pm_cr_bank' => $b_id2,
                'pm_cr_type' => $bk_credit_type_credit2,
                'pm_cr_holder' => $bk_crcard_fname2,
                'pm_cr_number' => $this->encrypt->encode($bk_crcard_no2),
                'pm_cr_approve_code' => $bk_credit_approve_code2,
                'pm_cr_expire' => $bk_crcard_date2
            );
           $this->tb_payment->record($data_payment);
        }
        if(!empty($bk_other_amount)) {
            if($bk_other_by == 'Check'){
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Check',
                    'pm_amount' => $bk_other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank
                );
            }else
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $bk_other_by,
                    'pm_amount' => $bk_other_amount
                );
           $this->tb_payment->record($data_payment);
        }
        ///////////////////////////////////////////////
        
        return $newbid;
    }
    
    function insertContract($data, $bkCode)
    {
        date_default_timezone_set('Asia/Bangkok');
        ///////////////  input  //////////////////
        $cus          = $data->Customer.(empty($data->Customer2)?'':','.$data->Customer2).
            (empty($data->Customer3)?'':','.$data->Customer3);
        $unitnumberid = $data->Unit;
        $remark       = $data->Remark;
        $sale         = $data->Sale;
        $contractfee  = $data->ContractFee;
        $ct_amount          = $data->ContractPayment['CashAmount'];
        $b_id               = $data->ContractPayment['CreditBank'];
        $ct_cr_type         = $data->ContractPayment['CreditType'];
        $ct_cr_approve_code = $data->ContractPayment['CreditApprove'];
        $ct_cr_number       = $data->ContractPayment['CreditNumber'];
        $ct_cr_expire       = $data->ContractPayment['CreditEXP'];
        $ct_crcard_amount   = $data->ContractPayment['CreditAmount'];
        $ct_cr_holder       = $data->ContractPayment['CreditOwner'];
        $b_id2               = $data->ContractPayment['CreditBank2'];
        $ct_cr_type2         = $data->ContractPayment['CreditType2'];
        $ct_cr_approve_code2 = $data->ContractPayment['CreditApprove2'];
        $ct_cr_number2       = $data->ContractPayment['CreditNumber2'];
        $ct_cr_expire2       = $data->ContractPayment['CreditEXP2'];
        $ct_crcard_amount2   = $data->ContractPayment['CreditAmount2'];
        $ct_cr_holder2       = $data->ContractPayment['CreditOwner2'];
        $ct_other_by        = $data->ContractPayment['OtherType'];
        $ct_other_amount    = $data->ContractPayment['OtherAmount'];
        $pm_check_number    = $data->ContractPayment['CheckNumber'];
        $pm_check_date      = $data->ContractPayment['CheckDate'];
        $pm_check_bank      = $data->ContractPayment['CheckBank'];
        $installmentMonth   = $data->TotalMonth;
        $today        = $data->ContractDate;
        $bookCode     = $bkCode;
        $projectid    = $this->project_id_sel;
        //////////////////////////////////////////
        
        ////////////////  model  /////////////////
        $this->load->model('tb_project');
        $this->load->model('tb_payment');
        $this->load->model('tb_booking');
        $this->load->model('tb_contract');
        $this->load->model('tb_installment');
        $this->load->model('tb_room_status');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_customer_project');
        $this->load->model('tb_receipt_temporary');
        $this->load->model('tb_transfer_ownership');
        //////////////////////////////////////////
        
        ////////////////  code  //////////////////
        $newid = $this->tb_contract->get_new_contract_id($this->project_id_sel);
        $tmp   = strlen($newid);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) { 
            $tmpID .= '0';
        }
        $tmptmp = strlen($projectid);
        $tmpIDP = '';
        for ($i=$tmptmp; $i < 2 ; $i++) {
            $tmpIDP .= '0';
        }
        
        $booking = $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bookCode);
        
        $dateQuo = date("ymd"); 
        $newid ='C'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid;
        //////////////////////////////////////////
        
        ///////////////  booking  ////////////////
        if($this->tb_booking->get_detail_by_bk_booking_code($bookCode)->bk_status === 'on') {
            $data_booking = array('bk_status' => 'off');
            $this->tb_booking->update($data_booking,$bookCode);
        }
        //////////////////////////////////////////
        
        //////////////  contract  ////////////////
        $data_contract = array(
            'ct_code' => $newid,
            'ct_booking_code' => $bookCode,
            'ct_cus_id' => $cus,
            'ct_type' => 'people',
            'ct_date' => $booking->bk_contract_date,
            'ct_pay_day' => $booking->bk_pay_day,
            'ct_staff_id' => $sale,
            'ct_project_id' => $projectid,
            'ct_paid' => 'yes',
            'ct_active' => 'off',  ///////////////
            'ct_remark' => $remark,
            'ct_temp_receipt_date' => $today
        );
        $this->tb_contract->record($data_contract);
        //////////////////////////////////////////
        
        /////////////////  unit  /////////////////
        $unitnumber = $this->tb_unit_number->get_detail_unit_by_un_id($unitnumberid)->un_name;
        $data_unit_number = array(
            'un_status_room' => 'Sold'
        );
        $this->tb_unit_number->update_where($data_unit_number,"un_id = '$unitnumberid' AND un_name = '$unitnumber' AND un_status_room = 'Booked'");
        //////////////////////////////////////////
        
        ///////////////  customer  ///////////////
        $ctCode = $newid;
        $ctDetail = $this->tb_contract->get_detail_by_ct_code($ctCode);
        foreach(explode(',', $ctDetail->ct_cus_id) as $val) {
            if( empty( $this->tb_customer_project->get_id_by_cus($val) ) ) {
                $data = array(
                    'cp_cus_id' => $val,
                    'cp_project_id' => $projectid
                );
                $this->tb_customer_project->record($data);
            }
        }
        /////////////////////////////////////////
        
        //////////////  room status  /////////////
        $data_room_sts = array(
            'rs_unit_number' => $unitnumberid,
            'rs_cus_id' => $cus,
            'rs_status' => 'Make Contract',
            'rs_staff_id' => $sale
        );
        $this->tb_room_status->record($data_room_sts);
        $data_room_sts = array(
            'rs_unit_number' => $unitnumberid,
            'rs_cus_id' => $cus,
            'rs_status' => 'Temp receipt for contract',
            'rs_staff_id' => $sale
        );
        $this->tb_room_status->record($data_room_sts);
        //////////////////////////////////////////
        
        //////////////  installment  /////////////
        $this->load->library('payment');
        $unit_name = '';
        for($i = strlen($unitnumber);$i<4;$i++){
            $unit_name .= '0';
        }
        $unit_name .= $unitnumber;
        $imcode = 'IM-'.$unit_name.'-';
        // // // // // // // // // // // // // //
        $bkDetail = $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bkCode);
        $projectDetail = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($bkDetail->bk_project_id);
        $startDate = strtotime($projectDetail->pj_end_downpayment);
        $startDate = strtotime("-$installmentMonth month", $startDate);
        
        $Arr = (array)$bkDetail;
//        foreach($bkDetail as $index=>$value) $Arr[$index] = $value;
        for ($i=1; $i <= $installmentMonth; $i++) {
            $final = date("Y-m-".$ctDetail->ct_pay_day, strtotime("+$i month", $startDate));    
            
            $temp = '';
            for($j = strlen($i);$j<2;$j++){
                $temp .= '0';
            }
            
            $installmantfee_paymant = $this->payment->getDefinefee($temp.$i, $Arr);
            
            $data_installment = array(
                'im_code' => $imcode.$temp.$i,
                'im_contract_code' => $ctCode,
                'im_cus_id' => $ctDetail->ct_cus_id,
                'im_installment_time' => $temp.$i,
                'im_duedate' => $final,
                'im_fee_define' => $installmantfee_paymant,
            );
            $this->tb_installment->record($data_installment);
        }
        /////////////////////////////////////////
        
        /////////////  promotion  ///////////////
        $oldProID = array();
        foreach ($this->tb_contract_promotion->get_detail_by_bk_code($bkCode) as $key => $value) {
            $oldProID[] = $value->cp_promotion_id;
            $data_promotion = array(
                'cp_contract_code' => $ctCode
            );
            $this->tb_contract_promotion->update($data_promotion,$value->cp_id);
        }
        foreach ($this->input->post('pro') as $key => $value) {
            if(!in_array($value, $oldProID)) {
                $data_promotion = array(
                    'cp_contract_code' => $ctCode,
                    'cp_booking_code'  => $bkCode,
                    'cp_promotion_id'  => $value
                );
                $this->tb_contract_promotion->record($data_promotion);
            }
        }
        /////////////////////////////////////////
        
        ////////////  temp receipt  /////////////
        $newid = $this->tb_receipt_temporary->get_next_id();
        $tmp   = strlen($newid);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) { 
            $tmpID .= '0';
        }
        $projectid = $this->project_id_sel;
        $tmptmp = strlen($projectid);
        $tmpIDP = '';
        for ($i=$tmptmp; $i < 2 ; $i++) {
            $tmpIDP .= '0';
        }
        
        $dateQuo = date("ymd"); 
        $newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid; 
        $receiptID = implode(',', $this->input->post('receiptID'));
        $data_receipt = array(
            'rc_code' => $newrcv,
            'rc_refer_form' => $receiptID,
            'rc_customer_id' => $ctDetail->ct_cus_id,
            'rc_payfor' => 'Contract Fee',
            'rc_booking_code' => $bkCode,
            'rc_contract_code' => $ctCode,
            'rc_total_amount' => $contractfee,
            'rc_temporary_date' => $today,
            'rc_staff_temporary' => $sale,
            'rc_un_name' => $unitnumber
        );
        $this->tb_receipt_temporary->record($data_receipt);
        /////////////////////////////////////////
        
        ///////////////  payment  ///////////////
        $this->load->library('encrypt');
        if(!empty($ct_amount)) {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $ct_amount,
            );
            $this->tb_payment->record($data_payment);
        }
        if(!empty($ct_crcard_amount)) {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Credit',
                'pm_amount' => $ct_crcard_amount,
                'pm_cr_bank' => $b_id,
                'pm_cr_type' => $ct_cr_type,
                'pm_cr_holder' => $ct_cr_holder,
                'pm_cr_number' => $this->encrypt->encode($ct_cr_number),
                'pm_cr_approve_code' => $ct_cr_approve_code,
                'pm_cr_expire' => $ct_cr_expire
            );
            $this->tb_payment->record($data_payment);
        }
        if(!empty($ct_crcard_amount2)) {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Credit',
                'pm_amount' => $ct_crcard_amount2,
                'pm_cr_bank' => $b_id2,
                'pm_cr_type' => $ct_cr_type2,
                'pm_cr_holder' => $ct_cr_holder2,
                'pm_cr_number' => $this->encrypt->encode($ct_cr_number2),
                'pm_cr_approve_code' => $ct_cr_approve_code2,
                'pm_cr_expire' => $ct_cr_expire2
            );
            $this->tb_payment->record($data_payment);
        }
        if(!empty($ct_other_amount)) {
            if($ct_other_by == 'Check'){
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $ct_other_by,
                    'pm_amount' => $ct_other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank                     
                );
            }else {
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $ct_other_by,
                    'pm_amount' => $ct_other_amount                   
                );
            }
            $this->tb_payment->record($data_payment);
        }
        /////////////////////////////////////////
        
        ///////////////// transfer ownership //////////////////
        $trNewID = $this->tb_transfer_ownership->get_next_id();
        $tmpID = '';
        for($i=strlen($trNewID);$i<5;$i++)
            $tmpID.= '0';
        $tmpIDP = '';
        for ($i=strlen($projectid); $i < 2 ; $i++) {
            $tmpIDP .= '0';
        }
        $trCode = 'TR'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$trNewID;
        
        $amount = $bkDetail->qt_unit_price - $bkDetail->qt_total_down_payment;
        
        $dataTransferOwnership = array(
            'tr_code'           => $trCode,
            'tr_contract_code'  => $ctCode,
            'tr_customer_id'    => $ctDetail->ct_cus_id,
            'tr_unit_number_id' => $unitnumberid,
            'tr_amount'         => $amount
        );
        $this->tb_transfer_ownership->record($dataTransferOwnership);
        //////////////////////////////////////////////////////////////
    }
    
    public function download_csv(){
        $this->load->helper('download');
        $data = file_get_contents("csvTemplate/insertCSV.xlsx"); 
        $name = 'insertCSV.xlsx';
        force_download($name, $data);
    }
    
    public function download_example_csv(){
        $this->load->helper('download');
        $data = file_get_contents("csvTemplate/exampleInsertCSV.xlsx"); 
        $name = 'exampleInsertCSV.xlsx';
        force_download($name, $data);
    }
}
?>