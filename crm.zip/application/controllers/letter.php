<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Letter extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view_building(); 
	}
	/*----------------------------------*/
	/*------WarningBookingLetter--------*/
	/*----------------------------------*/
	public function warningBookingLetter(){
		$data['title'] = $this->title_page;
		$data['page'] = 'letter';
		$data['permission'] = $this->get_user_permission();
		$data['list_letter'] = $this->fetch_booking_warning_letter();
		$this->load->view('Letter/warningBooking/warningBooking',$data);	
	}
	public function warningBookingLetter_record(){


		$bcode = $this->input->post('bcode');
		$sale = $this->user_id;
        
        $cusid     = $this->input->post("cus");
        $unitid    = $this->input->post("unitid");
        $unitno    = $this->input->post("unt");
        $building  = $this->input->post("building");
        $custname  = $this->input->post("cusname");
        $reason    = $this->input->post("reason");
        $this->load->model('tb_booking');
		$this->load->model('tb_letter_booking_warning');
		$this->load->model('tb_room_status');

		$newid= $this->tb_letter_booking_warning->get_new_letter_id();
		$tmp = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($this->project_id_sel);
        $tmptmp = $tmptmp == 0?1:$tmptmp;
		$tmpIDP = '';

		for ($i=$tmptmp; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateContract = date("ymd"); 

		$newid ='L'.$tmpIDP.$this->project_id_sel.'-'.$dateContract.'-'.$tmpID.''.$newid; 

		$data_update = array(
			'bk_letter_warning' => 'sent',
		  	'bk_remark' => $reason
		);
		$this->tb_booking->update($data_update,$bcode);
		
		$objResult = $this->tb_booking->get_detail_by_bk_booking_code($bcode);

		$bkdate = date('d/m/Y',strtotime($objResult->bk_time_stamp));
        $bkno   = $objResult->bk_booking_code;
        $bkdue  = $objResult->bk_date_booking;
        $bkfee  = $objResult->bk_money_amount;
        $bkdue  = date('d/m/Y',strtotime($objResult->bk_contract_date));
        $ltdate = date('d/m/Y');

		$data_letter = array(
			'lt_code' => $newid,
			'lt_cus_id' => $objResult->bk_leads_id,
			'lt_project_id' => $this->project_id_sel,
			'lt_booking_id' => $bcode
		);
		$this->tb_letter_booking_warning->record($data_letter);

		$data_roomSts = array(
			'rs_unit_number' => $unitid,
			'rs_cus_id' => $cusid,
			'rs_status' => 'Warning Booking',
			'rs_staff_id' => $sale
		);
		$this->tb_room_status->record($data_roomSts);
		
		//echo "<script>  window.open('letterWarningBookingReport.php?actionid=$bcode&ltdat=$ltdate&bkno=$bkno&bkdat=$bkdate&bkfee=$bkfee&due=$bkdue&building=$building&unt=$unitno&cus=$custname','_blank'); </script>";
		redirect('/overdue/booking');
	}
	public function warningBookingReport($language, $ltCode){
        
        $this->load->library('DateFormat');
        
        $this->load->model('tb_letter_booking_warning');
        $this->load->model('tb_quotation');
        $this->load->model('tb_booking');
        $this->load->model('tb_project');
        $this->load->model('tb_unit_number');
        
        $ltDetail = $this->tb_letter_booking_warning->get_detail_by_code($ltCode);
        
        $bkDetail = $this->tb_booking->get_fullDetail_by_bk_booking_code($ltDetail->lt_booking_id);
        
        $pdb = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($bkDetail->bk_project_id);
        
        $cusName = $bkDetail->pers_prefix.' '.$bkDetail->pers_fname.' '.$bkDetail->pers_lname;
        
        $qtDetail = $this->tb_quotation->getDetail_by_id($bkDetail->bk_quotation_code);
        $unit = $this->tb_unit_number->get_detail_unit($qtDetail->qt_unit_number_id);
        
        $data['ltDetail'] = $ltDetail;
        $data['bkDetail'] = $bkDetail;
        $data['project'] = $pdb;
        $data['customerName'] = $cusName;
        $data['unit'] = $unit;
                
        if($language == 'th')
            $this->load->view('Letter/warningBooking/warningBooking_report',$data);
        else
            $this->load->view('Letter/warningBooking/warningBooking_report_en',$data);
	}
	/*----------------------------------*/
	/*------TransferBookingLetter-------*/
	/*----------------------------------*/
	public function transferBookingLetter(){
		$data['title'] = $this->title_page;
		$data['page'] = "tranferBooking";
		$data['permission'] = $this->get_user_permission();
		$data['list_letter'] = $this->fetch_letter_transfer_booking();
		$this->load->view('Letter/transferBooking/transferBooking',$data);
	}
	public function transferBookingLetter_record($bookCode=null){
		$this->load->model('tb_booking');
		$this->load->model('tb_transfer_booking');
		$this->load->model('tb_room_status');
 
		$sale = $this->user_id;
		$cus = '';
		$count =0;
		$unitnumber = $this->input->post('unitnumber');
		$oldCus = $this->input->post('oldCus');
		
		$flagCusId1 = TRUE;
	
		$cus1 = $this->input->post('user_fullname1');
		
		if ($cus1!=NULL) {

		$cusid_post = $this->input->post('cusid');
		if ($cusid_post[0]==0) {
				$flagCusId1 = FALSE;
			}
		}
	
		if ($flagCusId1==FALSE) {
				echo "<script> alert('Can not create contract , Please check customer');  history.back();</script>";
				exit;
		}
		
		
		$cusid = $this->input->post('cusid');
		$newid= $this->tb_booking->get_new_booking_id($this->project_id_sel);
		$tmp = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 4 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($projectid);
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 3 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateQuo = date("ymd"); 
		$newid ='B'.$tmpIDP.$this->project_id_sel.'-'.$dateQuo.'-'.$tmpID.''.$newid; 
	
		$today = date("Y-m-d"); 
		
		$bk_obj = $this->tb_booking->get_detail_by_bk_booking_code($bookCode);
		$data_add_booking = array(
			'bk_booking_code' => $newid,
			'bk_quotation_code' => $bk_obj->bk_quotation_code,
			'bk_leads_id' => $cusid,
			'bk_project_id' => $bk_obj->bk_project_id,
			'bk_type_payment' => $bk_obj->bk_type_payment,
			'bk_crcard_bank' => $bk_obj->bk_crcard_bank,
			'bk_crcard_no' => $bk_obj->bk_crcard_no,
			'bk_crcard_date' => $bk_obj->bk_crcard_date,
			'bk_other_by' => $bk_obj->bk_other_by,
			'bk_money_amount' => $bk_obj->bk_money_amount,
			'bk_date_booking' => $bk_obj->bk_date_booking,
			'bk_contract_date' => $bk_obj->bk_contract_date,
			'bk_staff_id' => $bk_obj->bk_staff_id
		);
		$this->tb_booking->record($data_add_booking);
		 
		$data_add_renfbk = array(
			'tf_from_cus' => $oldCus,
			'tf_to_cus' => $cusid,
			'tf_room' => $unitnumber,
			'tf_booking_id' => $newid
		);
		$this->tb_transfer_booking->record($data_add_renfbk);

		$data_update_bk = array(
			'bk_status' => 'off'
		);
		$this->tb_booking->update($data_update_bk,$bookCode);

		$data_add_roomsts = array(
			'rs_unit_number' => $unitnumber,
			'rs_cus_id' => $cusid,
			'rs_status' => 'Transfer Booking'
		);
		$this->tb_room_status->record($data_add_roomsts);
		
		
		//echo "<script>  window.open('transferBookingReport.php?actionid=$bcode','_blank'); </script>";
		redirect('/letter/transferBookingLetter');
	}
	public function transferBookingLetter_adding($bookCode=null){
		$this->load->model('tb_booking');
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_customer');
		$this->load->model('tb_quotation');
		$this->load->model('tb_building');
		$this->load->model('tb_unit_number');
		$this->load->model('tb_price');
		$this->load->model('tb_promotion');
		$this->load->model('tb_payment_terms');

		$data['title'] = $this->title_page;
		$data['page'] = "tranferBooking";
		$data['permission'] = $this->get_user_permission();
		
		$data['bookCode'] = $bookCode;

		$act = $_GET['act'];
		if(!isset($bookCode)){
			redirect('/letter/transferBookingLetter_searching');
		}

		$getQuocode= $this->tb_booking->get_detail_by_bk_booking_code($bookCode);
		$quoCode = $getQuocode->bk_quotation_code;
		$bookingDeposit = $getQuocode->bk_money_amount;	
		$bookingCusid = $getQuocode->bk_leads_id;	
		
		$getBookingName= $this->tb_customer->get_detail_leads_withOut_oppotunityStageAndActive($bookingCusid);
		$BookingName = $getBookingName->pers_fname.' '.$getBookingName->pers_lname;
				

		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);	
		$Project = 	$getQuo->qt_project_id;
		$Building =$getQuo->qt_buliding_id;
		$Floor =$getQuo->qt_floor_id;
		$Number =$getQuo->qt_unit_number_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$dateQuo =$getQuo->qt_date;
		$promotiomQuo =$getQuo->qt_promotion;
	
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$getRoom = $this->tb_unit_number->get_detail_unit_withUnitTypeRoomType_by_un_id($Number);
		$unit_type_name 	= $getRoom->unit_type_name;
		$un_name 			= $getRoom->un_name;
		$unit_type_area_sqm 	= $getRoom->unit_type_area_sqm;
		$un_direction		= $getRoom->un_direction;
		$room_type_name		= $getRoom->room_type_name;

		$getPrice = $this->tb_price->get_detail_by_buildingID_UnitNumberID($Building,$Number);
		$pr_selling_sqm 			= $getPrice->pr_selling_sqm;
		$pr_asking_price			= $getPrice->pr_asking_price;
		
	
		$today = $dateQuo;   
		$getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotiomQuo);
		$promotionID		= $getPromotion->pm_id;
		$pm_name		= $getPromotion->pm_name;
		$pm_value		= $getPromotion->pm_value;
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
	
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value;
		$htmlGift = '';
		$list_gift = $this->tb_promotion->fetchGiftBySearchQuotation($promotiomQuo);
		foreach($list_gift as $getGift):
			
			$htmlGift .= '<tr>
    						<td ><font size="2"><b> Name : '.$getGift->pm_name.'</b></font></td>
    						<td ><font size="2"><b> Type : '.$getGift->pm_type.'</b></font></td>
    						<td ><font size="2"><b> Detail : '.$getGift->pm_detail.'</b></font></td>
  			</tr>';
			
		endforeach;
		
		$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($PaymentTerms);
		$pt_booking			= $getPaymentTerms->pt_booking;
		$pt_contract		= $getPaymentTerms->pt_contract;
		$pt_down_payment_mount		= $getPaymentTerms->pt_down_payment_mount;
	
		$todayQuo = $dateQuo;   
		$CondoPrice = $pr_asking_price1;
		$Percent = $getPaymentTerms->pt_total_down_percent;
		$TotalDownMonth = $getPaymentTerms->pt_down_payment_mount;
		$BookingFee 	= $getPaymentTerms->pt_booking;
		$ContractFee 	= $getPaymentTerms->pt_contract;
		$MarketPrice 	= $getPaymentTerms->pt_ballon_market_installment;
		$BalloonMonth 	= $getPaymentTerms->pt_ballon_installment_month;
		$BalloonMonthText 	= $getPaymentTerms->pt_ballon_month;
		$TotalDownPayment = ($CondoPrice * $Percent) / 100;
		$TotalInstallmentFee = $TotalDownPayment - $BookingFee - $ContractFee;
	  	$NormalMonth = $TotalDownMonth - $BalloonMonth;
		$Balloon 	= $getPaymentTerms->pt_ballon_payment;
		 if ($Balloon ==0 )
            {
                $TotalNormalFee =  $TotalInstallmentFee;
                $TotalBalloonFee = 0;
               	$BalloonFee = 0;
                $InstallmentFee = $TotalInstallmentFee / $TotalDownMonth;
            }
            else
            {
                $TotalNormalFee = $NormalMonth * $MarketPrice;
                $TotalBalloonFee = $TotalInstallmentFee - $TotalNormalFee;
                $BalloonFee = $TotalBalloonFee / $BalloonMonth;
                $InstallmentFee = $MarketPrice;
            }
		
			 $TotalNormalFee = ceil( $InstallmentFee) *  $NormalMonth;
             $TotalBalloonFee = ceil( $BalloonFee) *  $BalloonMonth;
             $TotalDownPayment =  $TotalNormalFee +  $TotalBalloonFee +  $BookingFee +  $ContractFee;
             $TotalInstallmentFee = $TotalDownPayment - $BookingFee -  $ContractFee;
             $InstallmentFee = ceil($InstallmentFee);
             $BalloonFee = ceil($BalloonFee);
             $TransferPayment = $specialPrice - $TotalDownPayment ;

		
		if ($Balloon==0) {
			$InstallmentDetail = '
			
				<tr>
			    	<td width="517px"><font size="2">Installment Fee : Down Payment '.$TotalDownMonth .' months (ผ่อนดาวน์  '.$TotalDownMonth .' เดือน) </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($InstallmentFee ,2).'</font></td>
			    	<td width="90px"><font size="2">Baht/Month</font></td>
			  	</tr>
				<tr>
			    	<td width="517px"><font size="2">Total Installment Fee  </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($TotalInstallmentFee ,2).'</font></td>
			    	<td width="90px"><font size="2">Baht </font></td>
			  	</tr>
				<tr>
			    	<td colspa="3"><br></td>
			  	</tr>
			  	<tr>
			    	<td width="517px"><font size="2">Total of Down Payment </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($TotalDownPayment,2).'</font></td>
			    	<td width="90px"><font size="2">Baht</font></td>
			  	</tr>
			
			';
		} else {
			$InstallmentDetail = '
		
			  	<tr>
			    	<td width="517px"><font size="2">Installment Fee : Down Payment '.$NormalMonth .' months (ผ่อนดาวน์  '.$NormalMonth .' เดือน) </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($InstallmentFee ,2).'</font></td>
			    	<td width="90px"><font size="2">Baht/Month</font></td>
			  	</tr>
			  	<tr>
			    	<td width="517px"><font size="2">Installment Fee : Balloon Payment '.$BalloonMonth .' months (ผ่อนดาวน์  '.$BalloonMonth .' เดือน เดือนที่ '.$BalloonMonthText .') </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($BalloonFee ,2).'</font></td>
			    	<td width="90px"><font size="2">Baht per month</font></td>
			  	</tr>
			  	<tr>
			    	<td width="517px"><font size="2">Total Installment Fee  </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($TotalInstallmentFee ,2).'</font></td>
			    	<td width="90px"><font size="2">Baht </font></td>
			  	</tr>
			  	<tr>
			    	<td colspa="3"><br></td>
			  	</tr>
				<tr>
			    	<td width="517px"><font size="2">Total of Down Payment </font></td>
			    	<td width="150px" align="right"><font size="2">'.number_format($TotalDownPayment,2).'</font></td>
			    	<td width="90px"><font size="2">Baht</font></td>
			  	</tr>
			';
		}

		$data['quoCode'] = $quoCode;
		$data['pj_name'] = $this->project_name_sel;
		$data['todayQuo'] = $todayQuo;
		$data['BookingName'] = $BookingName;
		$data['building_name'] = $building_name;
		$data['unit_type_name'] = $unit_type_name;
		$data['unit_type_area_sqm'] = $unit_type_area_sqm;
		$data['room_type_name'] = $room_type_name;
		$data['pr_selling_sqm'] = $pr_selling_sqm;
		$data['un_direction'] = $un_direction;
		$data['pr_asking_price'] = $pr_asking_price;
		$data['CondoPrice'] = $CondoPrice;
		$data['pm_value'] = $pm_value;
		$data['BookingFee'] = $BookingFee;
		$data['ContractFee'] = $ContractFee;
		$data['InstallmentDetail'] = $InstallmentDetail;
		$data['TransferPayment'] = $TransferPayment;
		$data['un_name'] = $un_name;
		$data['bookingCusid'] = $bookingCusid;
		$data['allCus'] = $allCus;
		$data['htmlGift'] = $htmlGift;


		$this->load->view('Letter/transferBooking/transferBooking_add',$data);
	}
	public function transferBookingLetter_Report($actionid,$cust1,$cust2){
		$data['actionid'] = $actionid;
		$data['cust1'] = $cust1;
		$data['cust2'] = $cust2;
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_authorize_user');

		$data['customer'] = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($cust1);
		$data['customer2'] = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($cust2);
		$data['signature'] = $this->tb_authorize_user->get_info_by_au_document('Booking Transfer Letter');
		$this->load->view('Letter/transferBooking/transferBooking_report',$data);
	}
	public function transferBookingLetter_searching(){
		$this->load->model('tb_booking');

		$data['title'] = $this->title_page;
		$data['page'] = "tranferBooking";
		$data['permission'] = $this->get_user_permission();

		$Booking_post = $this->input->post('Booking');
		$Booking = trim($Booking_post);
		$data['Booking'] = $Booking;

		$comma = '';
		$allBooking = '';

		$result = $this->tb_booking->fetch_all_ststusON();
		foreach ($result as $row) {
			$allBooking .= $comma.'{value: "'.$row->bk_booking_code.'",label: "'.$row->bk_booking_code.'"}';
			if($comma==='') $comma = ',';
		}
		$allBooking = '['. $allBooking . ']';
		$data['allBooking'] = $allBooking;

		//////
		$data['list_data'] = $this->tb_booking->fetch_all_by_bk_booking_codeAndbk_project_id($Booking,$this->project_id_sel);
		//$this->output->enable_profiler(TRUE);
		$this->load->view('Letter/transferBooking/transferBooking_searching',$data);
	}
	/*----------------------------------*/
	/*------WarningContractLetter-------*/
	/*----------------------------------*/
	public function warningContractLetter(){
		$data['title'] = $this->title_page;
		$data['page'] = "installment";
		$data['permission'] = $this->get_user_permission();
		$data['list_letter'] = $this->fetch_contract_warning_letter();
		$this->load->view('Letter/warningContract/warningContract',$data);
	}
	public function warningContractLetter_record($actionid,$cus,$untid){
		$this->load->model('tb_letter_contract_warning');
		$this->load->model('tb_contract');
		$this->load->model('tb_booking');
		$this->load->model('tb_room_status');

		$actionid= $actionid;
        $cusid   = $cus;
		$unitid  = $untid;
        $sale    = $this->user_id;

		$newid= $this->tb_letter_contract_warning->get_new_letter_id();
        //echo $newid.'<hr>';
		$tmp = strlen($newid);
		$tmpID = '';
      //echo $tmp.'<hr>';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($this->project_id_sel);
        $tmptmp = $tmptmp == 0?1:$tmptmp;
		$tmpIDP = '';
        //echo ' length '.$projectid.':'.$tmptmp.'<hr>';
		for ($i=$tmptmp; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateContract = date("ymd"); 
        //echo $dateQuo.'<hr>';
		$newid ='L'.$tmpIDP.$this->project_id_sel.'-'.$dateContract.'-'.$tmpID.''.$newid; 

		$data_update = array(
			'ct_letter_warning' => 'sent'
		);
		$this->tb_contract->update_where_equal_ct_code($data_update,$actionid);
		
		$objResult = $this->tb_booking->getBookingInfo_by_ct_codeAndbk_project_id($actionid,$this->project_id_sel);	
		
		
		$data_add_letter = array(
			'lt_code' => $newid,
			'lt_cus_id' => $objResult->ct_cus_id,
			'lt_project_id' => $this->project_id_sel,
			'lt_contract_id' => $actionid
		); 


		$this->tb_letter_contract_warning->record($data_add_letter);

		$data_add_roomsts = array(
			'rs_unit_number' => $unitid,
			'rs_cus_id' => $cusid,
			'rs_status' => 'Warning Installment',
			'rs_staff_id' => $sale
		);
		$this->tb_room_status->record($data_add_roomsts);

		//echo "<script>  window.open('letterWarningInstallmentReport.php?lid=$newid','_blank'); </script>";
		redirect('/letter/warningContractLetter');
	}
	public function warningContractLetter_Report($actionid){
		$data['actionid'] = $actionid;
		$this->load->view('Letter/warningContract/warningContract_report',$data);
	}
	public function warningInstallmentLetter_Report($lid){

		$this->load->model('tb_letter_contract_warning');
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_quotation');
		$this->load->model('tb_building');
		$this->load->model('tb_authorize_user');
		$data['lid'] = $lid;
		$this->load->library('Currency');
		$data['Currency'] = $this->currency;

		$get = $this->tb_letter_contract_warning->get_detail_by_lt_code($bid);
		$data['letter_date']   = date('d/m/Y',strtotime($get->lt_timestamp));
		$data['letter_number'] = $get->lt_code;

		$get1 = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($get->lt_cus_id);
		$data['letter_to_customer'] = " คุณ ".$get1->pers_fname." ".$get1->pers_lname;

		$get2 = $this->tb_quotation->getDetail_by_ct_code_withContractTable($get->lt_contract_id);
		$data['booking_fee']        = $get2->bk_money_amount;
		$data['booking_number']     = $get2->bk_booking_code;
		$data['booking_date']       = date('d/m/Y',strtotime($get2->bk_time_stamp));
		$data['letter_ondate']      = date('d/m/Y');
		$data['building']           = $get2->qt_buliding_id;
		$data['contact_due_date']   = date('d/m/Y',strtotime($get2->bk_contract_date));

		$getb = $this->tb_building->get_detail_building_by_un_idAndun_build_id($get2->qt_unit_number_id,$data['building']);
		$data['unit_number']        = $getb->un_name;							
		$data['building_name'] =  $getb->building_name;            
		$data['floor_number']  =  $getb->fl_name;
                   
        $data['signature'] = $this->tb_authorize_user->get_info_by_au_document('Installment Warning  Letter');

        $data['get'] = $get;
        $data['get2'] = $get2;
        $data['getb'] = $getb;
        $data['pjname'] = $this->project_name_sel;

		$this->load->view('Letter/warningContract/warningInstallment_report',$data);
	}
	public function warningContractLetter_searching(){
		$this->load->model('tb_contract');
		$this->load->model('tb_booking');

		$Contract_post = $this->input->post('Contract');
		$Contract = trim($Contract_post);
		$data['Contract'] = $Contract;

		$data['title'] = $this->title_page;
		$data['page'] = "installment";
		$data['permission'] = $this->get_user_permission();

		$comma = '';
		$allContract = '';
		$result = $this->tb_contract->fetch_all_by_bk_project_id($this->project_id_sel);
		foreach ($result as $row):
			$allContract .= $comma.'{value: "'.$row->ct_code.'",label: "'.$row->ct_code.'"}';
			if($comma==='') $comma = ',';
		endforeach;
		$allContract = '['. $allContract . ']';
		$data['allContract'] = $allContract;


		/////
		$data['list_data'] = $this->tb_booking->fetch_all_by_ct_codeAndbk_project_id($Contract,$this->project_id_sel);
		//$this->output->enable_profiler(TRUE);
		$this->load->view('Letter/warningContract/warningContract_searching',$data);
	}
	/*----------------------------------*/
	/*------TransferContractLetter-------*/
	/*----------------------------------*/
	public function transferContractLetter(){
		$data['title'] = $this->title_page;
		$data['page'] = "tranferContract";
		$data['permission'] = $this->get_user_permission();
		$data['list_letter'] = $this->fetch_letter_transfer_contract();
		$this->load->view('Letter/transferContract/transferContract',$data);
	}
	public function transferContractLetter_Report($actionid,$cus1,$cus2){
		$data['actionid'] = $actionid;
		$data['cus1'] = $cus1;
		$data['cus2'] = $cus2;

		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_authorize_user');

		$get1 = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($cus1);
		$get2 = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($cus2);

		$data['fromcust'] =  $get1->pers_prefix." ".$get1->pers_fname." ".$get1->pers_lname;
		$data['tocust'] = $get2->pers_prefix." ".$get2->pers_fname." ".$get2->pers_lname;

		$signature = $this->tb_authorize_user->get_info_by_au_document('Contract Transfer Letter');
	    $data['authorize'] = $signature->user_pers_fname.' '.$signature->user_pers_lname;

	    $data['get1'] = $get1;
	    $data['get2'] = $get2;
	    $data['signature'] = $signature;
		$this->load->view('Letter/transferContract/transferContract_Report',$data);
	}
	public function transferContractLetter_searching(){

		$this->load->model('tb_contract');
		$this->load->model('tb_booking');

		$data['title'] = $this->title_page;
		$data['page'] = "tranferContract";
		$data['permission'] = $this->get_user_permission();

		$comma = '';
		$list_contract = $this->tb_contract->fetch_all_by_bk_project_id($this->project_id_sel);
		foreach ($list_contract as $row):
			$allContract .= $comma.'{value: "'.$row->ct_code.'",label: "'.$row->ct_code.'"}';
			if($comma==='') $comma = ',';
		endforeach;
						
		$data['allContract'] = '['. $allContract . ']';
		$Contract_ = $this->input->post('Contract');
		$Contract = trim($Contract_);
		$data['Contract'] = $Contract;
		$data['list_data'] = $this->tb_booking->fetch_all_by_ct_codeAndbk_project_id($Contract,$this->project_id_sel);
		$this->load->view('Letter/transferContract/transferContract_searching',$data);
	}
	public function transferContractLetter_record($actionid=null){
		$this->load->model('tb_contract');
		$this->load->model('tb_booking');
		$this->load->model('tb_transfer_contract');
		$this->load->model('tb_room_status');
		$this->load->model('tb_installment');

		$sale = $this->user_id; 
		$cus = '';
		$count =0;
		$unitnumber = $this->input->post('unitnumber');
		$bookingcode = $this->input->post('bookingcode');
		$cusOld = $this->input->post('cusOld');
		
		$flagCusId1 = TRUE;
	
		$cus1 = $this->input->post('user_fullname1');
		
		if ($cus1!=NULL) {
		$cusid_post = $this->input->post('cusid');
		if ($cusid_post[0]==0) {
				$flagCusId1 = FALSE;
			}
		}
	
		if ($flagCusId1==FALSE) {
			echo "<script> alert('Can not create contract , Please check customer');  history.back();</script>";
			exit;
		}
		
		
		$cusid = $this->input->post('cusid');
		$newid= $this->tb_contract->get_new_contract_id($this->project_id_sel);
		$tmp = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($project_sel);
       
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateQuo = date("ymd"); 
        $newid        = 'C'.$tmpIDP.$this->project_id_sel.'-'.$dateQuo.'-'.$tmpID.''.$newid; 
		$today = date("Y-m-d"); 
		
	    
		$newb= $this->tb_booking->get_new_booking_id($this->project_id_sel);
		$tmp = strlen($newb);
		$tmpID = '';
      //echo $tmp.'<hr>';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($projectid);
        $tmptmp = $tmptmp == 0?1:$tmptmp;
		$tmpIDP = '';
        //echo ' length '.$projectid.':'.$tmptmp.'<hr>';
		for ($i=$tmptmp; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateQuo = date("ymd"); 
        //echo $dateQuo.'<hr>';
		
        $newbook ='B'.$tmpIDP.$this->project_id_sel.'-'.$dateQuo.'-'.$tmpID.''.$newb; 
    
    	$bk_obj = $this->tb_booking->get_detail_by_bk_booking_code_overload1($bookingcode);
    	$data_add_bk = array(
    		'bk_booking_code' => $newbook,
    		'bk_quotation_code' => $bk_obj->bk_quotation_code,
    		'bk_leads_id' => $cusid->bk_leads_id,
    		'bk_project_id' => $bk_obj->bk_project_id,
    		'bk_cash_type' => $bk_obj->bk_cash_type,
    		'bk_cash_amount' => $bk_obj->bk_cash_amount,
    		'bk_credit_bank' => $bk_obj->bk_credit_bank,
    		'bk_credit_no' => $bk_obj->bk_credit_no,
    		'bk_credit_date' => $bk_obj->bk_credit_date,
    		'bk_credit_holder' => $bk_obj->bk_credit_holder,
    		'bk_credit_type' => $bk_obj->bk_credit_type,
    		'bk_credit_amount' => $bk_obj->bk_credit_amount,
    		'bk_other_by' => $bk_obj->bk_other_by,
    		'bk_other_type' => $bk_obj->bk_other_type,
    		'bk_other_amount' => $bk_obj->bk_other_amount,
    		'bk_money_amount' => $bk_obj->bk_money_amount,
    		'bk_contract_date' => $bk_obj->bk_contract_date,
    		'bk_staff_id' => $bk_obj->bk_staff_id,
    		'bk_status' => $bk_obj->bk_status
    	);
    	$this->tb_booking->record($data_add_bk);
		
		$newtf= $this->tb_transfer_contract->get_new_transfer_contract_id();
		$tmp = strlen($newtf);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($project_sel);
       
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateQuo = date("ymd"); 
		//$newbook      = 'B'.$tmpIDP.$_SESSION['project_id_sel'].'-'.$dateQuo.'-'.$tmpID.''.$newid; 
        $newletter    = 'L'.$tmpIDP.$this->project_id_sel.'-'.$dateQuo.'-'.$tmpID.''.$newtf; 
    
    	$data_update_bk = array(
    		'bk_status' => 'cancel',
    		'bk_transfer_from' => 'contract',
    		'bk_transfer_letter' => $newletter
    	);
    	$this->tb_booking->update($data_update_bk,$bookingcode);
    
    	$ct_obj = $this->tb_contract->get_detail_by_ct_code($actionid);
    	$data_add_ct = array(
    		'ct_code' => $newid,
    		'ct_booking_code' => $bookingcode,
    		'ct_cus_id' => $cusid,
    		'ct_type' => $ct_obj->ct_type,
    		'ct_date' => $ct_obj->ct_date,
    		'ct_active' => 'on',
    		'ct_letter_warning' => $ct_obj->ct_letter_warning,
    		'ct_time_stamp' => $ct_obj->ct_time_stamp,
    		'ct_project_id' => $ct_obj->ct_project_id,
    		'ct_credit_bank' => $ct_obj->ct_credit_bank,
    		'ct_credit_no' => $ct_obj->ct_credit_no,
    		'ct_credit_date' => $ct_obj->ct_credit_date,
    		'ct_credit_holder' => $ct_obj->ct_credit_holder,
    		'ct_credit_type' => $ct_obj->ct_credit_type,
    		'ct_credit_amount' => $ct_obj->ct_credit_amount,
    		'ct_other_by' => $ct_obj->ct_other_by,
    		'ct_other_type' => $ct_obj->ct_other_type,
    		'ct_other_amount' => $ct_obj->ct_other_amount,
    		'ct_cash_type' => $ct_obj->ct_cash_type,
    		'ct_authorized_user' => $ct_obj->ct_authorized_user,
    		'ct_cash_amount' => $ct_obj->ct_cash_amount
    	);
    	$this->tb_contract->record($data_add_ct);

		$data_add_tfct = array(
			'tf_code' => $newletter,
			'tf_from_cus' => $cusOld,
			'tf_to_cus' => $cusid,
			'tf_room' => $unitnumber,
			'tf_contract_id_old' => $actionid,
			'tf_contract_id_new' => $newid,
			'tf_project_id' => $project_sel
		);
		$this->tb_transfer_contract->record($data_add_tfct);

		$data_update_ct = array(
			'ct_active' =>'cancel',
			'ct_tranfer_letter' => $newletter
		);
		$this->tb_contract->update_where_equal_ct_code($data_update_ct,$actionid);
		
		$data_add_roomSts = array(
			'rs_unit_number' => $unitnumber,
			'rs_cus_id' => $cusid,
			'rs_status' => 'Transfer Contract',
			'rs_staff_id' => $sale
		);
		$this->tb_room_status->record($data_add_roomsts);

        $data_update_pt = array(
        	'pm_status' => 'cancel'        
        );
        $where = "pm_contract_id = ".$actionid."";
        $this->tb_installment->update_where($data_update_pt,$where);
		
		$pt_obj = $this->tb_installment->get_detail_by_in_contract_id($actionid);
		$data_add_pt = array(
			'in_receipt_id' => $pt_obj->in_receipt_id,
			'in_contract_id' => $newid,
			'in_cus_id' => $cusid,
			'in_installment_name' => $pt_obj->in_installment_name,
			'in_installment_time' => $pt_obj->in_installment_time,
			'in_due_date' => $pt_obj->in_due_date,
			'in_received_date' => $pt_obj->in_received_date,
			'in_fee_define' => $pt_obj->in_fee_define,
			'in_time_stamp' => $pt_obj->in_time_stamp
		);
		$this->tb_installment->record($data_add_pt);
		//echo "<script>  window.open('transferContractReport.php?actionid=$newletter&cus1=$cusOld&cus2=$cusid','_blank'); </script>";
		redirect('/letter/transferContractLetter');
	}
	public function transferContractLetter_adding($actionid=null){
		$this->load->model('tb_authorize_user');
		$this->load->model('tb_contract');
		$this->load->model('tb_customer');
		$this->load->model('tb_quotation');
		$this->load->model('tb_building');
		$this->load->model('tb_unit_number');
		$this->load->model('tb_customer_personal_info');

		$data['actionid'] = $actionid;
		$data['title'] = $this->title_page;
		$data['page'] = "tranferBooking";
		$data['permission'] = $this->get_user_permission();

		$project_sel = $this->project_id_sel;

		if(!isset($actionid)){
			redirect('/letter/transferContractLetter_searching');
		}       
         
        $signature = $this->tb_authorize_user->get_info_by_au_document('Contract Transfer Letter');
        $data['signature'] = $signature;

		$getcon= $this->tb_quotation->getDetail_by_ct_code_withContractTable($actionid);
		$quoCode = $getcon->bk_quotation_code;
		$bookingCode = $getcon->ct_booking_code;
		$ct_cus_id = $getcon->ct_cus_id;
		$condate  = $getcon->ct_date;

		$getBookingName= $this->tb_customer->get_detail_leads_withOut_oppotunityStageAndActive($ct_cus_id);
		$BookingName = '<b>'.$getBookingName->pers_fname.' '.$getBookingName->pers_lname.'</b><br><b>Mobile :</b>&nbsp;'.
        $getBookingName->pers_mobile.'<br><b>Tel:</b>&nbsp;'.$getBookingName->pers_lname.'<br><b>Email:</b>&nbsp;'.
        $getBookingName->pers_email.'<br><br>';
	
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$Project = 	$getQuo->qt_project_id;
		$Building =$getQuo->qt_buliding_id;
		$Floor =$getQuo->qt_floor_id;
		$Number =$getQuo->qt_unit_number_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$dateQuo =$getQuo->qt_date;
		$promotiomQuo =$getQuo->qt_promotion;
	
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$getRoom = $this->tb_unit_number->get_detail_unit_withUnitTypeRoomType_by_un_id($Number);
		$unit_type_name 	= $getRoom->unit_type_name;
		$un_name 			= $getRoom->un_name;
		$room_type_name		= $getRoom->room_type_name;

		$comma = '';
		$allCus = '';
		$result = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
		foreach ($result as $row) {
			$allCus .= $comma.'{value: "'.$row->cus_id.'",label: "'.$row->fullname.'"}';
			if($comma==='') $comma = ',';
		}
		$allCus = '['. $allCus . ']';
		$data['allCus'] = $allCus;
		$data['quoCode'] = $quoCode;
		$data['bookingCode'] = $bookingCode;
		$data['actionid'] = $actionid;
		$data['BookingName'] = $BookingName;
		$data['un_name'] = $un_name;
		$data['building_name'] = $building_name;
		$data['unit_type_name'] = $unit_type_name;
		$data['Number'] = $Number;
		$data['ct_cus_id'] = $ct_cus_id;

		$this->load->view('Letter/transferContract/transferContract_add',$data);
	}
	/*----------------------------------*/
	/*------------referralLetter--------*/
	/*----------------------------------*/
	public function referralLetter(){
		$data['title'] = $this->title_page;
		$data['page'] = "referredletter";
		$data['permission'] = $this->get_user_permission();
		$data['list_letter'] = $this->fetch_letter_referral();
		$this->load->view('Letter/referral/referralLetter',$data);
	}
	public function referralLetter_adding(){
		$data['title'] = $this->title_page;
		$data['page'] = "referredletter";
		$data['permission'] = $this->get_user_permission();

		$this->load->model('tb_customer_personal_info');
		$comma = '';
		$allEmp = '';
		$result = $this->tb_customer_personal_info->fetch_all_customer_smallInfo();
		foreach ($result  as $row) {
			$allEmp .= $comma.'{value: "'.$row->cus_id.'",label: "'.$row->fullname.'"}';
			if($comma==='') $comma = ',';
		}
						
		$allEmp = '['. $allEmp . ']';
		$data['allEmp'] = $allEmp;
		
		$this->load->view('Letter/referral/referral_letteradd',$data);
	}
	public function referralLetter_approve(){

		$loginby = $this->user_id;
		$approvdate = date("Y-m-d");

		$lettercode_post = $this->input->post('lettercode');
		$newcustid_post = $this->input->post('newcustid');
		$fromcustid_post = $this->input->post('fromcustid');
		$contractnewcustomer_post = $this->input->post('contractnewcustomer');

		$letter        = isset($lettercode_post)?$lettercode_post:'';
		$newcustomer   = isset($newcustid_post)?$newcustid_post:'';
        $fromcustomer  = isset($fromcustid_post)?$fromcustid_post:'';
        $contractcode  = isset($contractnewcustomer_post)?$contractnewcustomer_post:'';
    
		if ( !empty($letter) && !empty($newcustomer) && !empty($fromcustomer) && !empty($contractcode) )
	    {
	    	$this->load->model('tb_letter_referred');
	    	$data_update = array(
	    		'lt_status' => 'Approval',
	    		'lt_approve_by' => $loginby,
	    		'lt_approve_date' => $approvdate,
	    		'lt_ct_code' => $contractcode
	    	);
	    	$where = "lt_referredfee_id=".$letter." 
	    			  AND lt_new_customer = '".$newcustomer."'
	    			  AND lt_contract_referfrom = '".$fromcustomer."'
		        	  AND lt_project_id = '".$this->project_id_sel."'
	    			  ";
	    	$this->tb_letter_referred->update_where($data_update,$where);
			redirect("javascript:history.back();");
		}else{
			alert('โปรดตรวจสอบความเรียบร้อยของข้อมูลในเอกสารให้ถูกต้อง');
		}
	}
	public function referralLetter_process(){
		$this->load->model('tb_contract');
		$this->load->model('tb_letter_referred');

	  	$referid_post = $this->input->post('referid');
		$newcustomerid_post = $this->input->post('newcustomerid');
		$contractreferfrom =  isset($referid_post)?$referid_post:'';
		$newcustomer =  isset($newcustomerid_post)?$newcustomerid_post:'';
	  			
		$pj_id = $this->project_id_sel;
		$staffid = $this->user_id;

    	$getcontract = $this->tb_contract->fetch_all_by_ct_cus_idAndCt_project_id($newcustomer,$pj_id);
    	$contract_referredfee= empty($getcontract->lt_ct_code)?$getcontract->ct_code:'';
     
		$getnewid = $this->tb_letter_referred->get_new_letter_id();
		$newid= $getnewid;
		
		$tmp = strlen($newid);
		$tmpProjectid = strlen($pj_id);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($newid);
		$tmpIDP = '';
		for ($i=$tmpProjectid; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateletter = date("ymd"); 
		$newLetter ='L'.$tmpIDP.$pj_id.'-'.$dateletter.'-'.$tmpID.''.$newid; 
		

        $data_add = array(
        	'lt_referredfee_id' => $newLetter,
        	'lt_ct_code' => $contract_referredfee,
        	'lt_contract_referfrom' => $contractreferfrom,
        	'lt_new_customer' => $newcustomer,
        	'lt_deadline' => '45',
        	'lt_staffid' => $staffid,
        	'lt_project_id' => $pj_id
        );
		$this->tb_letter_referred->record($data_add);
            
        //echo "<script> window.open('referral_letterreportView.php?letter=$newLetter','_blank');</script>";	
        redirect('/letter/referralLetter');
	}
	public function referralLetter_Report($letter=''){

		$this->load->model('tb_letter_referred');
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_quotation');
		$this->load->model('tb_customer_address_current_info');
		$this->load->model('tb_customer_address_info');
		$this->load->model('tb_customer_address_lastest');
		$this->load->model('tb_unit_number');
		$this->load->model('tb_authorize_user');
		$this->load->model('tb_promotion');

		$data['permission'] = $this->get_user_permission();
		$this->load->library('Currency');
		$data['Currency'] = $this->currency;

		$letterid = $letter;
		$pj_name  = $this->project_name_sel;
		$pj_id    = $this->project_id_sel;
		$salename=  $this->user_username;

 		if( !empty($letterid) )
		{
   
		   	$letter_ondate = date('d/m/Y');
		   	$get = $this->tb_letter_referred->fetch_allFullInfo_by_lt_project_id_And_lt_referredfee_id($pj_id,$letterid);
		   	$refercustomer = $get->lt_contract_referfrom;
		   	$newcustomer   = $get->lt_new_customer;
    
    	   	$getnewcust = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($newcustomer);
    		$getrefer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($refercustomer);
   	      
         	$referunt = $this->tb_quotation->getDetail_by_ct_project_id_And_ct_cus_id($pj_id,$refercustomer);

	        $addr  = $this->tb_customer_personal_info->get_detail_by_cus_id_withCustomerTable($get->refercustomer); 
       
    		$referred='';
		    if ( $addr->cus_addr_default ==1 )
		    {
		        $referred  = $this->tb_customer_address_current_info->get_detail_by_addr_cur_id_cus($get->refercustomer);
		        $referredaddr= $referred->addr_cur_address.' '.
		        $referred->addr_cur_sub_district.' '.
		        $referred->addr_cur_district.' '.
		        $referred->addr_cur_province.' '.
		        $referred->addr_cur_post_code;
		    }
		    else if ( $addr->cus_addr_default ==2 )
		    {
		        $referred  = $this->tb_customer_address_info->get_detail_by_addr_id_cus($get->refercustomer);
		        $referredaddr= $referred->addr_address.','.
		        $referred->addr_sub_district.' '.
		        $referred->addr_district.' '.
		        $referred->addr_province.' '.
		        $referred->addr_country;
		    }
		    else
		    {
		        $referred  = $this->tb_customer_address_lastest->get_detail_by_addr_lastest_id_cus($get->refercustomer);
		        $referredaddr= $referred->addr_lastest_address.','.
		        $referred->addr_lastest_sub_district.' '.
		        $referred->addr_lastest_district.' '.
		        $referred->addr_lastest_province.' '.
		        $referred->addr_lastest_post_code;
		    }
       
         	$unt = $this->tb_quotation->getDetail_by_ct_project_id_And_ct_cus_id_overload1($pj_id,$newcustomer);
		   	if ( !empty($unt) )
		   	{      
			    $getunit = $this->tb_unit_number->get_detail_unit_withUnitTypeRoomTypeAndPrice_by_un_id($unt->qt_unit_number_id);       
			    $sale = $this->tb_customer_personal_info->get_detail_by_user_pers_id($unt->qt_sale_id);
		        
		   	}       
		    $Signature = $this->tb_authorize_user->get_info_by_au_document('Referred Letter');

		}
		else 
		{
			echo "<script>history.back()</script>";
		}
        $data['list_promotion'] = $this->tb_promotion->get_detail_by_pm_type('Reffered');
        $data['pj_name'] = $pj_name;
		$data['letter_ondate'] = $letter_ondate;
		$data['referunt'] = $referunt;
		$data['getrefer'] = $getrefer;
		$data['referredaddr'] = $referredaddr;
		$data['getnewcust'] = $getnewcust;
		$data['sale'] = $sale;
		$data['addr'] = $addr;
		$data['Signature'] = $Signature;
		$data['getunit'] = $getunit;

		$this->load->view('Letter/referral/referral_letter_report',$data);
	}
	public function json_contract($nextList,$Customer){
		$this->load->model('tb_contract');
		$nextList = isset($nextList) ?$nextList : '';

		switch($nextList) {
			case 'contract':
				$Customer = isset($Customer) ? $Customer : '';
				$result = $this->tb_contract->fetch_all_notActive_by_ct_cus_id($Customer); 
		}

		$data = array();
		foreach($result as $row) {
			$data[] = $row;
		}


		echo json_encode($data);
	}
	public function json_referred_contract($nextList,$Customer){
		$this->load->model('tb_contract');
		$pj_id = $this->project_id_sel;
		$nextList = isset($nextList) ? $nextList : '';

		switch($nextList) {
			case 'contract':
				$Customer = isset($Customer) ? $Customer : '';
				$result = $this->tb_contract->fetch_all_by_ct_cus_idAndCt_project_id($Customer,$pj_id);
		}

		$data = array();
		foreach($result as $row) {
		    if ( empty($row->lt_ct_code) )
			$data[] = $row;
		}
		echo json_encode($data);
	}

	/*----------------------------------*/
	/*------------PRIVATE METHOD--------*/
	/*----------------------------------*/
	private function fetch_booking_warning_letter(){
		$this->load->model('tb_letter_booking_warning');
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_quotation');
		$this->load->model('tb_unit_number');
		$list_letter = $this->tb_letter_booking_warning->fetch_all_by_lt_project_id($this->project_id_sel);
		foreach($list_letter as $letter):
			$letter->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->lt_cus_id);
			$letter->quotation = $this->tb_quotation->getDetail_by_bk_booking_code_withBookingTable($letter->lt_booking_id);
			$letter->unit_number = $this->tb_unit_number->get_detail_unit_by_un_id_withBuildingTable($letter->quotation->qt_unit_number_id);
		endforeach;
		return $list_letter;
	}
	private function fetch_letter_transfer_booking(){
		$this->load->model('tb_transfer_booking');
		$this->load->model('tb_customer_personal_info');
		$list_letter = $this->tb_transfer_booking->fetch_all_by_tf_project_id($this->project_id_sel);
		foreach($list_letter as $letter):
			$letter->customer_form = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->tf_from_cus);
			$letter->customer_to = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->tf_to_cus);
		endforeach;
		return $list_letter;
	}
	private function fetch_contract_warning_letter(){
		$this->load->model('tb_letter_contract_warning');
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_quotation');
		$this->load->model('tb_unit_number');
		$list_letter = $this->tb_letter_contract_warning->fetch_all_by_lt_project_id($this->project_id_sel);
		foreach($list_letter as $letter):
			$letter->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->lt_cus_id);
			$letter->quotation = $this->tb_quotation->getDetail_by_ct_code_withContractTable($letter->lt_contract_id);
			$letter->unit_number = $this->tb_unit_number->get_detail_unit_by_un_id_withBuildingTable($letter->quotation->qt_unit_number_id);
		endforeach;
		return $list_letter;
	}
	private function fetch_letter_transfer_contract(){
		$this->load->model('tb_transfer_contract');
		$this->load->model('tb_customer_personal_info');
		$list_letter = $this->tb_transfer_contract->fetch_all_by_tf_project_id($this->project_id_sel);
		foreach($list_letter as $letter):
			$letter->customer_form = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->tf_from_cus);
			$letter->customer_to = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->tf_to_cus);
		endforeach;
		return $list_letter;
	}
	private function fetch_letter_referral(){

		$this->load->model('tb_letter_referred');
		$this->load->model('tb_customer_personal_info');
		$this->load->model('tb_contract');
		$list_letter = $this->tb_letter_referred->fetch_allFullInfo_by_lt_project_id($this->project_id_sel);
		foreach($list_letter as $letter):
			$letter->contract = $this->tb_contract->get_detail_by_ct_cus_id($letter->lt_new_customer);
			$letter->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($letter->lt_contract_referfrom);
			$letter->contract_cus = $this->tb_contract->get_detail_by_ct_cus_id($letter->customer->cus_id);
		endforeach;
		return $list_letter;
	}

}

/* End of file room_status.php */
/* Location: ./application/controllers/room_status.php */