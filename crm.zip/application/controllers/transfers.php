<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transfers extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'transfers';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
    
	public function view(){
        $this->load->model('tb_transfer_ownership');
        $this->load->model('tb_receipt_temporary');
        
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['fetch_transfer'] = $this->tb_transfer_ownership->fetch_transfer_ownership_by_project_id($this->project_id_sel);
        $data['pj'] = $this->dbCommon;
        
        $this->LoadView('Transfers/transfers',$data);
	}
    
    function maketempreceipt($trCode, $type)
    {
        $this->load->model('tb_transfer_ownership');
        $transferDetail = $this->tb_transfer_ownership->get_by_code($trCode);
        $ctCode = $transferDetail->tr_contract_code;
        if($transferDetail->tr_paid !== 'no' || $transferDetail->tr_status === 'cancelled') {
            alert_redirect('Can not create temp receipt.','/transfers/view');
            exit;
        }
		/////////////////////////////////////////////////////////////
        
		/////////////////////////////////////////////////////////////
        $this->load->model('tb_contract');
        $ctDetail = $this->tb_contract->get_detail_by_ct_code($ctCode);
        $bkCode = $ctDetail->ct_booking_code;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_booking');
        $bkDetail = $this->tb_booking->get_detail_by_bk_booking_code($bkCode);
        $qtCode = $bkDetail->bk_quotation_code;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_quotation');
        $qtDetail = $this->tb_quotation->getDetail_by_id($qtCode);
        $Number =$qtDetail->qt_unit_number_id;
        $Building =$qtDetail->qt_buliding_id;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_customer_personal_info');
        $cusList = $this->tb_customer_personal_info->list_customer($ctDetail->ct_cus_id);
        $cusFullName = array();
        foreach($cusList as $cus)
            $cusFullName[] = $cus->pers_fname.' '.$cus->pers_lname;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
        $room_type_id = $getRoom->room_type_id;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_payment_terms');
		$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($qtDetail->qt_payment_terms);
        $BookingFee 	= $getPaymentTerms->pt_booking;
        $ContractFee 	= $getPaymentTerms->pt_contract;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_selling_sqm 	= $getPrice->pr_selling_sqm;
		$pr_asking_price	= $getPrice->pr_asking_price;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_contract_promotion');
        $proList = $this->tb_contract_promotion->get_detail_by_bk_code($bkCode);
        $proID = array();
        foreach($proList as $pro) {
            $proID[] = $pro->cp_promotion_id;
        }
        $promotionid = implode(',', $proID);
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_promotion');
        $pm_value = 0;
		$pm_value = $this->tb_promotion->getPromotionBySearchQuotation_Discount($promotionid);
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
		$specialPrice = (float)intval($pr_asking_price1)-(float)$pm_value-(float)$qtDetail->qt_total_down_payment;
        $getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotionid);
        /////////////////////////////////////////////////////////////
        
        $TransferPayment = $specialPrice;
        
        $data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
        if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $this->load->model('tb_receipt_offical');
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled();
        }
        $data['trCode'] = $trCode;
        $data['ctCode'] = $ctCode;
        $data['bkCode'] = $bkCode; 
        $data['qtCode'] = $qtCode;
        $data['type']   = $ctDetail->ct_type;
        $data['cusList']= $cusFullName;
        $data['todayQuo'] = $qtDetail->qt_date;
        $data['unName'] = $getRoom->un_name;
        $data['building'] = $getBuilding->building_name;
        $data['unType'] = $getRoom->unit_type_name;
        $data['unit_type_area_sqm'] = $getRoom->unit_type_area_sqm;
        $data['un_direction'] = $getRoom->un_direction;
        $data['room_type_name'] = $getRoom->room_type_name;
        $data['pr_selling_sqm'] = $getPrice->pr_selling_sqm;
        $data['pr_asking_price'] = $getPrice->pr_asking_price;
        $data['project_database_sel'] = $this->project_database_sel;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        $data['room_type_id'] = $room_type_id;
        $data['TransferPayment'] = $TransferPayment;
        $data['qtDetail'] = $qtDetail;
        $data['list_promotion'] = $getPromotion;
        $data['promotionid'] = $promotionid;
        $data['Number'] = $Number;
        $data['transferDetail'] = $transferDetail;
        $data['bkDetail'] = $bkDetail;
        $data['ctDetail'] = $ctDetail;
        $data['type'] = $type;
        
        $this->LoadView('Transfers/transfers_maketempreceipt',$data);
    }
    
    function update($type)
    {
        date_default_timezone_set('Asia/Bangkok');
        
        $unitnumber     = $this->input->post('unitnumber');
        $installmentMonth   = $this->input->post('installmentMonth');
        $unitnumberid   = $this->input->post('unitnumberid');
        $contractfee    = $this->input->post('contractfee');
        $trCode         = $this->input->post('trCode');
        $ctCode         = $this->input->post('ctCode');
        $bkCode         = $this->input->post('bkCode');
        $remark         = $this->input->post('Remark');
        $transferAmount = $this->input->post('transfer');
//        echo('<script>alert("$ctDetail->ct_cus_id :'.$trCode.'")</script>');
        $Project = 	$this->project_id_sel;
        $today = date('Y-m-d H:i:s');
        
        $this->load->database();
        $this->pdb->trans_begin();
		
        $this->load->model('tb_transfer_ownership');
        $data = array(
            'tr_paid' => 'yes'
        );
        $this->tb_transfer_ownership->update($data,$trCode);
        
        $trDetail = $this->tb_transfer_ownership->get_by_code($trCode);
		$data_room_sts = array(
			'rs_unit_number' => $unitnumberid,
			'rs_cus_id' => $trDetail->tr_customer_id,
			'rs_status' => 'Transfer Ownership',
			'rs_staff_id' => $this->user_id
		);
		$this->load->model('tb_room_status');
		$this->tb_room_status->record($data_room_sts);
        
        
        //////////////////////////////////////////////////////////
        $this->load->model('tb_receipt_temporary');
        $newid = $this->tb_receipt_temporary->get_next_id();
		$tmp   = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
        $projectid = $this->project_id_sel;
		$tmptmp = strlen($projectid);
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) {
			$tmpIDP .= '0';
		}
        
		$dateQuo = date("ymd"); 
        $newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid; 
        $receiptID = implode(',', $this->input->post('receiptID'));
		$data_receipt = array(
			'rc_code' => $newrcv,
            'rc_refer_form' => $receiptID,
			'rc_customer_id' => $trDetail->tr_customer_id,
			'rc_payfor' => 'Transfer Ownership',
			'rc_booking_code' => $bkCode,
			'rc_contract_code' => $ctCode,
			'rc_transfer_code' => $trCode,
			'rc_total_amount' => $transferAmount,
            'rc_temporary_date' => $today,
			'rc_staff_temporary' => $this->user_id,
            'rc_un_name' => $unitnumber
		);
		$this->load->model('tb_receipt_temporary');
		$this->tb_receipt_temporary->record($data_receipt);
        //////////////////////////////////////////////////////////////
        $ct_type_payment = '';
        $ct_pay_crcard   = '';
        $ct_pay_other    = '';
        $Type = $this->input->post('Type');              
        if(!empty($Type))
        {      
          foreach($Type as $checkbox):
             if ( trim($checkbox) == 'Cash' )   $ct_type_payment = 'yes';
             if ( trim($checkbox) == 'CrCard' ) $ct_pay_crcard = 'yes';
             if ( trim($checkbox) == 'Other' )  $ct_pay_other  = 'yes';              
          endforeach;
        }
        $ct_amount          = $this->input->post('Cashamount');
        $ct_cr_bank         = $this->input->post('CardBank');
        $BankName           = $this->input->post('BankName');
        $ct_cr_type     	= $this->input->post('CardType');
        $ct_cr_approve_code	= $this->input->post('ApproveCode');
        $ct_cr_number       = $this->input->post('Cardno');
        $expiremonth_       = $this->input->post('expiremonth');
        $expireyear_        = $this->input->post('expireyear');
        $ct_cr_expire       = "";
        $ct_crcard_amount   = $this->input->post('Cardamount');
        $ct_cr_holder       = $this->input->post('CardHolder');
        $ct_other_by        = $this->input->post('OtherBy');
        $ct_other_amount    = $this->input->post('Otheramount');
        $pm_check_number    = $this->input->post('CheckNo');
        $pm_check_date      = $this->input->post('CheckDate');
        $pm_check_bank      = $this->input->post('CheckBank');
        $this->load->model('tb_payment');
        $this->load->model('tb_bank');
        if($ct_type_payment == "yes") {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $ct_amount,
            );
            $this->tb_payment->record($data_payment);
        }
        if($ct_pay_crcard == "yes") {
            $this->load->library('encrypt');
            $bankCount = 0;
            for($i=0;$i<count($ct_crcard_amount);$i++) {
                $ct_cr_expire = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";
                
                if($ct_cr_bank[$i] === 0) {
                    $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
                    echo $b_id;
                    if(empty($b_id)) {
                        $b_id = $this->tb_bank->get_next_id();
                        $data = array(
                            'b_id' => $b_id,
                            'bank_name_th' => $BankName[$bankCount]
                        );
                        $this->tb_bank->record($data);
                    }
                    $bankCount++;
                }else $b_id = $ct_cr_bank[$i];
                
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Credit',
                    'pm_amount' => $ct_crcard_amount[$i],
                    'pm_cr_bank' => $b_id,
                    'pm_cr_type' => $ct_cr_type[$i],
                    'pm_cr_holder' => $ct_cr_holder[$i],
                    'pm_cr_number' => $this->encrypt->encode($ct_cr_number[$i]),
                    'pm_cr_approve_code' => $ct_cr_approve_code[$i],
                    'pm_cr_expire' => $ct_cr_expire
                );
                $this->tb_payment->record($data_payment);
            }
        }
        if($ct_pay_other == "yes") {
            if($ct_other_by == 'Check'){
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $ct_other_by,
                    'pm_amount' => $ct_other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank                     
                );
            }else {
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $ct_other_by,
                    'pm_amount' => $ct_other_amount                   
                );
            }
            $this->tb_payment->record($data_payment);
        }
        
        //////////////////////////////////////////////////////////////
        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            alert_redirect('Make temp receipt Fail','/transfers/view');
        }
        else{
            $this->pdb->trans_commit();
            $getTempReceipt = $this->tb_receipt_temporary->get_by_transfer_ownership($trCode);
            echo "<script>window.open('".BASE_DOMAIN."receipt/report/th/$getTempReceipt->rc_code','_blank');";
            if ($type == 'transfer') {
                echo "window.location.href = '".BASE_DOMAIN."transfers/view';</script>";
            } else if ($type == 'installmentList') {
                echo "window.location.href = '".BASE_DOMAIN."installment/listInstallment/".$ctCode."';</script>";
            }
            
        }
    }
    
    function make_all_ttransfer()
    {
        $projectid = $this->project_id_sel;
        $dateQuo = date("ymd"); 
        $tmpIDP = '';
        for ($i=strlen($projectid); $i < 2 ; $i++) {
            $tmpIDP .= '0';
        }
        $code = 'TR'.$tmpIDP.$projectid.'-'.$dateQuo.'-';
        
        $this->load->model('tb_transfer_ownership');
        $this->load->model('tb_booking');
        $this->load->model('tb_contract');
        $ctList = $this->tb_contract->fetch_all_by_bk_project_id($projectid);
        
        $this->load->database();
        $this->pdb->trans_begin();
        foreach($ctList as $ctDetail)
        {
            $new = false;
            if($ctDetail->ct_active == 'on')
            {
                $new = true;
            }
            if($ctDetail->ct_active == 'transferred')
            {
                if(!empty($this->tb_transfer_ownership->get_by_ct_code($ctDetail->ct_code)->tr_code))
                    $new = true;
            }
            
            if($new)
            {
                $bkDetail = $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($ctDetail->ct_booking_code);
                ///////////////// transfer ownership //////////////////
                $trNewID = $this->tb_transfer_ownership->get_next_id();
                $tmpID = '';
                for($i=strlen($trNewID);$i<5;$i++)
                    $tmpID.= '0';

                $trCode = $code.$tmpID.$trNewID;

                $amount = $bkDetail->qt_unit_price - $bkDetail->qt_total_down_payment;

                $dataTransferOwnership = array(
                    'tr_code'           => $trCode,
                    'tr_contract_code'  => $ctDetail->ct_code,
                    'tr_customer_id'    => $ctDetail->ct_cus_id,
                    'tr_unit_number_id' => $bkDetail->qt_unit_number_id,
                    'tr_amount'         => $amount
                );
                $this->tb_transfer_ownership->record($dataTransferOwnership);
                ///////////////////////////////////////////////////////
                $this->tb_contract->update_where_equal_ct_code(array('ct_active' => 'off'),$ctDetail->ct_code);   
            }
        }
        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            alert_redirect('Make all fail.','/transfers');
        }
        else{
            $this->pdb->trans_commit();
            echo "<script>alert('Make all success.');";
            echo "window.location.href = '".BASE_DOMAIN."transfers';</script>";
//            redirect('/contract/view');
        }
    }
    
    function Adding ($conCode)
    {
        
        $this->load->model('tb_transfer_ownership');
        $this->load->model('tb_contract');
        $this->load->model('tb_booking');
        $this->load->model('tb_quotation');
        
        $trNewID = $this->tb_transfer_ownership->get_next_id();
        $dateQuo = date("ymd");
        $tmpID = '';
        for($i=strlen($trNewID);$i<5;$i++)
            $tmpID.= '0';
        $projectid = $this->project_id_sel;
        $tmpIDP = '';
        for ($i=strlen($projectid); $i < 2 ; $i++) {
            $tmpIDP .= '0';
        }
        $trCode = 'TR'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$trNewID;
        
        
        $getContract = $this->tb_contract->get_detail_by_ct_code($conCode);
        $getBooking = $this->tb_booking->get_detail_by_bk_booking_code($getContract->ct_booking_code);
        $getQuotation = $this->tb_quotation->getDetail_by_id($getBooking->bk_quotation_code);
        
        $amount = $getQuotation->qt_unit_price - $getQuotation->qt_total_down_payment;
        
        $dataTransferOwnership = array(
            'tr_code'           => $trCode,
            'tr_contract_code'  => $conCode,
            'tr_customer_id'    => $getContract->ct_cus_id,
            'tr_unit_number_id' => $getQuotation->qt_unit_number_id,
            'tr_amount'         => $amount
        );
        $this->tb_transfer_ownership->record($dataTransferOwnership);
        //////////////////////////////////////////////////////////////
        
        echo "<script> window.location.href = '".BASE_DOMAIN."installment/listInstallment/".$conCode."';</script>";
    }
    
    function Report ($type)
    {
        $this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        
		
        
		$this->load->view('Transfers/transfers_report_th');
        
    }
}
?>