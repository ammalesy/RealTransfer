<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Authorized extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Authorized';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->model('tb_authorize_user');
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['list_auth'] = $this->tb_authorize_user->fetch_all();
		$data['menuLeft'] = 'off';
		$this->LoadView('Authorized/authorized',$data);
	}
	public function adding()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->model('tb_authorize_user');
		$this->load->model('tb_user_personal_info');
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['list_personal'] = $this->tb_user_personal_info->fetch_all_personal_infoNormal();
		$data['list_auth'] = $this->tb_authorize_user->fetch_();
		$data['menuLeft'] = 'off';
		$this->LoadView('Authorized/authorized_adding',$data);
	}
	public function record()
	{
		/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();
		$this->load->model('tb_authorize_user');
		$docname = trim($this->input->post('docname'));
		$authorize = $this->input->post('Permission');
		$result = $this->tb_authorize_user->checkDupplicate_name($docname);
		if($result == FALSE){
			$data = array(
				'au_document' => $docname,
				'au_user_id' => $authorize
			);
			$this->tb_authorize_user->record($data);
		}else{
			alert_redirect('Dupplicate Name','/authorized/view');
		}
		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
        	alert_redirect('ADD authorize user Fail','/authorized/view');
		}
		else{
		    $this->db->trans_commit();
		    alert_redirect('ADD authorize user Success','/authorized/view');
		}
	}
	public function editing($cid)
	{
		$this->load->model('tb_authorize_user');
		$this->load->model('tb_user_personal_info');
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['uid'] = $cid;
		$data['permission'] = $this->get_user_permission();
		$data['list_personal'] = $this->tb_user_personal_info->fetch_all_personal_infoNormal();
		$data['auth'] = $this->tb_authorize_user->get_info_by_au_id($cid);
		$data['list_auth'] = $this->tb_authorize_user->fetch_();
		$data['menuLeft'] = 'off';
		$this->LoadView('Authorized/authorized_editing',$data);
	}
	public function update($cid)
	{
		/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();
		$this->load->model('tb_authorize_user');
		$this->load->model('log_authorized_user');
		$docname = $this->input->post('docname');
		$authorize = $this->input->post('Permission');

		$data = array(
			'au_document' => $docname,
			'au_user_id' => $authorize
		);
		$this->tb_authorize_user->update($data,$cid);

		$obj = $this->tb_authorize_user->get_info_by_au_id($cid);
		$data_log = array(
			'au_document' => $obj->au_document,
			'au_user_id' => $obj->au_user_id,
			'au_update_by' => $this->user_id
		);
		$this->log_authorized_user->record($data_log);
		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
        	alert_redirect('Edit authorize user Fail','/authorized/view');
		}
		else{
		    $this->db->trans_commit();
		    alert_redirect('Edit authorize user Success','/authorized/view');
		}
	}
}

/* End of file authorized.php */
/* Location: ./application/controllers/authorized.php */