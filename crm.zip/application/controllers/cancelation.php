<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cancelation extends NZ_Controller {
	var $title_page = 'Admin System';
//	var $page_var = 'cancelation';
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->cancel();
	}
	function cancel($type) {
        $this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        $this->load->model('tb_building');
        $this->load->model('tb_cancelation');
        $data['title'] = $this->title_page;
		$data['permission'] = $this->get_user_permission();
        $data['buildinglist']   = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        
        if($type === 'contract') 
        {
            $data['page'] = 'cancelContract';
            $data['history'] = $this->tb_cancelation->get_contract_cancelled_history();
            $this->LoadView('Cancelation/cancelation_contract',$data);
        }
        else 
        {
            $data['page'] = 'cancelBooking';
            $data['history'] = $this->tb_cancelation->get_booking_cancelled_history();

            
            $this->LoadView('Cancelation/cancelation_booking',$data);
            
        }
    }
    public function unlock($type){
		$this->load->model('tb_unit_number');
		$this->load->model('tb_quotation');
		$this->load->model('tb_contract');
		$this->load->model('tb_contract_promotion');
		$this->load->model('tb_room_status');
		$this->load->model('tb_booking');
        $this->load->model('tb_installment');
        $this->load->model('tb_receipt_temporary');
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_cancelation');
        
        $bid     = $this->input->post('building');
        $un_name = $this->input->post('room');
        $remark  = $this->input->post('reason');
        $refund  = $this->input->post('refund');
        
        if($type === 'contract') {
            $status = 'Booking & Contract';
            $code = $this->input->post('contract');
        }else {
            $bk_code = $this->input->post('booking');
            $status = 'Booking';
        }
        $refund  = empty($refund)?'no':$refund;
        
        /*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->pdb->trans_begin();
        
        $log = array();
        if($type === 'contract') {
            $ctDetail = $this->tb_contract->get_detail_by_ct_code($code);
            $ct_code = $ctDetail->ct_code;
            $bk_code = $ctDetail->ct_booking_code;
        }
        
        $temp = $this->tb_receipt_temporary->get_one_by(array('rc_booking_code' => $bk_code));
        if($temp->rc_status != 'off')
            $log[] = $temp->rc_code;
        if($type === 'contract') {
            if($ctDetail->ct_paid === 'yes') {
                $temp = $this->tb_receipt_temporary->get_one_by(array('rc_contract_code' => $ct_code));
                if($temp->rc_status != 'off')
                    $log[] = $temp->rc_code;
            }
            foreach ($this->tb_installment->fetch_installment_by_in_contract_id($ct_code) as $value) {
                $temp = $this->tb_receipt_temporary->get_one_by(array('rc_installment_code' => $value->im_code));
                if( !empty($temp) && $temp->rc_status != 'off' ) {
                    $log[] = $temp->rc_code;
                }
            }
        }
        
        if(!empty($log)) {
            alert_redirect('Can not cancelation, Please make offical receipt\n'.implode(',\n',$log),"/cancelation/cancel/$type");
            exit;
        }
        
        if($type === 'contract') {
            foreach ($this->tb_installment->fetch_installment_by_in_contract_id($ct_code) as $value) {
                if ($value->im_paid !== 'yes') {
                    $data = array(
                        'im_status' => 'cancelled'
                    );
                    $this->tb_installment->update_where($data, array('im_id' => $value->im_id));
                }
            }
            $data = array(
                'ct_active' => 'cancelled'
            );
            $this->tb_contract->update_where_equal_ct_code($data, $ct_code);
        }
        
        $data = array(
            'bk_status' => 'cancelled'
        );
        $this->tb_booking->update($data, $bk_code);
        
        $data = array(
            'cc_booking_code'  => $bk_code,
            'cc_contract_code' => $ct_code,
            'cc_refund'        => $refund,
            'cc_remark'        => $remark,
            'cc_staff'         => $this->user_id
        );
        $this->tb_cancelation->record($data);
        
        if(!empty($ctDetail)) {
            $cusAll = $ctDetail->ct_cus_id;
        }else {
            $bkDetail = $this->tb_booking->get_detail_by_bk_booking_code($bk_code);
            $cusAll = $bkDetail->bk_leads_id;
        }
        $this->update_customer_project($cusAll);
        
        foreach($this->tb_contract_promotion->get_detail_by_bk_code($bk_code) as $value) {
            if ($value->cp_status !== 'off') {
                $data = array(
                    'cp_status' => 'cancelled'
                );
                $this->tb_contract_promotion->update($data, $value->cp_id);
            }
        }
        
        if($refund === 'yes') {
            foreach($this->tb_receipt_offical->get_by_booking($bk_code) as $receipt) {
                $data = array(
                    'rc_status' => 'cancelled',
                );
                $this->tb_receipt_offical->update($data, $receipt->rc_id);
            }
            foreach($this->tb_receipt_temporary->get_receipt_by_booking($bk_code) as $receipt) {
                $data = array(
                    'rc_status' => 'cancelled',
                );
                $this->tb_receipt_temporary->update($data, $receipt->rc_id);
            }
        }
        
        $room_detail = $this->tb_unit_number->get_detail_by_idAndName($bid, $un_name);
		$data_unit = array(
			'un_status_room' => 'Available'
		);
		$this->tb_unit_number->update_where($data_unit,"un_id = '".$room_detail->un_id."'");

		$list_quotation = $this->tb_quotation->fetch_quotation_by_qt_unit_number_id($rid,$this->project_id_sel);

		$data_status = array(
			'rs_unit_number' => $room_detail->un_id, 
			'rs_cus_id' => '0', 
			'rs_status' => "$status Cancelled",
            'rs_staff_id' => $this->user_id
		);
        
		$this->tb_room_status->record($data_status);
        $data_status = array(
			'rs_unit_number' => $room_detail->un_id, 
			'rs_cus_id' => '0', 
			'rs_status' => 'Status Changed to Available',
            'rs_staff_id' => $this->user_id
		);
        
		$this->tb_room_status->record($data_status);
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Cancelation Room Fail',"/cancelation/cancel/$type");
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Cancelation Room success',"/cancelation/cancel/$type");
		}
	}
    function report($type, $language, $id){
        $this->load->model('tb_cancelation');
        $this->load->model('tb_project');
        $this->load->model('tb_booking');
        $this->load->model('tb_contract');
        $this->load->model('tb_quotation');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_unit_type');
        $this->load->model('tb_floor');
        $this->load->model('tb_customer_personal_info');
        $this->load->library('dateformat');
        
        if($type == 'booking')
        {
            $getDeCan   = $this->tb_cancelation->fetch_cancelation_by_booking_code($id);
            $getDeBo = $this->tb_booking->get_detail_by_bk_booking_code($id);
            $getDeQuo   = $this->tb_quotation->getDetail_by_id($getDeBo->bk_quotation_code);
            $listName = split(',',$getDeBo->bk_leads_id);
            $checkBo = 'checked="checked"';
            $checkCon = '';
            
        }
        else if($type == 'contract')
        {
            $getDeCan   = $this->tb_cancelation->fetch_cancelation_by_contract_code($id);
            $getDeCon = $this->tb_contract->get_detail_by_ct_code($id);
            $getDeBo = $this->tb_booking->get_detail_by_bk_booking_code($getDeCon->ct_booking_code);
            $getDeQuo   = $this->tb_quotation->getDetail_by_id($getDeBo->bk_quotation_code);
            $listName = split(',',$getDeCon->ct_cus_id);
            $checkBo = '';
            $checkCon = 'checked="checked"';
        }
        
        $idCancel = 'CA04-'.sprintf("%05d",$getDeCan->cc_id);
        
        if($getDeCan->cc_refund == 'no')//ริบเงิน
        {
            $titleCase = $language=='th'?'โดยยินยอมให้ริบเงินมัดจำ':'with consent to confiscate the deposit';
            $bookCase  = $language=='th'?'ตกลงยินยอม ให้ท่าน <b><span class="under">ริบเงินมัดจำ</span></b> การจองซื้อ ห้องชุดทั้งหมดซึ่งได้ชำระต่อท่านไว้แล้ว':'has already received <b><span class="under">the deposit</span></b> of reservation to purchase the unit back from you';
            $contractCase = $language=='th'?'ตกลงยินยอมให้ผู้จะขาย <b><span class="under">ริบเงินมัดจำทั้งหมด</span></b> ซึ่งข้าพเจ้าได้ชำระต่อท่านไว้แล้ว เนื่องจากข้าพเจ้าไม่ปฏิบัติตามสัญญาจะ ซื้อจะขาย':'Condominium Sale and Purchase Agreement and agree to sell the said unit, also, and has already received the deposit of reservation to purchase the unit and all payment made under the Agreement back from you';
        }
        else
        {
            $titleCase = '';
            $bookCase  = $language=='th'?'<b><span class="under">ได้รับเงินมัดจำ</span></b> การจองซื้อ ห้องชุดทั้งหมดคืนจากท่านเรียบร้อยแล้ว':'agree to give consent for you to confiscate all of the deposits of reservation to purchase the unit which is paid to you beforehand';
            $contractCae = $language=='th'?'<b><span class="under">ได้รับเงินมัดจำทั้งหมด</span></b> คืนจากท่านเรียบร้อยแล้ว':'Reservation Letter and agree to give consent for you to confiscate all of the deposits of reservation to purchase the units and all other payments which are paid to you beforehand due to our incompliance with the Sale and Purchase Agreement since we do not perform the contract';
        }
        
        $getDeUnNum = $this->tb_unit_number->get_detail_unit_by_un_id($getDeQuo->qt_unit_number_id);
        $getDeUnTy  = $this->tb_unit_type->get_detail_by_unit_type_id($getDeUnNum->un_unit_type_id);
        $getDeFl    = $this->tb_floor->get_detail_by_id($getDeUnNum->un_floor_id);
        $getDePro   = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($this->project_id_sel);
        $project    = $language=='th'?$getDePro->pj_name_th.' '.$getDePro->pj_location_th:$getDePro->pj_name.' '.$getDePro->pj_location.' '.$getDePro->pj_type;
        
        
        foreach($listName as $_listName)
        {
            $getDeCus = $this->tb_customer_personal_info->get_detail_by_id($_listName);
            $nameCus .= $getDeCus->pers_prefix.' '.$getDeCus->pers_fname.' '.$getDeCus->pers_lname.' ';
        }
        $listFirName = $listName[0];
        $nameFirCus = $getDeCus->pers_prefix.' '.$getDeCus->pers_fname.' '.$getDeCus->pers_lname.' ';
        
        /////////////////////////// Chech Date Contract ///////////////////////////////////
        if($getDeCon->ct_date != null)
            $dateContract = $language=='th'?$this->dateformat->thaiDate(date('Y-m-d',strtotime($getDeCon->ct_date))):date('d F Y',strtotime($getDeCon->ct_date));
        else
            $dateContract = '-';
        
        $data['title']  = $title;
        $data['idCancel'] = $idCancel;
        $data['project'] = $project;
        $data['dateCancel'] = $language=='th'?$this->dateformat->thaiDate(date('Y-m-d',strtotime($getDeCan->cc_timestamp))):date('d F Y',strtotime($getDeCan->cc_timestamp));
        $data['company'] = $language=='th'?$getDePro->pj_owner:$getDePro->pj_owner_en;
        $data['unitNumber'] = $getDeUnNum->un_name;
        $data['unitType'] = $getDeUnTy->unit_type_name;
        $data['floor'] = $getDeFl->fl_name;
        $data['areaSqm'] = $getDeUnTy->unit_type_area_sqm;
        $data['price'] = number_format($getDeQuo->qt_unit_price,2);
        $data['bookingCode'] = $getDeBo->bk_booking_code;
        $data['dateBooking'] = $language=='th'?$this->dateformat->thaiDate(date('Y-m-d',strtotime($getDeBo->bk_date_booking))):date('d F Y',strtotime($getDeBo->bk_date_booking));
        $data['contractCode'] = !empty($getDeCon->ct_code)?$getDeCon->ct_code:'-';
        $data['dateContract'] = $dateContract;
        $data['nameCustomer'] = $nameCus;
        $data['checkBooking'] = $checkBo;
        $data['checkContract'] = $checkCon;
        $data['nameLicense'] = $nameFirCus;
        $data['titleCase'] = $titleCase;
        $data['bookCase'] = $bookCase;
        $data['contractCase'] = $contractCase;
        if($language == 'th')
            $this->LoadView('Cancelation/cancelation_report',$data);
        else
            $this->LoadView('Cancelation/cancelation_report_en',$data);
    }
    function transfer($type) {
        $this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        $this->load->model('tb_building');
        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_transferred');
        $data['title'] = $this->title_page;
		$data['permission'] = $this->get_user_permission();
        $data['buildinglist']   = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        
        if($type === 'contract') 
        {
            $data['page'] = 'transferContract';
            $data['history'] = $this->tb_transferred->get_contract_history();
            $this->LoadView('Cancelation/transfer_contract',$data);
        }
        else 
        {
            $data['page'] = 'transferBooking';
            $data['history'] = $this->tb_transferred->get_booking_history();
            $this->LoadView('Cancelation/transfer_booking',$data);
        }
    }
    function transferring($type) {
        date_default_timezone_set('Asia/Bangkok');
        
        $this->load->model('tb_unit_number');
		$this->load->model('tb_quotation');
		$this->load->model('tb_contract');
		$this->load->model('tb_contract_promotion');
		$this->load->model('tb_room_status');
		$this->load->model('tb_booking');
        $this->load->model('tb_installment');
        $this->load->model('tb_receipt_temporary');
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_transferred');
        $this->load->model('tb_payment');
        
        $bid     = $this->input->post('building');
        $un_name = $this->input->post('roomname');
        $remark  = $this->input->post('reason');
        
//        echo "bid : ".$bid;
//        echo "+++++un_name : ".$un_name;
//        echo "++++remark : ".$remark;
//        exit();
        
        $cusid = $this->input->post('cusid');
        $projectid = $this->project_id_sel;
        $userid = $this->user_id;
        $today = date("Y-m-d H:i:s");
        
        $cusAll = '';
        $cusFirst = '';
        $count = 0;
        foreach($cusid as $key => $value ){
            if (!empty($cusid[$key])) {
                if ($count++>0) {
                    $cusAll .=',';
                }else $cusFirst = $cusid[$key];
                $cusAll .= $cusid[$key];
            }
		}
        
        if($type === 'contract') {
            $ct_code  = $this->input->post('contract');
            $status = 'Contract';
        }else {
            $bk_code  = $this->input->post('booking');
            $status = 'Booking';
        }
        $refund  = empty($refund)?'no':$refund;
        
        /*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->pdb->trans_begin();
        
        /////////////////// new booking id ///////////////////////
//        $newid= $this->tb_booking->get_new_booking_id($projectid);
//        $tmp = strlen($newid);
//        $tmpID = '';
//        for ($i=$tmp; $i < 5 ; $i++) { 
//            $tmpID .= '0';
//        }
//        $tmptmp = strlen($projectid);
//        $tmpPID = '';
//        for ($i=$tmptmp; $i < 2 ; $i++) { 
//            $tmpPID .= '0';
//        }
//        $date = date("ymd"); 
//
//        $newbid ='B'.$tmpPID.$projectid.'-'.$date.'-'.$tmpID.''.$newid; 
//        $time = strtotime($today);
//        $contract_date = date("Y-m-d", strtotime("+2week", $time));
        ///////////////////////////////////////////////////////////////
        
        if($type === 'contract') {
            $detail = $this->tb_contract->get_contract_by_ct_code($ct_code);
            $ct_code = $detail->ct_code;
            $bk_code = $detail->bk_booking_code;
            
            ///////////////////////////////////////////////////////////////////
//            $newid = $this->tb_contract->get_new_contract_id($this->project_id_sel);
//            $tmp   = strlen($newid);
//            $tmpID = '';
//            for ($i=$tmp; $i < 5 ; $i++) { 
//                $tmpID .= '0';
//            }
//            $tmptmp = strlen($projectid);
//            $tmpIDP = '';
//            for ($i=$tmptmp; $i < 2 ; $i++) {
//                $tmpIDP .= '0';
//            }
//            $contractDate = date_format(date_create($detail->bk_contract_date), 'ymd');
//
//            $dateQuo = date("ymd"); 
//            $newcid ='C'.$tmpIDP.$projectid.'-'.$contractDate.'-'.$tmpID.''.$newid; 
            ///////////////////////////////////////////////////////////////////
//            $data_contract = array(
//                'ct_code' => $newcid,
//                'ct_booking_code' => $newbid,
//                'ct_cus_id' => $cusAll,
//                'ct_type' => $detail->ct_type,
//                'ct_date' => $detail->ct_date,
//                'ct_temp_receipt_date' => $detail->ct_temp_receipt_date,
//                'ct_active' => $detail->ct_active,
//                'ct_staff_id' => $detail->ct_staff_id,
//                'ct_project_id' => $detail->ct_project_id,
//                'ct_remark' => "Transfer from ".$detail->ct_code
//            );
//            $this->tb_contract->record($data_contract);
            $data = array(
                'ct_active' => 'transferred',
                'ct_cus_id' => $cusAll,
//                'ct_transfer_to' => $newcid
            );
            $this->tb_contract->update_where_equal_ct_code($data, $ct_code);
            
            foreach ($this->tb_installment->fetch_installment_by_in_contract_id($ct_code) as $value) {
//                $data_installment = array(
//                    'im_code' => $value->im_code,
//                    'im_contract_code' => $newcid,
//                    'im_cus_id' => $cusAll,
//                    'im_installment_time' => $value->im_installment_time,
//                    'im_duedate' => $value->im_duedate,
//                    'im_fee_define' => $value->im_fee_define,
//                );
//                $this->tb_installment->record($data_installment);
                $data = array(
                    //'im_status' => 'transferred',
                    'im_cus_id' => $cusAll
                );
                $this->tb_installment->update_where($data, array('im_id' => $value->im_id));
            }
        }else {
            
            $detail = $this->tb_booking->get_booking_by_bk_code($bk_code);
            $bk_code = $detail->bk_booking_code;
            
            $data = array(
                'bk_leads_id' => $cusFirst,
                'bk_status' => 'transferred',
//                'bk_transfer_to' => $newbid
            );
            $this->tb_booking->update($data, $bk_code);
        }
        
//        $bkDetail = $this->tb_booking->get_booking_by_unit_name($un_name);
//        $data_booking = array(
//            'bk_booking_code' => $newbid,
//            'bk_quotation_code' => $detail->bk_quotation_code,
//            'bk_leads_id' => $cusFirst,
//            'bk_project_id' => $projectid,
//            'bk_money_amount' => $detail->bk_money_amount,
//            'bk_date_booking' => $detail->bk_date_booking,
//            'bk_contract_date' => $detail->bk_contract_date,
//            'bk_remark' => "Transfer from ".$detail->bk_booking_code,
//            'bk_staff_id' => $detail->bk_staff_id,
//            'bk_status' => $detail->bk_status
//        );
//        $this->tb_booking->record($data_booking);
        
        $this->update_customer_project(!empty($detail->ct_cus_id)?$detail->ct_cus_id:$detail->bk_leads_id);
        
        $room_detail = $this->tb_unit_number->get_detail_by_idAndName($bid, $un_name);
        
        $data = array(
            'tf_old_booking'  => $detail->bk_booking_code,
            'tf_old_contract' => $detail->ct_code,
            'tf_new_booking'  => $detail->bk_booking_code,//$newbid,
            'tf_new_contract' => $detail->ct_code,//$newcid,
            'tf_old_customer' => !empty($detail->ct_cus_id)?$detail->ct_cus_id:$detail->bk_leads_id,
            'tf_new_customer' => $cusAll,
            'tf_unit_id'      => $room_detail->un_id,
            'tf_staff_id'     => $this->user_id,
            'tf_remark'       => $remark
        );
        $this->tb_transferred->record($data);
        
        $data_status = array(
			'rs_unit_number' => $room_detail->un_id, 
			'rs_cus_id' => $cusAll, 
			'rs_status' => "$status Transferred",
            'rs_staff_id' => $this->user_id
		);
		$this->tb_room_status->record($data_status);
        
//        foreach($this->tb_contract_promotion->get_detail_by_bk_code($bk_code) as $value) {
//            $data_promotion = array(
//                'cp_booking_code' => $newbid,
//                'cp_contract_code' => $newcid,
//                'cp_promotion_id' => $value->cp_promotion_id
//            );
//            $this->tb_contract_promotion->record($data_promotion);
//            $data = array(
//                'cp_status' => 'transferred'
//            );
//            $this->tb_contract_promotion->update($data, $value->cp_id);
//        }
        //////////////////////////////////////////////////////////
//        $projectid = $this->project_id_sel;
//        foreach($this->tb_receipt_offical->get_by_booking($bk_code) as $receipt) {
//            $newid  = $this->tb_receipt_offical->get_next_id();
//            $tmp    = strlen($newid);
//            $tmpID  = '';
//            for ($i=$tmp; $i < 5 ; $i++) { 
//                $tmpID .= '0';
//            }
//            $tmptmp = strlen($projectid);
//            $tmpIDP = '';
//            for ($i=$tmptmp; $i < 2 ; $i++) { 
//                $tmpIDP .= '0';
//            }
//            $dateQuo = date_format(date_create($official_date),"ymd"); 
//            $newrid ='R'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid; 
//            
//            /////////////////////////////////////
//            $newid  = $this->tb_receipt_temporary->get_next_id();
//            $tmp    = strlen($newid);
//            $tmpID  = '';
//            for ($i=$tmp; $i < 5 ; $i++) { 
//                $tmpID .= '0';
//            }
//            $tmptmp = strlen($projectid);
//            $tmpIDP = '';
//            for ($i=$tmptmp; $i < 2 ; $i++) { 
//                $tmpIDP .= '0';
//            }
//            $dateQuo = date_format(date_create($official_date),"ymd"); 
//            $temprid ='T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid; 
//            
//            $data = array(
//                'rc_code' => $newrid,
//                'rc_temp_code' => $temprid,
//                'rc_refer_form' => $receipt->rc_code,
//                'rc_payfor' => $receipt->rc_payfor,
//                'rc_booking_code' => $newbid,
//                'rc_contract_code' => !empty($receipt->rc_contract_code)?$newcid:NULL,
//                'rc_installment_code' => !empty($receipt->rc_installment_code)?$receipt->rc_installment_code:NULL,
//                'rc_installment_time' => !empty($receipt->rc_installment_time)?$receipt->rc_installment_time:NULL,
//                'rc_total_amount' => $receipt->rc_total_amount,
//                'rc_official_date' => $receipt->rc_official_date,
//                'rc_staff_official' => $receipt->rc_staff_official,
//                'rc_confirm' => $receipt->rc_confirm,
//                'rc_remark' => $receipt->rc_remark,
//                'rc_customer_id' => $receipt->rc_customer_id,
//                'rc_un_name' => $receipt->rc_un_name,
//            );
//            $this->tb_receipt_offical->record($data);
//            $data = array(
//                'rc_status' => 'transferred'
//            );
//            $this->tb_receipt_offical->update($data, $receipt->rc_id);
//            
//            $temp = $this->tb_receipt_temporary->get_receipt_by_code($receipt->rc_temp_code);
//            $data = array(
//                'rc_code' => $temprid,
//                'rc_refer_form' => $temp->rc_code,
//                'rc_payfor' => $temp->rc_payfor,
//                'rc_booking_code' => $newbid,
//                'rc_contract_code' => !empty($temp->rc_contract_code)?$newcid:NULL,
//                'rc_installment_code' => !empty($temp->rc_installment_code)?$temp->rc_installment_code:NULL,
//                'rc_installment_time' => !empty($temp->rc_installment_time)?$temp->rc_installment_time:NULL,
//                'rc_total_amount' => $temp->rc_total_amount,
//                'rc_temporary_date' => $temp->rc_temporary_date,
//                'rc_staff_temporary' => $temp->rc_staff_temporary,
//                'rc_confirm' => $temp->rc_confirm,
//                'rc_remark' => $temp->rc_remark,
//                'rc_customer_id' => $temp->rc_customer_id,
//                'rc_un_name' => $temp->rc_un_name,
//                'rc_status' => $temp->rc_status,
//            );
//            $this->tb_receipt_temporary->record($data);
//            $data = array(
//                'rc_status' => 'transferred'
//            );
//            $this->tb_receipt_temporary->update($data, $temp->rc_id);
//            ////////////////////////////////////////////////////////////
//            foreach($this->tb_payment->get_by_temp_receipt($temp->rc_code) as $payment) 
//            {
//                $data = array(
//                    'pm_temp_code' => $temprid,
//                    'pm_receipt_code' => $newrid,
//                    'pm_date' => $payment->pm_date,
//                    'pm_type' => $payment->pm_type,
//                    'pm_amount' => $payment->pm_amount,
//                    'pm_cr_bank' => $payment->pm_cr_bank,
//                    'pm_cr_type' => $payment->pm_cr_type,
//                    'pm_cr_holder' => $payment->pm_cr_holder,
//                    'pm_cr_number' => $payment->pm_cr_number,
//                    'pm_cr_approve_code' => $payment->pm_cr_approve_code,
//                    'pm_cr_expire' => $payment->pm_cr_expire,
//                    'pm_cr_fee' => $payment->pm_cr_fee,
//                    'pm_check_number' => $payment->pm_check_number,
//                    'pm_check_date' => $payment->pm_check_date,
//                    'pm_check_bank' => $payment->pm_check_bank,
//                    'pm_confirm' => $payment->pm_confirm,
//                    'pm_status' => $payment->pm_status,
//                    'pm_account' => $payment->pm_account,
//                    'pm_remark' => $payment->pm_remark,
//                );
//                $this->tb_payment->record($data);
//            }
//        }
//        ///////////////////////////////////////////////////////
//        foreach($this->tb_receipt_temporary->get_receipt_by_booking($bk_code) as $receipt) {
//            $newid  = $this->tb_receipt_temporary->get_next_id();
//            $tmp    = strlen($newid);
//            $tmpID  = '';
//            for ($i=$tmp; $i < 5 ; $i++) { 
//                $tmpID .= '0';
//            }
//            $tmptmp = strlen($projectid);
//            $tmpIDP = '';
//            for ($i=$tmptmp; $i < 2 ; $i++) { 
//                $tmpIDP .= '0';
//            }
//            $dateQuo = date_format(date_create($official_date),"ymd"); 
//            $newrid ='T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid; 
//            $data = array(
//                'rc_code' => $newrid,
//                'rc_refer_form' => $receipt->rc_code,
//                'rc_payfor' => $receipt->rc_payfor,
//                'rc_booking_code' => $newbid,
//                'rc_contract_code' => !empty($receipt->rc_contract_code)?$newcid:NULL,
//                'rc_installment_code' => !empty($receipt->rc_installment_code)?$receipt->rc_installment_code:NULL,
//                'rc_installment_time' => !empty($receipt->rc_installment_time)?$receipt->rc_installment_time:NULL,
//                'rc_total_amount' => $receipt->rc_total_amount,
//                'rc_temporary_date' => $receipt->rc_temporary_date,
//                'rc_staff_temporary' => $receipt->rc_staff_temporary,
//                'rc_confirm' => $receipt->rc_confirm,
//                'rc_remark' => $receipt->rc_remark,
//                'rc_customer_id' => $receipt->rc_customer_id,
//                'rc_un_name' => $receipt->rc_un_name
//            );
//            $this->tb_receipt_temporary->record($data);
//            $data = array(
//                'rc_status' => 'transferred'
//            );
//            $this->tb_receipt_temporary->update($data, $receipt->rc_id);
//            
//            foreach($this->tb_payment->get_by_temp_receipt($receipt->rc_code) as $payment) {
//                $data = array(
//                    'pm_temp_code' => $newrid,
//                    'pm_date' => $payment->pm_date,
//                    'pm_type' => $payment->pm_type,
//                    'pm_amount' => $payment->pm_amount,
//                    'pm_cr_bank' => $payment->pm_cr_bank,
//                    'pm_cr_type' => $payment->pm_cr_type,
//                    'pm_cr_holder' => $payment->pm_cr_holder,
//                    'pm_cr_number' => $payment->pm_cr_number,
//                    'pm_cr_approve_code' => $payment->pm_cr_approve_code,
//                    'pm_cr_expire' => $payment->pm_cr_expire,
//                    'pm_cr_fee' => $payment->pm_cr_fee,
//                    'pm_check_number' => $payment->pm_check_number,
//                    'pm_check_date' => $payment->pm_check_date,
//                    'pm_check_bank' => $payment->pm_check_bank,
//                    'pm_confirm' => $payment->pm_confirm,
//                    'pm_status' => $payment->pm_status,
//                    'pm_account' => $payment->pm_account,
//                    'pm_remark' => $payment->pm_remark,
//                );
//                $this->tb_payment->record($data);
//            }
//        }
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Transfer Room Fail',"/cancelation/transfer/$type");
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Transfer Room success',"/cancelation/transfer/$type");
		}
    }
    
    function update_customer_project($cusAll)
    {
        $this->load->model('tb_customer_project');
        foreach(explode(',', $cusAll) as $cus) {
            if($this->tb_customer_project->get_count_off_room_by_cus_id($cus) == 0) {
                $cpDetail = $this->tb_customer_project->get_id_by_cus($cus);
                $data = array(
                    'cp_status' => 'off'
                );
                $this->tb_customer_project->update($data, $cpDetail->cp_id);
            }
        }
    }
}
?>