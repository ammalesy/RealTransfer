<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_promotion extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Promotion';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_promotion');
		
		$data['list_promotion'] = $this->tb_promotion->fetch_all();
		
		$this->LoadView('Project_detail/Project_promotion/project_promotion_view',$data);
	}
	public function editing($pm_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$data['pmid'] = $pm_id;
		$this->load->model('tb_room_type');
		$this->load->model('tb_unit_type');
		$this->load->model('tb_promotion');
		$data['promotion'] = $this->tb_promotion->get_detail_by_id($pm_id);
		$promotion = $data['promotion'];

		$data['list_room_type'] = $this->tb_room_type->fetch_all();
		$data['list_unit_type'] = $this->tb_unit_type->fetch_all_by_unit_type_room_type_id($promotion->pm_room_type_id);
		
		
		$this->LoadView('Project_detail/Project_promotion/project_promotion_editing',$data);
	}
	public function update($pm_id)
	{
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		$this->load->model('tb_promotion');
		$this->load->model('log_promotion');
		$pmName			= $this->input->post('Name');
		$pmNameEng			= $this->input->post('NameEng');
		$Type			= $this->input->post('type');
		$PackageValue 	= $this->input->post('PackageValue');
		$PackageDetail 	= $this->input->post('PackageDetail');
		$PackageDetailEng 	= $this->input->post('PackageDetailEng');
		$Expire			= $this->input->post('Expire');
		$roomtype			= $this->input->post('roomtype');
    	$unittype			= $this->input->post('unittype');
		$userEdit 		= $this->user_id;

		$data_update = array(
			'pm_name' => $pmName,
			'pm_name_en' => $pmNameEng,
			'pm_type' => $Type,
			'pm_value' => $PackageValue,
			'pm_detail' => $PackageDetail,
			'pm_detail_en' => $PackageDetailEng,
			// 'pm_room_type_id' => $roomtype,
			// 'pm_unit_type' => $unittype,
			'pm_date_expire' => $Expire
			
		);
		$this->tb_promotion->update($data_update,$pm_id);

		//// KEEP LOG /////
		///////////////////
		$obj_promotion = $this->tb_promotion->get_detail_by_id($pm_id);
		$data_log = array(
			'pm_id' => $obj_promotion->pm_id,
			'pm_name' => $obj_promotion->pm_name,
			'pm_name_en' => $obj_promotion->pm_name_en,
			'pm_type' => $obj_promotion->pm_type,
			'pm_value' => $obj_promotion->pm_value,
			'pm_detail' => $obj_promotion->pm_detail,
			'pm_detail_en' => $obj_promotion->pm_detail_en,
			'pm_date_expire' => $obj_promotion->pm_date_expire,
			'pm_sts_active' => $obj_promotion->pm_sts_active,
			// 'pm_room_type_id' => $obj_promotion->pm_room_type_id,
			// 'pm_unit_type' => $obj_promotion->pm_unit_type,
			'pm_update_by' => $userEdit
			
		);
		$this->log_promotion->record($data_log);

		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Edit Promotion Fail','/project_promotion/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Edit Promotion Success','/project_promotion/view');
		}
		
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$this->load->model('tb_room_type');
		$this->load->model('tb_unit_type');
		$data['list_room_type'] = $this->tb_room_type->fetch_all();
		$data['list_unit_type'] = $this->tb_unit_type->fetch_all();
		$this->LoadView('Project_detail/Project_promotion/project_promotion_adding',$data);
	}
	public function record(){
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		$this->load->model('tb_promotion');
		$pmName			= $this->input->post('Name');
		$pmNameEng			= $this->input->post('NameEng');
		$Type			= $this->input->post('type');
		$PackageValue 		= $this->input->post('PackageValue');
		$PackageDetail 		= $this->input->post('PackageDetail');
		$PackageDetailEng 		= $this->input->post('PackageDetailEng');
		$Expire				= $this->input->post('Expire');
		$Expiretype			= $this->input->post('expiretype');
		$roomtype			= $this->input->post('roomtype');
    	$unittype			= $this->input->post('unittype');

		$data_adding = array(
			'pm_name' => $pmName,
			'pm_name_en' => $pmNameEng,
			'pm_value' => $PackageValue,
			'pm_detail' => $PackageDetail,
			'pm_detail_en' => $PackageDetailEng,
			'pm_type' => $Type,
			//'pm_room_type_id' => $roomtype,
			//'pm_unit_type' => $unittype,
			'pm_date_expire' => $Expire
			
		);
		$this->tb_promotion->record($data_adding);

		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Add Promotion Fail','/project_promotion/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Add Promotion Success','/project_promotion/view');
		}
	}
	public function deleting($pm_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'pm_sts_active' => 'off'
		);
		$this->load->model('tb_promotion');
		$this->tb_promotion->update($data_delete,$pm_id);
		
		alert_redirect('Delete Promotion Success','/project_promotion/view');
	}
}

/* End of file project_promotion.php */
/* Location: ./application/controllers/project_promotion.php */