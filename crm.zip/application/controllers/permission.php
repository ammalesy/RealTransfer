<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Permission extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['all_permission'] = $this->fetch_all_permission();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['menuLeft'] = 'off';
		$this->LoadView('Permission/permission',$data);
	}
	public function adding()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['permission'] = $this->get_user_permission();
        $data['type'] = 'adding';
        $data['menuLeft'] = 'off';
		$this->LoadView('Permission/permission_form',$data);
	}
	public function record()
	{
        $pm_calendar     = $this->input->post('calendar');
        $pm_name         = $this->input->post('name');
		$pm_leads        = $this->input->post('Leads1')+$this->input->post('Leads2')+$this->input->post('Leads3');
	   	$pm_customer     = $this->input->post('Customer1')+$this->input->post('Customer2')+$this->input->post('Customer3');
	  	$pm_quotation    = $this->input->post('Quotation1')+$this->input->post('Quotation2')+$this->input->post('Quotation3')+$this->input->post('Quotation4');
	  	$pm_booking      = $this->input->post('Booking1')+$this->input->post('Booking2');
	   	$pm_contract     = $this->input->post('Contract1')+$this->input->post('Contract2');
	    $pm_receipt      = $this->input->post('Receipt1')+$this->input->post('Receipt2')+$this->input->post('Receipt3')+$this->input->post('Receipt4')+$this->input->post('Receipt5')+$this->input->post('Receipt6')+$this->input->post('Receipt7');
	    $pm_payment      = $this->input->post('PaymentPage');
	 	$pm_letter       = $this->input->post('Letter1')+$this->input->post('Letter2');
	 	$pm_roomSts      = $this->input->post('roomSts1')+ $this->input->post('roomSts2');
	 	$pm_authorizeuser = $this->input->post('CanaddAuthorize')+$this->input->post('CanviewAuthorize');
	    $pm_project_add  = $this->input->post('Project1')+$this->input->post('Project2')+$this->input->post('Project3');
	    $pm_user         = $this->input->post('User1')+$this->input->post('User2')+$this->input->post('User3');
	   	$pm_room         = $this->input->post('Room1')+$this->input->post('Room2')+$this->input->post('Room3');
	    $pm_assign       = $this->input->post('Assign1')+$this->input->post('Assign2')+$this->input->post('Assign3');
	    $pm_permission   = $this->input->post('Permission1')+$this->input->post('Permission2')+$this->input->post('Permission3');
	    $pm_project_info = $this->input->post('Info1')+0;
	    $pm_project_building = $this->input->post('Building1')+$this->input->post('Building2')+$this->input->post('Building3');
	    $pm_project_floor = $this->input->post('Floor1')+$this->input->post('Floor2')+$this->input->post('Floor3');
	    $pm_project_unit_type = $this->input->post('Unit1')+$this->input->post('Unit2')+$this->input->post('Unit3');
	    $pm_project_unit_number = $this->input->post('Number1')+$this->input->post('Number2')+$this->input->post('Number3');
	    $pm_project_price = $this->input->post('Price1')+$this->input->post('Price2');
	    $pm_project_promotion = $this->input->post('Promotion1')+$this->input->post('Promotion2')+$this->input->post('Promotion3');
	    $pm_project_payment_terms = $this->input->post('Payment1')+$this->input->post('Payment2')+$this->input->post('Payment3');
	   	$pm_project_terms_and_conditions = $this->input->post('Terms2')+0;
	   	$pm_dashboard    = $this->input->post('CanviewDashboard');
	   	$pm_faq    = $this->input->post('faq')[0];

   		//Report
	    $pm_report = '';
	    $reportArr = $this->input->post('reportChart');
	    foreach($reportArr as $checkbox)  $pm_report .= $checkbox;
	    //

	    $pm_sms   = $this->input->post('smsbooking')+$this->input->post('smsinstallment');

	    $pm_overdue   = $this->input->post('overduebooking')+$this->input->post('overdueinstallment');

    	$pm_email = $this->input->post('emailbooking')+$this->input->post('emailinstallment');
    	$pm_referedleter = $this->input->post('referedletter1')+$this->input->post('referedletter2')+$this->input->post('referedletter3');

		$pm_project = $pm_project_info+$pm_project_building+$pm_project_floor+$pm_project_unit_type+$pm_project_unit_number+$pm_project_price+$pm_project_promotion+$pm_project_payment_terms+$pm_project_terms_and_conditions;
		$pm_setting = $pm_project_add+$pm_user+$pm_room+$pm_assign+$pm_permission+$pm_project;
	
		$flag = $pm_setting+$pm_leads+$pm_customer+$pm_quotation+$pm_booking+$pm_contract+$pm_receipt+$pm_letter+$pm_roomSts;

        $pm_update_promotion = 0;
        foreach($this->input->post('updatePro') as $value) $pm_update_promotion += $value;
        
        $pm_upload = 0;
        foreach($this->input->post('upload') as $value) $pm_upload += $value;
        
        $pm_cancelation = 0;
        foreach($this->input->post('cancelation') as $value) $pm_cancelation += $value;
//--------       
	    $pm_transfer = '';      
        $transferArr = $this->input->post('Transfer');
        //foreach($this->input->post('transfer') as $value) $pm_transfer += $value;
	    foreach($transferArr as $checkbox)  $pm_transfer .= $checkbox;
//--------        
        $pm_survey = 0;
        foreach($this->input->post('survey') as $value) $pm_survey += $value;
	
		if ($flag>0) {
			/*================================*/
		 	/*======= Transaction start ======*/
		 	/*================================*/
		 	$this->load->database();
		 	$this->db->trans_begin();
			$data = array(
                'pm_name' => $pm_name,
                'pm_leads' => $pm_leads,
                'pm_calendar' => $pm_calendar,
                'pm_customer' => $pm_customer,
                'pm_quotation' => $pm_quotation,
                'pm_booking' => $pm_booking,
                'pm_contract' => $pm_contract,
                'pm_upload' => $pm_upload,
                'pm_receipt' => $pm_receipt,
                'pm_payment' => $pm_payment,
                'pm_update_promotion' => $pm_update_promotion,
                'pm_letter' => $pm_letter,
                'pm_room_sts' => $pm_roomSts,
                'pm_cancelation' => $pm_cancelation,
                //-----
                'pm_transfer' => $pm_transfer,
                //-----
                'pm_setting' => $pm_setting,
                'pm_project_add' => $pm_project_add,
                'pm_user' => $pm_user,
                'pm_room' => $pm_room,
                'pm_assign' => $pm_assign,
                'pm_permission' => $pm_permission,
                'pm_project' => $pm_project,
                'pm_project_info' => $pm_project_info,
                'pm_project_building' => $pm_project_building,
                'pm_project_floor' => $pm_project_floor,
                'pm_project_unit_type' => $pm_project_unit_type,
                'pm_project_unit_number' => $pm_project_unit_number,
                'pm_project_price' => $pm_project_price,
                'pm_project_promotion' => $pm_project_promotion,
                'pm_project_payment_terms' => $pm_project_payment_terms,
                'pm_project_terms_and_conditions' => $pm_project_terms_and_conditions,
                'pm_dashboard' => $pm_dashboard,
                'pm_chart_report' => $pm_report,
                'pm_authorize_user' => $pm_authorizeuser,
                'pm_email'  => $pm_email,  
                'pm_sms'    => $pm_sms,
                'pm_overdue' => $pm_overdue,
                'pm_refered_letter' => $pm_referedleter,
                'pm_survey' => $pm_survey,
                'pm_faq' => $pm_faq
      		);
			$this->recordPermission($data);
			
			if ($this->db->trans_status() === FALSE){
	        	$this->db->trans_rollback();
	        	alert_redirect('Add Permission Fail','/permission/view');
			}
			else{
			    $this->db->trans_commit();
			   alert_redirect('Add Permission Success','/permission/view');
			}
			
		}else{
			alert_redirect('please select the permission box','/permission/adding');
		}
	}
	public function editing($pmid)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['pmid'] = $pmid;
		$data['permission'] = $this->get_user_permission();
		$data['get_permission'] = $this->get_detail_permission($pmid);
        $data['type'] = 'editting';
        $data['menuLeft'] = 'off';
		$this->LoadView('Permission/permission_form',$data);
	}
	public function update($pmid)
	{
        $pm_calendar = $this->input->post('calendar');
		$pm_leads= $this->input->post('Leads1')+$this->input->post('Leads2')+$this->input->post('Leads3');
	   	$pm_customer = $this->input->post('Customer1')+$this->input->post('Customer2')+$this->input->post('Customer3');
	  	$pm_quotation = $this->input->post('Quotation1')+$this->input->post('Quotation2')+$this->input->post('Quotation3')+$this->input->post('Quotation4');
	  	$pm_booking = $this->input->post('Booking1')+$this->input->post('Booking2');
	   	$pm_contract =$this->input->post('Contract1')+$this->input->post('Contract2');
	    $pm_receipt = $this->input->post('Receipt1')+$this->input->post('Receipt2')+$this->input->post('Receipt3')+$this->input->post('Receipt4')+$this->input->post('Receipt5')+$this->input->post('Receipt6')+$this->input->post('Receipt7');
	    $pm_payment = $this->input->post('PaymentPage');
	 	$pm_letter = $this->input->post('Letter1')+$this->input->post('Letter2');
	 	$pm_roomSts = $this->input->post('roomSts1')+ $this->input->post('roomSts2');
	 	$pm_authorizeuser = $this->input->post('CanaddAuthorize')+$this->input->post('CanviewAuthorize');
	    $pm_project_add = $this->input->post('Project1')+$this->input->post('Project2')+$this->input->post('Project3');
	    $pm_user = $this->input->post('User1')+$this->input->post('User2')+$this->input->post('User3');
	   	$pm_room =$this->input->post('Room1')+$this->input->post('Room2')+$this->input->post('Room3');
	    $pm_assign = $this->input->post('Assign1')+$this->input->post('Assign2')+$this->input->post('Assign3');
	    $pm_permission = $this->input->post('Permission1')+$this->input->post('Permission2')+$this->input->post('Permission3');
	    $pm_project_info = $this->input->post('Info1')+0;
	    $pm_project_building = $this->input->post('Building1')+$this->input->post('Building2')+$this->input->post('Building3');
	    $pm_project_floor = $this->input->post('Floor1')+$this->input->post('Floor2')+$this->input->post('Floor3');
	    $pm_project_unit_type = $this->input->post('Unit1')+$this->input->post('Unit2')+$this->input->post('Unit3');
	    $pm_project_unit_number = $this->input->post('Number1')+$this->input->post('Number2')+$this->input->post('Number3');
	    $pm_project_price = $this->input->post('Price1')+$this->input->post('Price2')+$this->input->post('Price3');
	    $pm_project_promotion = $this->input->post('Promotion1')+$this->input->post('Promotion2')+$this->input->post('Promotion3');
	    $pm_project_payment_terms = $this->input->post('Payment1')+$this->input->post('Payment2')+$this->input->post('Payment3');
	   	$pm_project_terms_and_conditions = $this->input->post('Terms2')+0;
	   	$pm_dashboard = $this->input->post('CanviewDashboard');
        $pm_faq = $this->input->post('faq')[0];
        

   		//Report
	    $pm_report = '';
	    $reportArr = $this->input->post('reportChart');
	    foreach($reportArr as $checkbox)  $pm_report .= $checkbox;
	    //

	    $pm_sms   = $this->input->post('smsbooking')+$this->input->post('smsinstallment');

	    $pm_overdue   = $this->input->post('overduebooking')+$this->input->post('overdueinstallment');

    	$pm_email = $this->input->post('emailbooking')+$this->input->post('emailinstallment');
    	$pm_referedleter = $this->input->post('referedletter1')+$this->input->post('referedletter2')+$this->input->post('referedletter3');

		$pm_project = $pm_project_info+$pm_project_building+$pm_project_floor+$pm_project_unit_type+$pm_project_unit_number+$pm_project_price+$pm_project_promotion+$pm_project_payment_terms+$pm_project_terms_and_conditions;
		$pm_setting = $pm_project_add+$pm_user+$pm_room+$pm_assign+$pm_permission+$pm_project;
	
		$flag = $pm_setting+$pm_leads+$pm_customer+$pm_quotation+$pm_booking+$pm_contract+$pm_receipt+$pm_letter+$pm_roomSts;
        
        $pm_update_promotion = 0;
        foreach($this->input->post('updatePro') as $value) $pm_update_promotion += $value;
        
        $pm_upload = 0;
        foreach($this->input->post('upload') as $value) $pm_upload += $value;
        
        $pm_cancelation = 0;
        foreach($this->input->post('cancelation') as $value) $pm_cancelation += $value;
//-------- 
	    $pm_transfer = '';      
        $transferArr = $this->input->post('Transfer');
        //foreach($this->input->post('transfer') as $value) $pm_transfer += $value;
	    foreach($transferArr as $checkbox)  $pm_transfer .= $checkbox;
//-------- 
        
        $pm_survey = 0;
        foreach($this->input->post('survey') as $value) $pm_survey += $value;
	
		if ($flag>0) {
			/*================================*/
		 	/*======= Transaction start ======*/
		 	/*================================*/
		 	$this->load->database();
		 	$this->db->trans_begin();
			$data = array(
                        'pm_calendar' => $pm_calendar,
          				'pm_leads' => $pm_leads,
						'pm_customer' => $pm_customer,
						'pm_quotation' => $pm_quotation,
					    'pm_booking' => $pm_booking,
					    'pm_contract' => $pm_contract,
                        'pm_upload' => $pm_upload,
						'pm_receipt' => $pm_receipt,
				      	'pm_payment' => $pm_payment,
                        'pm_update_promotion' => $pm_update_promotion,
						'pm_letter' => $pm_letter,
						'pm_room_sts' => $pm_roomSts,
                        'pm_cancelation' => $pm_cancelation,
                        //-----
                		'pm_transfer' => $pm_transfer,
                        //-----
						'pm_setting' => $pm_setting,
						'pm_project_add' => $pm_project_add,
			     		'pm_user' => $pm_user,
						'pm_room' => $pm_room,
						'pm_assign' => $pm_assign,
						'pm_permission' => $pm_permission,
						'pm_project' => $pm_project,
						'pm_project_info' => $pm_project_info,
						'pm_project_building' => $pm_project_building,
						'pm_project_floor' => $pm_project_floor,
						'pm_project_unit_type' => $pm_project_unit_type,
						'pm_project_unit_number' => $pm_project_unit_number,
						'pm_project_price' => $pm_project_price,
						'pm_project_promotion' => $pm_project_promotion,
						'pm_project_payment_terms' => $pm_project_payment_terms,
						'pm_project_terms_and_conditions' => $pm_project_terms_and_conditions,
						'pm_dashboard' => $pm_dashboard,
                        'pm_chart_report' => $pm_report,
                        'pm_authorize_user' => $pm_authorizeuser,
                        'pm_email'  => $pm_email,  
                        'pm_sms'    => $pm_sms,
                        'pm_overdue' => $pm_overdue,
                        'pm_refered_letter' => $pm_referedleter,
                        'pm_survey' => $pm_survey,
                        'pm_faq' => $pm_faq
      		);
			$this->updatePermission($data,$pmid);
			
			//// KEEP LOG ////
			//////////////////
			$object = $this->get_allDetail_permission($pmid);
			$userEdit = $this->user_id;
			$data_log = array(
				'pm_id' => $object->pm_id,
				'pm_name' => $object->pm_name,
                'pm_calendar' => $object->pm_calendar,
				'pm_leads' => $object->pm_leads,
				'pm_customer' => $object->pm_customer,
				'pm_quotation' => $object->pm_quotation,
				'pm_booking' => $object->pm_booking,
				'pm_contract' => $object->pm_contract,
                'pm_upload' => $pm_upload,
				'pm_receipt' => $object->pm_receipt,
				'pm_payment' => $object->pm_payment,
                'pm_update_promotion' => $pm_update_promotion,
				'pm_letter' => $object->pm_letter,
				'pm_room_sts' => $object->pm_room_sts,
                'pm_cancelation' => $pm_cancelation,
                //-----
				'pm_transfer' => $object->pm_transfer,
                //-----
				'pm_setting' => $object->pm_setting,
				'pm_project_add' => $object->pm_project_add,
				'pm_user' => $object->pm_user,
				'pm_room' => $object->pm_room,
				'pm_assign' => $object->pm_assign,
				'pm_permission' => $object->pm_permission,
				'pm_project' => $object->pm_project,
				'pm_project_info' => $object->pm_project_info,
				'pm_project_building' => $object->pm_project_building,
				'pm_project_floor' => $object->pm_project_floor,
				'pm_project_unit_type' => $object->pm_project_unit_type,
				'pm_project_unit_number' => $object->pm_project_unit_number,
				'pm_project_price' => $object->pm_project_price,
				'pm_project_promotion' => $object->pm_project_promotion,
				'pm_project_payment_terms' => $object->pm_project_payment_terms,
				'pm_project_terms_and_conditions' => $object->pm_project_terms_and_conditions,
				'pm_sts_active' => $object->pm_sts_active,
				'pm_update_by' => $userEdit,
				'pm_dashboard' => $object->pm_dashboard,
				'pm_chart_report' => $object->pm_chart_report,
				'pm_authorize_user' => $object->pm_authorize_user,
				'pm_email' => $object->pm_email,
				'pm_sms' => $object->pm_sms,
				//'pm_overdue' => $object->pm_overdue,
				//'pm_refered_fee' => $object->pm_refered_fee,
				'pm_refered_letter' => $object->pm_refered_letter,
                'pm_survey' => $object->pm_survey,
                'pm_faq' => $object->pm_faq
			);
			$this->record_log_permission($data_log);
			if ($this->db->trans_status() === FALSE){
	        	$this->db->trans_rollback();
	        	alert_redirect('Edit Permission Fail','/permission/view');
			}
			else{
			    $this->db->trans_commit();
			   alert_redirect('Edit Permission Success','/permission/view');
			}
			
		}else{
			alert_redirect('please select the permission box','/permission/view');
		}
	}
	public function deleting($pmid){
		$permission = $this->get_user_permission();
		
		if (strpos($permission->pm_user,'4') === FALSE) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}else{
			if($this->user_permission == $pmid){
				alert_redirect('Permission is already... Please check your user!!!','/permission/view');
			}else{
				$data = array(
          				'pm_sts_active' => 'off'
      			);
	      		$this->updatePermission($data,$pmid);
	      		alert_redirect('Delete Permission Success','/permission/view');
			}
		}
	}

	/**
	* -------------------------------------
	* Scope [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function fetch_all_permission()
	{
		$this->load->model('tb_permission');
		return $this->tb_permission->fetch_all_permission();
	}
	private function get_detail_permission($pm_id){
		$this->load->model('tb_permission');
		return $this->tb_permission->get_detail_permission($pm_id);
	}
	private function get_allDetail_permission($pm_id){
		$this->load->model('tb_permission');
		return $this->tb_permission->get_allDetail_permission($pm_id);
	}

	//////// RECORD //////////
	//////////////////////////
	private function recordPermission($data){
		$this->load->model('tb_permission');
		$this->tb_permission->record($data);
	}

	//////// UPDATE //////////
	//////////////////////////
	private function updatePermission($data,$pm_id){
		$this->load->model('tb_permission');
		$this->tb_permission->update($data,$pm_id);
	}

	/**
	* -------------------------------------
	* Log Management [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function record_log_permission($data)
	{
		$this->load->model('log_permission');
	 	$this->log_permission->record($data);
	}
}

/* End of file permission.php */
/* Location: ./application/controllers/permission.php */