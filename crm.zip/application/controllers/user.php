<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['menu'] = $this->get_user_permission();
		$data['list_personal'] = $this->fetch_all_personal();
		$data['title'] = $this->title_page;
		$data['menuLeft'] = 'off';
		$this->LoadView('User/user',$data);
	}
	public function profile(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['menu'] = $this->get_user_permission();
		$data['list_permission'] = $this->fetch_all_permission();
		$data['title'] = $this->title_page;
		$data['uid'] = $this->user_id;

		$this->load->model('tb_user_personal_info');
		$data['user'] = $this->tb_user_personal_info->get_detail_personal($this->user_id);
		$data['menuLeft'] = 'off';

		$this->LoadView('User/user_profile',$data);
	}
	public function update_profile(){
		$this->load->model('tb_user');
		$user = $this->tb_user->get_detail_user($this->user_id);
		$txtOldPw = $this->input->post('Current');
		$txtNewPw = $this->input->post('New');
		$txtConPw = $this->input->post('Renew');
		if($user->user_password==md5($txtOldPw) && $txtNewPw==$txtConPw){

			$data_update = array(
				'user_password' => md5($txtNewPw)
			);
			$this->tb_user->update($data_update,$this->user_id);
			alert_redirect('Change Password Success','/user/');
		}else{
			alert_redirect('Please check your password','/user/profile');
		}
	}
	public function adding() /// Load view before save
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['menu'] = $this->get_user_permission();
		$data['list_permission'] = $this->fetch_all_permission();
		$data['title'] = $this->title_page;
		$data['menuLeft'] = 'off';
		$this->LoadView('User/user_adding',$data);
	}
	public function deleting($user_id)
	{
		$permission = $this->get_user_permission();
		
		if (strpos($permission->pm_user,'4') === FALSE) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}else{			
			$data_user_update = array(
          				'user_sts_active' => 'off'
      		);
      		$this->updateUser($data_user_update,$user_id);
      		alert_redirect('Delete User Success','/user/view');
		}
	}
	public function editting($user_id) /// Load view before save
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->model('tb_user_authorize');
        $this->load->model('tb_user');
        $user = $this->tb_user->get_detail_user($user_id);
		$data['user_id'] = $user_id;
        $data['username'] = $user->user_username;
		$data['personal'] = $this->get_detail_personal($user_id);
		$data['company'] = $this->fetch_user_company($user_id);
		$data['menu'] = $this->get_user_permission();
		$data['list_permission'] = $this->fetch_all_permission();
		$data['title'] = $this->title_page;
		$data['authorize'] = $this->tb_user_authorize->get_distinct_info_by_user_id($user_id);
		$data['menuLeft'] = 'off';
		$this->LoadView('User/user_editting',$data);
	}
	public function record() //// save
	{
		$username = trim($this->input->post('username'));
		if(!$this->isUsernameExist($username)){

			/*================================*/
			/*======= Transaction start ======*/
		 	/*================================*/
		 	$this->load->database();
		 	$this->db->trans_begin();
			/*
			* Record Personal info
			*/
			$pers_card_id = $this->input->post('idcard');
			$new_user_id = $this->get_new_user_id();
			$pers_id = $this->get_new_personal_id();
			$work_id = $this->get_new_working_id();
			$pers_fname = $this->input->post('firstname');
			$pers_lname = $this->input->post('lastname');
			$pers_fname_en = $this->input->post('firstnameEN');
			$pers_lname_en = $this->input->post('lastnameEN');
			$pers_mobile = $this->input->post('mobile');
			$pers_address = $this->input->post('address');

			$data_personal_info = array(
          				'user_pers_id' => $pers_id ,
          				'user_pers_fname' => $pers_fname ,
          				'user_pers_lname' => $pers_lname,
          				'user_pers_fname_en' => $pers_fname_en ,
          				'user_pers_lname_en' => $pers_lname_en,
          				'user_pers_card_id' => $pers_card_id,
          				'user_pers_address' => $pers_address,
          				'user_pers_mobile' => $pers_mobile,
          				'user_pers_user_id' => $new_user_id
      		);
			$this->recordPersonal($data_personal_info);

			/*
			* Record User working info
			*/
			$empId = $this->input->post('empId');
			$company = $this->input->post('company');
			foreach($this->input->post('position')  as $index => $position ){
				$position_add = $position;
				$empId_add = $empId[$index] ;
                $empId_add = empty($empId_add)?$new_user_id:$empId_add;
				$company_add = $company[$index];

				$data_working_info = array(
          				'user_work_id' => 0,
          				'user_work_company' => $company_add,
          				'user_work_position' => $position_add,
          				'user_work_emp_id' => $empId_add,
          				'user_work_user_id' => $new_user_id
      			);
				$this->recordWorking($data_working_info);	
			}

			/*
			* Record User 
			*/
			$newPermission = $this->input->post('Permission');
			$newUsername = $this->input->post('username');
			$newPassword = md5($this->input->post('password'));
			$data_user = array(
          				'user_id' => $new_user_id,
          				'user_pers_id_ref' => $pers_id,
          				'user_permission' => $newPermission,
          				'user_sts_active' => 'on',
          				'user_username' => $newUsername,
          				'user_password' => $newPassword
      		);
      		$this->recordUser($data_user);

      // 		$post_auth = $this->input->post('authorize');
      // 		 if(!empty($post_auth))
		    // {
		    //     $authorize_bf = "";
		    //     $authorize_cf = "";
		    //     $authorize_if = "";
		    //     foreach($post_auth as $checkbox)  
		    //     {
		    //       if ( trim($checkbox) == "Booking Fee" )          $authorize_bf = "yes";
		    //       else if ( trim($checkbox) == "Contact Fee" )     $authorize_cf = "yes";
		    //       else if ( trim($checkbox) == "Installment Fee" ) $authorize_if = "yes";
		    //     }
		    //     $this->load->model('tb_user_authorize');
		    //     $data_auth = array(
		    //     	'user_id' => $new_user_id,
		    //     	'user_bookingfee' => $authorize_bf,
		    //     	'user_contactfee' => $authorize_cf,
		    //     	'user_installmentfee' => $authorize_if,
		    //     	'user_remark' => ''
		    //     );
		    //     $this->tb_user_authorize->record($data_auth);       
		    // }

      		/*=======================================*/
		 	/*======= check status transaction ======*/
			/*=======================================*/
			if ($this->db->trans_status() === FALSE){
	     		$this->db->trans_rollback();
	 			alert_redirect('Add User Fail','/user/view');
			}
			else{
			  	$this->db->trans_commit();
			   	alert_redirect('Add User Success','/user/view');
			}
		}else{
			alert_redirect('Username is already... Please change new Username','/user/adding');
		}
	}
	public function update($user_id) //// save
	{
		/*================================*/
		/*======= Transaction start ======*/
		/*================================*/
		$this->load->database();
		$this->db->trans_begin();

		$pers_card_id = $this->input->post('idcard');
		if(strlen($pers_card_id)<13){
			alert_redirect('ID card number is not correct... Please enter check ID card number!!!',"/user/editting/".$user_id);
		}

		/*
		* Record Log Personal info
		*/
		$pers_fname = $this->input->post('firstname');
		$pers_lname = $this->input->post('lastname');
		$pers_fname_en = $this->input->post('firstnameEN');
		$pers_lname_en = $this->input->post('lastnameEN');
		$pers_idcard = $this->input->post('idcard');
		$pers_mobile = $this->input->post('mobile');
		$pers_address = $this->input->post('address');
		$password = $this->input->post('password');
		$pers_Permission = $this->input->post('Permission');
		$userEdit = $this->user_id;

		$data_log_personal_info = array(
          				'user_pers_id' => $user_id ,
          				'user_pers_fname' => $pers_fname ,
          				'user_pers_lname' => $pers_lname,
          				'user_pers_fname_en' => $pers_fname_en ,
          				'user_pers_lname_en' => $pers_lname_en,
          				'user_pers_card_id' => $pers_idcard,
          				'user_pers_address' => $pers_address,
          				'user_pers_mobile' => $pers_mobile
      	);
      	$this->record_log_personal($data_log_personal_info);

      	/*
		* Update Personal info
		*/
		$data_personal_info = array(
          				'user_pers_fname' => $pers_fname ,
          				'user_pers_lname' => $pers_lname ,
          				'user_pers_fname_en' => $pers_fname_en ,
          				'user_pers_lname_en' => $pers_lname_en,
          				'user_pers_card_id' => $pers_idcard,
          				'user_pers_address' => $pers_address,
          				'user_pers_mobile' => $pers_mobile
      	);
		$this->updatePersonal($data_personal_info,$user_id);

		/*
		* Update User 
		*/
		$data_user['user_permission'] = $pers_Permission;
        if(!empty($password)) {
            $data_user['user_password'] = md5($password);
        }
		$this->updateUser($data_user,$user_id);

		$this->load->model('tb_user_authorize');
		$post_auth = $this->input->post('authorize');
		$authorize_bf = "";
        $authorize_cf = "";
        $authorize_if = "";
        if(!empty($post_auth))
        {              
              foreach($post_auth as $checkbox)  
              {
                   if ( trim($checkbox) == "Booking Fee" )          $authorize_bf = "yes";
                   else if ( trim($checkbox) == "Contact Fee" )     $authorize_cf = "yes";
                   else if ( trim($checkbox) == "Installment Fee" ) $authorize_if = "yes";
              }              
        }
        // $authorize = $this->tb_user_authorize->get_info_by_user_id($user_id);
        // if (count($authorize) > 0)
        // {
        //     $data_update_auth = array(
        //     	'user_bookingfee' => $authorize_bf,
        //     	'user_contactfee' => $authorize_cf,
        //     	'user_installmentfee' => $authorize_if,
        //     	'user_remark' => ''
        //     );
        //     $this->tb_user_authorize->update($data_update_auth,$user_id);      
        // }
        // else
        // {	
        // 	$data_add_auth = array(
        // 		'user_id' => $user_id,
        // 		'user_bookingfee' => $authorize_bf,
        // 		'user_contactfee' => $authorize_cf,
        // 		'user_installmentfee' => $authorize_if,
        // 		'user_remark' => ''
        // 	);
      		// $this->tb_user_authorize->record($data_add_auth);                  
        // }
		/*
		* Update Working info
		*/
//		$empId = $this->input->post('empId');
		$company = $this->input->post('company');
		$object = $this->fetch_user_working($user_id);

		foreach($object as $get){
			$user_work_id = $get->user_work_id;
			$this->deleteWorkingInfo(array('user_work_id' => $user_work_id));
			
		}

		if($this->input->post('position') != ''){
			foreach($this->input->post('position')  as $index => $position ){
				$position_add = $position;
//				$empId_add = $empId[$index];
				$company_add = $company[$index];
				$data = array(
          				'user_work_id' => '0' ,
          				'user_work_company' => $company_add ,
          				'user_work_position' => $position_add,
          				'user_work_emp_id' => $user_id,
          				'user_work_user_id' => $user_id
      			);
				$this->recordWorking($data);

				// KEEP LOG
				$data_log_working_info = array(
          				'user_work_id' => '0',
          				'user_work_company' => $company_add,
          				'user_work_position' => $position_add,
          				'user_work_emp_id' => $empId_add,
          				'user_work_user_id' => $user_id,
          				'user_work_update_by' => $this->user_id
      			);
				$this->record_log_working($data_log_working_info);
				///////////
				
			}
		}
		/*=======================================*/
		/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->db->trans_status() === FALSE){
	     	$this->db->trans_rollback();
	 		alert_redirect('Edit User Fail','/user/view');
		}
		else{
		  	$this->db->trans_commit();
		   	alert_redirect('Edit User Success','/user/view');
		}
		
	}
	

	/**
	* -------------------------------------
	* Scope [PRIVATE METHOD]
	* -------------------------------------
	*/
	//////// FETCH DATA //////
	//////////////////////////
	private function fetch_all_permission()
	{
		$this->load->model('tb_permission');
		return $this->tb_permission->fetch_all_permission();
	}
	private function fetch_all_personal()
	{
		$this->load->model('tb_user_personal_info');
		return $this->tb_user_personal_info->fetch_all_personal();
	}
	private function fetch_user_company($user_id)
	{
		$this->load->model('tb_user_working_info');
		return $this->tb_user_working_info->fetch_user_company($user_id);
	}
	private function fetch_user_working($user_id)
	{
		$this->load->model('tb_user_working_info');
		return $this->tb_user_working_info->fetch_user_working($user_id);
	}

	//////// AUTO INCREATMENT ID //////
	///////////////////////////////////
	private function get_new_user_id()
	{
		$this->load->model('tb_user');
		return $this->tb_user->get_new_user_id();
	}
	private function get_new_personal_id()
	{
		$this->load->model('tb_user_personal_info');
		return $this->tb_user_personal_info->get_new_personal_id();
	}
	private function get_new_working_id()
	{
		$this->load->model('tb_user_working_info');
		return $this->tb_user_working_info->get_new_working_id();
	}

	//////// INSERT DATA //////
	///////////////////////////
	private function recordPersonal($data)
	{
		$this->load->model('tb_user_personal_info');
	 	$this->tb_user_personal_info->record($data);
	}
	private function recordWorking($data)
	{
		$this->load->model('tb_user_working_info');
		$this->tb_user_working_info->record($data);
	}
	private function recordUser($data)
	{
		$this->load->model('tb_user');
		$this->tb_user->record($data);
	}

	//////// UPDATE DATA //////
	///////////////////////////
	private function updateUser($data,$user_id)
	{
		$this->load->model('tb_user');
		$this->tb_user->update($data,$user_id);
	}
	private function updatePersonal($data,$user_id)
	{
		$this->load->model('tb_user_personal_info');
		$this->tb_user_personal_info->update($data,$user_id);
	}

	//////// DELETE DATA //////
	///////////////////////////
	private function deleteWorkingInfo($where)
	{
		$this->load->model('tb_user_working_info');
		$this->tb_user_working_info->delete($where);
	}
	
	//////// COMMON METHOD //////
	/////////////////////////////
	private function isUsernameExist($username)
	{
		$this->load->model('tb_user');
		return $this->tb_user->isUsernameExist($username);
	}
	private function get_detail_personal($user_id)
	{
		$this->load->model('tb_user_personal_info');
		return $this->tb_user_personal_info->get_detail_personal($user_id);
	}
	/**
	* -------------------------------------
	* Log Management [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function record_log_personal($data)
	{
		$this->load->model('log_user_personal_info');
	 	$this->log_user_personal_info->record($data);
	}
	private function record_log_working($data)
	{
		$this->load->model('log_user_working_info');
	 	$this->log_user_working_info->record($data);
	}

}

/* End of file user.php */
/* Location: ./application/controllers/user.php */