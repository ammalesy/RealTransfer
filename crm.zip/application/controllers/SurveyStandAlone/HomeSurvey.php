<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class HomeSurvey extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin Back Office';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
   	public function index()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['setting'] = $this->get_user_permission();
		$data['list_project'] = $this->fetch_user_project();
		$data['title'] = $this->title_page;
		$data['loginName'] = $this->user_username;
		$this->load->view('Home/HomeSurvey',$data);
	}
	private function fetch_user_project(){
		$this->load->model('tb_project');
		return $this->tb_project->fetch_user_project($this->user_id);
	}
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */