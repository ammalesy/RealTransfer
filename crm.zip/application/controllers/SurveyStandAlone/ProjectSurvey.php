<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ProjectSurvey extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
  {
      parent::__construct();
  }
	public function index()
	{
		$this->view();
	}
	public function select($pj_id){
		$detail_pj = $this->get_detail_project($pj_id);
		$this->session->set_userdata('project_id_sel', $detail_pj->pj_id);
		$this->session->set_userdata('project_name_sel', $detail_pj->pj_name);
		$this->session->set_userdata('project_database_sel',  $detail_pj->pj_datebase_name);
		$this->refreshSession();
    	echo '<script>window.location.href = "'.BASE_DOMAIN.'survey/surveyStandAlone"</script>';
	}
	/**
	* -------------------------------------
	* [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function get_detail_project($pjid){
		$this->load->model('tb_project');
		return $this->tb_project->get_detail_project($pjid);
	}
}

/* End of file project.php */
/* Location: ./application/controllers/project.php */