<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class NZ_Model extends CI_Model{

	var $dbCommon = NULL;
	
	function __construct()
    {
        parent::__construct();
        $CI =& get_instance();
        $CI->load->database();
        $this->dbCommon = $CI->db->database;
    }
}
