<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_transfer_contract extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_transfer_contract', $array);
    }
    function fetch_all_by_tf_project_id($tf_project_id){
      $query = $this->pdb->query("SELECT
                                  tf_id,
                                  tf_code,
                                  tf_from_cus,
                                  tf_to_cus,
                                  tf_room,
                                  tf_contract_id_new,
                                  tf_contract_id_old,
                                  tf_timestamp,
                                  un_name
                                  FROM tb_transfer_contract,tb_unit_number
                                  WHERE  tf_room = un_id
                                  AND tf_project_id = '".$tf_project_id."'");
      return $query->result();
    }
    function get_detail_by_tf_code($tf_code){

      $query = $this->pdb->query("SELECT *
                                  FROM tb_transfer_contract
                                  INNER JOIN tb_contract  
                                  ON (ct_code = ct_tranfer_letter)
                                  WHERE tf_code = '".$tf_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_new_transfer_contract_id()
    {

        $query = $this->pdb->query("SELECT  COUNT(tf_code) as newid
                                    FROM tb_transfer_contract
                                    WHERE tf_project_id = '".$this->project_id_sel."'");
        $row = $query->result();
        $new_id = ($row[0]->newid + 1);
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    
}

/* End of file tb_transfer_contract.php */
/* Location: ./application/models/tb_transfer_contract.php */