<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_cancelation extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_cancelation', $array);
    }
    function update($array,$cc_id)
    {
      $this->pdb->where('cc_id', $cc_id);
      $this->pdb->update('tb_cancelation', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_cancelation', $array, $where);
    }
    function fetch_cancelation_by_booking_code($bkcode)
    {
        $query = $this->pdb->query("
            SELECT *
            FROM tb_cancelation
            WHERE cc_booking_code = '$bkcode'
        ");
        $result = $query->result();
        return $result[0];
    }
    function fetch_cancelation_by_contract_code($ctcode)
    {
        $query = $this->pdb->query("
            SELECT *
            FROM tb_cancelation
            WHERE cc_contract_code = '$ctcode'
        ");
        $result = $query->result();
        return $result[0];
    }
    function get_booking_cancelled_history()
    {
        $query = $this->pdb->query("
            SELECT cc_booking_code, CONCAT(pers_fname, ' ', pers_lname) AS fullname, CONCAT(building_name, ' ', un_name) as unit, cc_timestamp as cc_date, CONCAT(user_pers_fname, ' ', user_pers_lname) AS staff, cc_remark
            FROM tb_cancelation
            LEFT JOIN tb_booking ON (bk_booking_code = cc_booking_code)
            LEFT JOIN tb_quotation ON (qt_code = bk_quotation_code)
            LEFT JOIN tb_unit_number ON (un_id = qt_unit_number_id)
            LEFT JOIN tb_building ON (building_id = un_build_id)
            LEFT JOIN $this->dbCommon.tb_customer_personal_info ON (pers_id_cus = bk_leads_id)
            LEFT JOIN $this->dbCommon.tb_user_personal_info ON (user_pers_user_id = cc_staff)
            WHERE cc_contract_code IS NULL
            ORDER BY cc_timestamp DESC
        ");
        return $query->result();
    }
    function get_contract_cancelled_history()
    {
        $query = $this->pdb->query("
            SELECT cc_contract_code, CONCAT(pers_fname, ' ', pers_lname) AS fullname, CONCAT(building_name, ' ', un_name) as unit, DATE_FORMAT(cc_timestamp, '%d/%m/%Y') as cc_date, CONCAT(user_pers_fname, ' ', user_pers_lname) AS staff, cc_remark
            FROM tb_cancelation
            LEFT JOIN tb_contract ON (ct_code = cc_contract_code)
            LEFT JOIN tb_booking ON (bk_booking_code = cc_booking_code)
            LEFT JOIN tb_quotation ON (qt_code = bk_quotation_code)
            LEFT JOIN tb_unit_number ON (un_id = qt_unit_number_id)
            LEFT JOIN tb_building ON (building_id = un_build_id)
            LEFT JOIN $this->dbCommon.tb_customer_personal_info ON (pers_id_cus = SUBSTRING_INDEX(ct_cus_id, ',', 1))
            LEFT JOIN $this->dbCommon.tb_user_personal_info ON (user_pers_user_id = cc_staff)
            WHERE cc_contract_code IS NOT NULL
            ORDER BY cc_timestamp DESC
        ");
        return $query->result();
    }
}
?>