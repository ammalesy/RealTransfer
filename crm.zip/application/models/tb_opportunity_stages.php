<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_opportunity_stages extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_opportunity_stages', $array);
    }
    function fetch_opportunity_stages(){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_opportunity_stages");
      return $query->result();
    }
    function get_by_id($id)
    {
        $query = $this->db->where('op_id',$id)->get("tb_opportunity_stages");
        return $query->result()[0];
    }
}

/* End of file tb_opportunity_stages.php */
/* Location: ./application/models/tb_opportunity_stages.php */