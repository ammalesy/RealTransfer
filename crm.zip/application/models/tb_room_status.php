<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_room_status extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_room_status', $array);
    }
    function fetch_room_by_rs_unit_number($rs_unit_number){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_room_status  
                                 WHERE  rs_unit_number =  '".$rs_unit_number."'");
      return $query->result();
    }
    function fetch_fullDetailroom_by_rs_unit_number($rs_unit_number){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_room_status 
                                 LEFT JOIN ".$this->dbCommon.".tb_user ON (rs_staff_id=user_id)
                                 LEFT JOIN ".$this->dbCommon.".tb_user_personal_info ON (user_pers_id_ref=user_pers_id)
                                 WHERE rs_unit_number = ".$rs_unit_number);
      return $query->result();
    }
}

/* End of file tb_room_status.php */
/* Location: ./application/models/tb_room_status.php */