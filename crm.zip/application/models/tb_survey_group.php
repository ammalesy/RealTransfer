<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_survey_group extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_survey_group', $array);
      $insert_id = $this->pdb->insert_id();
      return  $insert_id;
    }
    function update($array, $id)
    {
        $this->pdb->where('sg_id', $id)->update('tb_survey_group', $array); 
    }
    function get_all()
    {
      return $this->pdb->get('tb_survey_group')->result();
      
    }
    function get_all_active() {
      $this->load->database();
      $query = $this->pdb->query("  select 
                                      sg_id AS id,
                                      sg_name AS nameTh,
                                      sg_name_en AS nameEn 
                                    from `tb_survey_group`
                                    where sg_active = 'Y'");
      $result = $query->result();
      return $result;
    }
    function get_by_id($id)
    {
        return $this->pdb->where('sg_id',$id)->get('tb_survey_group')->result()[0];
    }
    
    function get_detail_by_id($id)
    {
        $this->load->database();
      	$query = $this->pdb->query("	SELECT * FROM tb_survey_group
                                        WHERE sg_id = '".$id."'");
      	$result = $query->result();
  		if(count($result) > 0){
  		return $result[0];
  		}else{
  		return NULL;
  		}
    }
    function create_table_survey ($sg_table_code, $columns) {
      $this->load->database();
      $sql = "CREATE TABLE IF NOT EXISTS `".$sg_table_code."` (";
      $sql .= "`id` int(10) NOT NULL";
      $sql .= ",`cus_id` int(10) NOT NULL";
      foreach ($columns as $column) {
        $sql .= ",`".$column."` varchar(2000) NOT NULL  DEFAULT '[]'";
      }
      $sql .= ",`sg_id` int(10) NOT NULL";
      $sql .= ",`timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";
      $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
      $this->pdb->query($sql);
      
      $sql = "ALTER TABLE `".$sg_table_code."` ADD PRIMARY KEY (`id`);";
      $this->pdb->query($sql);

      $sql = "ALTER TABLE `".$sg_table_code."` MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;";
      $this->pdb->query($sql);
    }
    function get_question_survey ($sgID) {
      $this->load->database();
      $query = $this->pdb->query("  select 
                                      sq_id, 
                                      sq_name, 
                                      sq_name_en AS nameEng,
                                      sq_main_sub AS checkMain
                                    from `tb_survey_question`
                                    where FIND_IN_SET( sq_id, (select sg_question from `tb_survey_group` where sg_id = '".$sgID."'))
                                    ORDER BY FIND_IN_SET( sq_id, (SELECT sg_question FROM `tb_survey_group` WHERE sg_id = '3'))");
      $result = $query->result();
      return $result;
    }
    function get_question_survey_dashboard ($sgID) {
      $this->load->database();
      $query = $this->pdb->query("  select 
                                      sq_id, 
                                      sq_name, 
                                      sq_name_en AS nameEng,
                                      sq_main_sub AS checkMain
                                    from `tb_survey_question`
                                    where FIND_IN_SET( sq_id, (select sg_question from `tb_survey_group` where sg_id = '".$sgID."'))");
      $tmpResult = $query->result();
      $result = array();
      foreach ($tmpResult as $index => $tmpResult) {
        if ($tmpResult->checkMain === 'M') {
          $query = $this->pdb->query("  SELECT 
                                            sq_id AS id,
                                            sq_name AS nameTh,
                                            sq_name_en AS nameEn
                                        FROM tb_survey_question
                                        WHERE sq_main_question = '$tmpResult->sq_id'
                                        AND sq_active = 'Y'");
          $tmpSubResult = $query->result();
          foreach ($tmpSubResult as $indexSub => $tmpSubResult) {
            $resultArr[$index+$indexSub+100]->id = $tmpSubResult->id;
            $resultArr[$index+$indexSub+100]->nameTh = $tmpSubResult->nameTh;
            $resultArr[$index+$indexSub+100]->nameEn = $tmpSubResult->nameEn;
            array_push($result, $resultArr[$index+$indexSub+100]);
          }
        } else {
          $resultArr[$index]->id = $tmpResult->sq_id;
          $resultArr[$index]->nameTh = $tmpResult->sq_name;
          $resultArr[$index]->nameEn = $tmpResult->nameEng;
          array_push($result, $resultArr[$index]);
        }
      }
      return $result;
    }
}
?>