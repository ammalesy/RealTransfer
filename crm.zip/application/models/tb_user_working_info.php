<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_user_working_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_user_working_info', $array);
    }
    function delete($where)
    {
        $this->db->delete('tb_user_working_info',$where);
    }
    function fetch_user_working($user_id)
    {
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM  tb_user_working_info
                                   WHERE  user_work_user_id = '".$user_id."'");
        return $query->result();
    }
    function fetch_user_company($user_id)
    {
        $this->load->database();
        $query = $this->db->query("SELECT user_work_company, user_work_position, user_work_emp_id
                                   FROM  tb_user_working_info
                                   WHERE  user_work_user_id = '".$user_id."'");
        return $query->result();
    }
    function get_new_working_id()
    {

        $this->load->database();
        $query = $this->db->query("SELECT Max(user_work_id)+1 as MaxID 
                                  FROM tb_user_working_info");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    
    function get_user_company($user_id)
    {
        $this->load->database();
        $query = $this->db->query("SELECT user_work_company, user_work_position, user_work_emp_id
                                   FROM  tb_user_working_info
                                   WHERE  user_work_user_id = '".$user_id."'");
        $result = $query->result();
        if(count($result) > 0){
        return $result[0];
        }else{
        return NULL;
        }
    }
    
}

/* End of file tb_user_working_info.php */
/* Location: ./application/models/tb_user_working_info.php */