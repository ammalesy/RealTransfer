<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_lead_remark  extends NZ_Model {
    function __construct()
    {
        parent::__construct();
    }
    
    function FetchAll()
    {
        $query = $this->db->query("SELECT * FROM log_lead_remark");
        return $query->result();
    }
    
    function Lastest($cusid) {
        $query = $this->db->query("SELECT * FROM log_lead_remark
                                   WHERE lr_cus_id = $cusid
                                    AND lr_status = 'on'
                                   ORDER BY lr_id DESC;");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
//		return $this->db->get_where('log_lead_remark', array('lr_cus_id' => $cusid, 'lr_status' => 'on'))->result()[0];
    }
}