<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_credit_type extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function get_all_credit_type()
    {
        $query = $this->db->query("SELECT *
                                   FROM tb_credit_type");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_by_abbreviation($ct_abbreviation)
    {
        return $this->db->where('ct_abbreviation',$ct_abbreviation)->get('tb_credit_type')->result()[0]; 
    }
}
?>