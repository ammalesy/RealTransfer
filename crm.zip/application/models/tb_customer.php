<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_customer extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_customer', $array);
    }
    function update($array,$cus_id)
    {
      $this->load->database();
      $this->db->where('cus_id', $cus_id);
      $this->db->update('tb_customer', $array); 
    }
    function get_new_customer_id()
    {
        $this->load->database();
        $query = $this->db->query("SELECT Max(cus_id)+1 as MaxID from tb_customer");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    function get_detail_by_id($cid){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer 
                                 WHERE cus_id = '".$cid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_id_joinInfo_AddressInfo($cid){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM  tb_customer , tb_customer_personal_info , tb_customer_address_info
                                 WHERE addr_id = cus_addr_id 
                                 AND pers_id = cus_pers_id 
                                 AND cus_id in (".$cid.")
                                 ORDER BY FIELD(cus_id,".$cid.")");
      $result = $query->result();
      if(count($result) > 0){
        return $result;
      }else{
        return NULL;
      }
    }
    function get_detail_customer($cid){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM  tb_customer_address_current_info ,tb_customer_address_info, tb_customer_contact_info ,
                                       tb_customer_personal_info,tb_customer_working_info, tb_customer,tb_customer_address_lastest
                                 WHERE cus_addr_cur_id = addr_cur_id 
                                 AND cus_addr_id = addr_id 
                                 AND cus_con_id =con_id 
                                 AND cus_pers_id = pers_id 
                                 AND cus_work_id =work_id
                                 AND cus_addr_lastest_id = addr_lastest_id
                                 AND cus_id ='".$cid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_small_detail_customer($cid){
      $this->load->database();
      $query = $this->db->query("SELECT  *
                                 FROM  tb_customer, tb_customer_personal_info, 
                                       tb_customer_address_info , tb_nationality
                                 WHERE addr_id = cus_addr_id 
                                 AND pers_id = cus_pers_id 
                                 AND cus_id = '".$cid."' 
                                 AND pers_nationality = nt_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_small_detail_customer_cur($cid){
      $this->load->database();
      $query = $this->db->query("SELECT  *
                                 FROM  tb_customer, tb_customer_personal_info, 
                                       tb_customer_address_current_info , tb_nationality
                                 WHERE addr_cur_id = cus_addr_cur_id 
                                 AND pers_id = cus_pers_id 
                                 AND cus_id = '".$cid."' 
                                 AND pers_nationality = nt_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function fetch_customerSearchIN($cid){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM  tb_customer , tb_customer_personal_info , tb_customer_address_info
                                 WHERE  addr_id = cus_addr_id 
                                 AND pers_id = cus_pers_id 
                                 AND cus_id in (".$cid.")");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    

    function getCustomerFlag_by_id($cid){
      $this->load->database();
      $query = $this->db->query("SELECT cus_flag FROM tb_customer WHERE cus_id = '".$cid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0]->cus_flag;
      }else{
        return NULL;
      }
    }
    function get_detail_leads($cid){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer, tb_opportunity_stages ,tb_customer_personal_info 
                                 WHERE  cus_pers_id = pers_id 
                                 AND  cus_stages_id = op_id 
                                 AND cus_id = '".$cid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_leads_withOut_oppotunityStage($cid){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer ,tb_customer_personal_info 
                                 WHERE  cus_pers_id = pers_id 
                                 AND cus_sts_active = 'on'  
                                 AND cus_id = '".$cid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_leads_withOut_oppotunityStageAndActive($cid){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer ,tb_customer_personal_info 
                                 WHERE  cus_pers_id = pers_id  
                                 AND cus_id = '".$cid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function fetch_customer(){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE pers_id = cus_pers_id 
                                 AND cus_sts_active = 'on'  
                                 AND  cus_flag != 'leads'
                                 ORDER BY cus_id DESC");
      return $query->result();
    }
    function fetch_leads(){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_customer,tb_opportunity_stages,tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_stages_id = op_id
                                 AND cus_sts_active = 'on'   
                                 AND  cus_flag = 'leads'");
      return $query->result();
    }
    function fetch_leads_ignorActive(){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_customer,tb_opportunity_stages,tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_stages_id = op_id  
                                 AND  cus_flag = 'leads'
                                 ORDER BY cus_created_date DESC");
      return $query->result();
    }
    /*
    * Provide For DashBoard Module
    */

    function count_cus_id_with_flag($flag){
      $this->load->database();
      $query = $this->db->query("SELECT COUNT(cus_id) as newid  
                                 FROM tb_customer 
                                 WHERE cus_flag = '".$flag."'");
      $result = $query->result();
      $newid = $result[0]->newid;
      return $newid;
    }
    function count_cus_id_where($where){
      $this->load->database();
      $query = $this->db->query("SELECT COUNT(cus_id) as newid  
                                 FROM tb_customer 
                                 WHERE ".$where);
      $result = $query->result();
      return $result[0]->newid;
    }
    function get_lastCustomer(){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname  
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_flag = 'cus' 
                                 order by cus_id desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }
      return NULL;
    }
    function get_lastLead(){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname  
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_flag != 'cus' 
                                 order by cus_id desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }
      return NULL;
    }
    function get_fullname_of_quotationID($quoid){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname   
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_flag = 'cus' 
                                 AND cus_id = '".$quoid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0]->fullname;
      }else{
        return NULL;
      }
    }
    function get_fullname_of_contractID($conid){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname   
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_flag = 'cus' 
                                 AND cus_id = '".$conid."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0]->fullname;
      }else{
        return NULL;
      }
    }
    function get_fullname_of_receiptCustomerID($rep){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname   
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE cus_pers_id = pers_id 
                                 AND  cus_flag = 'cus' 
                                 AND cus_id = '".$rep."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0]->fullname;
      }else{
        return NULL;
      }
      
    }
    
    function get_customer_lead(){
      $query = $this->db->query("SELECT * FROM tb_customer");
      return $query->result();
    }
    
    function get_lead_min_date($start, $end){
      $query = $this->db->query(" SELECT MIN(cus_created_date) AS minDate FROM tb_customer ");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_lead_by_date($start, $end){
      $query = $this->db->query("   SELECT * FROM tb_customer
                                    WHERE (cus_created_date BETWEEN  '".$start."' AND  '".$end."')");
      return $query->result();
    }
}

/* End of file tb_customer.php */
/* Location: ./application/models/tb_customer.php */