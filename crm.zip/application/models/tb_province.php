<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_province extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_province', $array);
    }
    function fetch_all_province(){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM tb_province
                                 ORDER BY pv_name_th ASC");
      return $query->result();
    }
}

/* End of file tb_province.php */
/* Location: ./application/models/tb_province.php */