<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_authorize_user extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_authorized_user', $array);
    }
    function update($array,$au_id)
    {
      $this->load->database();
      $this->db->where('au_id', $au_id);
      $this->db->update('tb_authorized_user', $array); 
    }
     function fetch_(){
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_authorized_user");
        return $query->result();
    }
    function fetch_all(){
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_authorized_user
                                   LEFT JOIN tb_user_personal_info ON (au_user_id = user_pers_id) 
                                   ORDER BY au_id ASC");
        return $query->result();
    }
    function get_info_by_au_id($au_id){
      $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_authorized_user INNER JOIN tb_user_personal_info
                                   ON (au_user_id = user_pers_id)
                                   WHERE au_id = '".$au_id."'");
       $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    } 
    function get_info_by_au_user_id($au_user_id){
      $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_authorized_user INNER JOIN tb_user_personal_info
                                   ON (au_user_id = user_pers_id)
                                   WHERE au_user_id = '".$au_user_id."'");
       $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    }
     function get_info_by_documentContract(){
      $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_authorized_user
                                   INNER JOIN tb_user_personal_info ON (au_user_id = user_pers_user_id )
                                   WHERE au_document = 'Contract' ");
       $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    }
    function get_info_by_au_document($au_document){
      $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_authorized_user
                                   INNER JOIN tb_user_personal_info ON (au_user_id = user_pers_user_id )
                                   WHERE au_document = '".$au_document."' ");
       $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    }
    function checkDupplicate_name($docname){
      $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_authorized_user 
                                   WHERE TRIM(au_document) ='".$docname."'");
        $row = $query->result();
        if (count($row) > 0) {
            return TRUE;
        }else{
          return FALSE;
        }
      
    }
}

/* End of file tb_authorize_user.php */
/* Location: ./application/models/tb_authorize_user.php */