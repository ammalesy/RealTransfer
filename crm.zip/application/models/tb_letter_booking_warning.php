<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_letter_booking_warning extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_letter_booking_warning', $array);
    }
    function fetch_all_letter_booking_warning(){
      $query = $this->pdb->query("SELECT *
                                 FROM tb_letter_booking_warning");
      return $query->result();
    }
    function get_detail_by_code($lt_code)
    {
        return $this->pdb->where('lt_code',$lt_code)->get('tb_letter_booking_warning')->result()[0];
    }
    function fetch_all_by_lt_project_id($lt_project_id){
      $query = $this->pdb->query("SELECT
                                  lt_id,
                                  lt_code,
                                  lt_cus_id,
                                  lt_project_id,
                                  lt_booking_id,
                                  bk_remark,
                                  lt_timestamp
                                  FROM 
                                  tb_letter_booking_warning 
                                  INNER JOIN tb_booking
                                  ON (lt_booking_id=bk_booking_code) 
                                  WHERE lt_project_id = '".$lt_project_id."'");
      return $query->result();
    }
    function get_new_letter_id()
    {

        $query = $this->pdb->query("SELECT COUNT(lt_id) as newid  
                                    FROM tb_letter_booking_warning  
                                    WHERE lt_project_id ='".$this->project_id_sel."'");
        $row = $query->result();
        $new_id = $row[0]->newid;
        if($new_id == NULL){ 
            return "1";
        }else{
            return ($new_id + 1);
        }
    }

}

/* End of file tb_letter_booking_warning.php */
/* Location: ./application/models/tb_letter_booking_warning.php */