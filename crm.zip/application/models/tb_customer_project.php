<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_customer_project extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_customer_project', $array);
    }
    function update($array,$cpid)
    {
      $this->load->database();
      $this->db->where('cp_id', $cpid);
      $this->db->update('tb_customer_project', $array);
    }
    function get_id_by_cus($cusid)
    {
        $this->load->database();
        $this->db->where('cp_cus_id', $cusid);
        $this->db->where('cp_status', 'on');
        $get = $this->db->get('tb_customer_project');
        return $get->result()[0];
    }
    function get_count_off_room_by_cus_id($cusid)
    {
        $query = $this->pdb->query("
            SELECT
            (
                SELECT COUNT(ct_id)
                FROM tb_contract
                WHERE ct_active = 'on'
                AND $cusid IN (ct_cus_id)
            )
            +
            (
                SELECT COUNT(bk_booking_id)
                FROM tb_booking
                WHERE bk_status = 'on'
                AND bk_leads_id = $cusid
            )
            AS num
        ");
        return $query->result()[0]->num;
    }
    function get_string_pro($cid) {
        $query = $this->db->query("
            SELECT  pj_name
            FROM tb_customer_project, tb_project
            WHERE cp_status = 'on'
            AND cp_cus_id = $cid
            AND cp_project_id = pj_id
            /*SELECT  cp_project_id
            FROM tb_customer_project
            WHERE cp_status = 'on'
            AND cp_cus_id = $cid*/
        ");

        $pid = '';
        foreach($query->result() as $val) {
            // $pid .= empty($pid)?'':',';
            // $len  = strlen($val->cp_project_id);
            // $tmp  = '';
            // for($i=$len;$i<2;$i++) $tmp .= '0';
            // $pid .= 'P'.$tmp.$val->cp_project_id;
            $pid .= $val->pj_name;
        }
        return $pid;
    }
}
?>
