<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_customer_contact_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_customer_contact_info', $array);
    }
    function update($array,$cus_id)
    {
      $this->load->database();
      $this->db->where('con_id', $cus_id);
      $this->db->update('tb_customer_contact_info', $array); 
    }
    function get_detail_by_con_id_cus($con_id_cus){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer_contact_info 
                                 WHERE con_id_cus = '".$con_id_cus."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_new_customer_contact_info_id()
    {

        $this->load->database();
        $query = $this->db->query("SELECT Max(con_id)+1 as MaxID from tb_customer_contact_info");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    
}

/* End of file tb_customer_contact_info.php */
/* Location: ./application/models/tb_customer_contact_info.php */