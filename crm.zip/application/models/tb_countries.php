<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_countries extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_countries', $array);
    }
    function fetch_all_countries(){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM tb_countries");
      return $query->result();
    }
}

/* End of file tb_countries.php */
/* Location: ./application/models/tb_countries.php */