<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_bank_account  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function get_all_bank_account()
    {
        $query = $this->db->query("SELECT *
                                   FROM tb_bank_account");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
}
?>