<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_customer extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('log_customer', $array);
    }
    function update($array,$cus_id)
    {
      $this->load->database();
      $this->db->where('cus_id', $cus_id);
      $this->db->update('log_customer', $array); 
    }
}

/* End of file log_customer.php */
/* Location: ./application/models/log_customer.php */