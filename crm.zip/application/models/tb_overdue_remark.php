<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_overdue_remark extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_overdue_remark ', $array);
    }
}
?>