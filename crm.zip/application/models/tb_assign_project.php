<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_assign_project extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_assign_project', $array);
    }
    function update($array,$assign_id)
    {
      $this->load->database();
      $this->db->where('assign_id', $assign_id);
      $this->db->update('tb_assign_project', $array); 
    }
    function get_detail_assign_project($aid){
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_assign_project
                                   WHERE assign_id ='".$aid."'");
        $row = $query->result();
        return $row[0]; 
    }
    function fetch_all_assign_project()
    {
    	  $this->load->database();
        $query = $this->db->query("SELECT  assign_id , pj_name, user_pers_fname, user_pers_lname 
                                   FROM tb_assign_project, tb_user_personal_info  , tb_user, tb_project
                                   WHERE pj_id = assign_project_id 
                                   AND user_pers_id_ref =  user_pers_id 
                                   AND assign_user_id = user_id
                                   AND user_sts_active = 'on' 
                                   AND assign_sts_active= 'on'");
  
        return $query->result();
    }
     
}

/* End of file tb_assign_project.php */
/* Location: ./application/models/tb_assign_project.php */