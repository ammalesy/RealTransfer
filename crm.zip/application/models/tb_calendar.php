<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_calendar extends NZ_Model {

    function __construct()
    {
        parent::__construct();
    }
    function record($data)
    {
        $this->pdb->insert('tb_calendar', $data);
        return $this->pdb->insert_id();
    }
    function update($id, $data)
    {
        $this->pdb->where('cd_id', $id)->update('tb_calendar', $data);
    }
    
    function jsonEvent()
    {
        $select = 'cd_id AS id, cd_title AS title, cd_start AS start, cd_end AS end, cd_url AS url';
        return $this->pdb->select($select)->where('cd_status', 'on')->get('tb_calendar')->result();
    }
}
?>