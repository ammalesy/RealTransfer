<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_authorized_user extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('log_authorized_user', $array);
    }
}

/* End of file log_authorized_user.php */
/* Location: ./application/models/log_authorized_user.php */