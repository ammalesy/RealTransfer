<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Installment_ extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function fetch_all_installment($project_id_sel){
        $this->load->database();
        $query = $this->db->query(" 
            SELECT  distinct bk_quotation_code, bk_booking_code, bk_contract_date, ct_code, ct_paid, ct_active, ct_date,
                cp.pers_fname, cp.pers_lname, cp.pers_mobile, cp.pers_tel, cp.pers_email,
                CONCAT(tp.pers_fname,' ',tp.pers_lname) AS old_name, tp.pers_mobile AS old_mobile,
                tp.pers_tel AS old_tel, tp.pers_email AS old_email
            FROM ".$this->project_database_sel.".tb_booking  
            INNER JOIN ".$this->project_database_sel.".tb_contract  ON (ct_booking_code = bk_booking_code) 
            INNER JOIN tb_customer ON (ct_cus_id = cus_id)
            INNER JOIN tb_customer_personal_info cp ON (cus_pers_id = cp.pers_id)                
            LEFT JOIN $this->project_database_sel.tb_transferred ON (tf_old_contract = ct_code)
            LEFT JOIN tb_customer_personal_info tp ON (tp.pers_id_cus = SUBSTRING_INDEX(tf_old_customer, ',', 1))
            WHERE bk_project_id = '$project_id_sel'
            GROUP BY ct_code
            ORDER BY ct_code desc
        ");
        return $query->result();
    }
}

/* End of file installment_.php */
/* Location: ./application/models/installment_.php */