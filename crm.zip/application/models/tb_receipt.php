<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_receipt  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_receipt', $array);
    }
    function update($array,$rc_receipt_id)
    {
      $this->pdb->where('rc_id', $rc_receipt_id);
      $this->pdb->update('tb_receipt', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_receipt', $array, $where);
    }
    function get_next_id() {
        $this->pdb->select_max('rc_id');
        $query = $this->pdb->get('tb_receipt');
        return $query->result()[0]->rc_id + 1;
    }
    function get_receipt_by_id($rid)
    {
        return $this->pdb->query("
            SELECT *
            FROM tb_receipt
            WHERE rc_id = '$rid'
            AND rc_code LIKE 'wait%'
        ")->result()[0];
    }
    function fetch_full_receipt($type,$project_id_sel){
      $condition  = " and`rc_code` like 'wait%'";
      if($type=='all'){
          $condition  = ''; 
      }
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM  ".$this->project_database_sel.".tb_booking  ,".$this->project_database_sel.".tb_receipt , tb_customer ,tb_customer_personal_info 
                                 WHERE bk_leads_id = cus_id 
                                 AND  pers_id = cus_pers_id AND rc_booking_code = bk_booking_code ".$condition." 
                                 AND  bk_project_id = '".$project_id_sel."'");
      return $query->result();
    }
    function get_full_detailReceipt($rc_receipt_code){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                FROM ".$this->project_database_sel.".tb_receipt , tb_customer, tb_customer_personal_info 
                                WHERE rc_customer_id = cus_id 
                                AND  pers_id = cus_pers_id 
                                AND rc_code ='".$rc_receipt_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detailReceipt_by_id($rc_receipt_id){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM ".$this->project_database_sel.".tb_receipt , tb_customer, tb_customer_personal_info
                                 WHERE rc_id = '".$rc_receipt_id."' 
                                 AND  rc_customer_id =  cus_id  
                                 AND cus_pers_id =  pers_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
       
    }
    function get_detailReceipt_by_id_withBooking($rc_receipt_id){
       $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM ".$this->project_database_sel.".tb_receipt , ".$this->project_database_sel.".tb_booking , 
                                      tb_customer, tb_customer_personal_info
                                 WHERE rc_id = '".$rc_receipt_id."' 
                                AND  rc_customer_id = cus_id  
                                AND cus_pers_id =  pers_id 
                                AND rc_booking_code = bk_booking_code");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_new_receipt_id()
    {
       
        $query = $this->pdb->query("SELECT MAX(rc_id) as newid  
                                   FROM tb_receipt  
                                   WHERE rc_code LIKE 'R%'");
        $row = $query->result();
        $new_id = $row[0]->newid + 1;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    } 

    /*
    * Provide For DashBoard Module
    */
    function ge_last_receipt_customer(){
     
      $query = $this->pdb->query("SELECT rc_code, bk_leads_id
                                  FROM  tb_booking  ,tb_receipt  
                                  WHERE rc_code LIKE 'Waiting%' 
                                  AND rc_booking_code = bk_booking_code 
                                  order by  rc_id desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function count_rc_receipt_code(){
       
       $query = $this->pdb->query("SELECT  COUNT(rc_code)  as Recwaitnumber 
                                  FROM tb_booking  ,tb_receipt  
                                  WHERE rc_code LIKE 'Waiting%' 
                                  AND  rc_booking_code = bk_booking_code");
       $result = $query->result();
       return $result[0]->Recwaitnumber;
    }
	
	function count_receipt_waiting_code(){
	 $query = $this->pdb->query("SELECT  COUNT(rc_code)  AS waitnumber 
                                  FROM tb_receipt  
                                  WHERE rc_confirm ='N' OR rc_confirm ='no'");
       $result = $query->result();
       return $result[0]->waitnumber;	
	}
    
    function get_receiptCode_by_contract($conid) {
        $query = $this->pdb->query("SELECT * FROM tb_receipt ,tb_contract"           
                                ." WHERE ct_code = '".$conid."' AND rc_contract_code = ct_code ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_receipt_by_contract($conid) {
        $query = $this->pdb->query("SELECT * FROM tb_receipt WHERE rc_contract_code = '".$conid."'");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_receiptCode_and_installmentTime_by_contract($conid , $in_time) {
        $query = $this->pdb->query("SELECT * FROM tb_receipt ,tb_contract          
                                WHERE ct_code = '".$conid."' 
                                AND rc_contract_code = ct_code 
                                AND rc_installment_time = '".$in_time."' 
                                ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }

    function get_receiptCode_by_booking($bid) {
        $query = $this->pdb->query("SELECT * FROM tb_receipt ,tb_booking"           
                                ." WHERE bk_booking_code = '".$bid."' AND rc_booking_code = bk_booking_code ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_receipt_by_booking($bid) {
        $query = $this->pdb->query("SELECT * FROM tb_receipt"           
                                ." WHERE rc_booking_code = '".$bid."'");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
}

/* End of file ".$this->project_database_sel.".tb_receipt .php */
/* Location: ./application/models/".$this->project_database_sel.".tb_receipt .php */