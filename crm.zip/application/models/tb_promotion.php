<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_promotion extends NZ_Model {
  
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_promotion', $array);
    }
    function update($array,$pm_id)
    {
      $this->pdb->where('pm_id', $pm_id);
      $this->pdb->update('tb_promotion', $array); 
    }
    function get_detail_by_id($pm_id){
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_promotion 
                                 WHERE pm_sts_active = 'on'  
                                 AND pm_id ='".$pm_id."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    }
    
    function fetch_detailTypeCash_by_pm_room_type_id($pm_room_type_id){
      $query = $this->pdb->query("SELECT distinct pm_id,pm_value,pm_name,pm_room_type_id,pm_unit_type
                                   FROM tb_promotion  
                                   WHERE pm_room_type_id = ".$pm_room_type_id." 
                                   AND  pm_type ='Credit'");
      return $query->result();
    }
    function get_detail_by_pm_type($pm_type){
      $query = $this->pdb->query("SELECT * FROM tb_promotion 
                                  WHERE pm_type = '".$pm_type."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    }
    function get_detail_typeCredit_by_id($pm_id){
      $query = $this->pdb->query("SELECT * FROM tb_promotion 
                                  WHERE TRIM(pm_type) = 'Credit'
                                  AND pm_id ='".$pm_id."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
      
    }
    function getPromotionTypeCash_equalGreaterDateExpire($today){

      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_type = 'Cash' 
                                 AND  pm_sts_active = 'on' 
                                 AND pm_date_expire >= '".$today."' 
                                 ORDER BY pm_id DESC LIMIT 1");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function getPromotionBySearchQuotation($promotiomQuo){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion
                                 WHERE  pm_id in ($promotiomQuo)");
      $row = $query->result();

      if(count($row) > 0){
        return $query->result();
      }else{
        return NULL;
      }
    }

    function getPromotionBySearchQuotation_Discount($promotiomQuo) {
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT SUM(pm_value) AS pm_value
                                 FROM  tb_promotion  
                                 WHERE pm_type = 'Cash' 
                                 AND  pm_id in ($promotiomQuo)");
      $row = $query->result();
      return $row[0]->pm_value;
    }

    function getPromotionBySearchQuotation_statusON($promotiomQuo){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_type = 'Cash' 
                                 AND pm_sts_active = 'on'
                                 AND  pm_id in ($promotiomQuo)");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_all(){

      $query = $this->pdb->query("SELECT * 
                                 FROM tb_promotion 
                                 WHERE pm_sts_active = 'on' 
                                ORDER BY pm_id ASC");
      return $query->result();
    }
    function fetchGiftBySearchQuotation($promotiomQuo){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_type != 'Cash' 
                                 AND  pm_id in ($promotiomQuo)");
      return $query->result();
    }
    
    function fetchDiscountBySearchQuotation($promotiomQuo){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_type = 'Cash' 
                                 AND  pm_id in ($promotiomQuo)");
      return $query->result();
    }
    function fetchFurnitureBySearchQuotation($promotiomQuo){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_type = 'Furniture' 
                                 AND  pm_id in ($promotiomQuo)");
      return $query->result();
    }
    function fetchAllCredit (){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_type = 'Credit'");
      return $query->result();
    }
    function fetchBySearchQuotation($promotiomQuo){
      if(empty($promotiomQuo)) 
        $promotiomQuo = 0;
      $query = $this->pdb->query("SELECT *
                                 FROM  tb_promotion  
                                 WHERE pm_id in ($promotiomQuo)");
      return $query->result();
    }
}

/* End of file tb_promotion.php */
/* Location: ./application/models/tb_promotion.php */