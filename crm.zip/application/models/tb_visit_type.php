<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_visit_type extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_visit_type', $array);
    }
    
    function fetch_all()
    {
        $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_visit_type ORDER BY vt_id");
  
        return $query->result();
    }
    function get_name_by_id($vt_id)
    {
        if(empty($vt_id)) {
            return '';
        }
        $this->load->database();
        return $this->db->query("
            SELECT vt_name
            FROM tb_visit_type 
            WHERE vt_id IN ($vt_id)
        ")->result()[0]->vt_name;
    }
    
    function report($id, $date)
    {
        return $this->db->query("
            SELECT COUNT(*) AS count
            FROM tb_visit_type
            INNER JOIN tb_customer ON (cus_media_type = vt_id $date)
            WHERE vt_id = $id
        ")->result()[0]->count;
    }
}