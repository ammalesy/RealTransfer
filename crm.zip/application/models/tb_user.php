<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_user extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_user', $array);
    }
    function update($array,$user_id)
    {
      $this->load->database();
      $this->db->where('user_id', $user_id);
      $this->db->update('tb_user', $array); 
    }
    function get_detail_user($user_id)
    {
        $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_user
                                   WHERE user_id = '".$user_id."'");
        $row = $query->result();
        return $row[0]; 
    }
    function get_new_user_id()
    {
        $this->load->database();
        $query = $this->db->query("SELECT Max(user_id)+1 as MaxID 
                                  FROM tb_user");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    function authentication($username,$password)
    {
        $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_user , tb_permission
                   WHERE user_permission = pm_id 
                   AND user_sts_active = 'on' 
                   AND user_username = '".$username."' AND user_password = '".$password."'");
  
        if($query->num_rows() == 1){

            $row = $query->result();
            $obj = $row[0];

            $result_success = array(
                   'success' => TRUE,
                   'user_id' => $obj->user_id,
                   'user_username' => $obj->user_username,
                   'user_permission' => $obj->user_permission
            );
            return $result_success;
        }else{
            $result_fail = array(
                   'success' => FALSE,
                   'user_id' => '',
                   'user_username' => '',
                   'user_permission' => ''
            );
          return $result_fail;
        }
    }
    function isUsernameExist($username)
    {
      $this->load->database();
        $query = $this->db->query("SELECT user_username 
                                   FROM tb_user 
                                   where user_username= '".$username."'");
        $row = $query->num_rows();
        if($row > 0){
          return TRUE;
        }
        else{
          return FALSE;
        }
    }
}

/* End of file tb_user.php */
/* Location: ./application/models/tb_user.php */