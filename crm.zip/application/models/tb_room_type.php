<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_room_type extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_room_type', $array);
    }
    function update($array,$room_type_id)
    {
      $this->load->database();
      $this->db->where('room_type_id', $room_type_id);
      $this->db->update('tb_room_type', $array); 
    }
    
    function fetch_all(){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_room_type");
      return $query->result();

    }
    function get_detail_room($room_type_id){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_room_type  
                                 WHERE room_type_id = '".$room_type_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_active_room(){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_room_type  
                                 WHERE room_type_sts_active = 'on' 
                                 order by room_type_name");
      return $query->result();

    }
    
}

/* End of file tb_room_type.php */
/* Location: ./application/models/tb_room_type.php */