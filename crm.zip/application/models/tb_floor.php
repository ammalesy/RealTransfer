<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_floor extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor   
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_floor', $array);
      return $this->pdb->insert_id();
    }
    function update($array,$fl_id)
    {
      $this->pdb->where('fl_id', $fl_id);
      $this->pdb->update('tb_floor', $array); 
    }
    function get_detail_by_id($fl_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_floor 
                                 WHERE fl_id = '".$fl_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_id_withBuildingTable($fl_id){
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_floor ,tb_building
                                 WHERE building_id = fl_build_id 
                                 AND building_sts_active ='on' 
                                 AND fl_sts_active ='on' 
                                 AND fl_id ='".$fl_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_idAndName($fl_build_id,$fl_name){

      $query = $this->pdb->query("SELECT * 
                                 FROM tb_floor 
                                 WHERE fl_sts_active = 'on' 
                                 AND fl_build_id = '".$fl_build_id."' 
                                 AND fl_name = '".$fl_name."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_all_floor_withBuildingTable(){
       $query = $this->pdb->query("SELECT * 
                                  FROM tb_floor, tb_building 
                                  WHERE  building_id = fl_build_id 
                                  AND building_sts_active ='on' 
                                  AND fl_sts_active ='on' 
                                  order by building_id asc");
       return $query->result();
    }
}

/* End of file tb_floor.php */
/* Location: ./application/models/tb_floor.php */