<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_customer_contact_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('log_customer_contact_info', $array);
    }
    function update($array,$cus_id)
    {
      $this->load->database();
      $this->db->where('con_id_cus', $cus_id);
      $this->db->update('log_customer_contact_info', $array); 
    }
}

/* End of file log_customer_contact_info.php */
/* Location: ./application/models/log_customer_contact_info.php */