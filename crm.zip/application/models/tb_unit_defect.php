<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_unit_defect  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    function fetch_all_defect_room($pj_id){
        $query = $this->db->query("
            SELECT * FROM $this->project_database_sel.tb_building JOIN (
                SELECT *
                FROM $this->project_database_sel.tb_unit_defect
                JOIN $this->project_database_sel.tb_unit_number
                ON (un_id = df_un_id)
            ) tb_join ON (un_build_id = building_id)
        ");
        return $query->result();
    }
    function unlock($df_room_id){
        $query = $this->db->query("
            UPDATE `".$this->project_database_sel."`.`tb_unit_defect`
            SET `df_sync_status` = '0'
            WHERE `tb_unit_defect`.`df_room_id` = ".$df_room_id.";
        ");

    }
    function updateLastPrint($df_room_id,$date){
        $query = $this->db->query("
            UPDATE `".$this->project_database_sel."`.`tb_unit_defect`
            SET `last_print_date` = '".$date."'
            WHERE `tb_unit_defect`.`df_room_id` = ".$df_room_id.";
        ");

    }
    function get_user_by_un_id($un_id){
      //$this->load->database();
      $sql = "SELECT qt_unit_number_id,pers_prefix, pers_fname, pers_lname, pers_sex, pers_card_id, pers_mobile, pers_tel, pers_email
																		 FROM condo_common.tb_customer_personal_info JOIN
																		 						(SELECT qt_unit_number_id,cus_id,ct_cus_id, cus_pers_id
																								 FROM condo_common.tb_customer JOIN
																								 								(SELECT qt_unit_number_id,ct_cus_id
																																 FROM ".$this->project_database_sel.".tb_quotation JOIN
																																 						(SELECT ct_code, ct_booking_code, ct_cus_id, bk_quotation_code, bk_booking_code
																																						 FROM ".$this->project_database_sel.".tb_contract JOIN ".$this->project_database_sel.".tb_booking
																																						 ON (ct_booking_code = bk_booking_code) ) tb_booking_join
																																 ON (qt_code = bk_quotation_code)) tb_quotation_join
																								ON (cus_id = ct_cus_id)) tb_customer_join
																			ON (pers_id = cus_pers_id)
																			WHERE qt_unit_number_id = '".$un_id."'";
      $query = $this->db->query($sql);
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }

    function roomDefectInfo($un_id) {
        $sql = "SELECT un_id,unit_type_id,room_type_id, room_type_info, unit_type_name
  											FROM condo_common.tb_room_type JOIN (
  																				 SELECT un_id, un_unit_type_id, unit_type_name,unit_type_id,unit_type_room_type_id
  																				 FROM ".$this->project_database_sel.".tb_unit_number JOIN ".$this->project_database_sel.".tb_unit_type ON (un_unit_type_id = unit_Type_id)
  																				 WHERE un_id = ".$un_id.") tb_room
  																			ON (room_type_id = unit_type_room_type_id)";

      $query = $this->db->query($sql);
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }

    }

    function getDefectInfo($un_id) {
      $sql = "SELECT * FROM ".$this->project_database_sel.".`tb_unit_defect` WHERE df_un_id = ".$un_id."";

      $query = $this->db->query($sql);
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }

    }
    function getDetail($df_room_id) {
      $sql = "SELECT * FROM ".$this->project_database_sel.".`tb_unit_defect` WHERE df_room_id = ".$df_room_id."";

      $query = $this->db->query($sql);
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }

    }
    function getUnitAndRoomByDefectRoomID($df_room_id) {
      $query = $this->db->query("
          SELECT * FROM $this->project_database_sel.tb_building JOIN (
              SELECT *
              FROM $this->project_database_sel.tb_unit_defect
              JOIN $this->project_database_sel.tb_unit_number
              ON (un_id = df_un_id)
          ) tb_join ON (un_build_id = building_id)
          WHERE df_room_id = ".$df_room_id."
      ");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }

    }
    function getUserByID($user_id) {
      $sql = "SELECT * FROM tb_user JOIN tb_user_personal_info ON (user_pers_user_id = user_id) WHERE user_id = ".$user_id."";

      $query = $this->db->query($sql);
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }

    }

}
