<?php
$name='AngsanaNew';
$type='TTF';
$desc=array (
  'Ascent' => 923,
  'Descent' => -239,
  'CapHeight' => 437,
  'Flags' => 4,
  'FontBBox' => '[-490 -410 791 941]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$up=-50;
$ut=25;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/angsa.ttf';
$TTCfontID='0';
$originalsize=109760;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='angsa';
$panose=' 1 5 2 2 6 3 5 4 5 2 3 4';
$haskerninfo=false;
$unAGlyphs=false;
?>