<?php
$name='TFPimpakarn-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 895,
  'Descent' => -460,
  'CapHeight' => 473,
  'Flags' => 262148,
  'FontBBox' => '[-513 -420 793 894]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 500,
);
$up=-35;
$ut=30;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/TF-Pimpakarn-Bol.ttf';
$TTCfontID='0';
$originalsize=164492;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='pimpakarnB';
$panose=' 3 5 2 0 8 6 0 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>