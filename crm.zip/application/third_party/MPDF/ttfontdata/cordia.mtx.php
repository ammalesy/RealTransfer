<?php
$name='CordiaNew';
$type='TTF';
$desc=array (
  'Ascent' => 893,
  'Descent' => -254,
  'CapHeight' => 469,
  'Flags' => 4,
  'FontBBox' => '[-452 -488 777 898]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$up=-50;
$ut=25;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/cordia.ttf';
$TTCfontID='0';
$originalsize=103432;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='cordia';
$panose=' 8 5 2 b 3 4 2 2 2 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>