<?php
$name='TFPimpakarn';
$type='TTF';
$desc=array (
  'Ascent' => 895,
  'Descent' => -460,
  'CapHeight' => 473,
  'Flags' => 4,
  'FontBBox' => '[-487 -399 810 850]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-35;
$ut=30;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/TF-Pimpakarn.ttf';
$TTCfontID='0';
$originalsize=159452;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='pimpakarn';
$panose=' 3 5 2 0 5 6 0 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>