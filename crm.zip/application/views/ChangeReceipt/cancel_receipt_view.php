<script>
    $(window).load(function () {
        $('#loading').remove();
        $('#tbsearch').css('visibility', 'visible');
        $('#history').css('visibility', 'visible');
        $('.separator:eq(0)').hide();
    });

    Number.prototype.format = function (n, x) {
        var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
        return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
    };

    $(function() {
        $("#search").submit(function (event) {
            $('#load').modal('show');
            Search($('#buildingName').val(), $('#unitNumber').val());
            event.preventDefault();
        });

        $('.closeModal').on('click', function(event) {
            $("#modal_cancel_receipt").closeModal();
            /* Act on the event */
        });
    });
    

    function Search(building, unit) {
        var table = $('#dynamicTable').DataTable();
        table.fnClearTable();

        $.ajax({
            url: "<?= BASE_DOMAIN; ?>assets/ajax/jsonChangeReceipt.php",
            data: ({
                Building: building,
                Unit: unit,
                project_database_sel: '<?= $project_database_sel; ?>'
            }),
            dataType: "json",

            success: function (json) {

                $.each(json, function (index, value) {
                    if (value.rc_payfor == 'Installment Fee') {
                        var date = new Date(value.rc_time_stamp);
                        date = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();

                        var payfor = value.rc_payfor + ' ' + value.rc_installment_time;
                        var action = '<a href="#modal_cancel_receipt" class="modal-trigger2" onclick="PopConfirm(\'' + value.rc_code + '\', \'' + value.building_name + '\', \'' + value.un_name + '\', \'' + value.un_id + '\')"><font color="#c00">Cancel</font></a>';
                        table.fnAddData([
                            value.rc_code,
                            payfor,
                            value.building_name + ' ' + value.un_name,
                            parseFloat(value.rc_total_amount).format(2),
                            date,
                            action
                        ]);
                    }
                });
                $('.modal-trigger2').leanModal();
                $('#load').modal('hide');
            }
        });
    }

    function PopConfirm(rcCode, building, unit, unitid) {
        console.log("r: "+rcCode+"b: "+ building+"u: "+ unit+"ui: "+unitid);
        $('#cancel-title').html('Cancel receipt ' + rcCode);
        $('#form-cancel').prop('action', '<?=BASE_DOMAIN ?>changereceipt/cancelling/' + rcCode);
        $('.building').html(building);
        $('#building').val(building);
        $('.unit-number').html(unit);
        $('#unit-number').val(unitid);
        $('input[name="unit"]').val(unitid);
        $('.receipt-number').html(rcCode);
        $('#receipt-number').val(rcCode);
    }

    function PopRemark(remark) {
        $('#remark').text(remark);
    }
    var basePath = '',
        commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
        rootPath = '<?php echo BASE_DOMAIN; ?>',
        DEV = false,
        componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

    var primaryColor = '#cb4040',
        dangerColor = '#b55151',
        infoColor = '#466baf',
        successColor = '#8baf46',
        warningColor = '#ab7a4b',
        inverseColor = '#45484d';

    var themerPrimaryColor = primaryColor;
    $(document).ready(function(){
        $('.modal-trigger').leanModal();
      });
</script>
<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>

<div class="cancel-receipt">
    <div class="content">
        <div class="content-header">
            <font color="#78ad13">Cancel Receipt</font> <label class="table-total">...</label>
        </div>
        <div class="content-body">
            <form id="search">
                <div class="row">
                    <div class="input-field select-building">
                        <select name="buildingName" id="buildingName">
                            <?php
                                foreach($buildinglist as $building) { ?>
                                <option value="<?=$building->building_id?>">Building : <?=$building->building_name?></option>
                                <?php } ?>
                        </select>
                    </div>
                    <div>
                        <div class="input-field select-search">
                            <input id="unitNumber" type="text" class="validate" name="unitNumber">
                            <label for="unitNumber">Search by unitnumber</label>
                        </div>
                    </div>
                    <div class="search">
                        <button type="submit" class="waves-effect waves-light"><i class="material-icons small">search</i></button>
                    </div>
                </div>
            </form>
                    <!-- Table -->
            <table class="dynamicTable colVis table highlight bordered" id="dynamicTable">
                <!-- Table heading -->
                <thead class="bg-gray">
                    <tr>
                        <th>Receipt</th>
                        <th>Payfor</th>
                        <th>Unit Number</th>
                        <th>Amount</th>
                        <th>Timestamp</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <br />
        </div>
            
    <div class="clearfix"></div>

              <div class="content-body grey lighten-4">
                <div class="history-title">Change History</div>
                <div class="history-table">
                                <!-- Table -->
                    <table class="dynamicTable colVis table">
                        <!-- Table heading -->
                        <thead class="bg-gray">
                            <tr>
                                <th>Date</th>
                                <th>Offical Receipt</th>
                                <th>Temporary Receipt</th>
                                <th>Unit Number</th>
                                <th>Staff</th>
                                <th></th>
                            </tr>
                        </thead>
                        <!-- // Table heading END -->
                        <!-- Table body -->
                        <tbody>
                            <!-- Table row -->
                            <?php foreach($history as $row) { ?>
                                <tr>
                                    <td>
                                        <span style="display: none"><?php echo date('Y/m/d H:i:s',strtotime($row->cr_timestamp))?></span><?php echo date('d/m/Y',strtotime($row->cr_timestamp))?>
                                    </td>
                                    <td>
                                        <?= $row->cr_offical_code ?>
                                    </td>
                                    <td>
                                        <?= $row->cr_temp_code ?>
                                    </td>
                                    <td>
                                        <?= $row->building_name.' '.$row->un_name ?>
                                    </td>
                                    <td>
                                        <?= $row->user_pers_fname.' '.$row->user_pers_lname ?>
                                    </td>
                                    <td>
                                        <a href="#modal-remark" class="modal-trigger" onclick="PopRemark('<?= $row->cr_reason ?>')"><font color="#FF7F00">Reason</font></a>&nbsp;&nbsp;&nbsp;
                                    </td>
                                </tr>
                                <?php } ?>
                                    <!-- // Table row END -->
                        </tbody>
                        <!-- // Table body END -->

                    </table>
                    <!-- // Table END -->
                </div>
            </div>
            <!-- // Widget END -->
        </div>
    </div>
    <!-- // Content END -->
    <div class="clearfix"></div>

<div id="modal_cancel_receipt" class="modal">
    <div class="modal-content">
        <div class="title-head">Cancel Receipt</div>
        <form class="form-horizontal no-margin" role="form" name='form' id="form-cancel" method="post">
            <div class="customer-infomation">
                <div class="name-title title">Receipt Number</div>
                <div class="receipt-number query-result"></div>
                <input type="hidden" class="form-control" name="receipt-number" id="receipt-number">
                <div class="left-content margin-top-20">
                    <div class="title">Building</div>
                    <div class="query-result building"></div>
                    <input type="hidden" class="form-control" id="building">
                </div>
                <div class="right-content margin-top-20">
                    <div class="title">Unit Number</div>
                    <div class="query-result unit-number"></div>
                    <input type="hidden" class="form-control" name="unit-number" id="unit-number">
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="warning-msg">
                <div class="input-field">
                    <textarea id="warning" class="materialize-textarea" name="reason" id="reason"></textarea>
                    <label for="warning">Reason</label>
                </div>
            </div>
            <div class="submit-action">
                <div class="input-field left-content cb-confirm">
                    <input type="checkbox" class="filled-in" name='refund' id='refund'/>
                    <label for="refund">Check box to confirm</label>
                </div>
                <div class="right-content text-right">
                    <button type="submit" class="waves-effect waves-light btn btn-submit"><i class="fa fa-check-circle"></i>Confirm</button>
                    <a class="waves-effect waves-light btn btn-discard modal-action modal-close"><i class="fa fa-times"></i>Close</a>
                </div>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>
<div class="modal fade" id="modal-remark" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal heading -->
            <div class="modal-header">
<!--                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                <h3 class="modal-title">Change receipt history reason</h3>
            </div>
            <div class="modal-body padding-none">
                <div class="bg-gray innerAll border-bottom">
                    <div class="innerLR">
                        <div class="form-group">
                            <div id="remark"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="innerAll text-center border-top">
                <a class="waves-effect waves-light btn btn-discard modal-action modal-close"><i class="fa fa-times"></i>Close</a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="load" data-backdrop="static">

    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal heading -->
            <div class="modal-header">
                <h3 class="modal-title">Loading...</h3>
            </div>
        </div>
    </div>
</div>
