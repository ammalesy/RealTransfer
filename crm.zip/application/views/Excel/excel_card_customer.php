<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="card_customer_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>

    <table class="table table-hover" border="1" style="font-size:10pt">

        <tr>
            <td>
                <table width="100%" border="0">
                    <tr>
                        <td width="3%">ตึก</td>
                        <td width="10%"><?php echo $buildingDetail->building_name; ?></td>
                        <td width="19%">&nbsp;</td>
                        <td width="8%">เลขที่ห้อง</td>
                        <td width="15%"><?php echo $unitNumberDetail->un_name; ?></td>
                        <td width="19%">&nbsp;</td>
                        <td width="4%">ชั้น</td>
                        <td width="10%"><?php echo $floorDetail->fl_name; ?></td>
                        <td width="19%">&nbsp;</td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="2%">ชื่อ</td>
                        <td width="42%"><?php echo $customerPerDetail->pers_fname; ?></td>
                        <td width="6%">นามสกุล</td>
                        <td width="50%"><?php echo $customerPerDetail->pers_lname; ?></td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="14%">ที่อยู่ตามทะเบียนบ้าน</td>
                        <td width="86%"><?php echo($addressCurDetail->addr_cur_address.' ต.'.$addressCurDetail->addr_cur_sub_district.' อ.'.$addressCurDetail->addr_cur_district.' จ.'.$addressCurDetail->addr_cur_province ); ?></td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="11%">ที่อยู่จัดส่งเอกสาร</td>
                        <td width="89%">
                            <?php
                                if($customerDetail->cus_addr_default == 1)
                                {
                                    echo($addressCurDetail->addr_cur_address.' ต.'.$addressCurDetail->addr_cur_sub_district.' อ.'.$addressCurDetail->addr_cur_district.' จ.'.$addressCurDetail->addr_cur_province );
                                }
                                else if($customerDetail->cus_addr_default == 2)
                                {
                                    echo($addressDetail->addr_address.' ต.'.$addressDetail->addr_sub_district.' อ.'.$addressDetail->addr_district.' จ.'.$addressDetail->addr_province );
                                }
                                else if($customerDetail->cus_addr_default == 3)
                                {
                                    echo($addressLastDetail->addr_lastest_address.' ต.'.$addressLastDetail->addr_lastest_sub_district.' อ.'.$addressLastDetail->addr_lastest_district.' จ.'.$addressLastDetail->addr_lastest_province );
                                }
                            ?>
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="11%">เบอร์โทรศัพท์บ้าน</td>
                        <td width="25%"><?php echo (!empty($customerPerDetail->pers_tel)?$customerPerDetail->pers_tel:'-');?></td>
                        <td width="7%">เบอร์มือถือ</td>
                        <td width="24%"><?php echo $customerPerDetail->pers_mobile;?></td>
                        <td width="5%">E-mail</td>
                        <td width="28%"><?php echo (!empty($customerPerDetail->pers_email)?$customerPerDetail->pers_email:'-');?></td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="25%">เลขที่บัตรประชาชน</td>
                        <td width="35%">
                            <?php
                                if($customerPerDetail->pers_nationality == '171')
                                {
                                    echo $customerPerDetail->pers_card_id;
                                }
                                else
                                {
                                    echo $customerPerDetail->pers_passport;
                                }

                            ?>
                        </td>
                        <td width="40%">&nbsp;</td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="25%">เลขที่สัญญาจะซื้อจะขาย</td>
                        <td width="35%"><?php echo $contractDetail->ct_code;?></td>
                        <td width="40%">&nbsp;</td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td width="25%">มูลค่าตามสัญญา</td>
                        <td width="35%"><?php echo number_format($quotationDetail->qt_unit_price,2);?></td>
                        <td width="40%">&nbsp;</td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td>เงื่อนไข</td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <?php
                    foreach($contractPromotionDetail as $_contractPromotionDetail)
                    {
                        $getPromotion = $this->tb_promotion->get_detail_by_id($_contractPromotionDetail->cp_promotion_id);
                        echo ("<tr><td> - ".$getPromotion->pm_name."</td></tr>");
                    }
                    ?>
                </table>
                <table width="100%" border="1">
                    <thead>
                        <tr>
                            <td width="11%" rowspan="2">ลำดับที่</td>
                            <td colspan="4">กำหนดการชำระเงิน</td>
                            <td colspan="8">วันที่ชำระ</td>
                        </tr>
                        <tr>
                            <td width="4%">งวด</td>
                            <td width="16%">วันครบกำหนดชำระ</td>
                            <td width="17%">จำนวนเงินที่ต้องชำระ</td>
                            <td width="7%">คงเหลือ</td>
                            <td width="30%">วันที่ชำระ</td>
                            <td width="2%">ชื่อธนาคาร</td>
                            <td width="2%">เลขที่บัตรเครดิต</td>
                            <td width="2%">เลขที่เช็ค</td>
                            <td width="2%">เงินสด</td>
                            <td width="2%">โอนเงิน</td>
                            <td width="2%">จำนวนเงินชำระ</td>
                            <td width="3%">จำนวนเงินคงเหลือ</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $htmlBooking; ?>
                        <?php echo $htmlContract; ?>
                        <?php echo $html; ?>
                        <?php echo $htmlDiscount; ?>
                        <?php echo $htmlTransfer; ?>
                            <tr>
                                <td colspan="3">ทั้งหมด</td>
                                <td>
                                    <?php echo number_format($totalPayAmount,2); ?>
                                </td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>
                                    <?php echo number_format($totalPaidAmount,2); ?>
                                </td>
                                <td>-</td>
                            </tr>
                    </tbody>
                </table>
            </td>
        </tr>


    </table>
</BODY>

</HTML>