<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="overdue_contract_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>

    <table class="table table-striped colVis" border="1" style="font-size:10pt">
        <thead class="bg-gray" style="font-weight: bold;">
            <tr>
                <td rowspan="2" style="vertical-align:middle;">ลำดับ</td>
                <td rowspan="2" style="vertical-align:middle;">ชั้น</td>
                <td rowspan="2" style="vertical-align:middle;">ตึก</td>
                <td rowspan="2" style="vertical-align:middle;">เลขที่</td>
                <td rowspan="2" style="vertical-align:middle;">ชื่อลูกค้า</td>
                <td rowspan="2" style="vertical-align:middle;">พื้นที่ขาย</td>
                <td rowspan="2" style="vertical-align:middle;">ราคาตามสัญญา</td>
                <td colspan="2" style="vertical-align:middle;">วันครบกำหนดชำระตามสัญญา</td>
                <td>ค้างชำระเงินสัญญา</td>
            </tr>
            <tr>
                <td>จำนวนเงิน</td>
                <td>วันครบกำหนดชำระตามสัญญา</td>
                <td>ระยะเวลาที่ค้างชำระ (วัน)</td>
            </tr>
        </thead>
        <tbody>
            <?php echo $html; ?>
                <tr>
                    <td colspan="7">ทั้งหมด</td>
                    <td>
                        <?php echo $totalContractAmount; ?>
                    </td>
                    <td>-</td>
                    <td>-</td>
                </tr>
        </tbody>
    </table>
</BODY>

</HTML>