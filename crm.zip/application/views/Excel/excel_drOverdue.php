<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="DiaryReportOverdue_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>
    <table class="table table-hover" border="1" style="font-size:10pt">
        <thead>
            <tr>
                <td align="center" colspan="7" bgcolor="#8baf46"><font color="black"><b>รายงานลูกหนี้คงค้าง ณ วันที่ <?php echo $this->dateformat->thaiDate(date('Y-m-d', strtotime($beginDate))); ?></b></font></td>
            </tr>
            <tr>
                <th>No.</th>
                <th>Customer</th>
                <th>Building</th>
                <th>Unit Number</th>
                <th>จำนวนงวดที่ค้าง</th>
                <th>งวดละ</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $html; ?>
        </tbody>
    </table>
</BODY>

</HTML>