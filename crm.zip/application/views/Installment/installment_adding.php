	
	<script type="text/javascript">
        $( document ).ready( loadDis );
        function loadDis() {
            $('#InstallmentTime').val("");
            $('#InstallmentTime').prop('disabled', true);
            $('#Booking').val("");
            $('#Booking').prop('disabled', true);
            $('#contract').val("");
            $('#contract').prop('disabled', true);
            $('#contract').prop('required', true);
            $('#Booking').prop('required', false);
            $('#InstallmentTime').prop('required', true);

            $('#Booking').val($('#bookid').val());
            $('#contract').val($('#conid').val());
            $('#InstallmentTime').val($('#inscode').val());
        }
    </script>
	<style> 
	  #leads-label {
	    display: block;
	    font-weight: bold;
	    margin-bottom: 1em;
	  }
	  #leads-icon {
	    float: left;
	    height: 32px;
	    width: 32px;
	  }
	</style>

<div class="install-add">	
    <div class="content">
       
       <div class="content-header">
           <?php 
            $from=$_GET["from"];
            if ($from == "over") {
            ?>
                <a href="<?php echo BASE_DOMAIN; ?>overdue/installment" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <?php
            }
            else {
            ?>
                <a href="<?php echo BASE_URL; ?>/installment/listInstallment/<?=$con_code ?>" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <?php
            }
            ?>
            
            
            <span class="title-header">Create Temp Receipt</span>
        </div>
        <form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off" action="<?php echo BASE_URL; ?>/installment/record">
            <?php
            $comma = '';
            $allCus = '';
            foreach ($list_customer as $row):
                $allCus .= $comma.'{value: "'.$row->cus_id.'",label: "'.$row->fullname.'"}';
                if($comma==='') $comma = ',';
            endforeach;
            $allCus = '['. $allCus . ']';
            ?>
            <div class="customer-detail">
                <div class="row">
                    <div class="col l4 title-info">Customer Detail</div>
                    <div class="col l8 form-info">
                        <div class="show-detail quotation left-content">
                            Booking fee : <span class="query-result"><?=$bookcode ?></span>
                        </div>
                        <div class="show-detail booking right-content">
                            Contract : <span class="query-result"><?=$con_code ?></span>
                        </div>
                        <div class="show-detail installment left-content">
                            Installment fee : <span class="query-result"><?=$installment_code?></span>
                        </div>

                        <div class="input-field name-1 left-content">
                            <input id="user_fullname" type="text" class="validate" name="user_fullname1" value="<?=$cusList[0]?>" disabled>
                            <label for="user_fullname1">Customer Name #1</label>
                        </div>
                        <div class="input-field name-2 right-content">
                            <input id="user_fullname2" type="text" class="validate" name="user_fullname1" value="<?=$cusList[1]?>" disabled>
                            <label for="user_fullname2">Customer Name #2</label>
                        </div>
                        <div class="input-field name-3 left-content">
                            <input id="user_fullname3" type="text" class="validate" name="user_fullname1" value="<?=$cusList[2]?>" disabled>
                            <label for="user_fullname3">Customer Name #3</label>
                        </div>
                        <div class="input-field name-4 right-content">
                            <input id="user_fullname4" type="text" class="validate" name="user_fullname1" value="<?=$cusList[3]?>" disabled>
                            <label for="user_fullname4">Customer Name #4</label>
                        </div>
                    </div>
                </div>
            </div>

            <input type="hidden" name="building" value="<?=$building?>" />
            <?php 
                $data['definefee'] = $definefee;
                $data['allCus'] = $allCus;
                $data['banklist'] = $banklist;
                $data['credittypelist'] = $credittypelist;
                $data['submit'] = 'Submit';
                $data['cancel'] = 'installment/listInstallment/'.$con_code;
                $data['installment_paid'] = 'yes';
                if(strpos($permission->pm_receipt,'4') !== false) {
                    $data['receipt'] = 'yes';
                    $data['receiptList'] = $receiptList;
                }
                $this->load->view("form_payment", $data); 
            ?>
                           

            <!-- // Widget END -->
            <input type="hidden" value="<?php echo $projectid; ?>" name="projectid" id="projectid">
            <input type="hidden" value="<?php echo $overdue; ?>" name="overdue" id="overdue">
            <input type="hidden" name='cusid' id="cus-id" value="<?=$getpmid->im_cus_id?>" />
            <input type="hidden" id="unitname" name="unitname" value="<?=$unitname?>" />
            <input type="hidden" id="bookid" name="bookcode" value="<?=$bookcode ?>" />
            <input type="hidden" id="conid" name="conid" value="<?=$con_code ?>" />
            <input type="hidden" name='installmentid' value="<?=$installmentid?>"  />
            <input type="hidden" name='instime' id="instime" value="<?=$installment?>"/>
            <input type="hidden" name='inscode' id="inscode" value="<?=$installment_code?>"/>
            <input type="hidden" name="Payfor" value="Installment Fee" />
            
        </form>
    </div>
</div>

<!-- // Content END -->
		
