<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">	
	<title><?php echo $title; ?></title>
    <!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
    <!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
    <!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
    <!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    
	<link href="<?php echo BASE_DOMAIN; ?>assets/css/bootstrap.css" rel="stylesheet">
	<link href="<?php echo BASE_DOMAIN; ?>assets/css/style.css" rel="stylesheet">
   
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script src="<?php echo BASE_DOMAIN; ?>assets/js/ie10-viewport-bug-workaround.js"></script>
	<script src="<?php echo BASE_DOMAIN; ?>assets/js/ie-emulation-modes-warning.js"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.min.js"></script>
    <script src="assets/js/css3-mediaqueries.js"></script>
    <script src="assets/js/respond.min.js"></script>
    <![endif]-->

    
    <!-- Google CDN jQuery with fallback to local -->
    <script src="<?php echo BASE_DOMAIN; ?>assets/js/jquery-1.11.1.min.js"></script>
	<script src="<?php echo BASE_DOMAIN; ?>assets/js/bootstrap.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/js/modernizr.custom.js"></script>


</head>
<body>
    <div id="home">
        <div class="header-blue">
            <div class="container no-padding-small">
                <div class="row no-padding-small">
                    <div class="col-xs-12 col-sm-2 col-md-1 realcrm">
                    <?php echo image_asset('image/realcrm.gif',NULL,array('class'=>'img-responsive')); ?>
                    </div>
                    <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-5 col-lg-5 col-lg-offset-6 link">
                        <ul>
                            <li><span class="hidden-xs">Welcome :</span> <span class="bold"><?php echo $loginName; ?></span></li>
                            <li><?php echo image_asset('image/welcome.gif',NULL,array('class'=>'img-responsive')); ?></li>
                            <li class="br">
<!--                                <?php echo image_asset('image/mycompany-small.gif',NULL,array('class'=>'img-responsive')); ?>-->
                            </li>
                            <a href="<?php echo BASE_DOMAIN; ?>SurveyStandAlone/AuthenSurvey/logout" style="color: #fff;font-size: 1em;line-height: 1em;display: table-cell;vertical-align: middle;padding: 0px 5px;">
                            <li> <?php echo image_asset('image/login.gif',NULL,array('class'=>'img-responsive')); ?></li>
                            <li>Log Out</li>
                            </a>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container no-padding-small">
            <div class="row no-padding-small">
                <div class="col-xs-6 col-md-4 bg-project">
                     <?php echo image_asset('image/project.gif',NULL,array('class'=>'img-responsive')); ?> PROJECT
                </div>
<!--
                <div class="col-xs-6 col-md-2  col-md-offset-6 addproject">
                    <a href="#"> <?php echo image_asset('image/addproject.gif',NULL,array('class'=>'img-responsive')); ?> Add New Project</a>
                </div>
-->

            </div>
        </div>

        <div class="bg-content">
            <div class="container no-padding-small">
                <div class="row no-padding-small">
                    <?php foreach($list_project as $row): ?>
                        <div class="col-xs-12 col-sm-4 col-md-3">
                            <a href="<?php echo BASE_DOMAIN; ?>SurveyStandAlone/ProjectSurvey/select/<?php echo $row->pj_id; ?>">
                            <div class="gray <?php if($i==0) echo "active" ?>">
                                <div class="bd">
                                    <img src="<?php echo BASE_DOMAIN.$row->pj_image; ?>" class="img-responsive" />
                                    <div class="line"></div>
                                    <div class="detail">
                                        <?php echo $row->pj_name; ?>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                    <?php endforeach; ?>       
                </div>
            </div>
        </div>
        <?php if($setting->pm_dashboard > 0 || 
                 $setting->pm_project_add > 0 || 
                 $setting->pm_room > 0 ||
                 $setting->pm_user > 0 || 
                 $setting->pm_assign > 0 || 
                 $setting->pm_permission > 0) { ?>
        <!-- <div class="container no-padding-small">
            <div class="row no-padding-small">
                <div class="col-xs-6 col-md-4 bg-setting">
                    <?php echo image_asset('image/setting.gif',NULL,array('class'=>'img-responsive')); ?> SETTING
                </div>
            </div>
        </div> -->
        <!-- <div class="bg-content-setting">
            <div class="container no-padding-small">
                <div class="row no-padding-small">
                    <?php 
					if ($setting->pm_dashboard>0) {
                        
                    ?>
                        <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>dashboard/all/" > 
                            <div class="gray active">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/dashboard.gif',NULL,array('class'=>'img-responsive')); ?>
                                </div>
                            </div>
                            </a>
                            Dashboard
                        </div>
                    <?php
                    }
                    if ($setting->pm_project_add>0) {
					?>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>project/view/" > 
                            <div class="gray">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/folder_new.gif',NULL,array('class'=>'img-responsive')); ?>
                                </div>
                            </div>
                            </a>New Project
                        </div>
                    <?php
                    }
                    if ($setting->pm_room>0) {
					?>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>room/view/" > 
                            <div class="gray">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/room.gif',NULL,array('class'=>'img-responsive')); ?>
                                   
                                </div>
                            </div>
                            </a>Room
                        </div>
                    <?php
                    }
                    if ($setting->pm_user>0) {
					?>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>user/view/" > 
                            <div class="gray">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/add_user.gif',NULL,array('class'=>'img-responsive')); ?>
                                  
                                </div>
                            </div>
                            </a>Users
                        </div>
                    <?php
                    }
                    if ($setting->pm_assign>0) {
					?>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>assign/view/" > 
                            <div class="gray">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/assign.gif',NULL,array('class'=>'img-responsive')); ?>
                                    
                                </div>
                            </div>
                            </a>Assign
                        </div>
                    <?php
                    }
                    if ($setting->pm_permission>0) {
					?>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>permission/view/" > 
                            <div class="gray">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/permission.gif',NULL,array('class'=>'img-responsive')); ?>
                      
                                </div>
                            </div>
                            </a>Permission
                        </div>
                    <?php
                    }
                    if ($setting->pm_permission>0) {
					?>
                    <div class="col-xs-12 col-sm-4 col-md-2 no-padding-setting">
                            <a href="<?php echo BASE_DOMAIN; ?>authorized/view/" >
                            <div class="gray">
                                <div class="bd">
                                	<?php echo image_asset('image/setting/permission.gif',NULL,array('class'=>'img-responsive')); ?>
                                   
                                </div>
                            </div>
                            </a>Authorized User
                        </div>
                    <?php
                    }
                    
                    ?>
                </div>
            </div>
        </div> -->
        <?php } ?>
    </div>
    <?php include "application/views/footer.php"; ?>
</body>
</html>