    <script>
        $(window).load(function() {
            $('#loading').remove();
            $('#dataTable').css('visibility', 'visible');
        });
    </script>
<style>
    a {color:rgb(19, 46, 232);}
</style>

<div class="email_booking_view">
	
		<div id="menu" class="hidden-print hidden-xs">
			<?php
			if ($permission->pm_booking<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			?>
		</div>


	<div class="content">
        
        <!-- Modal SMS -->
        <div class="modal fade" id="modal-composemsg" data-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
<!--                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                        <h3 class="modal-title" id="lblmessage">Sent Email</h3>
                    </div> 

                    <form class="form-horizontal" role="form" action='<?php echo BASE_DOMAIN; ?>email/sendmessage' method="post" name='form2' id='form2'>

                        <input type="hidden" value="email" name="msgtype" id="msgtype">
                        <input type="hidden" value="" name="cusID" id="cusID">
                        <input type="hidden" value="booking" name="doctype"/>

                        <!-- Modal body -->
                        <div class="modal-body padding-none">
                            <div class="bg-gray innerAll border-bottom">
                                <div class="innerLR">
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Booking number</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="docno" name='bkCode' readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Customer</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="customername" name='customername' readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Due Date</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="dueDate" name='dueDate' readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label" id="typeMessage">Email</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="contact" name='contact' size="60">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Message</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <textarea class="form-control" cols="50" rows="3" id="message" name='message'></textarea>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- // Modal body END -->

                        <div class="innerAll text-center border-top">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Sent</button>
                            <a class="btn btn-default" data-dismiss="modal"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- // Modal END -->


        <div class="content-header">
            <font color="#78ad13">View Email Booking</font> <label class="table-total">...</label>
        </div>
        
<form class="form-horizontal" role="form" action='<?php echo BASE_URL; ?>/email/preview' method="post" name='form1' id='form1'>      
    <input type="hidden" value='' name="customers" id="customers" >
    <input type="hidden" value='email' name="msg" id="msg" >
    <input type="hidden" value='booking' name="doctype" id="doctype" >
    
<div class="innerAll spacing-x2" id="loading">
    <div class="widget widget-inverse">
        <div class="widget-head">
            <h2 class="heading">loading...</h2>
        </div>
    </div>
</div>	
<div class="innerAll spacing-x2" style="visibility: hidden;"  id="dataTable">


	<!-- Widget -->
		<div class="widget-body padding-bottom-none">
			<!-- Table -->
			<?php
					if (strpos($permission->pm_booking,'1') !== false) {
				?>
		<!--	<a href="booking_searchQuotation.php">
			<button class="btn btn-inverse"><i class="fa fa-user"></i> New </button>
			</a> 
			<br/>--><?php } ?>
            
<!--            <input type="submit" class="btn btn-primary" value="Send All">
			<br/>-->
            
<table class="dynamicTable colVis table">

	<!-- Table heading -->
	<thead class="bg-gray">
		<tr>
			
		    
            <th style='width:210px'>Booking</th>
			<th>Customer</th>
			<th>Quotation</th>
			<th >Unit Number</th>
			<th >Due Date</th>
			<th class="center">Action</th>
            
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody>
		<!-- Table row -->
		
			<?php
				foreach($list_booking as $get){
					$today = date("Y-m-d"); 
					$warningDue = '';
					$contractFlag  = false;
                   
					if (strpos($permission->pm_contract,'1') !== false) {
                   		$get_contract = $this->tb_contract->get_detail_by_ct_booking_code($get->bk_booking_code);
						if(count($get_contract) > 0){
							$contractFlag  = true;
						}
                    
						$letterFlag = false;
                        
						if ( date('Y-m-d',strtotime($get->bk_contract_date)) < $today && $contractFlag) {
							$warningDue = trim($get->bk_status) !=='cancel'?'style="color:red"':'';
							$letterFlag = TRUE;
						}
					
					?>
					<tr >
                    <td <?php echo $warningDue; ?> ><?php echo $get->bk_booking_code; ?> 
                        </td>
						<td <?php echo $warningDue; ?> >
                            <a href="#" onmouseover="Tip('Mobile :&nbsp;<b> <?php echo $get->pers_mobile."</b><br> Tel :  ".
                        $get->pers_tel.
                        '<br> Email :'.$get->pers_email; ?>', SHADOW, true, SHADOWCOLOR, '#cccccc',BORDERCOLOR,'#cccccc')" 
                           onmouseout="UnTip()">    
                                <?php echo $get->pers_fname." ".$get->pers_lname; ?> </a>
                        </td>
						<td <?php echo $warningDue; ?> ><?php echo $get->bk_quotation_code; ?> </td>
						<?php
						
							$qcode = $get->bk_quotation_code;
							$get1 = $this->tb_quotation->getDetail_by_id_withProjectTable($qcode);
							$Number				=	$get1->qt_unit_number_id;	
							$Building 			=	$get1->qt_buliding_id;
//							$databasenameQuo 	= 	$get1->pj_datebase_name;
							$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
							$building_name 	= $getBuilding->building_name;
							$getRoom = $this->tb_unit_number->get_detail_unit_by_un_id($Number);
//							$un_name 	= 	$getRoom->un_name.' <br><font size=2>'.ucfirst($getRoom->un_status_room).'</font>';
						?>
						<td  <?php echo $warningDue; ?> ><?php echo $building_name; ?> <?php echo $getRoom->un_name; ?> </td>
						<td  <?php echo $warningDue; ?> ><?php echo date('d/m/Y',strtotime($get->bk_contract_date)); ?> 
							
							
							</td>
						<td class="left">
							<div class="btn-group btn-group-xs ">
								<?php
									                                
									 } ?>
								
							</div>
                            
                            <?php
                            if (  $get->bk_status !=='off'  )
                            {
                            ?>
                        
                        <a href="#modal-composemsg" class="modal-trigger" 
                           onclick="Sentmessage(
                                    '<?=$get->bk_booking_code?>',
                                    '<?=$get->bk_leads_id?>',
                                    '<?=$get->pers_fname.' '.$get->pers_lname;?>',
                                    '<?=$get->pers_email?>',
                                    'เนื่องจากท่านได้จองห้อง <?=$getRoom->un_name?> โครงการ <?php echo $CI->project_name_sel; ?> ไว้ \n กรุณามาทำสัญญา ภายในวันที่ <?=date('d/m/Y',strtotime($get->bk_contract_date))?>\n หากเลยกำหนด จะถือว่าท่านสละสิทธิ์',
                                    '<?=date('d/m/Y',strtotime($get->bk_contract_date))?>')">
                            <?php //echo image_asset('image/email.gif',NULL,NULL); ?>Email</a>
                            <?php
                            }
                    
                               echo  empty($get->email_booking_code)?'waitting':'sent';   
                            
                            ?>
						</td>
                        
					</tr>
				 <?php
				}
			?>
			
		<!-- // Table row END -->
	</tbody>
	<!-- // Table body END -->
	
</table>
            
<!-- // Table END -->

            <br>
		</div>
	<!-- // Widget END -->
	

	
</div>
        </form>
		</div>
		<!-- // Content END -->
		
		<div class="clearfix"></div>
		
	</div>	
<script>
    $(document).ready(function(){
        $('.modal-trigger').leanModal();
      });
   /* var peo = '';
         peo = '<?php echo $booking?>';
     
    if ( peo !== '' ) 
    {       
       document.getElementById('rep').href = 'booking_reportView.php?bid='+peo;     
       document.getElementById('rep').click();
    }
    */
    
    
        
    $( "#form2" ).submit(function( event ) {    
  
      if ( $( "#docno" ).val() == ''  ) 
      {
          //$( "#docno" ).focus();
           event.preventDefault();
      }
      else if ( $( "#customername" ).val() == ''  ) 
      {
          //$( "#docno" ).focus();
           event.preventDefault();
      }
      else if ( $( "#contact" ).val() == ''  ) 
      {
          //$( "#docno" ).focus();
           event.preventDefault();
      }
      else  $( "#target" ).submit();
  
    });
    
    function Sentmessage(bookno,custno,customer,contact,msg,dueDate)
    { 
        $( "#docno" ).val(bookno);  
        $( "#cusID" ).val(custno);  
        $( "#customername" ).val(customer);  
        $( "#contact" ).val(contact);  
        $( "#message" ).val(msg);
        $('#dueDate').val(dueDate);
    }
  
 </script>