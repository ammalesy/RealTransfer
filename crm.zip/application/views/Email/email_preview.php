<!DOCTYPE html>
<!--[if lt IE 7]> <html class="ie lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="ie lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="ie lt-ie9"> <![endif]-->
<!--[if gt IE 8]> <html> <![endif]-->
<!--[if !IE]><!--><html><!-- <![endif]-->
<head>
	<title><?php echo $title; ?></title>
	
	<!-- Meta -->
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
	
	<!-- 
	**********************************************************
	In development, use the LESS files and the less.js compiler
	instead of the minified CSS loaded by default.
	**********************************************************
	<link rel="stylesheet/less" href="<?php echo BASE_DOMAIN; ?>assets/less/admin/module.admin.page.tables.less" />
	-->
	
		<!--[if lt IE 9]><link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/css/bootstrap.min.css" /><![endif]-->
	<link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.tables.min.css" />
	
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

	<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>	
</head>
<body class="">

		<div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
		    <?php
			include "application/views/menu_top.php";
			?>
		</div>
	
		<div id="menu" class="hidden-print hidden-xs">
			<?php
			include "application/views/menu_left.php";
			
			if ($permission->pm_booking<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			?>
		</div>


            
	<div id="content">
<form class="form-horizontal" role="form" action='<?php echo BASE_URL; ?>/email/send_multiple_mobile' method="post" name='form1' id='form1'>      
    <input type="hidden" value='' name="contentCusts" id="contentCusts" >
    <input type="hidden" value='email' name="msgtype" id="msgtype" >
    <input type="hidden" value='<?php echo trim($doctype); ?>' name="doctype" id="doctype" >		
<div class="innerAll spacing-x2">


	<!-- Widget -->
	<div class="widget widget-inverse">
		<div class="widget-head">
			<h4 class="heading"><?php echo trim($doctype) == 'booking'?'Preview Booking':'Preview Installment'; ?></h4>
		</div>
		<div class="widget-body padding-bottom-none">
			
			
   
    <table class="maxTable colVis table">

	<!-- Table heading -->
	<thead class="bg-gray">
		
		<!-- Table row -->
		
			<?php
     

     
        $CI =& get_instance();
        $CI->load->model('tb_booking');
      	$CI->load->model('tb_paymant');
         if (  trim($doctype) == 'booking' )
         {         
         ?>
          <tr>
            
			<th>Customer</th>			
			<th>Mobile</th>
			<th style='width:210px'>Booking Number</th>
			<th class="center">Contract</th>
            <th class="center">status</th>
			<th><input type='checkbox' name='ckall' id='ckall' ></th>
            
		</tr>
	       </thead>
	      <tbody>
         <?php     
            
            	
				$list_booking = $CI->tb_booking->fetch_all_BookingInfoSms_byProjectID__overload1($CI->project_id_sel);
				   foreach($list_booking as	$get)
                   {
					?>
					<tr>
						<td><?php echo $get->pers_prefix.' '.$get->pers_fname.' '.$get->pers_lname; ?> </td>
						<td><?php echo $get->pers_mobile; ?> </td>
                        
						<td><?php echo $get->bk_booking_code; ?> </td>
                        <td><?php echo date('d/m/Y',strtotime($get->bk_contract_date)); ?> </td>
						
						
						<td class="center">
							<?php
                              echo !empty($get->email_booking_code)?'Already sent':'Waitting';
                            ?>
						</td>
                        <td><input type="checkbox" name="oksend[]" id="oksend" value="<?php echo $get->bk_booking_code; ?>" checked></td>
					</tr>
				 <?php
                   }
            
         }
         else  if (  trim($doctype) == 'installment' )
         {         
            ?>
          <tr>			
            <th>Customer</th>
			<th>Mobile</th>
			         
            <th>Contact</th>
            <th>Installment</th>
            <th>Payment</th>
            <th>Due Date</th>
            <th>Status</th>
            <th><input type='checkbox' name='ckall' id='ckall' checked ></th> </tr>
	       </thead>
	      <tbody>
         <?php  
				$list_paymant = $CI->tb_paymant->fetch_payment_customerInfoAndSmsInfo();
			
				   foreach($list_paymant as	$get)
                   {
					?>
					<tr>
						<td><?php echo $get->pers_prefix.' '.$get->pers_fname.' '.$get->pers_lname; ?> </td>
						<td><?php echo $get->pers_mobile; ?> </td>
                       
						<td><?php echo $get->pm_contract_id; ?> </td>
                        <td><?php echo 'Installment #'.$get->pm_installment_time; ?> </td>
                        <td ><?php echo number_format($get->pm_fee_define,0)?> </td>
                        <td><?php echo date('d/m/Y',strtotime($get->pm_due_date)); ?> </td>
						
						
						<td class="center">
							<?php
                              echo !empty($get->email_ct_code)?'Already sent':'Waitting';
                            ?>
						</td>
                        <td><input type="checkbox" name="oksend[]" id="oksend" value="<?php echo $get->pm_id; ?>" checked></td>
					</tr>
				 <?php
                   }
            
         }
     
			?>
			
		<!-- // Table row END -->
	</tbody>
	<!-- // Table body END -->
	
</table>
     <input type="hidden" value='' name="contentCusts" id="contentCusts" >
<!-- // Table END -->
    <div class="innerAll text-center border-top">
				<a href="<?php echo BASE_URL; ?>/email/booking" class="btn btn-default"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
				<input type="submit" class="btn btn-primary" value="Send">
			</div>
           

		</div>
	</div>
	<!-- // Widget END -->
    <input type="checkbox" name="oksend[]" id="oksend" value="" style='display:none'>
	</form>
	
</div>
		
		<!-- // Content END -->
		
		<div class="clearfix"></div>
		<!-- // Sidebar menu & content wrapper END -->
		
		<div id="footer" class="hidden-print">
			

	
		</div>
		<!-- // Footer END -->
		
	</div>
	<!-- // Main Container Fluid END -->
	

	

	<script>
	var basePath = '<?php echo BASE_DOMAIN; ?>',
		commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
		rootPath = '<?php echo BASE_DOMAIN; ?>',
		DEV = false,
		componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';
	
	var primaryColor = '#cb4040',
		dangerColor = '#b55151',
		infoColor = '#466baf',
		successColor = '#8baf46',
		warningColor = '#ab7a4b',
		inverseColor = '#45484d';
	
	var themerPrimaryColor = primaryColor;
	</script>
	
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>	
<script>
    $( "#form1" ).submit(function( event ) {    
       var oksend = "";
       $('input[type=checkbox]').each(function () {
           
               if ( $('input[name=oksend]:checked')  && $(this).is(":checked") )
                 oksend += oksend =="" ?$(this).val() : ";"+$(this).val();
                 
        });
      
        if ( oksend != '' )  {
           $( "#contentCusts" ).val(oksend);                                  
           $( "#target" ).submit();
        }
        else event.preventDefault(); 
  
       }); 
    
</script>
</body>
</html>