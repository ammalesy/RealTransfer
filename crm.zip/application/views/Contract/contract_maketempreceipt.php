<!--contract make reciept-->
        <script type="text/javascript">
            $(function() {
                $('#trCredit').hide();
                $.ajax({
                    url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
                    data: ({
                        nextList: 'Project',
                        Project: $('#Project').val(),
                        project_database_sel: '<?php echo $project_database_sel; ?>'
                    }),
                    dataType: "json",

                    success: function(json) {
                        $('#trLoad').hide();
                        var tbWidth = 400;
                        var Credit = 0;
                        var trCreditID = 1;
                        var arr = [<?=$promotionid?>];
                        $.each(json, function() {
                            var check = false;
                            var id = parseInt(this.pm_id);
                            $.each(arr, function(index, value) {
                                if (value == id) {
                                    check = true;
                                    return false;
                                }
                            });
                            if (this.pm_type == 'Credit') {
                                if (Credit++ == 0)
                                    $('#trCredit').show();
                                if (Credit % 3 == 1)
                                    $("#tbCredit").append('<tr id="tbCredit' + trCreditID + '">');
                                $('#tbCredit' + trCreditID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_detail).prepend(
                                    $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                                if (Credit % 3 == 0) {
                                    $('#tbCredit' + trCreditID).append('</tr>');
                                    trCreditID++;
                                }
                            }
                        });
                        if (Credit % 3 > 0) {
                            var td = 3 - (Credit % 3);
                            $('#tbCredit' + trCreditID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                        }
                        if (Credit == 0) {
                            $('#trLoad').show();
                            $('#logPromotion').html('<br/><b>None</b>');
                        }
                    }
                });

            });

        </script>
<div class="temp-receipt-form">
    <div class="content">
        <div class="content-header">
            <a href="<?php echo BASE_DOMAIN; ?>contract/view" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <span class="title-header">Create Temp Reciept</span>
            <input type="radio" class="people filled-in" id="people" name="TypeCon" value="people" <?=($type==='people'||$type=='')?'checked="checked"':''?>/>
            <label for="people">บุคคลทั่วไป</label>
<!--
            <input type="radio" class="company filled-in" id="company" name="TypeCon" value="people" <?=($type==='company')?'checked="checked"':''?> disabled="disabled"/>
            <label for="company">นิติบุคคล</label>
-->
        </div>
        <form class="form-horizontal" id="validateSubmitForm" method="post" autocomplete="off" action="<?= BASE_URL; ?>/contract/update/">
            <div class="quotation-detail">
                <div class="row">
                    <div class="col l4 title-info">Quotation Detail</div>
                    <div class="col l8 form-info">
                        <div class="show-detail quotation left-content">
                            Quotation Detail : <span class="query-result"><?=$qtCode?></span>
                        </div>
                        <div class="show-detail booking right-content">
                            Booking Number : <span class="query-result"><?=$bkCode?></span>
                        </div>
                        <div class="input-field name-1 left-content">
                            <input id="user_fullname" type="text" class="validate" name="user_fullname1" value="<?=$cusList[0]?>" disabled>
                            <label for="user_fullname1">Customer Name #1</label>
                        </div>
                        <div class="input-field name-2 right-content">
                            <input id="user_fullname2" type="text" class="validate" name="user_fullname1" value="<?=$cusList[1]?>" disabled>
                            <label for="user_fullname2">Customer Name #2</label>
                        </div>
                        <div class="input-field name-3 left-content">
                            <input id="user_fullname3" type="text" class="validate" name="user_fullname1" value="<?=$cusList[2]?>" disabled>
                            <label for="user_fullname3">Customer Name #3</label>
                        </div>
                        <div class="input-field name-4 right-content">
                            <input id="user_fullname4" type="text" class="validate" name="user_fullname1" value="<?=$cusList[3]?>" disabled>
                            <label for="user_fullname4">Customer Name #4</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="credit-promotion">
                <div class="row">
                    <div class="col l4 title-info">Credit Promotion</div>
                    <div class="col l8 form-info">
						<?php foreach ($allCredit as $val): ?>
                        <div class="credit-detail">
                            <input class="visit" name="pro[]" type="radio" id="promotion<?= $val->pm_id ?>" value="<?= $val->pm_id ?>">
                            <label for="promotion<?= $val->pm_id ?>"><?= $val->pm_detail ?></label>
                        </div>
						<?php endforeach; ?>
                    </div>
                </div>
            </div>       
<?php //if (!empty($qtDetail->qt_avg_installment)) {
//     echo '
//     <tr>
//         <td width="517px"><font size="2">Installment Fee : Down Payment '.$qtDetail->qt_total_months .' months (ผ่อนดาวน์  '.$qtDetail->qt_total_months .' เดือน) </font></td>
//         <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_avg_installment ,2).'</font></td>
//         <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
//     </tr>
//     <tr>
//         <td width="517px"><font size="2">Total Installment Fee  </font></td>
//         <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_avg_installment*$qtDetail->qt_total_months,2).'</font></td>
//         <td width="90px"><font size="2">&nbsp;Baht </font></td>
//     </tr>
//     <tr>
//         <td colspa="3"><br></td>
//     </tr>
//     <tr>
//         <td width="517px"><font size="2">Total of Down Payment </font></td>
//         <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_total_down_payment,2).'</font></td>
//         <td width="90px"><font size="2">&nbsp;Baht</font></td>
//     </tr>';
//     } else {
//     echo '
//     <tr>
//         <td width="517px"><font size="2">Installment Fee : Down Payment '.$qtDetail->qt_months_installment1.' months (ผ่อนดาวน์  '.$qtDetail->qt_months_installment1.' เดือน) </font></td>
//         <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_installment1 ,2).'</font></td>
//         <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
//     </tr>';
//     if(!empty($qtDetail->qt_installment2)) {
//         $arr   = explode('-',$qtDetail->qt_months_installment2);
//         $month = ($arr[0]===$arr[1])?$arr[0]:$qtDetail->qt_months_installment2;
//         $down  = $arr[1]-$arr[0]+1;
//         echo '
//         <tr>
//             <td width="517px"><font size="2">Installment Fee : Down Payment '.$month.' months (ผ่อนดาวน์  '.$down.' เดือน) </font></td>
//             <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_installment2 ,2).'</font></td>
//             <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
//         </tr>';
//     }if(!empty($qtDetail->qt_installment3)) {
//         $arr   = explode('-',$qtDetail->qt_months_installment3);
//         $month = ($arr[0]===$arr[1])?$arr[0]:$qtDetail->qt_months_installment3;
//         $down  = $arr[1]-$arr[0]+1;
//         echo '
//         <tr>
//             <td width="517px"><font size="2">Installment Fee : Down Payment '.$month.' months (ผ่อนดาวน์  '.$down.' เดือน) </font></td>
//             <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_installment3 ,2).'</font></td>
//             <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
//         </tr>';
//     }if(!empty($qtDetail->qt_installment4)) {
//         $arr   = explode('-',$qtDetail->qt_months_installment4);
//         $month = ($arr[0]===$arr[1])?$arr[0]:$qtDetail->qt_months_installment4;
//         $down  = $arr[1]-$arr[0]+1;
//         echo '
//         <tr>
//             <td width="517px"><font size="2">Installment Fee : Down Payment '.$month.' months (ผ่อนดาวน์  '.$down.' เดือน) </font></td>
//             <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_installment4 ,2).'</font></td>
//             <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
//         </tr>';
//     }if(!empty($qtDetail->qt_installment5)) {
//         $arr   = explode('-',$qtDetail->qt_months_installment5);
//         $month = ($arr[0]===$arr[1])?$arr[0]:$qtDetail->qt_months_installment5;
//         $down  = $arr[1]-$arr[0]+1;
//         echo '
//         <tr>
//             <td width="517px"><font size="2">Installment Fee : Down Payment '.$month.' months (ผ่อนดาวน์  '.$down.' เดือน) </font></td>
//             <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_installment5 ,2).'</font></td>
//             <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
//         </tr>';
//     }
//     echo '
//     <tr>
//         <td width="517px"><font size="2">Total Installment Fee  </font></td>
//         <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_total_down_payment-$qtDetail->qt_booking_fee-$qtDetail->qt_contract_fee ,2).'</font></td>
//         <td width="90px"><font size="2">&nbsp;Baht </font></td>
//     </tr>
//     <tr>
//         <td colspa="3"><br></td>
//     </tr>
//     <tr>
//         <td width="517px"><font size="2">Total of Down Payment </font></td>
//         <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_total_down_payment,2).'</font></td>
//         <td width="90px"><font size="2">&nbsp;Baht</font></td>
//     </tr>';
// } ?>
                                       
                <?php
                    $data['definefee'] = $qtDetail->qt_contract_fee;
                    $data['allCus'] = $allCus;
                    $data['banklist'] = $banklist;
                    $data['credittypelist'] = $credittypelist;
                    $data['submit'] = 'Submit';
                    $data['cancel'] = 'contract/view';
                    if(strpos($permission->pm_receipt,'4') !== false) {
                        $data['receipt'] = 'yes';
                        $data['receiptList'] = $receiptList;
                    }
                    $this->load->view("form_payment", $data);
                ?>
                
                         <input type="hidden" name="unitnumber" value="<?=$unName?>" />
                        <input type="hidden" name="installmentMonth" value="<?=$qtDetail->qt_total_months?>" />
                        <input type="hidden" name="unitnumberid" value="<?=$Number?>" />
                        <input type="hidden" name="contractfee" value="<?=$qtDetail->qt_contract_fee?>" />
                        <input type="hidden" name="ctCode" value="<?= $ctCode ?>" />
                        <input type="hidden" name="bkCode" value="<?= $bkCode ?>" /> 
        </form>
    </div>
</div>
<div class="clearfix"></div>
