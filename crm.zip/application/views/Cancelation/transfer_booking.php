<script>
    $(document).ready(function(){
        $('.modal-trigger').leanModal();
      });
    $(window).load(function() {
        $('#loading').remove();
        $('#tbsearch').css('visibility', 'visible');
        $('#history').css('visibility', 'visible');
        $('.separator:eq(0)').hide();
    });
    $(function() {
        $( "#search" ).submit(function( event ) {
            $('#load').modal('show');
            Search($('#buildingName').val(), $('#unitNumber').val());
            event.preventDefault();
        });
    });
    function Search(building, room) {
        var table = $('#dynamicTable').DataTable();
        table.fnClearTable();
        
        $.ajax({
            url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonCancelation_Booking.php",
            data: ({ Building: building, Room: room, project_database_sel:'<?php echo $project_database_sel; ?>' }),
            dataType: "json",

            success: function(json){
                var i = 0;
                $.each(json, function(index, value) {
                    i++;
                    var action = '';
                    if(value.un_status_room == 'Sold')
                        action = '<td>Contract</td>';
                    else if(value.bk_status != 'cancelled')// && value.bk_status != 'transferred')
                        action = '<td><a href="#modal_reserve_transfer" class="modal-trigger2" onclick="PopConfirmUnlock(\''+value.building_name+'\', \''+value.building_id+'\', \''+value.un_id+'\', \''+value.un_name+'\', \''+value.bk_booking_code+'\', \''+value.pers_fname+' '+value.pers_lname+'\')"><font color="#c00">Transfer</font></a></td>';
                    else
                        action = '<td><a href="<?php echo BASE_URL; ?>/cancelation/report/booking/'+value.bk_booking_code+'" target="_blank" class="btn btn-danger">View</a></td>';
                    
                    table.fnAddData([
                        value.bk_booking_code,
                        '<a href="#" onmouseover="Tip(\'Mobile :&nbsp;<b>'+value.pers_mobile+'</b><br> Tel :  '+value.pers_tel+'<br> Email : '+value.pers_email+'\', SHADOW, true, SHADOWCOLOR, \'#cccccc\',BORDERCOLOR,\'#cccccc\')" onmouseout="UnTip()">'+value.pers_fname+' '+value.pers_lname+'</a></td>',
                        value.building_name+' '+value.un_name,
                        action
                    ]);
                });
                $('.modal-trigger2').leanModal();
                $('#load').modal('hide');
            }
        });
    }
    
    function PopConfirmUnlock(building, buildid,roomno,roomname, booking, cus) {
        $( 'input[name="building"]' ).val(buildid);
        $( "#roomno" ).val(roomno);
        $( "#roomname" ).val(roomname);
        $( ".unit-number" ).html(roomname);
        $( '.booking' ).html(booking);
        $( 'input[name="booking"]' ).val(booking);
        $( '.name' ).html(cus);
    }
    function PopRemark(remark)
    {
        $('#remark').text(remark);
    }
</script>


<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>

<div id="menu" class="hidden-print hidden-xs">
    <?php

    if (strpos($permission->pm_cancelation,'3') === false) {
        alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
    }
    ?>
</div>
<div class="transfer-booking">
    <div class="content">
        
        <div class="content-header">
            <font color="#78ad13">Reserver Transfer</font> <label class="table-total">...</label>
        </div>
        
        <div class="content-body">
            <form id="search">
                <div class="row">
                    <div class="input-field select-building">
                        <select name="buildingName" id="buildingName">
                            <?php
                                foreach($buildinglist as $building) { ?>
                                <option value="<?=$building->building_id?>">Building : <?=$building->building_name?></option>
                                <?php } ?>
                        </select>
                    </div>
                    <div>
                        <div class="input-field select-search">
                            <input id="unitNumber" type="text" class="validate" name="unitNumber">
                            <label for="unitNumber">Search by unitnumber</label>
                        </div>
                    </div>
                    <div class="search">
                        <button type="submit" class="waves-effect waves-light"><i class="material-icons small">search</i></button>
                    </div>
                </div>
            </form>
                    <!-- Table -->
            <table class="dynamicTable colVis table highlight bordered" id="dynamicTable">
                <!-- Table heading -->
                <thead class="bg-gray">
                    <tr>
                        <th>Booking</th>
                        <th>Customer</th>
                        <th>Unit Number</th>
                        <th></th>
                    </tr>
                </thead>
                <!-- // Table heading END -->
                <!-- Table body -->
                <tbody>
                    <!-- Table row -->
                    <!-- // Table row END -->
                </tbody>
                <!-- // Table body END -->

            </table>
                    <!-- // Table END -->
          </div>
        
         <div class="clearfix"></div>
        
        <div class="content-body grey lighten-4">
            <div class="history-title">Transfer History</div>
            <div class="history-table">
               <table class="dynamicTable colVis table">
                <!-- Table heading -->
                    <thead class="bg-gray">
                        <tr>
                            <th>Date</th>
                            <th>From Customer</th>
                            <th>To Customer</th>
                            <th>Unit Number</th>
                            <th>Staff</th>
                            <th></th>
                        </tr>
                    </thead>
                    <!-- // Table heading END -->
                    <!-- Table body -->
                    <tbody>
                        <!-- Table row -->
                        <?php foreach($history as $row) { ?>
                        <tr>
                            <td>
                               <span style="display: none"><?php echo date('Y/m/d H:i:s',strtotime($row->tf_date))?></span><?php echo date('d/m/Y',strtotime($row->tf_date))?>
                            </td>
                            <td><?= $row->old_name ?></td>
                            <td><?= $row->new_name ?></td>
                            <td><?= $row->unit ?></td>
                            <td><?= $row->staff ?></td>
                            <td><a href="#modal-remark" class="modal-trigger" onclick="PopRemark('<?= $row->tf_remark ?>')"><font color="#FF7F00">Reason</font></a></td>
                        </tr>
                        <?php } ?>
                        <!-- // Table row END -->
                    </tbody>
                <!-- // Table body END -->

                </table>
                            <!-- // Table END -->
            </div>
        </div>
            <!-- // Widget END -->
    </div>
</div>
    <!-- // Content END -->
		
    <div class="clearfix"></div>
    <!-- // Sidebar menu & content wrapper END -->
    
    <div class="modal fade" id="modal-remark" data-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal heading -->
                 <div class="modal-header">
<!--                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                    <h3 class="modal-title">Transferred Booking History Reason</h3>
                </div>
                <div class="modal-body padding-none">
                    <div class="bg-gray innerAll border-bottom">
                        <div class="innerLR">
                            <div class="form-group">
                                <div id="remark"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="innerAll text-center border-top">
                    <a class="waves-effect waves-light btn btn-discard modal-action modal-close"><i class="fa fa-times"></i>Close</a>
                </div>
            </div>
        </div>
    </div>
<!--    ///////////  load  ////////////////////////-->
    <div class="modal fade" id="load" data-backdrop="static">
	
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal heading -->
                 <div class="modal-header">
                    <h3 class="modal-title">Loading...</h3>
                </div>
            </div>
        </div>
    </div>

     <div id="modal_reserve_transfer" class="modal">
        <div class="modal-content">
            <div class="title-head">Transfer Reserve</div>
            <form class="form-horizontal no-margin" role="form" action='<?php echo BASE_URL; ?>/cancelation/transferring/booking/' method="post" name='form' id='form'>
                <input type='hidden' value="" id='roomno' name='roomno'>
                <input type="hidden" class="form-control" name='building'>
                   
                <div class="customer-infomation row">
                    <div class="col l2">
                        <div class="text-title">From</div>
                    </div>
                    <div class="col l5">
                        <div class="name-title title">Customer Name</div>
                        <div class="name query-result"></div>
                        <div class="margin-top-20">
                            <div class="title">Booking No.</div>
                            <div class="booking query-result booking"></div>
                            <input type="hidden" class="form-control" name='booking'/>
                        </div>
                    </div>
                    <div class="col l5">
                        <div class="">
                            <div class="title">Unit Number</div>
                            <div class="query-result unit-number"></div>
                            <input type="hidden" id="roomname" name="roomname" value="">
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="center" style="margin-top: 15px;"><font color="red">*please add new customer into the system first*</font></div>
                <div class="row to-customer">
                    <div class="col l2">
                        <div class="text-title">To</div>
                    </div><div class="col l8 form-info">
                        
                    <div class="col l10">
                           
                         <div class="input-field no-margin">
                         <select class="form-control threeWord" name="cusID[]" id="cusID" style="width:200px" required>
                                <option value='all'>Customer1</option>
                                <?php
                                        foreach($list_customer as $customer):
                                            echo "<option value='$customer->cus_id'>$customer->fullname</option>";
                                        endforeach; 
                                    ?>
                            </select>
                        </div>
                        <div class="input-field">
                         <select class="form-control threeWord" name="cusID[]" id="cusID" style="width:200px" required>
                                <option value='all'>Customer2</option>
                                <?php
                                        foreach($list_customer as $customer):
                                            echo "<option value='$customer->cus_id'>$customer->fullname</option>";
                                        endforeach; 
                                    ?>
                            </select>
                        </div>
                        <div class="input-field">
                         <select class="form-control threeWord" name="cusID[]" id="cusID" style="width:200px" required>
                                <option value='all'>Customer3</option>
                                <?php
                                        foreach($list_customer as $customer):
                                            echo "<option value='$customer->cus_id'>$customer->fullname</option>";
                                        endforeach; 
                                    ?>
                            </select>
                        </div>
                        <div class="input-field">
                         <select class="form-control threeWord" name="cusID[]" id="cusID" style="width:200px" required>
                                <option value='all'>Customer4</option>
                                <?php
                                        foreach($list_customer as $customer):
                                            echo "<option value='$customer->cus_id'>$customer->fullname</option>";
                                        endforeach; 
                                    ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row submit-action">
                    <div class="input-field col l6">
                        <input id="reason" name='reason' type="text" class="validate">
                        <label for="reason">Reson</label>
                    </div>
                    <div class="submit-button-group col l6">
                        <button type="submit" class="waves-effect waves-light btn btn-submit"><i class="fa fa-check-circle"></i>Transfer</button>
                        <a class="waves-effect waves-light btn btn-discard modal-action modal-close"><i class="fa fa-times"></i>Close</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
        </div>
    </div>
                            <script>
                $(".threeWord").select2({
                    minimumInputLength: 3
                });

            </script>
<script>
         $(function() {
        //ถ้าใช้งานจริง ส่วนนี้จะถูกเขียนขึ้น เป็นไฟล์ .js เมื่อมีการเพิ่ม/แก้ไข ข้อมูลสมาชิก 
        var autoCompleteData = <?php echo $allEmp?>;
        if (!autoCompleteData) var autoCompleteData = new Array();
        $("#user_fullname").autocomplete({
                minLength: 3,
                source: autoCompleteData,
                focus: function(event, ui) {
                    $("#user_fullname").val(ui.item.label);
                    $("#leads-id").val(ui.item.value);
                    return false;
                },
                select: function(event, ui) {
                    $("#user_fullname").val(ui.item.label);
                    $("#leads-id").val(ui.item.value);
                    return false;
                }
            })
            .data("ui-autocomplete")._renderItem = function(ul, item) {
                return $("<li>")
                    .append("<a>" + item.label + "</a>")
                    .appendTo(ul);
            };
         });
         </script>