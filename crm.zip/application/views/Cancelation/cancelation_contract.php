<script>
    $(window).load(function() {
        $('#loading').remove();
        $('#tbsearch').css('visibility', 'visible');
        $('#history').css('visibility', 'visible');
        $('.separator:eq(0)').hide();
    });

    $(function() {
        $( "#search" ).submit(function( event ) {
            $('#load').modal('show');
            Search($('#buildingName').val(), $('#unitNumber').val());
            event.preventDefault();
        });
    });
    
    function Search(building, room){
        var table = $('#dynamicTable').DataTable();
        table.fnClearTable();
        
        $.ajax({
            url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonCancelation_Contract.php",
            data: ({ Building: building, Room: room, project_database_sel:'<?php echo $project_database_sel; ?>' }),
            dataType: "json",

            success: function(json){
                var i = 0;
                $.each(json, function(index, value) {
                    i++;
                    var action = '';
                    if(value.ct_active != 'cancelled' && value.ct_active != 'transferred')
                        action = '<td><a href="#modal_cancel_contract" class="modal-trigger2" onclick="PopConfirmUnlock(\''+value.building_name+'\', \''+value.building_id+'\', \''+value.un_id+'\', \''+value.un_name+'\', \''+value.ct_code+'\', \''+value.pers_fname+' '+value.pers_lname+'\')"><font color="#c00">Cancel</font></a></td>';
                    else
                        action = '<td>Cancelled</td>'
                       // action = '<td><a href="<?php echo BASE_URL; ?>/cancelation/report/contract/'+value.ct_code+'" target="_blank" class="btn btn-danger">View</a></td>';
                    
                    table.fnAddData([
                        value.ct_code,
                        '<a href="#" onmouseover="Tip(\'Mobile :&nbsp;<b>'+value.pers_mobile+'</b><br> Tel :  '+value.pers_tel+'<br> Email : '+value.pers_email+'\', SHADOW, true, SHADOWCOLOR, \'#cccccc\',BORDERCOLOR,\'#cccccc\')" onmouseout="UnTip()">'+value.pers_fname+' '+value.pers_lname+'</a></td>',
                        value.building_name+' '+value.un_name,
                        action
                    ]);
                });
                $('.modal-trigger2').leanModal();
                $('#load').modal('hide');
            }
        });
    }
    
    function PopConfirmUnlock(building, buildid,roomno,roomname, contract, cus)
    {
        $( ".building" ).html(building);
        $( 'input[name="building"]' ).val(buildid);
        $( "#roomno" ).val(roomno);
        $( ".unit-number" ).html(roomname);
        $( "#room" ).val(roomname);
        $( '.contract' ).html(contract);
        $( 'input[name="contract"]' ).val(contract);
        $( '.name' ).html(cus);
    }
    function PopRemark(remark)
    {
        $('#remark').text(remark);
    }
    $(document).ready(function(){
        $('.modal-trigger').leanModal();
      });
</script>
<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>

<div id="menu" class="hidden-print hidden-xs">
    <?php

    if (strpos($permission->pm_cancelation,'2') === false) {
        alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
    }
    ?>
</div>

<div class="cancel-contract">
    <div class="content">
        <div class="content-header">
            <font color="#78ad13">Cancel Contract</font> <label class="table-total">...</label>
        </div>
        <div class="content-body">
            <form id="search">
                <div class="row">
                    <div class="input-field select-building">
                        <select name="buildingName" id="buildingName">
                            <?php
                                foreach($buildinglist as $building) { ?>
                                <option value="<?=$building->building_id?>">Building : <?=$building->building_name?></option>
                                <?php } ?>
                        </select>
                    </div>
                    <div>
                        <div class="input-field select-search">
                            <input id="unitNumber" type="text" class="validate" name="unitNumber">
                            <label for="unitNumber">Search by unitnumber</label>
                        </div>
                    </div>
                    <div class="search">
                        <button type="submit" class="waves-effect waves-light"><i class="material-icons small">search</i></button>
                    </div>
                </div>
            </form>
            <!-- Table -->
            <table class="dynamicTable colVis table highlight bordered" id="dynamicTable">
                <!-- Table heading -->
                <thead class="bg-gray">
                    <tr>
                        <th style='width:210px'>Contract</th>
                        <th>Customer</th>
                        <th>Unit Number</th>
                        <th></th>
                    </tr>
                </thead>
                <!-- // Table heading END -->
                <!-- Table body -->
                <tbody>
                    <!-- Table row -->
                    <!-- // Table row END -->
                </tbody>
                <!-- // Table body END -->

            </table>
            <!-- // Table END -->
        </div>
        
         <div class="clearfix"></div>
        
        <div class="content-body grey lighten-4">
            <div class="history-title">Transfer History</div>
            <div class="history-table">
               <table class="dynamicTable colVis table">
                    <!-- Table heading -->
                    <thead class="bg-gray">
                        <tr>
                            <th>Date</th>
                            <th>Contract</th>
                            <th>Customer</th>
                            <th>Unit Number</th>
                            <th>Staff</th>
                            <th></th>
                        </tr>
                    </thead>
                    <!-- // Table heading END -->
                    <!-- Table body -->
                    <tbody>
                        <!-- Table row -->
                        <?php foreach($history as $row) { ?>
                        <tr>
                            <td>
                                <span style="display: none"><?php echo date('Y/m/d H:i:s',strtotime($row->cc_date))?></span><?php echo date('d/m/Y',strtotime($row->cc_date))?>
                            </td>
                            <td><?= $row->cc_contract_code ?></td>
                            <td><?= $row->fullname ?></td>
                            <td><?= $row->unit ?></td>
                            <td><?= $row->staff ?></td>
                            <td><a href="#modal-remark" class="modal-trigger" onclick="PopRemark('<?= $row->cc_remark ?>')"><font color="#FF7F00">Reason</font></a>&nbsp;&nbsp;&nbsp;
                            View: <a href="<?php echo BASE_DOMAIN; ?>cancelation/report/contract/th/<?= $row->cc_contract_code ?>" target="_blank"><font color="#0e7ccb">TH</font></a> / 
                                <a href="<?php echo BASE_DOMAIN; ?>cancelation/report/contract/en/<?= $row->cc_contract_code ?>" target="_blank"><font color="#0e7ccb">EN</font></a></td>
                        </tr>
                        <?php } ?>
                        <!-- // Table row END -->
                    </tbody>
                    <!-- // Table body END -->

                </table>
                    <!-- // Table END -->
                    <br />
                </div>
            </div>
            <!-- // Widget END -->
        </div>
    </div>
    <!-- // Content END -->
		
    <div class="clearfix"></div>
    <!-- // Sidebar menu & content wrapper END -->
<div id="modal_cancel_contract" class="modal">
    <div class="modal-content">
        <div class="title-head">Cancel Contract</div>
        <form class="form-horizontal no-margin" role="form" action='<?php echo BASE_URL; ?>/cancelation/unlock/contract/' method="post" name='form' id='form'>
            <div class="customer-infomation">
                <div class="name-title title">Customer Name</div>
                <div class="name query-result"></div>
                <div class="margin-top-20">
                    <div class="title">Contract</div>
                    <div class="contract text-red"></div>
                    <input type="hidden" class="form-control" name='contract'/>
                </div>
                <div class="left-content margin-top-20">
                    <div class="title">Building</div>
                    <div class="text-red building"></div>
                    <input type="hidden" class="form-control" name='building'>
                </div>
                <div class="right-content margin-top-20">
                    <div class="title">Unit Number</div>
                    <div class="text-red unit-number"></div>
                    <input type="hidden" id="room" name="room" value="">
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="warning-msg">
                <div class="input-field">
                    <textarea id="warning" class="materialize-textarea" name="reason" id="reason"></textarea>
                    <label for="warning">Reason</label>
                </div>
            </div>
            <div class="submit-action">
                <div class="input-field left-content cb-confirm">
                    <input type="checkbox" class="filled-in" name='refund' id='refund'/>
                    <label for="refund"><span class="text-green">Refund</span> if checked, it will cancel all receipts for this contract number</label>
                </div>
                <div class="right-content text-right">
                    <button type="submit" class="waves-effect waves-light btn btn-submit"><i class="fa fa-check-circle"></i>Confirm</button>
                    <a class="waves-effect waves-light btn btn-discard modal-action modal-close"><i class="fa fa-times"></i>Close</a>
                </div>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>
<div class="clearfix"></div>
<div class="modal fade" id="modal-remark" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal heading -->
             <div class="modal-header">
<!--                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                <h3 class="modal-title">Cancelled Contract History Reason</h3>
            </div>
            <div class="modal-body padding-none">
                <div class="bg-gray innerAll border-bottom">
                    <div class="innerLR">
                        <div class="form-group">
                            <div id="remark"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="innerAll text-center border-top">
                <a class="waves-effect waves-light btn btn-discard modal-action modal-close"><i class="fa fa-times"></i>Close</a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="load" data-backdrop="static">

    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal heading -->
             <div class="modal-header">
                <h3 class="modal-title">Loading...</h3>
            </div>
        </div>
        <div class="modal-body padding-none">
        </div>
    </div>
</div>