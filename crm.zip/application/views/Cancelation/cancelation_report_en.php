<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}

.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}

</style>

<table width="100%" border="1" class="oneLine">
    <tr>
        <td align="center">
            <table width="100%">
                <tr>
                    <td align="center"><pre><b>Application Form for Terminating the Reservation Letter / the Condominium Sale and Purchase Agreement
'.$titleCase.'</b></pre></td>
                </tr>
                <tr>
                    <td align="center"><pre><b>'.$project.'</font></b></pre></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table width="100%">
    <tr>
        <td width="80%" align="right"><pre>Application No.</pre></td>
        <td width="20%" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$idCancel.'</td>
    </tr>
</table>
<table width="100%">
    <tr>
        <td width="75%" align="right"><pre>Date</pre></td>
        <td width="25%" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$dateCancel.'</td>
    </tr>
</table>
<table width="100%" border="0" cellpadding="-1" cellspacing="0">
    <tr>
        <td width="10%"><pre>Re:</pre></td>
        <td width="90%"><pre>An Authorized person acting for '.$company.'</pre></td>
    </tr>
    <tr>
        <td><pre>Ref.</pre></td>
        <td>
            <table>
                <tr>
                    <td width="102px"><pre><input type="checkbox" checked="checked"> The Unit No.</pre></td>
                    <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$unitNumber.'</td>
                    <td width=""><pre>(Sale Code</pre></td>
                    <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$unitType.'</td>
                    <td width=""><pre>) Floor</pre></td>
                    <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$floor.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td><pre>of<span style="border-bottom-width:1px; border-bottom-style:solid;"> '.$project.' </span></pre></td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre><input type="checkbox" checked="checked"> Usage area approximately</pre></td>
                    <td width="100px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$areaSqm.'</td>
                    <td width=""><pre>Sq.m.</pre></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre><input type="checkbox" checked="checked"> At the price of</pre></td>
                    <td width="200px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$price.'</td>
                    <td width=""><pre>Baht</pre></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre>In accordance with the Reservation Letter No.</pre></td>
                    <td width="150px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$bookingCode.'</td>
                    <td width=""><pre>date</pre></td>
                    <td width="150px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$dateBooking.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre>In accordance with the Condominium Sale and Purchase Agreement No</pre></td>
                    <td width="180px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$contractCode.'</td>
                </tr>
            </table>
            <table>
                <tr>
                    <td><pre>dated on</pre></td>
                    <td width="130px" style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$dateContract.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table width="100%">
                <tr>
                    <td width="10%"><pre>We,</pre></td>
                    <td width="90%" style="border-bottom-width:1px; border-bottom-style:solid;">'.$nameCustomer.',</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td><pre><span class="under"> AS</span></pre></td>
        <td>(please mark with <input type="checkbox" checked="checked"> in front of the only one section you are desirous)</td>
    </tr>
    <tr>
        <td></td>
        <td><input type="checkbox" '.$checkBooking.'> Customer (please fill in the information in Section 1)</td>
    </tr>
    <tr>
        <td></td>
        <td><input type="checkbox" '.$checkContract.'> The Purchaser (please fill in the information in Section 2)</td>
    </tr>
</table>
<br>
<table border="1" class="oneLine">
    <tr>
        <td width="150px" align="center">In the case of Customer</td>
    </tr>
</table>
<pre class="tab"><input type="checkbox" '.$checkBooking.'> 1. We wish to inform you that due to an unavoidable reason causing us to be unable to enter into the Condominium Sale and Purchase Agreement with you, we are desirous to rescind the abovementioned Reservation Letter and '.$bookCase.'.</pre>
<br>
<table border="1" class="oneLine">
    <tr>
        <td width="180px" align="center">In the case of the Purchaser</td>
    </tr>
</table>
<pre class="tab"><input type="checkbox" '.$checkContract.'> 2. We wish to inform you that in the case where there is an unavoidable reason causing us to be unable to comply with conditions under the Condominium Sale and Purchase Agreement and the Seller does not breach of contract, we are desirous to rescind the abovementioned '.$contractCase.'.</pre>
<br>
<table width="100%">
    <tr>
        <td width="50%" valign="top" align="center"><pre>For your consideration,</pre></td>
        <td width="50%"></td>
    </tr>
    <tr>
        <td width="50%"></td>
        <td width="50%" align="right">
            <table width="100%">
                <tr>
                    <td width="10px"><pre>Sign</pre></td>
                    <td width="300px" style="border-bottom-width:1px; border-bottom-style:solid;" ></td>
                    <td width="120px"><pre>Customer / Seller</pre></td>
                </tr>
                <tr> 
                    <td align="right">(</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;" align="center"><pre>'.$nameLicense.'</pre></td>
                    <td align="left">)</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<br>
<table border="1" width="100%" class="oneLine">
    <tr>
        <td colspan="4" align="center"><pre><b>For officer of the Company only</b></pre></td>
    </tr>
    <tr>
        <td>
            <table border="0">
                <tr>
                    <td><pre>A/C_____________acknowledge</pre></td>
                </tr>
                <tr>
                    <td><pre>Date__________________</pre></td>
                </tr>
            </table>
            <table border="1">
                <tr></tr>
            </table>
        </td>
        <td>
            <table border="0">
                <tr>
                    <td><pre>Approved by___________</pre></td>
                </tr>
                <tr>
                    <td><pre>Date_____________</pre></td>
                </tr>
            </table>
            <table border="1">
                <tr></tr>
            </table>
        </td>
        <td>
            <table border="0">
                <tr>
                    <td><pre>Company officer (Sale/CS)</pre></td>
                </tr>
                <tr>
                    <td><pre>Sign____________________</pre></td>
                </tr>
            </table>
            <table border="1">
                <tr></tr>
            </table>
        </td>
        <td>
            <table border="0">
                <tr>
                    <td><pre>Conditions______________</pre></td>
                </tr>
                <tr>
                    <td><pre>____________________</pre></td>
                </tr>
            </table>
            <table border="1">
                <tr></tr>
            </table>
        </td>
    </tr>
</table>
';?>

<?php


include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>