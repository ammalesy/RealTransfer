<script>        
    function next() 
    {
        $('#load').modal('hide');
    }
        
    $(function() {
        $("#search").submit(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
        
        $(".subm").click(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
    });
</script>
<div class="customer-report">
    <div>
        <?php	
        if ($permission->pm_chart_report<1) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
        ?>
    </div>
    <div class="content">
           <div class="modal fade" id="load" data-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Loading...</h3>
                        </div>
                    </div>
                </div>
            </div>
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Customers</a>
                        <ul class="right hide-on-med-and-down">
                            <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/customer/total" class="subm">Total</a></li>
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/customer/today" class="subm">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/customer/week" class="subm">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/customer/month" class="subm">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="slide" style="display:none">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/customer/custom" method="post" id="search">
                    <div class="custom-date col l10">
                        <input class="datepicker" type="date" name="start" required="required" value="<?php echo date( "Y-m-d", strtotime("-30 days ", strtotime(date('Y-m-d'))) ); ?>" title="Please enter Start Date">
                        <label><b>TO</b></label>
                        <input class="datepicker" type="date" name="end" required="required" value="<?php echo date('Y-m-d'); ?>" title="Please enter End Date">
                    </div>

                    <div class="col l2 button-submit">
                        <button class="btn waves-effect waves-light" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="content-body" id="printPage">
            <div class="customer-report page">
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Customers</span>
                                <span class="card-title layout-date grey-text text-white right"><?php echo $date_show; ?></span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="container"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Age</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div class="ageChart"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Sex</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div class="piSex"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-break"></div>
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Province</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="provinceChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">District</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="districtChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-break"></div>
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Sub District</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="subDistrictChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="page-break"></div>
                <div class="row">
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content" >
                                <span class="card-title layout-title grey-text text-white">Visit Type</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="piVisit"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content" >
                                <span class="card-title layout-title grey-text text-white">Budget</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="piBudget"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Media Type</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="mediaChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Work Province</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="workProvinceChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Work District</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="workDistrictChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Work Sub District</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="workSubDistrictChart"></div>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function printDiv() {

        var chartCustomer = $('#container').highcharts();
        chartCustomer.setSize(1070,500, false);

         var chartMedia = $('#mediaChart').highcharts();
         chartMedia.setSize(1070,500, false); 

         var piVisit = $('#piVisit').highcharts();
         piVisit.setSize(520 ,500, false);

         var piBudget = $('#piBudget').highcharts();
         piBudget.setSize(520 ,500, false);

        var chartDistrict = $('#districtChart').highcharts();
        chartDistrict.setSize(1070,500, false);

        var chartSubDistrict = $('#subDistrictChart').highcharts();
        chartSubDistrict.setSize(1070,500, false);

        var chartProvince = $('#provinceChart').highcharts();
        chartProvince.setSize(1070,500, false);

        var piSex = $('.piSex').highcharts();
        piSex.setSize(520 ,500, false);

        var piAge = $('.ageChart').highcharts();
        piAge.setSize(520 ,500, false);

        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
       
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();

//        w=window.open();
//        w.document.write($('#printPage').html());
//        w.print();
//        w.close();
    }
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });

        $('#container').highcharts({
            chart: {
                type: '<?php echo $format_chart; ?>',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Customers. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $xAxis; ?>],

                labels: {
                    step: [<?php echo $date_cut; ?>],
                    <?php echo $rotation; ?>
                },
                crosshair: true



            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of Customer'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} <?php echo $type_name; ?>',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: '<?php echo $type_name; ?>',
                data: [<?php echo $count_cus; ?>]

            }]
        });
        $('#districtChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Districts. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $districtName; ?>],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of District'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Districts',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'District',
                data: [<?php echo $districtCount; ?>]

            }]
        });
        $('#subDistrictChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Sub Districts. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $subDistrictName; ?>],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of Sub District'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Sub Districts',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'Sub District',
                data: [<?php echo $subDistrictCount; ?>]

            }]
        });
        $('#provinceChart').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y}/{point.total} : <b>{point.percentage:.1f}% </b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            legend: {
                borderRadius: 0,
                backgroundColor: '#FFFFFF',
                //                itemMarginBottom: 7,
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                y: 30,
                x: -50,
                borderWidth: 0,
                width: 400,
                symbolPadding: 10,
                useHTML: false,
                shadow: {
                    color: '#000',
                    width: 3,
                    opacity: 0.15,
                    offsetY: 2,
                    offsetX: 1
                },
                itemWidth: 200,
                labelFormatter: function() {
                        return this.name + '<br>' + this.percentage.toFixed(0) + '% (' + this.y + '/' + this.total + ')';
                    }
                    //                labelFormatter: function() {
                    //                    var total = 0,
                    //                        percentage;
                    //                    $.each(this.series.data, function() {
                    //                        total += this.y;
                    //                    });
                    //                    percentage = ((this.y / total) * 100).toFixed(0);
                    ////                    return '<div class="' + this.name + '-arrow"></div><div style="font-size:16px">' + this.name + '</div><div style="font-size:10px; color:#ababaa">( Total ' + this.y + '/'+this.total+' :  ' + percentage + ' % )</div>';
                    //                    return '<span style="font-size:16px; ">' + this.name + '</span><br><span style="font-size:10px; color:#ababaa"> ( Total ' + this.y + '/'+this.total+' :  ' + percentage + ' % )</span>';
                    //                }
            },
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $provinceDetails; ?>

                ]
            }]
        });
        //        $('#provinceChart').highcharts({
        //            chart: {
        //                type: 'column'
        //            },
        //            title: {
        //                text: 'Monthly Average Rainfall'
        //            },
        //            subtitle: {
        //                text: 'Source: WorldClimate.com'
        //            },
        //            xAxis: {
        //                categories: [<?php echo $provinceName; ?>],
        //                crosshair: true
        //            },
        //            yAxis: {
        //                min: 0,
        //                title: {
        //                    text: 'Rainfall (mm)'
        //                }
        //            },
        //            tooltip: {
        //                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        //                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
        //                    '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
        //                footerFormat: '</table>',
        //                shared: true,
        //                useHTML: true
        //            },
        //            plotOptions: {
        //                column: {
        //                    pointPadding: 0.2,
        //                    borderWidth: 0
        //                }
        //            },
        //            series: [{
        //                name: 'Province',
        //                data: [<?php echo $provinceCount; ?>]
        //
        //            }]
        //        });
        $('#workDistrictChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Working Districts. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $districtNameWork; ?>],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of Working District'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Districts',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'District',
                data: [<?php echo $districtCountWork; ?>]

            }]
        });
        $('#workSubDistrictChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Working Sub Districts. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $subDistrictNameWork; ?>],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of Sub District'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Sub Districts',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'District',
                data: [<?php echo $subDistrictCountWork; ?>]

            }]
        });
        $('#workProvinceChart').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,

            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            legend: {
                borderRadius: 0,
                backgroundColor: '#FFFFFF',
                //                itemMarginBottom: 7,
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                y: 85,
                x: -50,
                borderWidth: 0,
                width: 400,
                symbolPadding: 10,
                useHTML: true,
                shadow: {
                    color: '#000',
                    width: 3,
                    opacity: 0.15,
                    offsetY: 2,
                    offsetX: 1
                },
                itemWidth: 200,
                height: 20,
                labelFormatter: function() {
                        return this.name + '<br>' + this.percentage.toFixed(0) + '% (' + this.y + '/' + this.total + ')';
                    }
                    //                labelFormatter: function() {
                    //                    var total = 0,
                    //                        percentage;
                    //                    $.each(this.series.data, function() {
                    //                        total += this.y;
                    //                    });
                    //                    percentage = ((this.y / total) * 100).toFixed(0);
                    ////                    return '<div class="' + this.name + '-arrow"></div><div style="font-size:16px">' + this.name + '</div><div style="font-size:10px; color:#ababaa">( Total ' + this.y + '/'+this.total+' :  ' + percentage + ' % )</div>';
                    //                    return '<span style="font-size:16px; ">' + this.name + '</span><br><span style="font-size:10px; color:#ababaa"> ( Total ' + this.y + '/'+this.total+' :  ' + percentage + ' % )</span>';
                    //                }
            },
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $provinceDetailsWork; ?>

                ]
            }]
        });
        //        $('#workProvinceChart').highcharts({
        //            chart: {
        //                type: 'column'
        //            },
        //            title: {
        //                text: 'Monthly Average Rainfall'
        //            },
        //            subtitle: {
        //                text: 'Source: WorldClimate.com'
        //            },
        //            xAxis: {
        //                categories: [<?php echo $provinceNameWork; ?>],
        //                crosshair: true
        //            },
        //            yAxis: {
        //                min: 0,
        //                title: {
        //                    text: 'Rainfall (mm)'
        //                }
        //            },
        //            tooltip: {
        //                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        //                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
        //                    '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
        //                footerFormat: '</table>',
        //                shared: true,
        //                useHTML: true
        //            },
        //            plotOptions: {
        //                column: {
        //                    pointPadding: 0.2,
        //                    borderWidth: 0
        //                }
        //            },
        //            series: [{
        //                name: 'District',
        //                data: [<?php echo $provinceCountWork; ?>]
        //
        //            }]
        //        });
        $('.ageChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft - 50,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Ages. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                <?php echo $xAxisAge; ?>
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of age'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Ages',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'Ages',
                <?php echo $dataAge; ?>

            }]
        });
        $('.piSex').highcharts({
            colors: ["#90caf9 ", "#f48fb1 ", "#9e9e9e ", "#7798BF", "#aaeeee", "#ff0066", "#eeaaee",
                "#55BF3B", "#DF5353", "#7798BF", "#aaeeee"
            ],
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' :<br>' + this.percentage.toFixed(0) + ' % (' + this.y + '/' + this.total + ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },

            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $sex; ?>

                ]
            }]
        });
        
        
        
        
        
        $('#mediaChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Medias. <?php echo $date_show; ?>'
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: "<?php echo $mediaCategories; ?>"
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of Media'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Medias',
                footerFormat: '</div>',
                shared: true,
                useHTML: true,
                borderWidth: 2
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'Media',
                data: [<?php echo $mediaDatas; ?>]
            }]
        });
        $('#piBudget').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.0f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' : <br>' +this.percentage.toFixed(0)+' % (' + this.y +'/'+this.total+ ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },
            
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $budget; ?>

                ]
            }]
        });
        $('#piVisit').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' : ' +this.percentage.toFixed(0)+' % (' + this.y +'/'+this.total+ ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },
            
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $visit; ?>
                ]
            }]
        });
    });
</script>