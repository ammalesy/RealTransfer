<script src="https://code.highcharts.com/modules/funnel.js"></script>
<div class="customer-report">
    <div>
        <?php	
        if ($permission->pm_chart_report<1) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
        ?>
    </div>
    <div class="content">
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Sales Funnel</a>
                        <ul class="right hide-on-med-and-down">
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/saleFunnel/today">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/saleFunnel/week">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/saleFunnel/month">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="slide" style="display:none">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/saleFunnel/custom" method="post">
                    <div class="custom-date col l9">
                        <input class="datepicker" type="date" name="start" required="required" value="<?php echo date( "Y-m-d", strtotime("-30 days ", strtotime(date('Y-m-d'))) ); ?>" title="Please enter Start Date">
                        <label><b>TO</b></label>
                        <input class="datepicker" type="date" name="end" required="required" value="<?php echo date('Y-m-d'); ?>" title="Please enter End Date">
                    </div>
                    
                    <div class="col l3 button-submit">
                        <button class="btn-large waves-effect waves-light" type="submit" >Submit</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="content-body">
            <div class="row">
                <div class="col l12">
                    <div class="card">
                        <div class="card-content">
                            <span class="card-title layout-title grey-text text-white">Sales Funnel</span>
                            <span class="card-title layout-date grey-text text-white right"><?php echo $date_show; ?></span>
                        </div>
                        <div class="card-image waves-effect waves-block waves-light">
                            <div id="container"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click',function(event) {
            $('.slide').toggle(300);
        });
        $('#container').highcharts({
            chart: {
                type: 'funnel',
                marginRight: 100
            },
            title: {
                text: 'Sales funnel',
                x: -50
            },
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b> ({point.y:,.0f})',
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                        softConnector: true
                    },
                    neckWidth: '30%',
                    neckHeight: '25%'

                    //-- Other available options
                    // height: pixels or percent
                    // width: pixels or percent
                }
            },
            legend: {
                enabled: false
            },
            series: [{
                name: 'Unique users',
                data: [
                    ['Total Quotation', <?php echo $totalQuotation ?>],
                    ['Total Booking', <?php echo $totalBooking ?>],
                    ['Total Contract', <?php echo $totalContract ?>]
                ]
            }]
        });
    });
</script>