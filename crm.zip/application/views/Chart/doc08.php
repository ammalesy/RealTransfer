<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}

</style>

<table border="1" width="100%" cellspacing="20">
    <tr>
        <td><center><pre><b>แบบคำขอเปลี่ยนแปลงห้องชุดที่จะซื้อจะขายโครงการ <span class="under"><font color="red">แดนลิฟวิ่ง รัชดา – วงศ์สว่าง</font></span></b></pre></center></td>
    </tr>
</table>
<br>
<table width="100%">
    <tr>
        <td><pre>เรียน</pre></td>
        <td><pre>ผู้รับมอบอำนาจกระทำการแทน <font color="red">บริษัท กีธา พร็อพเพอร์ตี้ส์ จำกัด</font></pre></td>
        <td align="right"><pre>วันที่ _________________</pre></td>
    </tr>
    <tr>
        <td><pre>อ้างถึง</pre></td>
        <td><pre><input type="checkbox" checked="checked"> ห้องชุดเลขที่ ________ อาคาร _______________ </pre></td>
    </tr>
    <tr>
        <td></td>
        <td><pre>ใน โครงการ <span class="under"><font color="red">แดนลิฟวิ่ง รัชดา – วงศ์สว่าง</font></span></pre></td>
    </tr>
    <tr>
        <td></td>
        <td><pre><input type="checkbox" checked="checked"> พื้นที่ใช้สอยประมาณ ___________ ตารางเมตร</pre></td>
    </tr>
    <tr>
        <td></td>
        <td><pre><input type="checkbox" checked="checked"> ในราคาเป็นจำนวนเงิน __________________ บาท</pre></td>
    </tr>
    <tr>
        <td></td>
        <td colspan="2"><pre>ตามหนังสือจองเลขที่ ___________________________ ลงวันที่ __________________</pre></td>
    </tr>
    <tr>
        <td></td>
        <td colspan="2">ตามสัญญาจะซื้อจะขายห้องชุดเลขที่ ________________ ลงวันที่ __________________</td>
    </tr>
    <tr>
        <td></td>
        <td colspan="2">
            <table>
                <tr>
                    <td><pre>ข้าพเจ้า</pre></td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="100%"></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td><pre><span class="under">ในฐานะ</span></pre></td>
        <td><pre><input type="checkbox"> ผู้จอง <i>(โปรดกรอกข้อ 1)</i></pre></td>
    </tr>
    <tr>
        <td></td>
        <td><pre><input type="checkbox"> ผู้จะซื้อ <i>(โปรดกรอกข้อ 2)</i></pre></td>
    </tr>
</table>
<pre><b>ขอแจ้งความประสงค์ว่า</b> (โปรดทำเครื่องหมาย <input type="checkbox" checked="checked"> หน้าข้อที่ต้องการเพียงข้อเดียว)</pre>
<pre><input type="checkbox"> 1. ข้าพเจ้าประสงค์ขอเปลี่ยนแปลงห้องชุดที่จะซื้อจะขาย (กรณีเป็นผู้จอง) โดยขอยกเลิกหนังสือจอง และขอจองซื้อห้องชุดที่จะซื้อจะ ขายยูนิตใหม่ ดังรายการเปลี่ยนแปลงในกรอบด้านล่างนี้ และในการนี้ให้ถือว่าเงินมัดจำเพื่อการจองซื้อห้องชุดที่ข้าพเจ้าได้ชำระไว้แล้ว จำนวนเงิน__________________________________บาท (_____________________________________________) ตามหนังสือจอง ซื้อที่อ้างถึงนั้น เป็นเงินมัดจำที่ข้าพเจ้าชำระให้แก่ท่าน ทั้งนี้ในการขอเปลี่ยนแปลงห้องชุดในครั้งนี้ ข้าพเจ้าตกลงชำระราคาห้องชุดใน แต่ละงวดตามที่ได้ตกลงกันใหม่กับท่าน ส่วนเงื่อนไขข้อตกลงอื่นๆ ข้าพเจ้ายินยอมผูกพันตามที่ได้ตกลงไว้เดิมกับท่านทุกประการ โดย ข้าพเจ้ายินยอมชำระค่าธรรมเนียมในการดำเนินการนี้เป็นจำนวนเงิน _______ บาท (____________) ด้วย</pre>
<pre><input type="checkbox"> 2. ข้าพเจ้าประสงค์ขอเปลี่ยนแปลงห้องชุดที่จะซื้อจะขาย (กรณีเป็นผู้จะซื้อ) โดยขอยกเลิกสัญญาจะซื้อ จะซื้อ จะขายห้องชุดเดิมและ ขอเข้าทำสัญญาจะซื้อ จะขายห้องชุดยูนิตใหม่ ดังรายการเปลี่ยนแปลงในกรอบด้านล่างนี้ และในการนี้ข้าพเจ้าตกลงยินยอมให้ท่านหัก เงินค่าเสียหายอันเกิดขึ้น เนื่องจากการยกเลิกสัญญาดังกล่าว ออกจากเงินผ่อนชำระซึ่งข้าพเจ้าได้ชำระไว้แล้วตามสัญญาจะซื้อจะขายที่ อ้างถึงได้และขอท่านได้โปรดโอนเงินส่วนที่เหลือหลังจากหักค่าเสียหายดังกล่าว จำนวน_________________________________บาท (__________________________________________) ไปชำระราคาตามสัญญาจะซื้อจะขายห้องชุดใหม่ และให้ถือว่าเงินดังกล่าว เป็นส่วนหนึ่งของเงินที่ข้าพเจ้าต้องชำระตามสัญญาจะซื้อจะขายใหม่ทุกประการ ทั้งนี้ ข้าพเจ้ายินยอมชำระค่าธรรมเนียมในการยกเลิก และเปลี่ยนแปลงห้องชุดเป็นจำนวน________________บาท (_________________________) ด้วย</pre>
<br>
<table border="1" width="100%">
    <tr>
        <td colspan="2" align="center"><pre><b>รายการเปลี่ยนแปลง</b></pre></td>
    </tr>
    <tr>
        <td width="40%"><pre>&nbsp;<span class="under">ขอเปลี่ยนเป็น</span> ห้องชุด</pre></td>
        <td width="60%">
            <table>
                <tr>
                    <td><pre><input type="checkbox"> โครงการ <font color="red"><span class="under">แดนลิฟวิ่ง รัชดา – วงศ์สว่าง</span></font></pre></td>
                </tr>
                <tr>
                    <td><pre><input type="checkbox"> เจ้าของโครงการ(ชื่อบริษัท) <font color="red">บริษัท กีธา พร็อพเพอร์ตี้ส์ จำกัด</font></pre></td>
                </tr>
                <tr>
                    <td><pre><input type="checkbox"> ห้องชุดเลขที่ _______________</pre></td>
                </tr>
                <tr>
                    <td><pre><input type="checkbox"> ที่ใช้สอยประมาณ________ ตารางเมตร</pre></td>
                </tr>
                <tr>
                    <td><pre><input type="checkbox"> ในราคาเป็นจำนวนเงิน__________________ บาท</pre></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table width="100%">
    <tr>
        <td width="50%" valign="top" align="center"><pre>จึงเรียนมาเพื่อโปรดพิจารณาอนุมัติ</pre></td>
        <td width="50%" align="right">
            <table width="100%">
                <tr>
                    <td width="10px"><pre>ลงชื่อ</pre></td>
                    <td width="300px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width="100px"><pre>ผู้จอง / ผู้จะซื้อ</pre></td>
                </tr>
                <tr>
                    <td colspan="3">&nbsp;</td>
                </tr>
                <tr> 
                    <td align="right">(</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                    <td align="left">)</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<br>
<table border="1" width="100%">
    <tr>
        <td colspan="4" align="center"><pre><b>สำหรับเจ้าหน้าที่ของบริษัทเท่านั้น</b></pre></td>
    </tr>
    <tr>
        <td>
            <table>
                <tr>
                    <td><pre>A/C_____________รับทราบ</pre></td>
                </tr>
                <tr>
                    <td><pre>วันที่__________________</pre></td>
                </tr>
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td><pre>ผู้อนุมัติ___________</pre></td>
                </tr>
                <tr>
                    <td><pre>วันที่_____________</pre></td>
                </tr>
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td><pre>เจ้าหน้าที่บริษัท (Sale/CS)</pre></td>
                </tr>
                <tr>
                    <td><pre>ลงชื่อ____________________</pre></td>
                </tr>
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td><pre>เงื่อนไข______________</pre></td>
                </tr>
                <tr>
                    <td><pre>____________________</pre></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
';?>

<?php


include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>