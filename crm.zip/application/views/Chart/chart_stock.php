<div id="menu" class="hidden-print hidden-xs">
    <?php		
	if ($permission->pm_chart_report<1) {
		alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
	}
    ?>
</div>
<div class="income-report">
    <div class="content" >
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Summary of Stock Report</a>
                        <ul class="right hide-on-med-and-down">
<!--
                            <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/total" class="subm">Total</a></li>
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/today" class="subm">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/week" class="subm">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/month" class="subm">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
-->
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print ">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body income-report" id="printPage">
            <div class="table-form">
                <table class="table table-striped colVis" border="1" style="font-size:10pt">
                    <thead class="bg-gray" style="font-weight: bold;">
                        <tr>
                            <td width="50">Room Type</td>
                            <td width="70">Total Size<br>(SQM)</td>
                            <td width="50">Total Room</td>
                            <td width="60">Total <br>Sold+Booked</td>
                            <td width="80">ขายแล้วคิดเป็น (%)</td>
                            <td width="90">Stock Room<br> Balance</td>
                            <td width="80">คงเหลือคิดเป็น(%)</td>
                            <td width="120">Min-Max Price</td>
                            <td width="60">SQM <br>Balance</td>
                            <td width="60">Avg. <br>Price/SQM</td>
                            <td width="90">Price Balance</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $html; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
            $(".threeWord").select2({
                minimumInputLength: 3
            });
        </script>
    </div>
</div>
<script type="text/javascript">
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
    
    function printDiv() {
        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
        
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();

        

    }
</script>
