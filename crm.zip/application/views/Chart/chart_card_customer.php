<script type="text/javascript">
    $(function() {
        var query = 0;
        var lastQuery = 0;
        $('.date').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'dd-mm-yyyy',
            formatSubmit: 'yyyy-mm-dd'
        });
        var type = "summary";
        var $startDate = $('.date').pickadate();
        var startPicker = $startDate.pickadate('picker');
        // startPicker.set('select', '<?php echo date('Y-m-d'); ?>', { format: 'yyyy-mm-dd' });
        console.log($('#date').val());
        loadAjax($('#status').val(), $('#date').val(), type, query);

        $('#status').change (function() {
            $("#data").html('');
            query = 0;
            loadAjax($('#status').val(), $('#date').val(), type, query);
        });
        $('#date').change (function() {
            $("#data").html('');
            query = 0;
            loadAjax($('#status').val(), $('#date').val(), type, query);
        });
    });

    function loadAjax (status, date, type, query){
        console.log("<?php echo BASE_DOMAIN; ?>chart/getDetailCardCustomer/" + status + "/" + date + "/" + type + "count"  + "/" + query);
        $.ajax({
            type:"POST",
            url:"<?php echo BASE_DOMAIN; ?>chart/getDetailCardCustomer/" + status + "/" + date + "/" + type + "count"  + "/" + query,
            success:function(data){
                lastQuery = data;
            }
        });
        $.ajax({
            type:"POST",
            url:"<?php echo BASE_DOMAIN; ?>chart/getDetailCardCustomer/" + status + "/" + date + "/" + type + "/" + query,
            success:function(data){
                $("#data").append(data);
                if (lastQuery = 0) {
                    
                }else if (query < lastQuery) {
                    query = query+100;
                    loadAjax($('#status').val(), $('#date').val(), type, query);
                }
            }
        });
    }
</script>
<div class="card-customer-report">
    <div id="menu" class="hidden-print hidden-xs">
        <?php
        if (strpos($permission->pm_chart_report,'g') == false) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen'); 
        }
        ?>
    </div>

    <div class="content">
           <div class="modal fade" id="load" data-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Loading...</h3>
                        </div>
                    </div>
                </div>
            </div>
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <span class="brand-logo">Card customer report</span>
                        <ul class="right hide-on-med-and-down">
                            <li><a href="<?php echo BASE_URL; ?>/chart/lead/total" class="subm">Summary ( สรุป )</a></li>
                            <li><a href="<?php echo BASE_URL; ?>/chart/lead/today" class="subm">Individual ( บุคคล )</a></li>
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print ">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body">
            <div class="row">
                <div class="col l6">
                    <div class="title">
                        <span>สถานะอนุมัติสัญญา</span>
                    </div>
                    <div class="input-field">
                        <select id="status">
                            <option value="" disabled selected>กรุณาเลือกสถานะ</option>
                            <option value="1" selected="selected">All</option>
                            <option value="2">Active</option>
                            <option value="3">Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="col l6">
                    <div class="title">
                        <span>วันที่ทำสัญญา</span>
                    </div>
                    <div class="input-field">
                        <input type="date" class="startDate" id="date" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
            </div>

            <div class="table-form table-scroll" id="printPage">
                <div class="table-title">
                    <span>รายงานการ์ดลูกค้า</span>
                </div>
                <div class="table-ownership">
                    <span>(ชื่อบริษัท : บริษัท เคพีเอ็น กรุ็ป คอปอร์เรชั่น จำกัด)</span>
                </div>
                <div>
                    <span class="input-title">สถานะอนุมัติสัญญา</span>
                    <span class="input-result">(All)</span>
                    <span class="input-title">วันที่ทำสัญญา</span>
                    <span class="input-result">(dd-mm-yyyy - dd-mm-yyyy)</span>
                </div>
                <div>
                    <span class="input-title">โครงการ</span>
                    <span class="input-result">(ชื่อโครงการ)</span>
                    <span class="input-title">SBU</span>
                    <span class="input-result">01-ธุรกิจอสังหาฯ</span>
                    <span class="input-title">สัญญา</span>
                    <span class="input-result">บันทึกสัญญา</span>
                    <span class="input-title">ที่อยู่</span>
                    <span class="input-result">ติดต่อได้ -> ตามสัญญา -> ที่ทำงาน</span>
                </div>
                <div class="income-report">
                    <table class="highlight" border="1">
                        <thead class="bg-gray">
                            <tr>
                                <th>ลำดับ</th>
                                <th>ห้อง</th>
                                <th>ลูกค้า</th>
                                <th>สัญญาหลักย่อย</th>
                                <th>มูลค่าสัญญา</th>
                                <th>มูลค่ารวม</th>
                                <th>ยอดชำระทั้งหมด</th>
                                <th>ยอดคงเหลือ</th>
                                <th>ส่วนลด</th>
                            </tr>
                        </thead>
                        <tbody id="data">
                            <tr>
                                <td colspan="9">ทั้งหมด</td>
                                <!-- <td><?php echo number_format($totalRealTotalAmount,2); ?></td>
                                <td><?php echo number_format($totalTotalDownPayment,2); ?></td>
                                <td><?php echo number_format($totalBalance,2); ?></td> -->
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>