<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}

.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}

</style>

<table border="0" width="100%">
    <tr>
        <td rowspan="2">ไว้ใส่รูปนะ</td>
        <td>&nbsp;</td>
        <td rowspan="3">ไว้ใส่รูปนะ</td>
    </tr>
    <tr>
        <td><b>หนังสือยินยอมให้หักเงินจากบัตรเครดิต (Recurring)</b></td>
    </tr>
    <tr>
        <td colspan="2">รายละเอียดการชำระค่าผ่อนดาวน์ผ่านบัตรเครดิต</td>
    </tr>
</table>
<table width="752px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="19%">ผู้ซื้อห้องชุดชื่อ-นามสกุล</td>
    <td width="40%" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="14%">ห้องชุดหมายเลข</td>
    <td width="12%" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="7%">อาคาร</td>
    <td width="8%" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Purchaser Name -Surname </td>
    <td>Unit No.</td>
    <td>&nbsp;</td>
    <td>Building</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="752px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="19">ที่อยู่</td>
    <td width="687" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><p>Address</p></td>
  </tr>
</table>
<table width="752px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="118"><p>เลือกชำระด้วยบัตรเครดิต</p></td>
    <td width="40">&nbsp;</td>
    <td width="173">&nbsp;</td>
    <td width="89">&nbsp;</td>
    <td width="226">&nbsp;</td>
  </tr>
  <tr>
    <td><input type="checkbox"/> VISA CARD</td>
    <td>ธนาคาร</td>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td><input type="checkbox"/> เงิน/Silver</td>
    <td><input type="checkbox"/>ไทเทเนียม/Titanium</td>
  </tr>
  <tr>
    <td><input type="checkbox"/>
      MASTER CARD</td>
    <td>ธนาคาร</td>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td><input type="checkbox"/>
      ทอง/Gold</td>
    <td><input type="checkbox"/>
      แพลตตินั่ม/Platinum</td>
  </tr>
</table>
<table width="752px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="57">ชื่อผู้ถือบัตร</td>
    <td width="316" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="134">หมายเลขโทรศัพท์เพื่อติดต่อ</td>
    <td width="159" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Cardholder&rsquo;s name</td>
    <td colspan="2"><p>Telephone No. for contact</p></td>
  </tr>
</table>
<table width="752px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="66">หมายเลขบัตร</td>
    <td width="385" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="100">วันหมดอายุบัตร :</td>
    <td width="131" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Card Number</td>
    <td colspan="2">Expiry date of Credit Card</td>
  </tr>
</table>
<p>โดยหนังสือฉบับนี้ ข้าพเจ้ามีความประสงค์ขอให้ธนาคารเรียกเก็บเงินจากบัตรเครดิตดังกล่าวข้างต้นของข้าพเจ้า เพื่อชำระค่าผ่อนดาวน์จำนวน.............งวด งวดละ ...........................บาท จำนวนเงินรวม ...............................  บาท ของห้องชุดหมายเลข....................... <strong>อาคาร ......</strong> <strong>โครงการ</strong> <strong>แดน ลิฟวิ่ง รัชดา-วงศ์สว่าง </strong>ให้แก่ <strong>บริษัท กีธา พร็อพเพอร์ตี้ส์ จำกัด </strong>ต่อไปนี้จะเรียกว่า &ldquo;บริษัท&rdquo; ตามที่ปรากฎในใบแจ้งหนี้หรือแผ่นบันทึกข้อมูลที่ธนาคารได้รับจากบริษัท และนำเงินจำนวนที่หักดังกล่าวโอนเข้าบัญชีบริษัทตามวันที่บริษัทกำหนด โดยข้าพเจ้าตกลงให้ถือว่าบรรดาเอกสารต่างๆเกี่ยวกับการยินยอมให้ธนาคารเรียกเก็บจากบัตรเครดิตที่ธนาคารได้จัดทำขึ้นมีความถูกต้องทุกประการ</p>
<p>ในการเรียกเก็บเงินจากบัตรเครดิตของข้าพเจ้าเพื่อชำระเงินงวดผ่อนดาวน์ให้แก่บริษัท หากปรากฎในภายหลังว่าจำนวนเงินที่บริษัทแจ้งแก่ธนาคารนั้นไม่ถูกต้องหรือมีความเสียหายหรือผิดพลาดใดๆ  และธนาคารได้ทำการเรียกเก็บเงินจากบัตรเครดิตของข้าพเจ้าตามจำนวนที่ปรากฏในใบแจ้งหนี้หรือแผ่นบันทึกข้อมูลเรียบร้อยแล้ว ข้าพเจ้าตกลงที่จะดำเนินการเรียกร้องจำนวนเงินดังกล่าวจากบริษัทโดยตรง ทั้งนี้ ข้าพเจ้าขอสละสิทธิในการเรียกร้องหรือฟ้องร้องให้ธนาคารชดใช้ที่ธนาคารได้เรียกเก็บเงินจากบัตรเครดิตของข้าพเจ้าตามจำนวนที่ปรากฏในใบแจ้งหนี้หรือแผ่นบันทึกข้อมูลตามที่ธนาคารได้รับจากบริษัท และในกรณีที่การเรียกเก็บเงินจากบัตรเครดิตดังกล่าวได้ก่อให้เกิดความเสียหายใดๆต่อธนาคาร ข้าพเจ้าตกลงรับผิดชอบชดใช้ค่าเสียหายให้แก่ธนาคารทุกประการโดยไม่มีเงื่อนไขใดๆทั้งสิ้น นอกจากนี้ข้าพเจ้ายอมรับว่า ในกรณีที่ข้าพเจ้ายินยอมให้เรียกเก็บเงินจากบัตรเครดิต ข้าพเจ้ายินยอมที่จะปฏิบัติตามระเบียบและเงื่อนไขในการใช้บัตรเครดิตทุกประการ</p>
<p>ในกรณีที่เอกสารหลักฐานหรือหมายเลขบัตรเครดิตดังกล่าวเปลี่ยนไป ไม่ว่าโดยเหตุใดก็ตามหนังสือยินยอมให้หักเงินจากบัตรเครดิตฉบับนี้คงมีผลใช้บังคับบัตรเครดิตหมายเลขที่ได้เปลี่ยนแปลงนั้นๆด้วย หากมีการเปลี่ยนแปลงหมายเลขบัตรเครดิตหรือบัตรเครดิตหมดอายุ ข้าพเจ้าจะต้องทำหนังสือแจ้งให้บริษัทรับทราบหมายเลขบัตรเครดิตใหม่หรือวันหมดอายุใหม่ล่วงหน้าอย่างน้อย 1 เดือนนับจากเดือนที่หมดอายุ</p>
<p>การเรียกเก็บเงินจากบัตรเครดิตข้างต้นให้มีผลบังคับใช้ทันที นับแต่วันทำหนังสือฉบับนี้เป็นต้นไปและให้คงมีผลบังคับใช้ต่อไปจนกว่าธนาคารจะได้บอกเลิกการใช้บัตรเครดิตตามหนังสือฉบับนี้ หรือข้าพเจ้าจะได้เพิกถอนโดยทำเป็นลายลักษณ์อักษรให้ธนาคารและบริษัททราบอย่างน้อยล่วงหน้า 2 เดือน </p>
<p>ข้าพเจ้าขอรับรองว่า ลายมือชื่อในหนังสือฉบับนี้เป็นลายมือชื่อของข้าพเจ้าจริง หากปรากฏว่าลายมือชื่อในหนังสือฉบับนี้แตกต่างจากลายมือชื่อที่ให้กับธนาคาร ข้าพเจ้ายินยอมให้ธนาคารหักเงินจากบัตรเครดิตของข้าพเจ้าทุกประการ โดยข้าพเจ้าขอสละสิทธิ์ในการโต้แย้งหรือใช้สิทธิเรียกร้องใดๆเอากับธนาคารและ/หรือบริษัททั้งสิ้น </p>

<table width="752px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="65">&nbsp;</td>
    <td width="27">ลงชื่อ</td>
    <td width="179" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="">&nbsp;</td>
    <td width="27">ลงชื่อ</td>
    <td width="179" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="6">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="right">(</div></td>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td>)</td>
    <td align="right">(</td>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td>)</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">ผู้จองซื้อ</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">พนักงานขาย</td>
    <td>&nbsp;</td>     
  </tr>
</table>
<table width="752px" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="65">&nbsp;</td>
    <td width="27">ลงชื่อ</td>
    <td width="179" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="">&nbsp;</td>
    <td width="27">ลงชื่อ</td>
    <td width="179" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td width="6">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="right">(</td>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td>)</td>
    <td align="right">(</td>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
    <td>)</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">พยาน</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">พยาน</td>
    <td>&nbsp;</td>
  </tr>
</table>
<pre>เงื่อนไขการชำระค่าผ่อนดาวน์ผ่านบัตรเครดิต (Term and Condition)<br/>
1.	ผู้จองซื้อและเจ้าของบัตรเครดิตต้องเป็นบุคคลเดียวกันเท่านั้น<br/>
2.	เจ้าหน้าที่ต้องตรวจสอบความเรียบร้อยของข้อมูล ผู้จองซื้อต้องกรอกรายละเอียดครบทุกช่อง (โดยเฉพาะลายมือชื่อบุคคลทั้ง 4 ท่าน ด้านล่าง)<br/>
3.	กรณีการใช้บัตรเครดิตเพื่อชำระค่างวดดาวน์ อนุญาตให้ใช้เฉพาะการจองและทำสัญญาเท่านั้น หากลูกค้าประสงค์จะใช้บัตรเครดิตในการผ่อนงวดดาวน์ จำเป็นต้องสมัครใช้บริการหักเงินจากบัตรเครดิต (Recurring) เท่านั้น</pre>
<table width="64%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="35%">เอกสารประกอบ</td>
    <td width="65%">- สำเนาบัตรเครดิตพร้อมรับรองสำเนาถูกต้อง</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><p>- สำเนาบัตรประชาชนพร้อมรับรองสำเนาถูกค้อง</p></td>
  </tr>
</table>
<table width="30%" border="0" cellspacing="0" cellpadding="0" align="right">
  <tr>
    <td style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><p align="center">คุณยุคลธร  สุทธิรักษ์ศิริ</p></td>
  </tr>
  <tr>
    <td align="center"><p align="center">(รองประธานธุรกิจฝ่ายขายและเช่า)</p></td>
  </tr>
  <tr>
    <td align="center"><p align="center">บริษัท  กีธา พร็อพเพอร์ตี้ส์ จำกัด</p></td>
  </tr>
</table>
';?>

<?php


include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>