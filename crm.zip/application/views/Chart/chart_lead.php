<script>        
    function next() 
    {
        $('#load').modal('hide');
    }
        
    $(function() {
        $("#search").submit(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
        
        $(".subm").click(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
    });
</script>
<div class="lead-report">
    <div id="menu" class="hidden-print hidden-xs">
        <?php
        if ($permission->pm_chart_report<1) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
        ?>
    </div>

    <div class="content">
           <div class="modal fade" id="load" data-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Loading...</h3>
                        </div>
                    </div>
                </div>
            </div>
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Leads</a>
                        <ul class="right hide-on-med-and-down">
                            <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/total" class="subm">Total</a></li>
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/today" class="subm">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/week" class="subm">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/month" class="subm">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print ">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="slide" style="display:none">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/lead/custom" method="post" id="search">
                    <div class="custom-date col l10">
                        <input class="datepicker" type="date" name="start" required="required" value="<?php echo date( "Y-m-d", strtotime("-30 days ", strtotime(date('Y-m-d'))) ); ?>" title="Please enter Start Date">
                        <label><b>TO</b></label>
                        <input class="datepicker" type="date" name="end" required="required" value="<?php echo date('Y-m-d'); ?>" title="Please enter End Date">
                    </div>
                    
                    
                    <div class="button-form">
                        <button class="btn waves-effect waves-light" type="submit" name="action">Search
                            <i class="material-icons left">search</i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="content-body" id="printPage">
            <div class="lead-report page">

                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Leads</span>
                                <span class="card-title layout-date grey-text text-white right"><?php echo $date_show; ?></span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="container"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content" >
                                <span class="card-title layout-title grey-text text-white">Visit Type</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="piVisit"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content" >
                                <span class="card-title layout-title grey-text text-white">Budget</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="piBudget"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-break"></div>
                <div class="row">
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Sex</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="piSex"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Opportunity Stages</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="piStage"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Media Type</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="mediaChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        
<script type="text/javascript">
    function printDiv() {
        var chart = $('#container').highcharts();
        chart.setSize(1070,500, false);

        var chartMedia = $('#mediaChart').highcharts();
        chartMedia.setSize(1070,500, false); 

        var piVisit = $('#piVisit').highcharts();
        piVisit.setSize(520 ,500, false);

        var piBudget = $('#piBudget').highcharts();
        piBudget.setSize(520 ,500, false);

        var piSex = $('#piSex').highcharts();
        piSex.setSize(520 ,500, false);

        var piStage = $('#piStage').highcharts();
        piStage.setSize(520 ,500, false);



        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
        
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();

        

    }
    $(function() {
        
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click',function(event) {
            $('.slide').toggle(300);
        });
        
        $('#container').highcharts({
            chart: {
                type: '<?php echo $format_chart; ?>',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Leads. <?php echo $date_show; ?>'
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $xAxis; ?>],

                labels: {
                    step: [<?php echo $date_cut; ?>],
                    <?php echo $rotation; ?>
                },
                crosshair: true



            },
            yAxis: {
                allowDecimals: false,
                min: 0,
                title: {
                    text: 'Units of <?php echo $type_name; ?>'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Leads',
                footerFormat: '</div>',
                shared: true,
                useHTML: true,
                borderWidth: 2
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                },

            },
            series: [{
                name: '<?php echo $type_name; ?>',
                data: [<?php echo $count_cus; ?>]

            }]
        });
        $('#mediaChart').highcharts({
            chart: {
                type: 'column',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                                'Total: ' + total,
                                this.plotLeft,
                                this.plotTop - 20
                            ).attr({
                                zIndex: 5
                            }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Medias. <?php echo $date_show; ?>'
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: "<?php echo $mediaCategories; ?>"
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of Media'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Medias',
                footerFormat: '</div>',
                shared: true,
                useHTML: true,
                borderWidth: 2
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: 'Media',
                data: [<?php echo $mediaDatas; ?>]
            }]
        });
        $('#piBudget').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.0f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' : <br>' +this.percentage.toFixed(0)+' % (' + this.y +'/'+this.total+ ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },
            
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $budget; ?>

                ]
            }]
        });

        $('#piSex').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' : <br>' +this.percentage.toFixed(0)+' % (' + this.y +'/'+this.total+ ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },
            
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $sex; ?>

                ]
            }]
        });
        $('#piStage').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' : ' +this.percentage.toFixed(0)+' % (' + this.y +'/'+this.total+ ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },
            
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $stage; ?>

                ]
            }]
        });
        // Build the chart
        $('#pi').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: 'Browser market shares at a specific website, 2014'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                type: 'pie',
                name: 'Browser share',
                data: [
                    ['<?php echo $budgetDetail; ?>', 1],
                    ['IE', 26.8], {
                        name: 'Chrome',
                        y: 12.8,
                        sliced: true,
                        selected: true
                    },
                    ['Safari', 8.5],
                    ['Opera', 6.2],
                    ['Others', 0.7]
                ]
            }]
        });
        $('#piVisit').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            if (this.y != 0) {
                                return this.point.name + ' : ' +this.percentage.toFixed(0)+' % (' + this.y +'/'+this.total+ ')';
                            }
                        }
                    },
                    showInLegend: false
                }
            },
            
            series: [{
                type: 'pie',
                name: 'Percents',
                data: [
                    <?php echo $visit; ?>
                ]
            }]
        });
    });
    
</script>