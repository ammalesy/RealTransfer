<div id="menu" class="hidden-print hidden-xs">
    <?php
	if ($permission->pm_chart_report<1) {
		alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
	}
	?>
</div>
<div class="income-report">
    <div class="content" >
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Daily Report Income</a>
                        <ul class="right hide-on-med-and-down">
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body">
            <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/drIncome" method="post">
                <div class="date-form row">
                    <div class="title col l4">Date</div>
                    <div class="col l8">
                        <input class="datepicker" type="date" name="beginDate" required="required" value="<?php echo $beginDate; ?>" title="Please enter Start Date">
                    </div>
                </div>
                <div class="button-form">
                    <button class="btn waves-effect waves-light" type="submit" name="action">Search
                        <i class="material-icons left">search</i>
                    </button>
                </div>
                <!-- <a href="<?php echo BASE_DOMAIN; ?>chart/drIncome/<?php echo $typeDr; ?>/<?php echo $beginDate; ?>"><?php echo image_asset('image/downloadexcel.gif',NULL,array('title'=>'Download Diary report for incomes')); ?></a> -->
            </form>
            <div class="table-form table-scroll" id="printPage">
                <div class="income-report">
                    <table class="table table-striped colVis" border="1" style="font-size:10pt">
                        <thead class="bg-gray" style="font-weight: bold;">
                            <!-- <tr>
                                <td colspan="<?php echo (10+$totalDownPay); ?>" align="center" bgcolor="#606060">
                                    <font color="white"><b>Dialy Report รายรับของวันที่ <?php echo $this->dateformat->thaiDate(date('Y-m-d', strtotime($beginDate))); ?></b></font>
                                </td>
                            </tr> -->
                            <tr>
                                <th width="40px">ลำดับ</th>
                                <th width="50px">ห้อง</th>
                                <th width="200px">ชื่อลูกค้า</th>
                                <th width="100px">เงินจอง</th>
                                <th width="100px">เงินทำสัญญา</th>
                                <th width="100px">ราคาตามสัญญา</th>
                                <th width="40px">งวด</th>
                                <?php 
                                for($temp=0;$temp<$totalDownPay;$temp++) { 
                                    echo "<th width='100px'>".($temp+1)."</th>";
                                } 
                                ?>
                                <th width="100px">ชำระแล้ว</th>
                                <th width="100px">ตามสัญญา</th>
                                <th width="100px">คงเหลือ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $details; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <script>
            $(".threeWord").select2({
                minimumInputLength: 3
            });
        </script>
    </div>
</div>
<script type="text/javascript">
    function printDiv() {
        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
        
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();
    }
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script>
