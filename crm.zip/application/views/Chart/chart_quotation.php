<script>        
    function next() 
    {
        $('#load').modal('hide');
    }
        
    $(function() {
        $("#search").submit(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
        
        $(".subm").click(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
    });
</script>
<div class="quotation-report">
    <div>
        <?php
        if ($permission->pm_chart_report<1) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
        ?>
    </div>
    <div class="content">
           <div class="modal fade" id="load" data-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Loading...</h3>
                        </div>
                    </div>
                </div>
            </div>
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Quotations</a>
                        <ul class="right hide-on-med-and-down">
                            <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/quotation/total" class="subm">Total</a></li>
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/quotation/today" class="subm">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/quotation/week" class="subm">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/quotation/month" class="subm">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="slide" style="display:none">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/quotation/custom" method="post" id="search">
                    <div class="custom-date col l10">
                        <input class="datepicker" type="date" name="start" required="required" value="<?php echo date( "Y-m-d", strtotime("-30 days ", strtotime(date('Y-m-d'))) ); ?>" title="Please enter Start Date">
                        <label><b>TO</b></label>
                        <input class="datepicker" type="date" name="end" required="required" value="<?php echo date('Y-m-d'); ?>" title="Please enter End Date">
                    </div>
                    
                    <div class="col l2 button-submit">
                        <button class="btn waves-effect waves-light" type="submit" >Submit</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="content-body" id="printPage">
            <div class="quotation-report">
                <div class="row">
                    <div class="col l12">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Quotations</span>
                                <span class="card-title layout-date grey-text text-white right"><?php echo $date_show; ?></span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div id="container"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Top 5 Promotions</span>
                                <span class="card-title layout-date grey-text text-white right">(Promotion ที่ออกสูงสุด)</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div>
                                    <table class="striped">
                                        <tr>
                                            <th>Promotion</th>
                                            <th class="right">No. of Promotion</th>
                                        </tr>
                                        <?php echo $tableTopPromotion; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Top 5 Units</span>
                                <span class="card-title layout-date grey-text text-white right">(ห้องที่ออก Quotations สูงสุด)</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div>
                                    <table class="striped">
                                        <tr>
                                            <th>Room</th>
                                            <th class="right">No. of Quotations</th>
                                        </tr>
                                        <?php echo $tableTopUnit; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col l6">
                        <div class="card">
                            <div class="card-content">
                                <span class="card-title layout-title grey-text text-white">Top 5 Units</span>
                                <span class="card-title layout-date grey-text text-white right">(พนักงานที่ออก Quotations สูงสุด)</span>
                            </div>
                            <div class="card-image waves-effect waves-block waves-light">
                                <div>
                                    <table class="striped">
                                        <tr>
                                            <th>Name</th>
                                            <th class="right">No. of Quotations</th>
                                        </tr>
                                        <?php echo $topEmpQout; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function printDiv() {

        var chartQuotation = $('#container').highcharts();
        chartQuotation.setSize(1070,500, false);

        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
       
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();

    }
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click',function(event) {
            $('.slide').toggle(300);
        });
        
        $('#container').highcharts({
            chart: {
                type: '<?php echo $format_chart; ?>',
                events: {
                    load: function(event) {
                        var total = 0; // get total of data
                        for (var i = 0, len = this.series[0].yData.length; i < len; i++) {
                            total += this.series[0].yData[i];
                        }
                        var text = this.renderer.text(
                            'Total: ' + total,
                            this.plotLeft,
                            this.plotTop - 20
                        ).attr({
                            zIndex: 5
                        }).add() // write it to the upper left hand corner
                    }
                }
            },
            title: {
                text: 'Quotations. <?php echo $date_show; ?> '
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $xAxis; ?>],

                labels: {
                    step: [<?php echo $date_cut; ?>],
                    <?php echo $rotation; ?>
                },
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Units of <?php echo $type_name; ?>'
                }
            },
            tooltip: {
                headerFormat: '<span class="headFormat" style="color:{series.color};padding:0">{point.key}</span><div class="contentFormat">',
                pointFormat: '{point.y} Quotations',
                footerFormat: '</div>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                name: '<?php echo $type_name; ?>',
                data: [<?php echo $count_cus; ?>]

            }]
        });
    });
</script>