<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $title; ?>
    </title>

    <!-- Meta -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.tables.min.css" />

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>

    <script>
        $(window).load(function() {
            $('#loading').remove();
            $('#dataTable').css('visibility', 'visible');
        });

    </script>
</head>
<style>
    a {
        color: rgb(19, 46, 232);
    }

</style>

<body class="">
    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>
    <div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
        <?php
			include "application/views/menu_top.php";
			?>
    </div>

    <div id="menu" class="hidden-print hidden-xs">
        <?php
			include "application/views/menu_left.php";
			
			if ($permission->pm_quotation<1) {
//				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			?>
    </div>


    <div id="content">

        <div class="innerAll spacing-x2" id="loading">
            <div class="widget widget-inverse">
                <div class="widget-head">
                    <h2 class="heading">loading...</h4>
        </div>
    </div>
</div>	
<div class="innerAll spacing-x2" style="visibility: hidden;"  id="dataTable">


	<!-- Widget -->
	<div class="widget widget-inverse">
		<div class="widget-head">
			<h4 class="heading">View Credit Card Auto Pay</h4>
		</div>
		<div class="widget-body padding-bottom-none">
			<!-- Table -->
			<?php
//					if (strpos($permission->pm_quotation,'1') !== FALSE) {
				?>
			<a href="<?php echo BASE_DOMAIN; ?>CreditAuto/adding">
			<button class="btn btn-inverse"><i class="fa fa-user"></i> New </button>
			</a>
			<br/><?php //} ?>
			<br/>
<table class="dynamicTable colVis table"  id="example">

	<!-- Table heading -->
	<thead class="bg-gray">
		<tr>
			
			<th>English Name</th>
			<th>Thai Name</th>
			<th width="140px" style="text-align:center">Action</th>
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody>
		<!-- Table row -->
		
			<?php foreach($reportList as $value): ?>
					<tr >
						<td ><?= $value->rp_name_en; ?></td>
						<td ><?= $value->rp_name_th; ?></td>
                        <td style="text-align:center">
                            <a href="<?= BASE_DOMAIN; ?>reportsystem/editing/<?= $value->rp_id; ?>"><?= image_asset('image/edit.gif',NULL,array('title'=>'Edit')); ?></a>
								
                            <a href="<?= BASE_DOMAIN; ?>reportsystem/deleting/<?= $value->rp_id; ?>" onclick="return confirm('Delete Leads ?')"><?= image_asset('image/delete.gif',NULL,array('title'=>'Delete')); ?></a>
                        </td>
					</tr>
			<?php endforeach; ?>
			
		<!-- // Table row END -->
	</tbody>
	<!-- // Table body END -->
	
</table>
<!-- // Table END -->
<br />

		</div>
	</div>
	<!-- // Widget END -->
	

	
</div>
		</div>
		<!-- // Content END -->
		
		<div class="clearfix"></div>
		<!-- // Sidebar menu & content wrapper END -->
		
		<div id="footer" class="hidden-print">
			

	
		</div>
		<!-- // Footer END -->
		
	</div>
	<!-- // Main Container Fluid END -->
	

	

	<!-- Global -->
	<script>
	var basePath = '',
		commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
		rootPath = '<?php echo BASE_DOMAIN; ?>',
		DEV = false,
		componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';
	
	var primaryColor = '#cb4040',
		dangerColor = '#b55151',
		infoColor = '#466baf',
		successColor = '#8baf46',
		warningColor = '#ab7a4b',
		inverseColor = '#45484d';
	
	var themerPrimaryColor = primaryColor;
	</script>
	
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>	

<script>
   
    var peo = '';
         peo = '<?php echo $quo; ?>';
     
    if ( peo !== '' ) 
    {       
       document.getElementById('rep').href = 'quotation_reportView.php?qid='+peo;     
       document.getElementById('rep').click();
    }
  
 </script>

</body>
</html>
