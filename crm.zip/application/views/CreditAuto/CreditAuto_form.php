<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $title; ?>
    </title>
    <!-- Meta -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

    <!-- 
	**********************************************************
	In development, use the LESS files and the less.js compiler
	instead of the minified CSS loaded by default.
	**********************************************************
	<link rel="stylesheet/less" href="assets/less/admin/module.admin.page.form_validator.less" />
	-->

    <!--[if lt IE 9]><link rel="stylesheet" href="../assets/components/library/bootstrap/css/bootstrap.min.css" /><![endif]-->
    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.form_validator.min.css" />
    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.shop_edit_product.min.css" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
    <script>
        $(function() {
            var defaultOption = '<option value=""> ------- Select ------ </option>';

            // Bind an event handler to the "change" JavaScript event, or trigger that event on an element.
            $(function() {
                $("#Building").html(defaultOption);

                $.ajax({
                    url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Building.php",
                    data: ({
                        Project: $('#Project').val(),
                        project_database_sel: '<?php echo $project_database_sel; ?>'
                    }),
                    dataType: "json",

                    success: function(json) {
                        $.each(json, function(index, value) {
                            $("#Building").append('<option value="' + value.building_id + '" >' + value.building_name + '</option>');
                        });
                    }
                });


                $.ajax({

                    url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
                    data: ({
                        Project: $('#Project').val(),
                        project_database_sel: '<?php echo $project_database_sel; ?>'
                    }),
                    dataType: "json",

                    success: function(json) {
                        var Cash = 0;
                        var Gift = 0;
                        var Furniture = 0;
                        $('#trCash').hide();
                        $('#trGift').hide();
                        $('#trFur').hide();
                        $.each(json, function() {
                            if (this.pm_type == 'Cash') {
                                if (Cash++ == 0)
                                    $('#trCash').show();
                                $("#checkboxescash").append($('<div class="col-xs-6 col-sm-4">' + '<label class="labelPromotion" > ' + '</div>').text(' ' + this.pm_name).prepend(
                                    $('<input  name="pro[]">').attr('type', 'checkbox').val(this.pm_id)));
                            } else if (this.pm_type == 'Gift') {
                                if (Gift++ == 0)
                                    $('#trGift').show();
                                $("#checkboxesgift").append($('<div class="col-xs-6 col-sm-4">' + '<label class="labelPromotion" > ' + '</div>').text(' ' + this.pm_name).prepend(
                                    $('<input  name="pro[]">').attr('type', 'checkbox').val(this.pm_id)));
                            } else if (this.pm_type == 'Furniture') {
                                if (Furniture++ == 0)
                                    $('#trFur').show();
                                $("#checkboxesfur").append($('<div class="col-xs-6 col-sm-4">' + '<label class="labelPromotion" > ' + '</div>').text(' ' + this.pm_name).prepend(
                                    $('<input  name="pro[]">').attr('type', 'checkbox').val(this.pm_id)));
                            }
                        });
                    }
                });

            });
            $('#Building').change(function() {
                $("#Floor").html(defaultOption);
                $("#Number").html(defaultOption);
                $("#PaymentTerms").html(defaultOption);

                $.ajax({
                    url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Building_Floor.php",
                    data: ({
                        Building: $('#Building').val(),
                        project_database_sel: '<?php echo $project_database_sel; ?>'
                    }),
                    dataType: "json",

                    success: function(json) {
                        $.each(json, function(index, value) {
                            $("#Floor").append('<option value="' + value.fl_id + '" >' + value.fl_name + '</option>');
                        });
                    }
                });
            });

            $('#Floor').change(function() {
                $("#Number").html(defaultOption);

                $.ajax({
                    url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Floor_Number.php",
                    data: ({
                        Floor: $('#Floor').val(),
                        project_database_sel: '<?php echo $project_database_sel; ?>',
                        common_database: '<?=$common_database?>'
                    }),
                    dataType: "json",

                    success: function(json) {
                        $.each(json, function(index, value) {
                            $("#Number").append('<option value="' + value.un_id + '">' + value.un_name + "&nbsp;&nbsp;&nbsp;" + value.type_name + '</option>');

                        });
                    }
                });
            });


        });

    </script>
</head>

<body ng-app="CreditAuto">
    <div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
        <?php
				include "application/views/menu_top.php";
			?>
    </div>

    <div id="menu" class="hidden-print hidden-xs">
        <?php
            include "application/views/menu_left.php";
            if (!strpos($permission->pm_table_report,'1') && !strpos($permission->pm_table_report,'2')) {
//                alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
            }
        ?>
    </div>


    <div id="content">
        <!--        <h1 class="content-heading bg-white border-bottom">Report System</h1>-->
        <div class="innerAll spacing-x2">
            <!-- Widget -->
            <div class="widget widget-inverse">

                <!-- Widget heading -->
                <div class="widget-head">
                    <h4 class="heading">Add Credit Auto Pay</h4>
                </div>
                <!-- // Widget heading END -->

                <div class="widget-body">
                    <form action="<?=BASE_DOMAIN?>reportsystem/<?= empty($rpDetail)?'record':'update' ?>" method="post">
                        <?= empty($rpDetail)?'':'<input type="hidden" name="rpID" value="'.$rpDetail->rp_id.'" />' ?>
                            <!-- Row -->
                            <div class="row">
                                <h4 class="heading">Room Detail</h4>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <!-- Column -->
                                <div class="col-md-12">
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Customer
                                        </label>
                                        <div class="col-sm-4">
                                            <input id="user_fullname" class="form-control" value="" required onkeypress="leadsCheck();" />
                                            <input type="hidden" name='leadsid' id="leads-id" value="" />
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Building Name
                                        </label>
                                        <div class="col-sm-4">
                                            <select class="form-control" id="Building" name="Building" style="width: 170px" required="required" title="Please Select Floor Name"></select> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <!-- Column -->
                                <div class="col-md-12">
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Floor Name
                                        </label>
                                        <div class="col-sm-4">
                                            <select class="form-control" id="Floor" name="Floor" style="width: 170px" required="required" title="Please Select Floor Name">
                                                <option value="" >------- Select ------</option>
                                            </select> 
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Unit Name
                                        </label>
                                        <div class="col-sm-4">
                                            <select class="form-control" id="Number" name="Number" style="width: 170px" required="required" title="Please Select Floor Name">
                                                <option value="" >------- Select ------</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <h4 class="heading">Credit Detail</h4>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Credit Type
                                        </label>
                                        <div class="col-sm-4">
                                            <select class="form-control" style="width:170px">
                                                <option value="">--- Please Select ---</option>
                                                <?php foreach($credit_type as $val): ?>
                                                    <option value="<?=$val->ct_id?>">
                                                        <?=$val->ct_name?>
                                                    </option>
                                                    <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Bank
                                        </label>
                                        <div class="col-sm-4">
                                            <select class="form-control" style="width:170px">
                                                <option value="">--- Please Select ---</option>
                                                <?php foreach($bank as $val): ?>
                                                    <option value="<?=$val->b_id?>">
                                                        <?=$val->bank_name_th?>
                                                    </option>
                                                    <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Owner
                                        </label>
                                        <div class="col-sm-4">
                                            <input class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Phone
                                        </label>
                                        <div class="col-sm-4">
                                            <input class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Credit Expiry
                                        </label>
                                        <div class="col-sm-4">
                                            <div class="col-sm-6">
                                                <select class="form-control" style="width:70px">
                                                    <?php for($i=1;$i<13;$i++): ?>
                                                        <option value="<?=$i?>">
                                                            <?=$i?>
                                                        </option>
                                                        <?php endfor; ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <select class="form-control" style="width:90px">
                                                    <?php for($i=2010;$i<2050;$i++): ?>
                                                        <option value="<?=$i?>">
                                                            <?=$i?>
                                                        </option>
                                                        <?php endfor; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Total Month
                                        </label>
                                        <div class="col-sm-4">
                                            <input class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Row END -->
                            <br/>
                            <!-- Row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Installment Fee
                                        </label>
                                        <div class="col-sm-4">
                                            <input class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="lable-control col-sm-3" align="right">
                                            Pay/Month
                                        </label>
                                        <div class="col-sm-4">
                                            <input class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Row END -->
                            <div class="row">
                                <div class="col-md-12">
                                    <br/>
                                    <br/>
                                    <br/>
                                    <div class="form-actions" align="center">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Save</button>
                                        <a href="<?php echo BASE_DOMAIN; ?>reportsystem/view">
                                            <button type="button" class="btn btn-default"><i class="fa fa-times"></i> Cancel</button>
                                        </a>
                                    </div>
                                </div>
                                <!-- // Column END -->
                            </div>
                            <!-- // Row END -->
                    </form>
                </div>

            </div>

        </div>
        <!-- // Content END -->

        <div class="clearfix"></div>
        <!-- // Sidebar menu & content wrapper END -->

        <div id="footer" class="hidden-print">

        </div>
        <!-- // Footer END -->

    </div>
    <!-- // Main Container Fluid END -->




    <!-- Global -->
    <script>
        var basePath = '',
            commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
            rootPath = '<?php echo BASE_DOMAIN; ?>',
            DEV = false,
            componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

        var primaryColor = '#cb4040',
            dangerColor = '#b55151',
            infoColor = '#466baf',
            successColor = '#8baf46',
            warningColor = '#ab7a4b',
            inverseColor = '#45484d';

        var themerPrimaryColor = primaryColor;

    </script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/lib/jquery.inputmask.bundle.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/custom/inputmask.user.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/editors/wysihtml5/assets/lib/js/wysihtml5-0.3.0_rc2.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/editors/wysihtml5/assets/lib/js/bootstrap-wysihtml5-0.0.2.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/editors/wysihtml5/assets/custom/wysihtml5.init.js?v=v1.2.3"></script>

    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>/assets/css/jquery-ui-1.10.2.custom.css" />

    <script src="<?php echo BASE_DOMAIN; ?>/assets/js/jquery-ui-1.10.2.custom.min.js"></script>
    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>/assets/themes/js/allEmpData.js"></script>
    <script>
        <?php
            $comma = '';
            $allEmp = '';
            $lead = '';

            foreach($list_customer as $aCustomer):
                if(!empty($cus_id) && $cus_id === $aCustomer->cus_id) {
                    $lead = $aCustomer->fullname;
                }
                $allEmp .= $comma.'{value: "'.$aCustomer->cus_id.'",label: "'.$aCustomer->fullname.'"}';
                if($comma==='') $comma = ',';
            endforeach;

            $allEmp = '['. $allEmp . ']';
        ?>
        $(function() {
            //ถ้าใช้งานจริง ส่วนนี้จะถูกเขียนขึ้น เป็นไฟล์ .js เมื่อมีการเพิ่ม/แก้ไข ข้อมูลสมาชิก 
            var autoCompleteData = <?php echo $allEmp?>;
            //--

            if (!autoCompleteData) var autoCompleteData = new Array();
            $("#user_fullname").autocomplete({
                    minLength: 3,
                    source: autoCompleteData,
                    focus: function(event, ui) {
                        $("#user_fullname").val(ui.item.label);
                        $("#leads-id").val(ui.item.value);
                        return false;
                    },
                    select: function(event, ui) {
                        $("#user_fullname").val(ui.item.label);
                        $("#leads-id").val(ui.item.value);
                        return false;
                    }
                })
                .data("ui-autocomplete")._renderItem = function(ul, item) {
                    return $("<li>")
                        .append("<a>" + item.label + "</a>")
                        .appendTo(ul);
                };
        });

        function leadsCheck() {
            $('#leads-id').val('0');
        }

    </script>
</body>

</html>
