<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $title; ?>
    </title>

    <!-- Meta -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.tables.min.css" />

    <script src="<?= BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>

    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>

    <script>
        $(window).load(function () {
            $('#loading').remove();
            $('#dataTable').css('visibility', 'visible');
        });
    </script>
</head>

<body>

    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>
    <div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
        <?php
			include "application/views/menu_top.php";
			?>
    </div>

    <div id="menu" class="hidden-print hidden-xs">
        <?php
			include "application/views/menu_left.php";
			
			if (!strpos(' '.$permission->pm_faq,'1')) {
                alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');		
			}
			
			?>
    </div>


    <div id="content">

        <div class="innerAll spacing-x2" id="loading">
            <div class="widget widget-inverse">
                <div class="widget-head">
                    <h2 class="heading">loading...</h2>
                </div>
            </div>
        </div>
        <div class="innerAll spacing-x2" style="visibility: hidden;" id="dataTable">


            <!-- Widget -->
            <div class="widget widget-inverse">
                <div class="widget-head">
                    <h4 class="heading">FAQ Adding</h4>
                </div>
                <div class="widget-body padding-bottom-none">
                    <div class="row">
                        <button id="add">+</button>
                        <label id="countLabel"> 1 </label>
                        <button id="remove">-</button>
                    </div>
                    <br/>
                    <form method="post" action="<?= BASE_DOMAIN ?>FAQ/record">
                        <?php $qa = '';
                        $qa = '<div class="row list">';
                        $qa .=   '<div class="form-group">';
                        $qa .=        '<div class="col-xl-6">';
                        $qa .=            '<label class="col-md-1"><button type="button" class="remove" onclick="RemoveRow(this.value)">-</button></label>';
                        $qa .=            '<label for="question" class="col-md-1 number"> Question</label>';
                        $qa .=            '<div class="col-md-6">';
                        $qa .=                '<input class="form-control question" name="question[]" id="question" />';
                        $qa .=           '</div>';
                        $qa .=       '</div>';
                        $qa .=       '<div class="col-xl-6">';
                        $qa .=           '<label for="answer" class="col-md-1">Answer</label>';
                        $qa .=           '<div class="col-md-6">';
                        $qa .=                '<textarea class="form-control answer" name="answer[]" id="answer" cols="50"></textarea>';
                        $qa .=            '</div>';
                        $qa .=       '</div>';
                        $qa .=    '</div>';
                        $qa .= '</div>';
                    ?>
                        <div id="list"></div>
                        
                        <br/>
                        <div class="row center">
                            <button class="btn btn-primary" type="submit"><i class="glyphicon glyphicon-ok"></i> Submit</button>
                            <button class="btn" type="button"><i class="glyphicon glyphicon-remove"></i> Cancel</button>
                        </div>
                        <br/>
                    </form>
                </div>
            </div>
            <!-- // Widget END -->



        </div>
    </div>
    <!-- // Content END -->

    <div class="clearfix"></div>
    <!-- // Sidebar menu & content wrapper END -->

    <div id="footer" class="hidden-print"></div>
    <!-- // Footer END -->


    <!-- // Main Container Fluid END -->




    <!-- Global -->
    <script>
        var basePath = '',
            commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
            rootPath = '<?php echo BASE_DOMAIN; ?>',
            DEV = false,
            componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

        var primaryColor = '#cb4040',
            dangerColor = '#b55151',
            infoColor = '#466baf',
            successColor = '#8baf46',
            warningColor = '#ab7a4b',
            inverseColor = '#45484d';

        var themerPrimaryColor = primaryColor;
    </script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
    <script>
        var count = 0;
        $(document).ready(function() {
            <?php if(empty($list)): ?>
            $('#add').click();
            <?php else: foreach($list as $row): ?>
            $('#countLabel').html(' '+(++count)+' ');
            $('#list').append('<?= $qa ?>');
            $('.number:eq('+(count-1)+')').html(count+'.Question');
            $('.remove:eq('+(count-1)+')').val(count);
            $('.question:eq('+(count-1)+')').val('<?= $row->fq_question ?>');
            $('.answer:eq('+(count-1)+')').val('<?= str_replace(array("\r\n", "\r", "\n"), '\n', $row->fq_answer) ?>');
            <?php endforeach; endif; ?>
        });
        
        $('#add').click(function() {
            $('#countLabel').html(' '+(++count)+' ');
            $('#list').append('<?= $qa ?>');
            $('.number:eq('+(count-1)+')').html(count+'.Question');
            $('.remove:eq('+(count-1)+')').val(count);
        });
        
        $('#remove').click(function() {
            if(count > 1) {
                $('#countLabel').html(' '+(--count)+' ');
                $('.list:eq('+($('.list').length - 1)+')').remove();
            }
        });
        
        function RemoveRow(val) {
            if(count > 1) {
                $('.list:eq('+(parseInt(val))+')').remove();
                $('#countLabel').html(' '+(--count)+' ');
                
                $('.list').each(function(index, value) {
                    $('.number:eq('+(index)+')').html((index+1)+'.Question');
                    $('.remove:eq('+(index)+')').val(index+1);
                });
            }
        }
    </script>
</body>

</html>