<?php
$count = count($list_defect);
$waiting = 0;
$complete = 0;
foreach ($list_defect as $defect) {

  if($defect->complete_status == "1"){
    $complete++;
  }else{
    $waiting++;
  }
}
$email .= 'N/A';
// $html .= '<div style="margin:30px;">';
$html .= '<htmlpageheader name="header">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="50%" height="77" align="left"><img src="'.$project_img_path.'" width="70" /></td>
                  <td width="50%" align="right"><div class="info">Tel : '.$project->pj_quotation_tel.'<br />
                  Email : '.$email.'</div></td>
                </tr>
                </table><div><hr></div>
            </htmlpageheader>
            <sethtmlpageheader name="header" value="on" />
          ';

$html.= '<table width="100%" border="0" cellpadding="0" cellspacing="0" style="padding-top:-60;">
  <tr>
    <td width="50%" align="left"><img src="'.$project_img_path.'" width="150" /></td>
    <td width="50%" align="right">
    <table width="10px" border="0">
        <tr>
            <td width="250px">&nbsp;
            </td>
            <td width="20px" align="right">
                <div class="info"><span>
                  '.$project->pj_owner_address.'</span><br>
                <span>Telephone: '.$project->pj_quotation_tel.'<br />
                Email: '.$email.'</span></div>
            </td>
        </tr>
    </table>


    </td>
  </tr>

  <tr>
    <td height="82" colspan="2" align="center"><div class="big"><hr><b>แบบฟอร์มการแจ้งซ่อมห้องพัก<br />
      โครงการ '.$pj_name.'</b></div></td>
  </tr>
  <tr>
    <td valign="top"><table width="100%" border="0">
      <tr>
        <td height="42" colspan="2" align="left"><b>ข้อมูลลูกค้า / Customer\'s Detail</b></td>
        </tr>

      <tr>
        <td width="22%"><strong>Building :</strong></td>
        <td width="78%">'.$defectRoom->building_name.'</td>
      </tr>
      <tr>
        <td><strong>Room :</strong></td>
        <td>'.$defectRoom->un_name.'</td>
      </tr>
      <tr>
        <td><strong>Name :</strong></td>
        <td>'.$user->name.'</td>
      </tr>
      <tr>
        <td><strong>Email :</strong></td>
        <td>'.$user->email.'</td>
      </tr>
      <tr>
        <td><strong>Phone No :</strong></td>
        <td>'.$user->phone.'</td>
      </tr>
      <tr>
        <td><strong>Room Type : </strong></td>
        <td>'.$roomInfo->room_type_info.'</td>
      </tr>
      <tr>
        <td><strong>Unit Type : </strong></td>
        <td>'.$roomInfo->unit_type_name.'</td>
      </tr>
      <tr>
        <td><strong>Check Date :</strong></td>
        <td>'.$defectInfo->date.'</td>
      </tr>
      <tr>
        <td><strong>Defect No :</strong></td>
        <td>'.$defectInfo->df_no.'</td>
      </tr>
      <tr>
        <td><strong>QC Checker : </strong></td>
        <td>'.$qcCheckerInfo->user_pers_fname." ".$qcCheckerInfo->user_pers_lname.'</td>
      </tr>
      <tr>
        <td><strong>CS : </strong></td>
        <td>'.$csInfo->user_pers_fname." ".$csInfo->user_pers_lname.'</td>
      </tr>
    </table></td>
    <td align="center" valign="middle"><img src="'.$unit_type_img_path.'" alt="" width="450"  /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr height="1">
    <td height="1" colspan="2" ><hr></td>
  </tr>

  <tr>
    <td height="18" colspan="2"><b>รายการสิ่งที่ต้องแก้ไข / Defect details</b></td>
  </tr>
  <tr>
    <td height="18" colspan="2">
    <table style="border-collapse: collapse; border: 1px solid #999999;">
    <tr>
      <td style="border: 1px solid #999999;" align="center" valign="middle">รายการสิ่งที่ต้องแก้ไขทั้งหมด</td>
      <td style="border: 1px solid #999999;" align="center" valign="middle">ตรวจสอบเรียบร้อยแล้ว</td>
      <td style="border: 1px solid #999999;" align="center" valign="middle">รอการตรวจสอบ</td>
    </tr>
    <tr>
      <td style="border: 1px solid #999999;" align="center" valign="middle">'.$count.'</td>
      <td style="border: 1px solid #999999;" align="center" valign="middle">'.$complete.'</td>
      <td style="border: 1px solid #999999;" align="center" valign="middle">'.$waiting.' </td>
    </tr>
    </table>

    </td>
  </tr>
  <tr>
    <td height="18" colspan="2" valign="top">&nbsp;</td>
  </tr>
</table>
';

if ($count > 0) {
  $html .= '<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #999999;">
      <tr style="border: 1px solid #999999;" >
        <td style="border: 1px solid #999999;" width="12%" align="center" valign="middle"><strong>ลำดับ</strong></td>
        <td style="border: 1px solid #999999;" width="30%" align="center" valign="middle"><strong>รูปภาพ</strong></td>
        <td style="border: 1px solid #999999;" width="40%" align="center" valign="middle"><strong>รายละเอียด</strong></td>
        <td style="border: 1px solid #999999;" width="18%" align="center" valign="middle"><strong>การประเมิน</strong></td>
      </tr>';
  $i = 0;

  foreach ($list_defect as $defect) {

    $icon_status = "รอตรวจสอบ";
    if($defect->complete_status == "1"){
      $icon_status = "<font color=green>เรียบร้อย</font>";
    }

    $i++;
    $html .= '
      <tr style="border: 1px solid #999999;"  >
        <td style="border: 1px solid #999999;" height="150"   align="center" valign="middle">'.$i.'/'.$count.'</td>
        <td style="border: 1px solid #999999;" height="150"   align="center" valign="middle"><img src="../Service/images/'.$pj_db.'/'.$un_id.'/'.$defect->df_image_path.'.jpg" alt="" width="180" /></td>
        <td style="border: 1px solid #999999;" style="height:auto;"  align="left" valign="middle">

        <div class="small"><font color="#000000"><b>&nbsp;&nbsp;ประเภทห้อง / พื้นที่</b></font></div>
        <div>&nbsp;&nbsp;'.$defect->df_category.'</div>
        <div class="small"><font color="#000000"><b>&nbsp;&nbsp;หมวดงานที่ต้องแก้ไข</b></font></div>
        <div>&nbsp;&nbsp;'.$defect->df_sub_category.'</div>
        <div class="small"><font color="#000000"><b>&nbsp;&nbsp;รายการที่ต้องแก้ไข</b></font></div>
        <div>&nbsp;&nbsp;'.$defect->df_detail.'</div>

        </td>
        <td style="border: 1px solid #999999;"  height="150"  align="center" valign="middle">'.$icon_status.'</td>
      </tr>';
  }
  $html .= '</table>';
}



$html .= '<pagebreak>';
$html .= '<p>ผู้จะซื้อยอมรับว่ารายการอื่นนอกจากรายการแก้ไขดังกล่าวข้างต้นผู้จะขายได้ดำเนินการเสร็จเรียบร้อยแล้วซึ่งผู้จะขายจะดำเนินการ แก้ไขงานดังกล่าวข้างต้นให้แล้วเสร็จพร้อมตรวจสอบความเรียบร้อยและรับมอบห้องชุดภายในวันที่<U>&nbsp;&nbsp;&nbsp;'.$date.'&nbsp;&nbsp;&nbsp;</U>โดยการแก้ไขดังกล่าวจะเป็นการแก้ไขตามมาตรฐานการก่อสร้างทั่วไปทั้งนี้ผู้จะซื้อต้องดำเนินการโอนกรรมสิทธิ์ห้องชุดภายในวันและเวลาตามที่ ระบุในหนังสือเชิญตรวจรับห้องชุดเป็นลำดับถัดไป</p>';
$html .= '<p>หากกำหนดแล้วเสร็จตามที่ผู้จะขายแจ้งให้ผู้จะซื้อทราบข้างต้นแต่ผู้จะซื้อไม่มาตรวจรับตามกำหนดให้ถือว่าผู้จะซื้อได้รับมอบห้องเรียบร้อยแล้ว <b><U>กรณีผู้จะซื้อจ้างทำงาน หรือบุคคลภายนอกมาตรวจงาน จะต้องใช้เอกสารชุดนี้ในการตรวจสอบรายการแก้ไข</U></b></p>';
$html .= '<p>ทั้งนี้<U><B>หากมีรายการแก้ไขเพิ่มเติมจากรายการข้างต้นจะดำเนินการภายหลังที่ลูกค้าโอนกรรมสิทธิ์เรียบร้อยแล้วเท่านั้น</B></U>ภายใต้เงื่อนไขการรับประกันคุณภาพ และในกรณีที่มีการโอนสิทธิตามสัญญาจะซื้อจะขาย ในส่วนของรายการงานแก้ไขห้องชุดฉบับนี้ ให้มีผลผูกพันไปถึงผู้รับโอนสิทธิตามสัญญาจะซื้อจะขายด้วย และเป็นหน้าที่ของผู้โอนสิทธิจะต้องแจ้งให้แก่ผู้รับโอนสิทธิทราบ โดยบริษัทขอสงวนสิทธิแก้ไขตามรายการดังกล่าวข้างต้น เท่านั้น</p>';
$html .= '<br><br>';
$html .= '<p>The purchaser accepts that the Seller as completed other items not specified above which are not repaired or modified futher. Ther Seller agrees to complete the above defect items within <U>&nbsp;&nbsp;&nbsp;'.$date.'&nbsp;&nbsp;&nbsp;</U>days, which will be carried out and ready for re-inspection on <U>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</U>. All dfect items will be carried out in accordance with feneral standard or construction. However, the Purchasher has tp complete the transferring ownership within the date mentioned in the Notice for the Condominium unit title transfer.</p>';
$html .= '<p>If the Purchaser cannot come for re-inspection by the appointment date, it will be considered that all defect items are automatically accepte by the Purchaser. <U><B>In case of the Purchaser hire the third party the inspect on behalf of the Purchaser, this defect list form must be used as the standard form.</B></U></p>';
$html .= '<p><U><B>If there are any other defect items in addition soecified above, they shall be arried out after the successful transfer of ownership</B></U> under warranty condition. In the event that the Purchaser transfer the right according to Sale and Purchase Agreement to the third party, this defect list form shall be effective to the third party and the Purchaser must inform the defect lists to the third party.</p>';
$html .= '<br><br><br><br><br>';


$html .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="middle">ลงชื่อผู้จะซื้อ / The Purchaser</td>
    <td align="center" valign="middle">ลงชื่อผู้จะขาย / The Seller</td>
  </tr>
  <tr>
    <td height="40" align="center" valign="middle">&nbsp;</td>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="middle">________________________________</td>
    <td align="center" valign="middle">________________________________</td>
  </tr>
  <tr>
    <td align="center" valign="middle">(_______________________)</td>
    <td align="center" valign="middle">(_______________________)</td>
  </tr>
  <tr>
    <td align="center" valign="middle">___/___/___</td>
    <td align="center" valign="middle">___/___/___</td>
  </tr>
</table>';

// $html = '</div>';
?>

<?php
	include("application/third_party/MPDF/mpdf.php");
	$nameFile = $df_room_id.".pdf";
	// $mpdf=new mPDF('UTF-8');
  $mpdf = new mPDF('utf-8','A4','','','25','15','30','18');
	$mpdf->SetAutoFont();
	$mpdf->SetDisplayMode('fullpage');




  //$mpdf->SetHTMLHeader($headerHtml,"ALL",TRUE);

  $mpdf->SetHTMLFooter('<div style="text-align: right; font-family: Arial, Helvetica,
  sans-serif; font-weight: bold;font-size: 7pt; ">{PAGENO} of {nb}</div><br> ');


	// LOAD a stylesheet
	$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4__defect_doc.css');
	$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

	$mpdf->WriteHTML($html);
	$mpdf->Output($nameFile,'I');
	exit;
?>
