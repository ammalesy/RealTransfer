
	
		<div id="menu" class="hidden-print hidden-xs">
			<?php
			if ($permission->pm_assign < 1) {
					alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			?>
		</div>


	<div class="setting_assign">
		
<div class="innerAll spacing-x2">
<!--
		<div class="widget-head">
			<h4 class="heading">View Assign user to project </h4>
		</div>
-->
		<div class="content-header">
           <a href="<?php echo BASE_URL; ?>" class="back-head"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <font color="#78ad13">View Assign user to project</font>
            <label class="table-total">...</label>
        </div><br/><br/>
		<?php 
        if (strpos($permission->pm_assign,'1') !== false) {
        ?>
			<!-- Table -->
<!--
			<a href="<?php echo BASE_URL; ?>/assign/adding">
			<button class="btn btn-inverse"><i class="fa fa-user"></i> New </button>
			</a>
			<br/><br/>
-->
           <div class="content-add">
                <a href="<?php echo BASE_URL; ?>/assign/adding" class="btn-floating btn-medium waves-effect waves-light red"><i class="material-icons">add</i></a>
            </div>
        <? } ?>
<table class="dynamicTable colVis table">

	<!-- Table heading -->
	<thead class="bg-gray">
		<tr>
			
			<th>User</th>
			<th>Project</th>
			<th>Action</th>
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody>
		<!-- Table row -->
		
			<?php
				foreach($assign_project as $aAssign):
					?>
					<tr>
						<td ><?php echo $aAssign->user_pers_fname." ".$aAssign->user_pers_lname; ?> </td>
						<td ><?php echo $aAssign->pj_name; ?> </td>
					
						<td class="center">
							<div class="btn-group btn-group-xs ">
                            <?php 
                            if (strpos($permission->pm_assign,'2') !== false) {
                            ?>
<!--								<a href="<?php echo BASE_URL; ?>/assign/editing/<?php echo $aAssign->assign_id; ?>" ><?php echo image_asset('image/Edit.gif',NULL,array('title'=>'Edit')); ?></a>-->
                                <a href="<?php echo BASE_URL; ?>/assign/editing/<?php echo $aAssign->assign_id; ?>"><i class="material-icons icon-hover">settings</i></a>
				            <?php 
                            }
                            if (strpos($permission->pm_assign,'4') !== false) {
                            ?>
<!--								<a href="<?php echo BASE_URL; ?>/assign/deleting/<?php echo $aAssign->assign_id; ?>" onclick="return confirm('Cancel Assign User ?')"><?php echo image_asset('image/delete.gif',NULL,array('title'=>'Delete')); ?></a>-->
                        <a href="<?php echo BASE_URL; ?>/assign/deleting/<?php echo $aAssign->assign_id; ?>" onclick="return confirm('Cancel Assign User ?')"><i class="material-icons icon-hover">delete</i></a>
	                        <? } ?>
							</div>
						</td>
					</tr>
				<?php endforeach; ?>
			
		<!-- // Table row END -->
	</tbody>
	<!-- // Table body END -->
	
</table>
<!-- // Table END -->


		</div>
	</div>
	<!-- // Widget END -->
		
		<div class="clearfix"></div>
	

	

	