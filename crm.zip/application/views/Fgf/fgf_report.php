<?php
$html = '
<style>

.text{
	line-height: 180%;
	text-align:justify;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
    position:fixed;
    bottom:0;
}
.border{
    border-bottom: 1px solid black !important;
}

</style>


<table border="0" width="762">
    <tr>
        <td align="center" width="762"><font size="6"><b>แบบฟอร์มแจ้งความจำนงค์แนะนำลูกค้า</b></font></td>
    </tr>
    <tr>
        <td align="center" width="762"><font size="6"><b>'.$pj_name.'</b></font></td>
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td align="left" width="30"><font size="5">วันที่ </font></td>
        <td align="left" width="200" class="border"><font size="5">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($issueDate))).'</font></></td>
        <td align="left" width="532"></td>
    </tr>
</table>
<br>
<pre><b><span class="under">ข้อมูลผู้แนะนำ</span></b></pre>

<table border="0" width="762">
    <tr>
        <td width="100"><span class="under">โปรดระบุ</span></td>
        <td width="50"><input type="checkbox" checked="checked"> ยูนิต</td>
        <td class="border" align="center" width="50">'.$unitName1.'</td>
        <td width="562"></td>
    </tr>
</table>

<table border="0" width="762">
    <tr>
        <td width="30">ชื่อ</td>
        <td class="border"  width="300">'.$fnameCus1.'</td>
        <td width="60">นามสกุล</td>
        <td class="border" width="372">'.$lnameCus1.'</td>
        
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td width="100">โทรศัพท์ (มือถือ)</td>
        <td class="border" width="281">'.$mobile1.'</td>
        <td width="100">โทรศัพท์ (อื่นๆ)</td>
        <td class="border" width="281">'.$tel1.'</td>
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td width="50">อีเมล</td>
        <td class="border" width="712">'.$email1.'</td>
    </tr>
    <tr>
        <td width="50">ที่อยู่</td>
        <td class="border" width="712">'.$address.'</td>
    </tr>
</table>
<br>
<pre><b><span class="under">ขอแนะนำลูกค้าให้แก่บริษัทฯ ดังนี้</span></b></pre>

<table border="0" width="762">
    <tr>
        <td width="60">ชื่อลูกค้า</td>
        <td class="border" width="321">'.$fnameCus2.'</td>
        <td width="60">นามสกุล</td>
        <td class="border" width="321">'.$lnameCus2.'</td>
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td width="110">หมายเลขโทรศัพท์</td>
        <td class="border" width="306">'.$mobile2.'</td>
        <td width="40">อีเมล</td>
        <td class="border" width="306">'.$email2.'</td>
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td width="82">พนักงานขาย</td>
        <td class="border" width="680">'.$saleFullname.'</td>
    </tr>
</table>
<br>
<br>
<table border="0" width="762">
    <tr>
        <td align="center">ลงชื่อ ____________________________ ผู้แนะนำ</td>
        <td align="center">ลงชื่อ ____________________________ พนักงานขาย</td>   
    </tr>
    <tr>
        <td align="center">(<span class="under"> '.$fnameCus1.' '.$lnameCus1.' </span>)</td>
        <td align="center">(<span class="under"> '.$saleFullname.' </span>)</td>
    </tr>
    <tr>
        <td align="center">วันที่ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($issueDate))).'</span></td>
        <td align="center">วันที่ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($issueDate))).'</span></td>
    </tr>
</table>
<br>
<table border="0" width="762">
    <tr>
        <td width="50">อนุมัติโดย</td>
        <td class="border" width="431">'.$approverFullname.'</td>
        <td width="50">ตำแหน่ง</td>
        <td class="border" width="231">'.$posApprover.'</td>
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td width="40">วันที่</td>
        <td class="border" width="222">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($dateApprove))).'</td>
        <td width="500"></td>
    </tr>
</table>

<hr width="100%" color="black">
<br>
<pre><b><span class="under">ส่วนของเจ้าหน้าที่บริษัทฯ</span></b></pre>
<table border="0" width="762">
    <tr>
        <td width="82">ยูนิตเลขที่</td>
        <td class="border" width="140">'.$unitName1.'</td>
        <td width="50">แบบห้อง</td>
        <td class="border" width="140">'.$unitTypeName1.'</td>
        <td width="350"></td>
    </tr>
</table>
<table border="0" width="762">
    <tr>
        <td width="200"><input type="checkbox" '.$cb1.'> 1 ห้องนอน ราคาห้องชุด </td>
        <td class="border" width="250" align="right">'.number_format($asking_price,2).'&nbsp;</td>
        <td width="31">บาท</td>
        <td width="50">ได้รับค่าแนะนำ</td>
        <td class="border" width="200" align="right">'.number_format($discount1,2).'&nbsp;</td>
        <td width="31">บาท</td>
    </tr>
    <tr>
        <td><input type="checkbox" '.$cb2.'> 2 ห้องนอน ราคาห้องชุด </td>
        <td class="border"></td>
        <td>บาท</td>
        <td>ได้รับค่าแนะนำ</td>
        <td class="border" align="right">'.number_format($discount2,2).'&nbsp;</td>
        <td>บาท</td>
    </tr>
    <tr>
        <td><input type="checkbox" '.$cb3.'> Penthouse / Duplex ราคาห้องชุด </td>
        <td class="border"></td>
        <td>บาท</td>
        <td>ได้รับค่าแนะนำ</td>
        <td class="border" align="right">'.number_format($discount3,2).'&nbsp;</td>
        <td>บาท</td>
    </tr>
</table>
<br>
<pre><b>ตรวจสอบแล้ว เอกสารถูกต้องครบถ้วน</b></pre>
<br>
<table border="0" width="762">
    <tr>
        <td class="border" width="330"></td>
        <td width="100">ผู้ตรวจสอบ</td>
        <td width="31">ฝ่าย</td>
        <td class="border" width="125"></td>
        <td width="20"></td>
        <td width="31">วันที่</td>
        <td class="border" width="125"></td>
    </tr>
</table>
<pagebreak>
<br>
<br>
<br>

<table border="0" width="762">
    <tr>
        <td align="center" width="762"><font size="6"><b>เงื่อนไขและข้อกำหนดการแนะนำลูกค้า ผู้แนะนำต้องปฏิบัติดังนี้</b></font></td>
    </tr>
</table>
<br>
<pre>
1. กรอกแบบฟอร์มฯ แนะนำลูกค้าให้ชัดเจนครบถ้วน และส่งกลับมาที่บริษัทฯ เพื่อยืนยันสิทธิการแนะนำ โดยวิธีหนึ่งวิธีใด ดังนี้ e-mail ถึง ______________________________________

2. ส่งแบบฟอร์มฯ ตามข้อ 1. ได้<b>ตั้งแต่วันนี้ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($issueDate))).'</span> สิ้นสุดวันที่ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($lastDate))).'</span></b>

<b>*3. ลูกค้าที่ท่านแนะนำจะต้องทำการจองซื้อ พร้อมชำระเงินให้ครบถ้วน ก่อนวันที่ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($lastDate))).'</span> เท่านั้น</b>

<b>*4. หากลูกค้าที่ท่านแนะนำได้ทำการจองซื้อแล้ว ก่อนที่บริษัทฯ จะได้รับแบบฟอรมฯ ตามข้อ 1. ท่านไม่มีสิทธิได้รับค่าแนะนำ ไม่ว่ากรณีใดๆ ทั้งสิ้น</b>

5. กรณีแนะนำชื่อลูกค้ารายเดียวกัน บริษัทฯ ขอสงวนสิทธิ์มอบค่าแนะนำให้แก่ผู้แนะนำที่ส่งแบบฟอร์มฯ ที่ถูกต้องครบถ้วนให้บริษัทฯ เป็นรายแรก โดยพิจารณาจากวันที่เจ้าหน้าที่บริษัทฯ ได้ตรวจสอบและรับเอกสารไว้โดยถูกต้องเรียบร้อยแล้ว

6. สำหรับโครงการใหม่ผู้แนะนำจะได้รับค่าแนะนำ ภายใน 45 วัน นับถัดจากวันที่ลูกค้าได้ทำสัญญาจะซื้อจะขายกับบริษัทฯ และชำระเงินค่าสัญญาเรียบร้อยแล้ว

7. ผู้แนะนำต้องจ่ายภาษีตามที่กฏหมายกำหนด (ยินยอมให้บริษัทฯ หักภาษี ณ ที่จ่าย 3% ของจำนวนเงินค่าแนะนำที่ได้รับ)

8. บริษัทฯ ขอสงวนสิทธิ์ในการยกเลิกหรือเปลี่ยนแปลงเงื่อนไขใดๆ โดยไม่ต้องแจ้งให้ทราบล่วงหน้า

9. กรณีมีข้อโต้แย้งใดๆ ให้ถือคำตัดสินของบริษัทฯ เป็นเด็ดขาดและที่สุด

<b><span class="under">สอบถามข้อมูลเพิ่มเติม</span></b>
</pre>
<br>
<table border="0" width="762">
    <tr>
        <td width="12">1.</td>
        <td width="25">คุณ</td>
        <td class="border" width="223"></td>
        <td width="25">โทร</td>
        <td class="border" width="223"></td>
        <td width="30">email</td>
        <td class="border" width="223"></td>
    </tr>
    <tr>
        <td><br></td>
    </tr>
    <tr>
        <td>2.</td>
        <td>คุณ</td>
        <td class="border"></td>
        <td>โทร</td>
        <td class="border"></td>
        <td>email</td>
        <td class="border"></td>
    </tr>
</table>


';
?>

<?php

include("application/third_party/MPDF/mpdf.php");

$nameFile = "test.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);
$mpdf->Output($nameFile,'I');


exit;


?>
