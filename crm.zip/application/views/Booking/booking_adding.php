<!--booking-->
        <script type="text/javascript">
            $(function() {
                $('#trCash').hide();
                $('#trGift').hide();
                $('#trFur').hide();
                $('#trCredit').hide();
                $.ajax({

                    url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
                    data: ({
                        nextList: 'Project',
                        Project: $('#Project').val(),
                        project_database_sel: '<?php echo $project_database_sel; ?>'
                    }),
                    dataType: "json",

                    success: function(json) {
                        $('#trLoad').hide();
                        var tbWidth = 400;
                        var Cash = 0;
                        var Gift = 0;
                        var Furniture = 0;
                        var Credit = 0;
                        var trCashID = 1;
                        var trGiftID = 1;
                        var trFurID = 1;
                        var trCreditID = 1;
                        var arr = [<?=$promotion?>];
                        $.each(json, function() {
                            var check = false;
                            var id = parseInt(this.pm_id);
                            $.each(arr, function(index, value) {
                                if (value == id) {
                                    check = true;
                                    return false;
                                }
                            });
                            if (this.pm_type == 'Cash') {
                                if (Cash++ == 0)
                                    $('#trCash').show();
                                if (Cash % 3 == 1)
                                    $("#tbCash").append('<tr id="tdCash' + trCashID + '">');
                                $('#tdCash' + trCashID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_name).prepend(
                                    $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                                if (Cash % 3 == 0) {
                                    $('#tdCash' + trCashID).append('</tr>');
                                    trCashID++;
                                }
                            } else if (this.pm_type == 'Gift') {
                                if (Gift++ == 0)
                                    $('#trGift').show();
                                if (Gift % 3 == 1)
                                    $("#tbGift").append('<tr id="tdGift' + trGiftID + '">');
                                $('#tdGift' + trGiftID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_name).prepend(
                                    $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                                if (Gift % 3 == 0) {
                                    $('#tdGift' + trGiftID).append('</tr>');
                                    trGiftID++;
                                }
                            } else if (this.pm_type == 'Furniture') {
                                if (Furniture++ == 0)
                                    $('#trFur').show();
                                if (Furniture % 3 == 1)
                                    $("#tbFur").append('<tr id="tbFur' + trFurID + '">');
                                $('#tbFur' + trFurID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_name).prepend(
                                    $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                                if (Furniture % 3 == 0) {
                                    $('#tbFur' + trFurID).append('</tr>');
                                    trFurID++;
                                }
                            } else if (this.pm_type == 'Credit') {
                                if (Credit++ == 0)
                                    $('#trCredit').show();
                                if (Credit % 3 == 1)
                                    $("#tbCredit").append('<tr id="tbCredit' + trCreditID + '">');
                                $('#tbCredit' + trCreditID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_detail).prepend(
                                    $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                                if (Credit % 3 == 0) {
                                    $('#tbCredit' + trCreditID).append('</tr>');
                                    trCreditID++;
                                }
                            }
                        });
                        if (Cash % 3 > 0) {
                            var td = 3 - (Cash % 3);
                            $('#tdCash' + trCashID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                        }
                        if (Gift % 3 > 0) {
                            var td = 3 - (Gift % 3);
                            $('#tdGift' + trGiftID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                        }
                        if (Furniture % 3 > 0) {
                            var td = 3 - (Furniture % 3);
                            $('#tbFur' + trFurID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                        }
                        if (Credit % 3 > 0) {
                            var td = 3 - (Credit % 3);
                            $('#tbCredit' + trCreditID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                        }
                        if (Credit + Gift + Furniture + Cash == 0) {
                            $('#trLoad').show();
                            $('#logPromotion').val('None');
                        }
                    }
                });
            });


            function leadsCheck() {
                $('#leads-id').val('0');
            }

        </script>
        <script type="text/javascript">
            function paidByDis() {
                var chk = $('input:radio[name=Type]:checked').val();
                if (chk == "Cash") {
                    //$('#CashAmount').val($('#unitreserv').val());

                    $('#cardBank').val("");
                    $('#cardno').val("");
                    $('#cardDate').val("");
                    //$('#cardAmountCrCard').val("");

                    //$('#OtherAmount').val("");
                    $('#OtherBy').val("");

                    //$('#CashAmount').prop('disabled', true);

                    $('#cardBank').prop('disabled', true);
                    $('#cardno').prop('disabled', true);
                    $('#cardDate').prop('disabled', true);
                    //  $('#cardAmountCrCard').prop('disabled', true);

                    //  $('#OtherAmount').prop('disabled', true);
                    $('#OtherBy').prop('disabled', true);

                    //  $('#CashAmount').prop('required', true);

                    $('#cardBank').prop('required', false);
                    $('#cardno').prop('required', false);
                    $('#cardDate').prop('required', false);
                    //  $('#cardAmountCrCard').prop('required', false);
                    //  $('#OtherAmount').prop('required', false);
                    $('#OtherBy').prop('required', false);



                } else if (chk == "CrCard") {

                    //  $('#CashAmount').val("");

                    $('#cardBank').val("");
                    $('#cardno').val("");
                    $('#cardDate').val("");
                    //  $('#cardAmountCrCard').val($('#unitreserv').val());
                    //  $('#OtherAmount').val("");
                    $('#OtherBy').val("");

                    //  $('#CashAmount').prop('disabled', true);

                    $('#cardBank').prop('disabled', false);
                    $('#cardno').prop('disabled', false);
                    $('#cardDate').prop('disabled', false);
                    //  $('#cardAmountCrCard').prop('disabled', true);

                    //  $('#OtherAmount').prop('disabled', true);
                    $('#OtherBy').prop('disabled', true);

                    //  $('#CashAmount').prop('required', false);

                    $('#cardBank').prop('required', true);
                    $('#cardno').prop('required', true);
                    $('#cardDate').prop('required', true);
                    //  $('#cardAmountCrCard').prop('required', true);

                    //  $('#OtherAmount').prop('required', false);
                    $('#OtherBy').prop('required', false);

                } else if (chk == "Other") {

                    //  $('#CashAmount').val("");

                    $('#cardBank').val("");
                    $('#cardno').val("");
                    $('#cardDate').val("");
                    //  $('#cardAmountCrCard').val("");
                    //  $('#OtherAmount').val($('#unitreserv').val());

                    $('#OtherBy').val("");

                    //  $('#CashAmount').prop('disabled', true);

                    $('#cardBank').prop('disabled', true);
                    $('#cardno').prop('disabled', true);
                    $('#cardDate').prop('disabled', true);
                    //  $('#cardAmountCrCard').prop('disabled', true);

                    // $('#OtherAmount').prop('disabled', true);
                    $('#OtherBy').prop('disabled', false);

                    //  $('#CashAmount').prop('required', false);

                    $('#cardBank').prop('required', false);
                    $('#cardno').prop('required', false);
                    $('#cardDate').prop('required', false);
                    //  $('#cardAmountCrCard').prop('required', false);

                    //  $('#OtherAmount').prop('required', true);
                    $('#OtherBy').prop('required', true);
                }

            }

            function leadsCheck() {
                $('#cus-id').val('0');
            }

        </script>
        <style>
            #cus-label {
                display: block;
                font-weight: bold;
                margin-bottom: 1em;
            }
            
            #cus-icon {
                float: left;
                height: 32px;
                width: 32px;
            }

        </style>
<?php
	if ($Balloon==0) {
		$InstallmentDetail = '
			<font size="2">Installment Fee : Down Payment '.$TotalDownMonth .' months (ผ่อนดาวน์  '.$TotalDownMonth .' เดือน) </font>
    		</td>
       		<td><br><font size="2">'.number_format($InstallmentFee ,2).' Baht</font></td></tr>
      		<tr>
		    	<td colspan="2"><font size="2">Total Installment Fee  </font></td>
		    	<td><font size="2">'.number_format($TotalInstallmentFee ,2).' Baht</font></td>
		  	</tr>
		  	<tr>
		    	<td colspan="2"><font size="2">Total of Down Payment </font></td>
		    	<td ><font size="2">'.number_format($TotalDownPayment,2).' Baht</font></td>
		  	</tr>';
	} else {
		$InstallmentDetail = '
	
	  	<font size="2">Installment Fee : Down Payment '.$NormalMonth .' months (ผ่อนดาวน์  '.$NormalMonth .' เดือน) </font></td>
	    	<td ><font size="2">'.number_format($InstallmentFee ,2).' Baht</font></td>
	  	</tr>
	  	<tr>
	    	<td colspan="2"><font size="2">Installment Fee : Balloon Payment '.$BalloonMonth .' months (ผ่อนดาวน์  '.$BalloonMonth .' เดือน เดือนที่ '.$BalloonMonthText .') </font></td>
	    	<td ><font size="2">'.number_format($BalloonFee ,2).' Baht</font></td>
	  	</tr>
	  	<tr>
	    	<td colspan="2"><font size="2">Total Installment Fee  </font></td>
	    	<td ><font size="2">'.number_format($TotalInstallmentFee ,2).' Baht</font></td>
	  	</tr>
  	
		<tr>
	    	<td ><font size="2">Total of Down Payment </font></td>
             <td></td>
	    	<td ><font size="2">'.number_format($TotalDownPayment,2).' Baht</font></td>
	  	</tr>';
	}
?>
<div class="booking-form">
	<div class="content">
		<div class="content-header">
            <a href="<?php echo BASE_URL; ?>/quotation/view" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <span class="title-header">Booking</span>
        </div>
		<form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off" action="<?php echo BASE_URL; ?>/booking/record/<?php echo $quoCode; ?>">
			<div class="quotation-detail">
				<div class="row">
					<div class="col l4 title-info">Quatation Detail</div>
					<?php
						$comma = '';
						$allCus = '';
						foreach($list_leads as $row):
							$allCus .= $comma.'{value: "'.$row->cus_id.'",label: "'.$row->fullname.'"}';
							if($comma==='') $comma = ',';
						endforeach;
						$allCus = '['. $allCus . ']';
					?>
					<input type="hidden" name='cusid' id="cus-id" value="<?php echo $leads; ?>" />
                	<div class="col l8 form-info">
                		<div class="input-field name-1">
                            <input id="user_fullname" type="text" class="validate" value="<?php echo $leadsname; ?>">
                            <label for="user_fullname">Customer Name #1*</label>
                        </div>
                        <div class="input-field name-2">
                            <input id="last_name" type="text" class="validate" disabled>
                            <label for="name">Customer Name #2</label>
                        </div>
                        <div class="input-field name-3">
                            <input id="last_name" type="text" class="validate" disabled>
                            <label for="name">Customer Name #3</label>
                        </div>
                        <div class="input-field name-4">
                            <input id="last_name" type="text" class="validate" disabled>
                            <label for="name">Customer Name #4</label>
                        </div>
                        <div class="quotation-number show-detail">
                            Quotation Number : <span class="query-result"><?php echo $quoCode; ?></span>
                        </div>
                        <div class="pay-date show-detail waves-light btn btn-paydate">
                            <label class="pay-date-title">Payment Date : </label>
                            <div class="input-field">
							    <select class="browser-default" name="payDay">
							    <?php for($i=1;$i<31;$i++): ?>
								    <option value="<?=$i?>" <?=$i==15?'selected':''?>><?=strlen($i)<2?'0'.$i:$i?></option>
							    <?php endfor; ?>
							    </select>
							</div>
                        </div>
                        <div class="unit-number show-detail">
                            Unit Number : <span class="query-result"><?php echo $un_name; ?></span>
                        </div>
                        <div class="direction show-detail">
                            Direction : <span class="query-result"><?php echo $un_direction; ?></span>
                        </div>
                        <div class="building show-detail">
                            Building : <span class="query-result"><?php echo $building_name; ?></span>
                        </div>
                        <div class="area show-detail">
                            Area : <span class="query-result"><?php echo $unit_type_area_sqm; ?></span>
                        </div>
                        <div class="unit-type show-detail">
                            Unit Type : <span class="query-result"><?php echo $unit_type_name; ?></span>
                        </div>
                        <div class="price-per-sqm show-detail">
                            Price per sq.m. : <span class="query-result"><?php echo $pr_selling_sqm. ' Baht'; ?></span>
                        </div>
                        <div class="room-type show-detail">
                            Room Type : <span class="query-result"><?php echo $room_type_name; ?></span>
                        </div>
                        <div class="total-unit-price show-detail">
                            Total Unit Price : <span class="query-result"><?php echo number_format(floatval(str_replace(',', '', str_replace('.', '', $pr_asking_price))),2).' 	Baht'; ?></span>
                        </div>
                	</div>
				</div>
				<div class="row promotion-detail">
					<div class="col l4 title-info">Promotion</div>
					<div class="col l8 form-info">
						<div class="promotion">
                            Current Promotion : 
                            <ul>
                            <?php foreach ($getPromotion as $value): ?>
                            	<li><?= $value->pm_name ?></li>
                            <?php endforeach; ?>
                            </ul>
                        </div>
                        <a class="waves-effect waves-light btn btn-add" onclick="promotion()">Add / Remove Promotion</a>
					</div>
				</div>


                

				<div class="promotion-edit" style="display: none">
                	<div class="promotion-title">Promotion</div>
              		<div class="giftHide">
	                	<div class="promotion-title text-center">Gift</div>
	                	<div class="row" id="gift"></div>
                	</div>
              		<div class="cashHide">
                    	<div class="cash-title text-center">Cash</div>
                    	<div class="row" id="cash"></div>
                	</div>
					<div class="furHide">
                    	<div class="furniture-title text-center">Furniture</div>
                    	<div class="row" id="fur"></div>
                	</div>
            	</div>

                
            <div class="credit-promotion" style="margin-top: 30px;">
                <div class="row">
                    <div class="col l4 title-info">Credit Promotion</div>
                    <div class="col l8 form-info">
						<?php foreach ($allCredit as $val): ?>
                        <div class="credit-detail">
                            <input class="visit" name="pro[]" type="radio" id="promotion<?= $val->pm_id ?>" value="<?= $val->pm_id ?>">
                            <label for="promotion<?= $val->pm_id ?>"><?= $val->pm_detail ?></label>
                        </div>
						<?php endforeach; ?>
                    </div>
                </div>
            </div>

			</div>
			<input type="hidden" name="projectid" value="<?php echo $Project; ?>" />
			<input type="hidden" name="buildingid" value="<?php echo $Building; ?>" />
			<input type="hidden" name="unitnumber" value="<?php echo $un_name; ?>" />
			<input type="hidden" name="unitnumberid" value="<?php echo $Number; ?>" />
			<input type="hidden" name="unitreserv"  id="unitreserv"  value="<?php echo $BookingFee; ?>" />
	        <input type="hidden" name="building" value="<?=$building?>" />
	        <?php 
	            $data['definefee'] = $BookingFee;
	            $data['allCus'] = $allCus;

	            $data['banklist'] = $banklist;
	            $data['credittypelist'] = $credittypelist;
	            $data['submit'] = 'Submit';
	            $data['cancel'] = 'quotation/view';
	            if(strpos($permission->pm_receipt,'4') !== false) {
	                $data['receipt'] = 'yes';
	                $data['receiptList'] = $receiptList;
	            }
	            $this->load->view("form_payment", $data);
	        ?>       
		</form>
		<div class="clearfix"></div>
		<!-- <div id="footer" class="hidden-print"></div> -->
	</div>
</div>

<script>
	var show = false;
	function promotion () {
		if (show) {
			$('.promotion-edit').hide();
		} else {
			$('.promotion-edit').show();
		}
		show = !show;
	}
   $(function() { 

   		$.ajax({
            url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
            data: { project_database_sel:'<?php echo $project_database_sel; ?>' },
            dataType: "json",
            success: function(json) {
                var Cash = 0;
                var Gift = 0;
                var Furniture = 0;
                var trCashID = 1;
                var trGiftID = 1;
                var trFurID = 1;
                $('.cashHide').hide();
                $('.giftHide').hide();
                $('.furHide').hide();

				var arr = [<?=$promotion?>];
                $.each(json, function() {
                	var check = '';
                    var id = parseInt(this.pm_id);
                    $.each(arr,function(index, value){
                        if(value == id) {
                            check = 'checked';
                            return;
                        }
                    });

	                if (this.pm_type == 'Cash') {
	                    if (Cash++ == 0)
	                        $('.cashHide').show();
	                    $("#cash").append('<div class="promotion-checkbox pull-left"><input type="checkbox" id="cash'+Cash+'" name="pro[]" value="'+this.pm_id+'" '+check+'/><label for="cash'+Cash+'">'+this.pm_name+'</label></div>');
	                    Cash++;
	                } else if (this.pm_type == 'Gift') {
	                    if (Gift++ == 0)
	                        $('.giftHide').show();
	                    $("#gift").append('<div class="promotion-checkbox pull-left"><input type="checkbox" id="gift'+Gift+'" name="pro[]" value="'+this.pm_id+'" '+check+'/><label for="gift'+Gift+'">'+this.pm_name+'</label></div>');
                        Gift++;
                    } else if (this.pm_type == 'Furniture') {
                        if (Furniture++ == 0)
                            $('.furHide').show();
                        $("#fur").append('<div class="promotion-checkbox pull-left"><input type="checkbox" id="fur'+Furniture+'" name="pro[]" value="'+this.pm_id+'" '+check+'/><label for="fur'+Furniture+'">'+this.pm_name+'</label></div>');
                        Furniture++;
                    }

                });
            }
        });




		var autoCompleteData = <?php echo $allCus?>;
		if(!autoCompleteData) var autoCompleteData = new Array();
		$( "#user_fullname" ).autocomplete({
			minLength: 3,
			source: autoCompleteData,
			focus: function( event, ui ) {
				$( "#user_fullname" ).val( ui.item.label );
				return false;
			},
			select: function( event, ui ) {
				$( "#user_fullname" ).val( ui.item.label );
				$( "#cus-id" ).val( ui.item.value );
				return false;
		  	}
		});
		// .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
		//   	return $( "<li>" )
		// 	.append( "<a>" + item.label + "</a>" )
		// 	.appendTo( ul );
		// };

		// $('#trCash').hide();
  //       $('#trGift').hide();
  //       $('#trFur').hide();
  //       $('#trCredit').hide();
		// $.ajax({
		// 	url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
		// 	data: ({ nextList : 'Project', Project: $('#Project').val(),project_database_sel:'<?php echo $project_database_sel; ?>' }),
		// 	dataType: "json",
		// 	success: function(json){
  //               $('#trLoad').hide();
  //               var tbWidth = 400;
  //               var Cash = 0;
  //               var Gift = 0;
  //               var Furniture = 0;
  //               var Credit = 0;
  //               var trCashID = 1;
  //               var trGiftID = 1;
  //               var trFurID = 1;
  //               var trCreditID = 1;
		// 		var arr = [<?=$promotion?>];
		// 		$.each(json, function () {
		// 			var check = false;
  //                   var id = parseInt(this.pm_id);
  //                   $.each(arr,function(index, value){
  //                       if(value == id) {
  //                           check = true;
  //                           return false;
  //                       }
  //                   });
		// 		    if  (this.pm_type=='Cash')
  //                   {
  //                       if(Cash++==0)
  //                           $('#trCash').show();
  //                       if(Cash%3==1)
  //                           $("#tbCash").append('<tr id="tdCash'+trCashID+'">');
  //                       $('#tdCash'+trCashID).append($('<td width="'+tbWidth+'">' + '<label class="labelPromotion" > '  + '</td>').text(' '+this.pm_name).prepend(
		// 		        $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check) ));
  //                       if(Cash%3==0) {
  //                           $('#tdCash'+trCashID).append('</tr>');
  //                           trCashID++;
  //                       }
  //                   }
  //                   else  if  (this.pm_type=='Gift')
  //                   {
  //                       if(Gift++==0)
  //                           $('#trGift').show();
  //                       if(Gift%3==1)
  //                           $("#tbGift").append('<tr id="tdGift'+trGiftID+'">');
  //                       $('#tdGift'+trGiftID).append($('<td width="'+tbWidth+'">' + '<label class="labelPromotion" > '  + '</td>').text(' '+this.pm_name).prepend(
		// 		        $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check) ));
  //                       if(Gift%3==0) {
  //                           $('#tdGift'+trGiftID).append('</tr>');
  //                           trGiftID++;
  //                       }
  //                   }
  //                   else  if  (this.pm_type=='Furniture')
  //                   {
  //                       if(Furniture++==0)
  //                           $('#trFur').show();
  //                       if(Furniture%3==1)
  //                           $("#tbFur").append('<tr id="tbFur'+trFurID+'">');
  //                       $('#tbFur'+trFurID).append($('<td width="'+tbWidth+'">' + '<label class="labelPromotion" > '  + '</td>').text(' '+this.pm_name).prepend(
		// 		        $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check) ));
  //                       if(Furniture%3==0) {
  //                           $('#tbFur'+trFurID).append('</tr>');
  //                           trFurID++;
  //                       }
  //                   }
  //                   else  if  (this.pm_type=='Credit')
  //                   {
  //                       if(Credit++==0)
  //                           $('#trCredit').show();
  //                       if(Credit%3==1)
  //                           $("#tbCredit").append('<tr id="tbCredit'+trCreditID+'">');
  //                       $('#tbCredit'+trCreditID).append($('<td width="'+tbWidth+'">' + '<label class="labelPromotion" > '  + '</td>').text(' '+this.pm_detail).prepend(
		// 		        $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check) ));
  //                       if(Credit%3==0) {
  //                           $('#tbCredit'+trCreditID).append('</tr>');
  //                           trCreditID++;
  //                       }
  //                   }
		// 		});
  //               if(Cash%3>0) {
  //                   var td = 3 - (Cash%3);
  //                   $('#tdCash'+trCashID).append('<td width="'+tbWidth+'" colspan="'+td+'"></td></tr>');
  //               }
  //               if(Gift%3>0) {
  //                   var td = 3 - (Gift%3);
  //                   $('#tdGift'+trGiftID).append('<td width="'+tbWidth+'" colspan="'+td+'"></td></tr>');
  //               }
  //               if(Furniture%3>0) {
  //                   var td = 3 - (Furniture%3);
  //                   $('#tbFur'+trFurID).append('<td width="'+tbWidth+'" colspan="'+td+'"></td></tr>');
  //               }
  //               if(Credit%3>0) {
  //                   var td = 3 - (Credit%3);
  //                   $('#tbCredit'+trCreditID).append('<td width="'+tbWidth+'" colspan="'+td+'"></td></tr>');
  //               }
		// 		if(Credit+Gift+Furniture+Cash == 0) {
  //                   $('#trLoad').show();
  //                   $('#logPromotion').val('None');
  //               }
		// 	}
		// });
	});
	function leadsCheck() {
		$('#leads-id').val('0');
	}
	function leadsCheck() {
		$('#cus-id').val('0');
	}
	function paidByDis() {
	 	var chk = $('input:radio[name=Type]:checked').val();
	  	if (chk == "Cash"){
	  		$('#cardBank').val("");
	  		$('#cardno').val("");
	  		$('#cardDate').val("");
	  		$('#OtherBy').val("");
	    	$('#cardBank').prop('disabled', true);
	  		$('#cardno').prop('disabled', true);
	  		$('#cardDate').prop('disabled', true);
	  		$('#OtherBy').prop('disabled', true);				  		
	    	$('#cardBank').prop('required', false);
	  		$('#cardno').prop('required', false);
	  		$('#cardDate').prop('required', false);
	  		$('#OtherBy').prop('required', false);
	 	} else if (chk == "CrCard") {
	  		$('#cardBank').val("");
	  		$('#cardno').val("");
	  		$('#cardDate').val("");
	  		$('#OtherBy').val(""); 	
	    	$('#cardBank').prop('disabled', false);
	  		$('#cardno').prop('disabled', false);
	  		$('#cardDate').prop('disabled', false);
	  		$('#OtherBy').prop('disabled', true);
	    	$('#cardBank').prop('required', true);
	  		$('#cardno').prop('required', true);
	  		$('#cardDate').prop('required', true);
	  		$('#OtherBy').prop('required', false);
	 	} else if (chk == "Other") {
	  		$('#cardBank').val("");
	  		$('#cardno').val("");
	  		$('#cardDate').val("");		
	  		$('#OtherBy').val("");
	    	$('#cardBank').prop('disabled', true);
	  		$('#cardno').prop('disabled', true);
	  		$('#cardDate').prop('disabled', true);
	  		$('#OtherBy').prop('disabled', false);
	    	$('#cardBank').prop('required', false);
	  		$('#cardno').prop('required', false);
	  		$('#cardDate').prop('required', false);
	  		$('#OtherBy').prop('required', true);
	 	}
	}
</script>