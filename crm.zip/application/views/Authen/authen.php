<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">	
	<title><?php echo $title; ?></title>
    <!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
    <!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
    <!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
    <!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    
	<link href="<?php echo BASE_DOMAIN; ?>assets/css/bootstrap.css" rel="stylesheet">
	<link href="<?php echo BASE_DOMAIN; ?>assets/css/style.css" rel="stylesheet">
    <link href="<?php echo BASE_DOMAIN; ?>assets/css/validationEngine.css" rel="stylesheet">
    <link href="<?php echo BASE_DOMAIN; ?>assets/css/input.css" rel="stylesheet">
   
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script src="<?php echo BASE_DOMAIN; ?>assets/js/ie10-viewport-bug-workaround.js"></script>
	<script src="<?php echo BASE_DOMAIN; ?>assets/js/ie-emulation-modes-warning.js"></script>

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.min.js"></script>
    <script src="assets/js/css3-mediaqueries.js"></script>
    <script src="assets/js/respond.min.js"></script>
    <![endif]-->

    
    <!-- Google CDN jQuery with fallback to local -->
    <script src="<?php echo BASE_DOMAIN; ?>assets/js/jquery-1.11.1.min.js"></script>
	<script src="<?php echo BASE_DOMAIN; ?>assets/js/bootstrap.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/js/modernizr.custom.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/js/jquery.form-validator.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets//js/input.js"></script>
    <script type="text/javascript">   
    $(function(){
        $.validate({validateOnBlur:false});
        customCheckbox("confirm");
    })
    </script>

</head>
<body>
    <div id="login">
        <div class="header-blue"></div>
        <div class="container loginbg">
            <div class="row">
                <div class="col-xs-12 col-md-5 logo">
                     <?php echo image_asset('image/logo.gif',NULL,array('id'=>'logo','class'=>'img-responsive')); ?>
                </div>
                <div class="col-xs-12 col-md-7 login">
                	<?php echo image_asset('image/mycompany.png',NULL,array('id'=>'logo','height'=>'150')); ?>
                    <form method="post" id="customForm" action="<?php echo BASE_DOMAIN; ?>authen/login" enctype="multipart/form-data">
                        <div class="col-xs-12 formgroup">
                            <label for="username">User Name :</label>
                            <input type="text" id="username" name="username" class="input" data-validation="length" data-validation-length="min1"  data-validation-error-msg="Please insert your user name."/>
                        </div>
                        <div class="col-xs-12 formgroup">
                            <label for="username">Password :</label>
                            <input type="password" id="password" name="password"  class="input"  data-validation="alphanumeric" data-validation-allowing="-_" maxlength="15" data-validation-error-msg="Please insert your password." />
                            <div id="errorpassword"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="col-xs-6 formgroup">
                            <input type="submit" value="SIGN IN" class="button" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>       
    <?php include "application/views/footer.php"; ?>
</body>
</html>