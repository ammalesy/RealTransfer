<?php

require_once('database_config.php');
require_once('Model/User.php');
require_once('Model/Project.php');
require_once('Model/UnitDefect.php');
require_once('Model/Defect.php');


?>