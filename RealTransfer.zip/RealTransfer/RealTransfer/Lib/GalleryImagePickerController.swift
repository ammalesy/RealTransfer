//
//  GalleryImagePickerController.swift
//  RealTransfer
//
//  Created by Apple on 7/19/16.
//  Copyright © 2016 nuizoro. All rights reserved.
//

import UIKit

class GalleryImagePickerController: UIImagePickerController {

    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.All
    }
    
}
