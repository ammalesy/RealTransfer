//
//  CachingManager.swift
//  RealTransfer
//
//  Created by Apple on 6/20/16.
//  Copyright © 2016 nuizoro. All rights reserved.
//

import UIKit


class CachingManager: NSObject {
    
    
    var holder:AnyObject?

}
