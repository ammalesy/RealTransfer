//
//  Model.swift
//  RealTransfer
//
//  Created by Apple on 6/16/16.
//  Copyright © 2016 nuizoro. All rights reserved.
//

import UIKit
import SwiftSpinner

class Model: NSObject {
    

}
