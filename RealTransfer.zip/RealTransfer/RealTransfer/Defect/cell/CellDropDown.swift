//
//  CellDropDown.swift
//  RealTransfer
//
//  Created by AmmalesPSC91 on 6/7/2559 BE.
//  Copyright © 2559 nuizoro. All rights reserved.
//

import UIKit

class CellDropDown: CellLabelStatic {

    @IBOutlet weak var dropDownImage: UIImageView!
}
