//
//  RowInfoModel.swift
//  RealTransfer
//
//  Created by AmmalesPSC91 on 6/7/2559 BE.
//  Copyright © 2559 nuizoro. All rights reserved.
//

import UIKit

class RowInfoModel: RowModel {
    
    var headInfo1:String?
    var headInfo2:String?
    var headInfo3:String?
    var headInfo4:String?
    var headInfo5:String?
    var headInfo6:String?
    var headInfo7:String?
    var headInfo8:String?
    
    var detailInfo1:String?
    var detailInfo2:String?
    var detailInfo3:String?
    var detailInfo4:String?
    var detailInfo5:String?
    var detailInfo6:String?
    var detailInfo7:String?
    var detailInfo8:String?

}
