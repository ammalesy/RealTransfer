<?php

$config['api_username'] = 'glJesr';
$config['api_password'] = 'GzDiau';
$config['default_from'] = 'chrisnharvey';

/* End of file */