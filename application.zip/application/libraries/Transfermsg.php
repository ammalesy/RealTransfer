<?php
class Transfermsg  extends Exception 
{
    public $erromessage =  0;
    public $CI = NULL;
    public $docType=  NULL;
    

    public function __construct($params) 
    {
        $msgType = $params['msgType'];
        $message = $params['message'];
        $docno = $params['bkCode'];
        $customer = $params['cusID'];
        $doctype = $params['type'];
        $contact = $params['contact'];
        $staffid = $params['staffID'];
        $imCode = $params['imCode'];
        $ctCode = $params['ctCode'];

        $this->docType = $doctype;
        $this->CI =& get_instance();
        
      if ( !empty($docno) && !empty($customer) && !empty($msgType) && !empty($doctype) )
      {
          if ( trim($msgType)=='2' ) 
          {
//             if ( $this->SentSms($message,$contact) != -1 )
//             {
                 try {

                     $this->CI->load->model('tb_sms');
                     if ($doctype=='booking') {
                         $data_sms = array(
                            'sms_cus_id' => $customer,
                            'sms_msg_type' => $doctype,
                            'sms_message' => $message,
                            'sms_staff_id' => $staffid,
                            'sms_booking_code' => $docno,
                            'sms_ct_code' => '',
                            'sms_installment_code' => ''
                         );
                     }else{
                        $data_sms = array(
                            'sms_cus_id' => $customer,
                            'sms_msg_type' => $doctype,
                            'sms_message' => $message,
                            'sms_staff_id' => $staffid,
                            'sms_booking_code' => $docno,
                            'sms_ct_code' => $ctCode,
                            'sms_installment_code' => $imCode
                         );
                     }
                     
                     $this->CI->tb_sms->record($data_sms);
                     
                    }
              catch (Exception $e) {
                    echo 'Caught exception: ',  $e->getMessage(), "\n";
                        $this->erromessage=2;   
                    }
//             } 
//             else $this->erromessage =  1;
          }
          else if ( trim($msgType)=='1' ) 
          {
//            $subject=$doctype=='booking'?'กรุณามาทำสัญญา':'กรุณามาชำระค่างวด'; 
//            if ( $this->SmtpMail($contact,$subject, $message)  )
//             {
                 try {

                      $this->CI->load->model('tb_email');
                     if ($doctype=='booking') {
                         $data_email = array(
                            'email_cus_id' => $customer,
                            'email_msg_type' => $doctype,
                            'email_message' => $message,
                            'email_staff_id' => $staffid,
                            'email_booking_code' => $docno,
                            'email_ct_code' => '',
                            'email_installment_code' => ''
                         );
                     }else{
                        $data_email = array(
                            'email_cus_id' => $customer,
                            'email_msg_type' => $doctype,
                            'email_message' => $message,
                            'email_staff_id' => $staffid,
                            'email_booking_code' => $docno,
                            'email_ct_code' => $ctCode,
                            'email_installment_code' => $imCode
                         );
                     }
                     $this->CI->tb_email->record($data_email);
               
                 }
                 catch (Exception $e) {
                   echo 'Caught exception: ',  $e->getMessage(), "\n";
                   $this->erromessage=2;   
                 }              
//             }
//             else  $this->erromessage =  1;
          
          }
          
      }
    }
     
    function SentSms($Message,$tel)
    {     
        try
        {
        $Username  = "mintedimages";
        $Password  = "Mintedimages4530";
        $tel = str_replace("-","",$tel);
        $PhoneList = $tel;
        
        $Message = iconv('UTF-8', 'TIS-620', $Message);
        $Message = urlencode($Message);
        $Sender = "QSukhumvit";

        $Parameter = "User=".$Username."&Password=".$Password."&Msnlist=".$PhoneList."&Msg=".$Message."&Sender=".$Sender;
        $API_URL   = "http://smsmkt.piesoft.net:8999/SMSLink/SendMsg/index.php";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $Parameter);
        
        
            
        $result = curl_exec($ch);
        
            if($this->docType == 'installment'){
                redirect('/sms/installment');
            }else{
                redirect('/sms/booking');
            }     
        }
        catch (Exception $e)
        {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
            $result =-1;
        }
        curl_close($ch);
    }
    
    function SmtpMail($email, $subject, $body) 
    {

        require_once("application/third_party/PHPMailer/class.phpmailer.php");

        try
        {
        //   $mail = new PHPMailer();
        // $mail->IsSMTP();
        
        // $mail->CharSet = "utf-8";                       // ในส่วนนี้ ถ้าระบบเราใช้ tis-620 หรือ windows-874 สามารถแก้ไขเปลี่ยนได้                         
        // $mail->Host = "aspmx.l.google.com";          // mail server ของเรา
        // $mail->Port = "25";
        // $mail->SMTPAuth = true;                         // เลือกการใช้งานส่งเมล์ แบบ SMTP
        // $mail->Username = "winamp14@gmail.com"; // account e-mail ของเราที่ต้องการจะส่ง
        // $mail->Password = "9B215ffa";                  // รหัสผ่าน e-mail ของเราที่ต้องการจะส่ง

        // $mail->From = "winamp14@gmail.com";     // account e-mail ของเราที่ใช้ในการส่งอีเมล
        // $mail->FromName = "winamp14@gmail.com";
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPSecure = 'ssl';
        $mail->CharSet = "utf-8";                       // ในส่วนนี้ ถ้าระบบเราใช้ tis-620 หรือ windows-874 สามารถแก้ไขเปลี่ยนได้                         
        $mail->Host = "mail.mintedimages.com";          // mail server ของเรา
        $mail->SMTPAuth = true;                         // เลือกการใช้งานส่งเมล์ แบบ SMTP
        $mail->Username = "demo@mintedimages.com"; // account e-mail ของเราที่ต้องการจะส่ง
        $mail->Password = "023742155";                  // รหัสผ่าน e-mail ของเราที่ต้องการจะส่ง

        $mail->From = "demo@mintedimages.com";     // account e-mail ของเราที่ใช้ในการส่งอีเมล
        $mail->FromName = "demo@mintedimages.com"; // ชื่อผู้ส่งที่แสดง เมื่อผู้รับได้รับเมล์ของเรา
        $mail->AddAddress($email);                      // Email ปลายทางที่เราต้องการส่ง(ไม่ต้องแก้ไข)

        $mail->IsHTML(true);                            // ถ้า E-mail นี้ มีข้อความในการส่งเป็น tag html ต้องแก้ไข เป็น true
        $mail->Subject = $subject;                      // หัวข้อที่จะส่ง(ไม่ต้องแก้ไข)
        $mail->Body = $body;                            // ข้อความ ที่จะส่ง(ไม่ต้องแก้ไข)
        $result = $mail->send();          
        return $result;
        }
        catch (Exception $e)
        {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
            $result =-1;
        }
        
    }
   
}
?>