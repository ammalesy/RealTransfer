<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class DateFormat{			
    	public function thaiDate($timeBegin){
			$thai_day_arr=array("อาทิตย์","จันทร์","อังคาร","พุธ","พฤหัสบดี","ศุกร์","เสาร์");
			$thai_month_arr=array(
				"0"=>"",
				"01"=>"มกราคม",
				"02"=>"กุมภาพันธ์",
				"03"=>"มีนาคม",
				"04"=>"เมษายน",
				"05"=>"พฤษภาคม",
				"06"=>"มิถุนายน",	
				"07"=>"กรกฎาคม",
				"08"=>"สิงหาคม",
				"09"=>"กันยายน",
				"10"=>"ตุลาคม",
				"11"=>"พฤศจิกายน",
				"12"=>"ธันวาคม"					
			);
				
			$time = split("-","$timeBegin");
			$y = $time[0]+543;
			$thai_date_return=	$time[2];
			$thai_date_return.= " " . $thai_month_arr[$time[1]];
			$thai_date_return.=	" พ.ศ. ".$y;
				
			return $thai_date_return;
		}
	   
        public function thaiShortDate($timeBegin){
			$thai_day_arr=array("อาทิตย์","จันทร์","อังคาร","พุธ","พฤหัสบดี","ศุกร์","เสาร์");
			$thai_month_arr=array(
				"0"=>"",
				"01"=>"ม.ค.",
				"02"=>"ก.พ.",
				"03"=>"มี.ค.",
				"04"=>"เม.ย.",
				"05"=>"พ.ค.",
				"06"=>"มิ.ย.",	
				"07"=>"ก.ค.",
				"08"=>"ส.ค.",
				"09"=>"ก.ย.",
				"10"=>"ต.ค.",
				"11"=>"พ.ย.",
				"12"=>"ธ.ค."					
			);
				
			$time = split("-","$timeBegin");
			$y = $time[0]+543;
			$thai_date_return=	$time[2];
			$thai_date_return.= " " . $thai_month_arr[$time[1]];
			$thai_date_return.=	" ".$y;
				
			return $thai_date_return;
		}
	}
?>