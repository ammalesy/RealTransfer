<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project {

	public function __construct()
	{
	
	}

	function fetchData($tb_name)
	{
		/* 
			Reference instance Codeinniter 
		*/
		$CI_ref =& get_instance();		
		$CI_ref->load->database('project');
		$query = $CI_ref->db->query("SELECT * FROM ".$tb_name);
		$row = $query->result();
		return $row;
	}
	function createProject(){
		
	}
	
}
	