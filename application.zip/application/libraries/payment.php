<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class   Payment {
    public function getDefinefee($time, $installment_detail,$rcid) {
        
        
        if(!empty($installment_detail['qt_avg_installment'])){
            if($rcid == $installment_detail['qt_avg_installment']){
                return $installment_detail['qt_avg_installment'];
            }else if ($rcid == null) {
                return $installment_detail['qt_avg_installment'];
            } else {
                return $rcid;
            }
        }else {
            for($i=19;$i>0;$i--):
                $arr = explode('-', $installment_detail['qt_months_installment'.$i]);
                if($time > $arr[1] && !empty($installment_detail['qt_months_installment'.$i])) {
                    return $installment_detail['qt_installment'.($i+1)];
                }
            endfor;
            return $installment_detail['qt_installment1'];
        }
    }
}
?>