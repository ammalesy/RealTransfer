<?php
class Join {
    public function Building_FloorJoin()
    {
      // fl_id ,fl_build_id        
      return  " tb_building.building_id = tb_floor.fl_build_id ";       
    }
    public function Unitnumber_UnittypeJoin()
    {
      // un_build_id,un_floor_id,un_unit_type_id,
        return  " tb_unit_number.un_unit_type_id = tb_unit_type.un_unit_type_id ";       
    }
    public function Unitnumber_Building_floor_UnittypeJoin()
    {
      // un_build_id,un_floor_id,un_unit_type_id,
         $cmd = "tb_unit_number.un_build_id = tb_building.building_id
           AND tb_unit_number.un_build_id = tb_floor.fl_build_id
           AND tb_unit_number.un_floor_id = tb_floor.un_floor_id
           AND tb_unit_number.un_unit_type_id = tb_unit_type.unit_type_id ";
        return  $cmd;
    }
    
    public function Unitnumber_PriceJoin()
    {
      // un_build_id,un_floor_id,un_unit_type_id,
       
        $cmd = "tb_price.pr_building_id = tb_unit_number.un_build_id
            AND tb_price.pr_floor       = tb_unit_number.un_floor_id
            AND tb_price.pr_unit_number_id = tb_unit_number.un_number ";
        
    }
    public function Unitnumber_UnitType_PriceJoin()
    {
      // un_build_id,un_floor_id,un_unit_type_id,
       
        $cmd = "tb_price.pr_building_id = tb_unit_number.un_build_id
            AND tb_price.pr_floor       = tb_unit_number.un_floor_id
            AND tb_price.pr_unit_number_id = tb_unit_number.un_number 
            AND tb_unit_type.unit_type_id = tb_unit_number.un_unit_type_id  ";
        
    }
    public function LeadJoin()
    {
      //cus_id,cus_pers_id,cus_addr_id,cus_addr_cur_id,cus_con_id,cus_work_id,cus_stages_id,
      // cus_flag=leads 
        return " tb_customer.cus_pers_id = tb_customer_personal_info.pers_id 
            AND tb_customer.cus_stages_id = tb_opportunity_stages.op_id 
            AND tb_customer.cus_flag = 'leads' 
            AND cus_sts_active = 'on' ";
    }
    public function Customer_NationalityJoin()
    {
      //cus_id,cus_pers_id,cus_addr_id,cus_addr_cur_id,cus_con_id,cus_work_id,cus_stages_id,
      // tb_customer_personal_info.pers_nationality=	nt_id
        
    }
    public function CurrentaddressJoin()
    {
      //cus_id,cus_pers_id,cus_addr_id,cus_addr_cur_id,cus_con_id,cus_work_id,cus_stages_id,
      //addr_cur_country= country_id
      // cus_flag=leads 
    }
    
    public function CustomJoin()
    {
      //cus_id,cus_pers_id,cus_addr_id,cus_addr_cur_id,cus_con_id,cus_work_id,cus_stages_id,
      // cus_flag=cust 
      //  cus_stages_id=6
        return   " tb_customer_personal_info.pers_id = tb_customer.cus_pers_id 
                   AND  tb_customer.cus_sts_active = 'on' 
                   AND  tb_customer.cus_flag != 'leads' ";
    }
    public function QuotationJoin()
    {        
      return " tb_customer_personal_info.pers_id = tb_customer.cus_pers_id 
               AND tb_customer.cus_sts_active = 'on' 
               AND tb_quotation.qt_leads_id   = tb_customer.cus_id 
               AND tb_project.pj_id           = tb_quotation.qt_project_id 
               AND tb_project.pj_id = .$_SESSION['project_id_sel'] ";
    }
    public function Booking_CustomerJoin()
    {
        return " tb_booking.pers_id = tb_customer.cus_pers_id 
                 AND  tb_booking.bk_leads_id   = tb_customer.cus_id 
                 AND  tb_booking.bk_project_id = .$_SESSION['project_id_sel'] ";
    }
    public function Booking_DetailJoin()
    {
        //return `pers_id` = `cus_pers_id` AND `bk_leads_id` = `cus_id` AND `bk_project_id` = '1'  
    }
    
    public function ContactJoin()
    {
        return 
            " tb_contract.ct_cus_id = tb_customer.cus_id 
            AND  tb_customer.cus_sts_active = 'on' 
            AND  tb_customer.cus_pers_id = tb_customer_personal_info.pers_id
            AND  tb_contract.ct_booking_code = tb_booking.bk_booking_code 
            AND  tb_booking.bk_project_id = .$_SESSION['project_id_sel'] ";
    }
    public function Receipt_customerJoin()
    {
        return 
            " rc_customer_id = cus_id 
            AND pers_id = cus_pers_id 
            AND rc_payfor_booking_id = bk_booking_code 
            AND rc_receipt_code like 'wait%' 
            AND bk_project_id = .$_SESSION['project_id_sel'] ";
    }
    public function Receipt_customerDetailJoin()
    {
        return 
            " rc_customer_id = cus_id 
            AND pers_id = cus_pers_id 
            AND rc_payfor_booking_id = bk_booking_code 
            AND rc_receipt_code like 'wait%' 
            AND bk_project_id = .$_SESSION['project_id_sel'] ";
         //+tb_Quotation , tb_building , tb_unitnumber
    }
    
    public function Quotation_ProjectJoin()
    {
        
    }
    public function Quotation_BookingJoin()
    {
        
    }
    public function Quotation_ContactJoin()
    {
        
    }    
    public function Quotation_ReceiptJoin()
    {
        
    }
    public function Quotation_UnitJoin()
    {
        
    }
    
    public function Quotation_BuildingJoin()
    {
        
    }
    public function Building_FloorJoin()
    {
        
    }
    public function Unit_UnitTypeJoin()
    {
        
    }
    public function Fkkey()
    {
        /*tb_customer_address_info->addr_id_cus
        tb_customer_personal_info ->pers_id_cus
        tb_customer_address_current_info->addr_cur_id_cus
        tb_customer_working_info->work_cus_id
        tb_customer_contact_info->con_id_cus
        */
    }
    
    
    
    
}
?>