<?php
  
 

  class Termago {
    public $CI = NULL;
       public $weekstart;

      function __construct()
      {
          // Call the Model constructor
          $this->CI =& get_instance();
      }
      public function sevendayago()
       {
          return " DATE_SUB(DATE(NOW()), INTERVAL 7 DAY)  AND CURDATE()  ";
       }
      public function sevendayago_startdate()
      {
          $query = mysql_query(" SELECT DATE_SUB( DATE( NOW( ) ) , INTERVAL 7 DAY ) as start");              
          $get = mysql_fetch_array($query);
          return $get['start'];
      }
      public function getTermCurweek()
      {
          
          if ( date("N") ==0 )      $decrease_start = 7;
          else if ( date("N") ==1 ) $decrease_start = 8;
          else if ( date("N") ==2 ) $decrease_start = 9;
          else if ( date("N") ==3 ) $decrease_start = 10;
          else if ( date("N") ==4 ) $decrease_start = 11;
          else if ( date("N") ==5 ) $decrease_start = 12;
          else if ( date("N") ==6 ) $decrease_start = 13;
          else if ( date("N") ==7 ) $decrease_start = 14;    
           
          
          $curweek = "SELECT curdate()- $decrease_start as startday ";
          
          /*$curweek = 'SELECT adddate(curdate(), INTERVAL 1-DAYOFWEEK(curdate()) DAY) AS startday,
                      adddate(curdate(), INTERVAL 7-DAYOFWEEK(curdate()) DAY) AS WeekEnd ';
                      */
          $query = mysql_query($curweek);              
          $get = mysql_fetch_array($query);
          $this->weekstart = $get['startday'];
          $todate = date("Ymd",strtotime("+6 days",strtotime($this->weekstart)));
          return " BETWEEN '".$this->weekstart."' AND '".$todate."' ";
      }
      public function getFormula($term,$back)
       {
           if ( $back == '1week' )       $this->ago = 7;
               
           else if ( $back == '2week' )  $this->ago = 14;
               
           else if ( $back == '1month' )  $this->ago = 1;
               
           else if ( $back == '3month' )  $this->ago  = 3;
               
               
           if ( $term == 'week' )
           {
                $query = "SELECT DATE_FORMAT( DATE_SUB( CURDATE( ) , INTERVAL $this->ago 
DAY ) ,  '%e.%b.%Y' ) AS start , DATE_FORMAT( DATE_SUB( CURDATE( ) , INTERVAL $this->ago 
DAY ) ,  '%e.%b.%Y' ) AS startdate ,DATE_FORMAT( CURDATE( ) ,  '%e.%b.%Y' ) AS enddate";                
                $query = mysql_query($query);             
                $get = mysql_fetch_array($query);               
                $this->fromdat   = $get['start'];
                $this->todat     = $get['enddate'];
                $this->begindate = $get['startdate'];
               
                $cmd =  ' DATE_SUB(CURDATE(), INTERVAL '.$this->ago.' DAY)  AND CURDATE() ';
           }   
           
           return $cmd;   
       }
      
  }
  

?>