<?Php
 
include 'Formula.php';
include 'Dob.php';
include 'Termago.php';
include 'Intervaltime.php'; 

class Utility 
{
     public $CI = NULL;
     public $lang_day_eng_full = array('SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY');
     public $xAxis='' ;
     public $deta='';
     public $series_column=array();// Refer Array 2 Dimension from sQL Command key=>value  ; 
    
     public $series_ =array();
     public $series_cust=array();
     public $series_lead=array();
        
     public $xAxis_cust ='';
     public $deta_cust='';
     public $xAxis_lead='';                           
     public $deta_lead='';
         
    
     public $lang_day_eng_abbreviation = array("SUN","MON","TUE","WED","THUR","FRI","SAT");
     public $lang_day_thai_full = array("อาทิตย์","จันทร์","อังคาร","พุธ","พฤหัสบดี","ศุกร์","เสาร์");
     public $lang_day_thai_abbreviation = array("อา.","จ.","อ.","พ.","พฤ.","ศ.","ส.");
     public $lang_month_eng_full = array("JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER");
     public $lang_month_eng_abbreviation = array("Jan.","Feb.","Mar.","Apr.","May.","Jun.","Jul.","Aug.","Sep.","Oct.","Nov.","Dec.");
     public $lang_month_thai_full = array("มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฏาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม");
     public $lang_month_thai_abbreviation = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
    public $dxy;
    public $longtime;
    public $detail;
    public $nationality;
    public $opportunity;
    public $sourcetype;
    public $cmd;
    public $ages;
    public $proportion_cust_detail;
    public $startdate;
    public $backdate;
    public $enddate;
    public $begin_date;
    public $begin_month;
    
    
    
    
    function __construct()
    {
        // Call the Model constructor
        $this->CI =& get_instance();
        $this->CI->mysql_connection_common_db();
    }
   public function proportion($index='day',$ago,$back)
   {
       
       $p=new Termago();
       $curweek = $p->getTermCurweek();
       $this->startdate = $p->weekstart;
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )     $w = new Intervaltime($interval='week',"cus_created_date");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"cus_created_date");
            if ( $back !== '1week' )
                $this->startdate   = $w->begindate_ref;
            else $this->startdate   = $p->sevendayago_startdate();
           
        }
       
       $cust_detail = 
         "(SELECT                
              distinct 'cust' AS leads, 
              DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
              pers_fname, 
              pers_lname, 
              pers_mobile, 
              pers_tel, 
              pers_email
            FROM 
              ".$this->CI->db->database.".tb_customer, 
              ".$this->CI->db->database.".tb_customer_personal_info
            WHERE 
              pers_id = cus_pers_id
              AND cus_sts_active !=  'off'
              AND cus_flag !=  'leads' ";
       
       $lead_detail = 
         "(SELECT 
            distinct 'lead' AS leads, 
            DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
            pers_fname, 
            pers_lname, 
            pers_mobile, 
            pers_tel, 
            pers_email
         FROM 
            ".$this->CI->db->database.".tb_customer, 
            ".$this->CI->db->database.".tb_opportunity_stages, 
            ".$this->CI->db->database.".tb_customer_personal_info, 
            ".$this->CI->db->database.".tb_countries
         WHERE 
            cus_pers_id = pers_id
            AND cus_stages_id = op_id
            AND country_id = pers_nationality           
            AND cus_sts_active !=  'off'
            AND cus_flag =  'leads')";
       
       if ( $index=='day' )
        {
            
            $lead=
               "(SELECT  'lead' as leads, 
                DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
                    DAY( cus_created_date ) AS day , 
                    DAYNAME( cus_created_date ) AS dayname ,                          
                    COUNT( cus_id ) AS total_cust 
                 FROM 
                    ".$this->CI->db->database.".tb_customer,
                    ".$this->CI->db->database.".tb_opportunity_stages ,
                    ".$this->CI->db->database.".tb_customer_personal_info, 
                    ".$this->CI->db->database.".tb_countries
                    WHERE  
                    cus_pers_id = pers_id and  cus_stages_id = op_id  
                    AND  country_id = pers_nationality                     
                    AND cus_flag = 'leads' 
                    AND cus_sts_active !=  'off'
                    AND cus_created_date   $curweek ";
            $cust = 
               "(SELECT 'cust' as leads,
                   DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
                    DAY( cus_created_date ) AS day , 
                    DAYNAME( cus_created_date ) AS dayname ,                          
                    COUNT( cus_id ) AS total_cust 
                 FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE  
                    pers_id = cus_pers_id 
                    AND cus_sts_active = 'on'  
                    AND  cus_flag != 'leads' 
                    AND cus_sts_active !=  'off'
                    AND cus_created_date   $curweek ";
            
            $total = !empty($this->longtime)?$cust." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime.
                " GROUP BY week,day
                  ORDER BY week,day ":$cust.
                " GROUP BY created,day,dayname ORDER BY day,created,dayname";
            $total .= "  
                      )
                UNION "
                    ;
                
            $total .=!empty($this->longtime)?$lead." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime.
                " GROUP BY week,day
                  ORDER BY week,day ":$lead.
                " GROUP BY created,day,dayname ORDER BY created,day,dayname )";
            
            
            $sql= !empty($this->longtime)?$cust_detail." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime:
                $cust_detail;
            $sql.= "
                    )
                UNION "
                    ;
                
            $sql .=!empty($this->longtime)?$lead_detail." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime:
            $lead_detail;
           
            $query = array('sum'=>$total,'detail'=>$sql);
           
            return $query;
            
        }
        else if ( $index=='week' )
        {
            
            $lead="(SELECT  'lead' as leads, 
                    CASE 
                    WHEN DAYOFMONTH( cus_created_date) < 8      THEN  CONCAT('7-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 15   THEN  CONCAT('14-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  CONCAT('21-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )                   
                      WHEN DAYOFMONTH( cus_created_date) < 29   THEN  CONCAT('28-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(cus_created_date) , 2 ),DATE_FORMAT( cus_created_date ,  '%m-%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH( cus_created_date) < 8   THEN  '1'
                      WHEN DAYOFMONTH( cus_created_date) < 15  THEN  '2'
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  '3' 
                      WHEN DAYOFMONTH( cus_created_date) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                    COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer,
                    ".$this->CI->db->database.".tb_opportunity_stages ,
                    ".$this->CI->db->database.".tb_customer_personal_info, 
                    ".$this->CI->db->database.".tb_countries
                    WHERE  
                    cus_pers_id = pers_id and  cus_stages_id = op_id  
                    AND  country_id = pers_nationality                    
                    AND cus_sts_active !=  'off'
                    AND  cus_flag = 'leads'";
            $cust = "(SELECT 'cust' as leads,
                   CASE 
                    WHEN DAYOFMONTH( cus_created_date) < 8      THEN  CONCAT('7-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 15   THEN  CONCAT('14-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  CONCAT('21-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )                   
                      WHEN DAYOFMONTH( cus_created_date) < 29   THEN  CONCAT('28-', DATE_FORMAT( cus_created_date ,  '%m-%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(cus_created_date) , 2 ),DATE_FORMAT( cus_created_date ,  '%m-%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH( cus_created_date) < 8   THEN  '1'
                      WHEN DAYOFMONTH( cus_created_date) < 15  THEN  '2'
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  '3' 
                      WHEN DAYOFMONTH( cus_created_date) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                    COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE  
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND  cus_flag != 'leads' ";
            
            $total = !empty($this->longtime)?$cust." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime.
                "
                 AND MONTH(cus_created_date) = MONTH(CURDATE()) -1
                 AND YEAR( cus_created_date ) = YEAR(CURDATE())   
                 GROUP BY week,month,year
                 ORDER BY week,month,year ":$cust.
                " AND MONTH(cus_created_date) = MONTH(CURDATE())
                  AND YEAR( cus_created_date ) = YEAR(CURDATE()) 
                  GROUP BY dat,weekno     ORDER BY week,month,year ";
            $total .= "
                    )
                UNION "
                    ;
                
            $total .=!empty($this->longtime)?$lead." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime.
                "
                 AND MONTH(cus_created_date) = MONTH(CURDATE())-1
                 AND YEAR( cus_created_date ) = YEAR(CURDATE())   
                 GROUP BY week,month,year
                 ORDER BY week,month,year ":$lead.
                " AND MONTH(cus_created_date) = MONTH(CURDATE())
                  AND YEAR( cus_created_date ) = YEAR(CURDATE()) 
                  GROUP BY dat,weekno     ORDER BY week,month,year  ) ";
            
            $sql= !empty($this->longtime)?$cust_detail." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime:
                 $cust_detail.
                "
                 AND MONTH(cus_created_date)  = MONTH(CURDATE())
                 AND YEAR( cus_created_date ) = YEAR(CURDATE()) ";
            $sql.= ")
                UNION ";
            $sql .=!empty($this->longtime)?$lead_detail." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime:
            $lead_detail.
                "
                 AND MONTH(cus_created_date)  = MONTH(CURDATE())
                 AND YEAR( cus_created_date ) = YEAR(CURDATE())  ) ";
            $query = array('sum'=>$total,'detail'=>$sql);  
            return $query;
        }
        else if ( $index=='month' )
        {
            
            $lead="(SELECT  
               'lead' as leads, 
               MONTHNAME(cus_created_date) AS month,
               YEAR(cus_created_date) AS year,
               COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer,
                    ".$this->CI->db->database.".tb_opportunity_stages ,
                    ".$this->CI->db->database.".tb_customer_personal_info, 
                    ".$this->CI->db->database.".tb_countries
                WHERE  
                    cus_pers_id = pers_id and  cus_stages_id = op_id  
                    AND  country_id = pers_nationality 
                    AND cus_sts_active !=  'off'
                    AND  cus_flag = 'leads'";
            $cust = "(SELECT 
                'cust' as leads,
                MONTHNAME(cus_created_date) AS month,
                YEAR(cus_created_date) AS year ,
                COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE  
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND  cus_flag != 'leads' ";
            
            $total = !empty($this->longtime)?$cust." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime.
                " GROUP BY month,year
                 ORDER BY month,year ":$cust.
                 " AND YEAR( cus_created_date ) = YEAR(CURDATE()) -1
                  GROUP BY month,year
                  ORDER BY year,month ";
            $total.="
                    )
                UNION "
                    ;
                
            $total .=!empty($this->longtime)?$lead." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime.
                " GROUP BY month,year
                 ORDER BY month,year ":$lead.
                " AND YEAR( cus_created_date ) = YEAR(CURDATE()) -1
                 GROUP BY month,year
                  ORDER BY year,month ) ";
            
            $sql = !empty($this->longtime)?$cust_detail." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime:
                 $cust_detail.
                " AND YEAR( cus_created_date ) = YEAR(CURDATE()) ";
            $sql.= " )
                UNION ";
            $sql .=!empty($this->longtime)?$lead_detail." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$this->longtime
                :$lead_detail.
                "  AND YEAR( cus_created_date ) = YEAR(CURDATE())  ) ";
            
            $query = array('sum'=>$total,'detail'=>$sql);  
            return $query;
        }
        else if ( $index=='ago' )
        {
            
            $this->series_ = $w->series_ref;
            
            if ( $back=='1week'  )  
                  $group = ' GROUP BY
                               created,day,dayname
                             ORDER BY created,day,dayname';
               else if ( $back=='1month' )
                  $group = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
               else if ( $back=='3month' )
                  $group = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
                   
            $where_lead = "FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_opportunity_stages, 
                          ".$this->CI->db->database.".tb_customer_personal_info, 
                          ".$this->CI->db->database.".tb_countries
                        WHERE 
                          cus_pers_id = pers_id
                          AND cus_stages_id = op_id
                          AND country_id = pers_nationality
                          AND cus_sts_active !=  'off'
                          AND cus_flag !=  'cust'";
            $where_cust = "FROM 
                 ".$this->CI->db->database.".tb_customer, 
                 ".$this->CI->db->database.".tb_customer_personal_info
               WHERE 
                 pers_id = cus_pers_id 
                 AND cus_sts_active !=  'off'
                 AND cus_flag != 'leads'"; 
            if ( $back=='1week' )
            {
               $where_lead = $where_lead." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago() .$group ;       
               $where_cust = $where_cust." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago() .$group ;       
            }
            else
            {
               $where_lead = $where_lead." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() "  .$group ;       
               $where_cust = $where_cust." AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() "  .$group ;       
            }
            $ago=array(
                "week"=>array(
                   "1week"=>
                       "(SELECT 
                          'lead' as leads, 
                          DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
                          DAY( cus_created_date ) AS day , 
                          DAYNAME( cus_created_date ) AS dayname ,                          
                          COUNT( cus_id ) AS total_cust $where_lead                          
                          )
                            UNION
                          (SELECT 'cust' AS leads,
                         DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
                         DAY( cus_created_date ) AS day , 
                         DAYNAME( cus_created_date ) AS dayname ,                          
                         COUNT( cus_id ) AS total_cust $where_cust )
                       ",
                   "2week"=>
                       "(SELECT 
                          'lead' as leads, 
                          cus_created_date ,
                          DAY( cus_created_date ) AS day , 
                          DAYNAME( cus_created_date ) AS dayname ,                          
                          COUNT( cus_id ) AS total_cust $where_lead                          
                          )
                            UNION
                          (SELECT 'cust' AS leads,
                         cus_created_date ,
                         DAY( cus_created_date ) AS day , 
                         DAYNAME( cus_created_date ) AS dayname ,                          
                         COUNT( cus_id ) AS total_cust $where_cust )
                       ",
                ),
                "month"=>array(
                    "1month"=>
                       "(SELECT   'lead' as leads, 
                           CASE ".$w->when."
                           END  AS  week, COUNT( cus_id ) AS total_cust  $where_lead 
                           )
                        UNION 
                         (SELECT 'cust' AS leads,
                           CASE ".$w->when."
                           END  AS  week, COUNT( cus_id ) AS total_cust  $where_cust 
                          )",
                    "3month"=>
                        "(SELECT    'lead' as leads,                         
                           CASE ".$w->when."
                           END  AS  week, COUNT( cus_id ) AS total_cust $where_lead 
                           )
                         UNION   
                          (SELECT  'cust' AS leads,                          
                           CASE ".$w->when."
                           END  AS  week, COUNT( cus_id ) AS total_cust $where_cust 
                           )",
                    "6month"=>
                       "(SELECT 
                           MONTH( cus_created_date) AS month,
                           YEAR( cus_created_date) AS year,
                           COUNT( cus_id ) AS total_cust $where_lead 
                        )
                        UNION
                        (SELECT 
                           MONTH( cus_created_date) AS month,
                           YEAR( cus_created_date) AS year,
                           COUNT( cus_id ) AS total_cust $where_cust 
                        )",
                ),
                "year"=>array(
                    "1year"=>
                      "(SELECT 
                         MONTH( cus_created_date ) AS month , 
                         MONTHNAME( cus_created_date ) AS monthname , 
                         YEAR( cus_created_date ) AS year, 
                         COUNT( cus_id ) AS total_cust $where_lead 
                        )
                        UNION
                        (SELECT 
                         MONTH( cus_created_date ) AS month , 
                         MONTHNAME( cus_created_date ) AS monthname , 
                         YEAR( cus_created_date ) AS year, 
                         COUNT( cus_id ) AS total_cust $where_cust 
                        )",
                         
                    "3year"=>
                      "(SELECT 
                         SELECT 
                         CEIL( MONTH( cus_created_date ) /6 ) AS month, 
                         YEAR( cus_created_date ) AS year, 
                         COUNT( cus_id ) AS total_cust $where_lead 
                        )
                        UNION
                        (SELECT 
                         SELECT 
                         CEIL( MONTH( cus_created_date ) /6 ) AS month, 
                         YEAR( cus_created_date ) AS year, 
                         COUNT( cus_id ) AS total_cust $where_cust 
                        )"                         
                 )                
                   
            );
            
           // echo 'BACK = '.$back;
            if ( $back=='1week' )
            {
                $query = array('sum'=>$ago['week']['1week'],'detail'=>$ago['week']['detail']);  
                //echo $ago['week']['1week'];
                return $query; 
            }
            
            else if ( $back=='1month' )
            {
                $query = array('sum'=>$ago['month']['1month'],'detail'=>$ago['month']['detail']);  
                return $query; 
            }
            else if ( $back=='3month' )
            {
                
                $query = array('sum'=>$ago['month']['3month'],'detail'=>$ago['month']['detail']);  
                
                return $query; 
            }
            else if ( $ago=='TODAY' )
            {
                $query = array('sum'=>$ago['month']['6month'],'detail'=>$ago['month']['detail']);  
                return $query; 
            }
            
                
         }
         
    }
   
    
    public function Leads($index='ago',$ago='week',$back='1week')
    {
        
        
        
        $p=new Termago();
        $curweek = $p->getTermCurweek();
        $this->startdate = $p->weekstart;
        
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )     $w = new Intervaltime($interval='week',"cus_created_date");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"cus_created_date");
            //echo $back;
            if ( $back !== '1week' )
                $this->startdate   = $w->begindate_ref;
            else $this->startdate   = $p->sevendayago_startdate();
          //  echo ' start : '.$this->startdate;
           
        }
        
        $cmd_leads = array(
         "day" => array(             
             "total"=>
               "SELECT
                    DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
                    DAY( cus_created_date ) AS day , 
                    DAYNAME( cus_created_date ) AS dayname ,                          
                    COUNT( cus_id ) AS total_cust 
                FROM 
                 ".$this->CI->db->database.".tb_customer, 
                 ".$this->CI->db->database.".tb_opportunity_stages, 
                 ".$this->CI->db->database.".tb_customer_personal_info, 
                 ".$this->CI->db->database.".tb_countries
               WHERE 
                 cus_pers_id = pers_id
                 AND cus_stages_id = op_id
                 AND country_id = pers_nationality
                 AND op_rates !=  '100'
                 AND cus_flag !=  'cust'
                 AND cus_sts_active !=  'off'
                 AND DATE_FORMAT(cus_created_date,'%Y%m%d')   $curweek ",
            "opportunity"=>
               "SELECT 
                    cus_stages_id, COUNT( cus_id ) AS total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND op_rates !=  '100'
                    AND cus_flag !=  'cust'
                    AND cus_sts_active !=  'off'
                    AND DATE_FORMAT(cus_created_date,'%Y%m%d')   $curweek ",
            "source"=>"SELECT cus_group_type, COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND op_rates !=  '100'
                    AND cus_flag !=  'cust'
                    AND cus_sts_active !=  'off'
                    AND DATE_FORMAT(cus_created_date,'%Y%m%d')   $curweek ",
         ),
         "week"=>array(
            "total"=>
                 "SELECT 
                    CASE 
                    WHEN DAYOFMONTH( cus_created_date) < 8      THEN  CONCAT('7.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 15   THEN  CONCAT('14.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  CONCAT('21.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )                   
                      WHEN DAYOFMONTH( cus_created_date) < 29   THEN  CONCAT('28.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(cus_created_date) , 2 ),DATE_FORMAT( cus_created_date ,  '.%m.%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH( cus_created_date) < 8   THEN  '1'
                      WHEN DAYOFMONTH( cus_created_date) < 15  THEN  '2'
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  '3' 
                      WHEN DAYOFMONTH( cus_created_date) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                    COUNT( cus_id ) AS total_cust
                FROM     
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info, 
                    ".$this->CI->db->database.".tb_countries
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND country_id = pers_nationality
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag !=  'cust' ",
            "opportunity"=>"SELECT 
                    cus_stages_id, COUNT( cus_id ) AS total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag !=  'cust' ",
            "source"=>"SELECT cus_group_type, COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag !=  'cust' "
         ),
        "month"=>array(
            "total"=>"SELECT 
                     MONTH( cus_created_date) AS month,
                     YEAR( cus_created_date) AS year,
                     COUNT( cus_id ) AS total_cust
                FROM     
                     ".$this->CI->db->database.".tb_customer, 
                     ".$this->CI->db->database.".tb_opportunity_stages, 
                     ".$this->CI->db->database.".tb_customer_personal_info, 
                     ".$this->CI->db->database.".tb_countries
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND country_id = pers_nationality
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag !=  'cust' ",
         
            "opportunity"=>"SELECT 
                    cus_stages_id, COUNT( cus_id ) AS total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag !=  'cust'",
            "source"=>"SELECT cus_group_type, COUNT( cus_id ) AS total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag !=  'cust' "),
          "ago"=>array(
              "week"=>array(
                  "1week" =>
                       "SELECT 
                         DATE_FORMAT(cus_created_date,'%Y-%m-%d') AS created,
                         DAY( cus_created_date ) AS day , 
                         DAYNAME( cus_created_date ) AS dayname ,                          
                         COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_opportunity_stages, 
                          ".$this->CI->db->database.".tb_customer_personal_info, 
                          ".$this->CI->db->database.".tb_countries
                        WHERE 
                          cus_pers_id = pers_id
                          AND cus_stages_id = op_id
                          AND country_id = pers_nationality
                          AND cus_sts_active !=  'off'
                          AND cus_flag !=  'cust'
                          AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago(), 
                  "2week" =>
                       "SELECT 
                         DATE_FORMAT(cus_created_date,'%Y-%m-%d') AS created,
                         DAY( cus_created_date ) AS day , 
                         DAYNAME( cus_created_date ) AS dayname , 
                         COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_opportunity_stages, 
                          ".$this->CI->db->database.".tb_customer_personal_info, 
                          ".$this->CI->db->database.".tb_countries
                        WHERE 
                          cus_pers_id = pers_id
                          AND cus_stages_id = op_id
                          AND country_id = pers_nationality
                          AND cus_sts_active !=  'off'
                          AND cus_flag !=  'cust'", 
                  
                    "opportunity"=>"SELECT 
                         cus_stages_id, COUNT( cus_id ) AS total_cust
                    FROM 
                         ".$this->CI->db->database.".tb_customer, 
                         ".$this->CI->db->database.".tb_opportunity_stages, 
                         ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE 
                        cus_pers_id = pers_id
                        AND cus_stages_id = op_id
                        AND cus_sts_active !=  'off'
                        AND cus_flag !=  'cust'
                        AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago().
                        " GROUP BY cus_stages_id  ORDER BY cus_stages_id ", 
                  "source"=>"SELECT cus_group_type, COUNT( cus_id ) AS total_cust
                    FROM 
                        ".$this->CI->db->database.".tb_customer, 
                        ".$this->CI->db->database.".tb_opportunity_stages, 
                        ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE 
                        cus_pers_id = pers_id
                        AND cus_stages_id = op_id
                        AND cus_sts_active !=  'off'
                        AND cus_flag !=  'cust'
                        AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago().
                        " GROUP BY cus_group_type ORDER BY cus_group_type "),
              "month"=> array(
                  "1month" =>
                       "SELECT 
                           CASE".$w->when.
                           " END AS week,
                           COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_opportunity_stages, 
                          ".$this->CI->db->database.".tb_customer_personal_info, 
                          ".$this->CI->db->database.".tb_countries
                        WHERE 
                          cus_pers_id = pers_id
                          AND cus_stages_id = op_id
                          AND country_id = pers_nationality
                        
                          AND cus_flag !=  'cust'
                          AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "3month" =>
                       "SELECT 
                           CASE".$w->when.
                           " END AS week,
                           COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_opportunity_stages, 
                          ".$this->CI->db->database.".tb_customer_personal_info, 
                          ".$this->CI->db->database.".tb_countries
                        WHERE 
                          cus_pers_id = pers_id
                          AND cus_stages_id = op_id
                          AND country_id = pers_nationality
                        
                          AND cus_flag !=  'cust'
                          AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  
                  
                    "opportunity"=>"SELECT 
                         cus_stages_id, COUNT( cus_id ) AS total_cust
                    FROM 
                         ".$this->CI->db->database.".tb_customer, 
                         ".$this->CI->db->database.".tb_opportunity_stages, 
                         ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE 
                        cus_pers_id = pers_id
                        AND cus_stages_id = op_id
                        AND cus_sts_active !=  'off'
                        AND cus_flag !=  'cust'
                        AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ".
                        " GROUP BY cus_stages_id  ORDER BY cus_stages_id ",
                  "source"=>"SELECT cus_group_type, COUNT( cus_id ) AS total_cust
                    FROM 
                        ".$this->CI->db->database.".tb_customer, 
                        ".$this->CI->db->database.".tb_opportunity_stages, 
                        ".$this->CI->db->database.".tb_customer_personal_info
                    WHERE 
                        cus_pers_id = pers_id
                        AND cus_stages_id = op_id
                        AND cus_sts_active !=  'off'
                        AND cus_flag !=  'cust'
                        AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ".
                      " GROUP BY cus_group_type ORDER BY cus_group_type "
              )
          ),
           "detail"=>
                "SELECT cus_created_date,pers_fname,pers_lname,pers_mobile,pers_tel,pers_email,nt_nationality
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_opportunity_stages, 
                    ".$this->CI->db->database.".tb_customer_personal_info, 
                    ".$this->CI->db->database.".tb_nationality
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_stages_id = op_id
                    AND pers_nationality = pers_nationality
                    AND op_rates !=  '100'
                    AND cus_sts_active !=  'off'
                    AND cus_flag =  'leads'"
          ,
          "today"=>array(
               "total"=>"
               SELECT
                    DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,                    
                    COUNT( cus_id ) AS total_cust 
                FROM 
                 ".$this->CI->db->database.".tb_customer, 
                 ".$this->CI->db->database.".tb_opportunity_stages, 
                 ".$this->CI->db->database.".tb_customer_personal_info, 
                 ".$this->CI->db->database.".tb_countries
               WHERE 
                 cus_pers_id = pers_id
                 AND cus_stages_id = op_id
                 AND country_id = pers_nationality
                 AND op_rates !=  '100'
                 AND cus_sts_active !=  'off'
                 AND cus_flag =  'leads'
                 AND DATE_FORMAT(cus_created_date,'%Y%m%d') = DATE_FORMAT(CURDATE(),'%Y%m%d') 
                 GROUP BY created ",
               "detail"=>
                 "SELECT 
                   cus_created_date,
                   pers_fname,
                   pers_lname,
                   pers_mobile,
                   pers_tel,
                   pers_email,
                   nt_nationality
                  FROM 
                   ".$this->CI->db->database.".tb_customer, 
                   ".$this->CI->db->database.".tb_opportunity_stages, 
                   ".$this->CI->db->database.".tb_customer_personal_info, 
                   ".$this->CI->db->database.".tb_nationality
                  WHERE 
                   cus_pers_id = pers_id
                   AND cus_stages_id = op_id
                   AND pers_nationality = pers_nationality
                   AND op_rates !=  '100'
                   AND cus_sts_active !=  'off'
                   AND cus_flag =  'leads'
                   AND DATE_FORMAT(cus_created_date,'%Y%m%d') = DATE_FORMAT(CURDATE(),'%Y%m%d') ")
              
            
       );              
           
        if ( $index=='day' )
           {
               
               $this->detail = !empty($this->longtime)?$cmd_leads['day']['detail'].' AND  cus_created_date BETWEEN '.$this->longtime:
                     $cmd_leads['day']['detail'].'  ORDER BY created,day,dayname';
               $this->opportunity = !empty($this->longtime)?$cmd_leads['day']['opportunity'].
                     ' AND  cus_created_date BETWEEN '.$this->longtime.' GROUP BY cus_stages_id  ORDER BY cus_stages_id ':
                     $cmd_leads['day']['opportunity'].' 
                       GROUP BY cus_stages_id  ORDER BY cus_stages_id';
               $this->sourcetype = !empty($this->longtime)?$cmd_leads['day']['source'].
                     ' AND  cus_created_date BETWEEN '.$this->longtime.' GROUP BY cus_group_type ORDER BY cus_group_type ':
                     $cmd_leads['day']['source'].' 
                       GROUP BY cus_group_type ORDER BY cus_group_type ';
              
               return  !empty($this->longtime)?$cmd_leads['day']['total'].' AND  cus_created_date BETWEEN '.$this->longtime.
                      ' GROUP BY created,day,dayname 
                         ORDER BY created,day,dayname ':$cmd_leads['day']['total'].
                      '  GROUP BY created,day,dayname ORDER BY created,day,dayname';
           }
           else if ( $index=='week' )
           {
               
               $this->detail = !empty($this->longtime)?$cmd_leads['week']['detail'].' AND  cus_created_date BETWEEN '.$this->longtime:
                     $cmd_leads['week']['detail'].' 
                        AND MONTH(cus_created_date) = MONTH(CURDATE())-1
                        AND YEAR(cus_created_date) = YEAR(CURDATE())';
               $this->opportunity = !empty($this->longtime)?$cmd_leads['week']['opportunity'].
                     ' AND  cus_created_date BETWEEN '.$this->longtime.' GROUP BY cus_stages_id  ORDER BY cus_stages_id ':
                     $cmd_leads['week']['opportunity'].' 
                       AND MONTH(cus_created_date) = MONTH(CURDATE())-1
                       AND YEAR(cus_created_date) = YEAR(CURDATE())
                        GROUP BY cus_stages_id  ORDER BY cus_stages_id ';
               $this->sourcetype = !empty($this->longtime)?$cmd_leads['week']['source'].
                     ' AND  cus_created_date BETWEEN '.$this->longtime.' GROUP BY cus_group_type ORDER BY cus_group_type ':
                     $cmd_leads['week']['source'].'
                       AND MONTH(cus_created_date) = MONTH(CURDATE())-1
                       AND YEAR(cus_created_date)  = YEAR(CURDATE()) 
                       GROUP BY cus_group_type ORDER BY cus_group_type ';
               $this->cmd = !empty($this->longtime)?$cmd_leads['week']['total'].' AND  cus_created_date BETWEEN '.$this->longtime.
                      ' GROUP BY dat,weekno ORDER BY dat,weekno ':$cmd_leads['week']['total'].
                      ' AND MONTH(cus_created_date) = MONTH(CURDATE())
                       AND YEAR(cus_created_date) = YEAR(CURDATE())
                      GROUP BY dat,weekno ORDER BY dat,weekno ';
               
               return  !empty($this->longtime)?$cmd_leads['week']['total'].' AND  cus_created_date BETWEEN '.$this->longtime.
                      ' GROUP BY dat,weekno ORDER BY dat,weekno ':$cmd_leads['week']['total'].
                      ' AND MONTH(cus_created_date) = MONTH(CURDATE())-1
                       AND YEAR(cus_created_date) = YEAR(CURDATE())
                      GROUP BY dat,weekno ORDER BY dat,weekno ';
           }
           else if ( $index=='month' )
           {
               $this->detail = !empty($this->longtime)?$cmd_leads['month']['detail'].' AND  cus_created_date BETWEEN '.$this->longtime:
                     $cmd_leads['month']['detail'].
                      ' AND YEAR(cus_created_date) = YEAR(CURDATE())';
               $this->opportunity = !empty($this->longtime)?$cmd_leads['month']['opportunity'].
                     ' AND  cus_created_date BETWEEN '.$this->longtime.' GROUP BY cus_stages_id  ORDER BY cus_stages_id ':
                     $cmd_leads['month']['opportunity'].' 
                       
                       AND YEAR(cus_created_date) = YEAR(CURDATE())-1
                       GROUP BY cus_stages_id  ORDER BY cus_stages_id  ';
               $this->sourcetype = !empty($this->longtime)?$cmd_leads['month']['source'].
                     ' AND  cus_created_date BETWEEN '.$this->longtime.' GROUP BY cus_group_type ORDER BY cus_group_type ':
                     $cmd_leads['month']['source'].' 
                       
                       AND YEAR(cus_created_date) = YEAR(CURDATE())-1
                        GROUP BY cus_group_type ORDER BY cus_group_type ';
               $this->cmd = !empty($this->longtime)?$cmd_leads['month']['total'].' AND  cus_created_date BETWEEN '.$this->longtime.
                     ' GROUP BY month,year
                       ORDER BY month,year ':$cmd_leads['month']['total'].
                     '  
                        AND YEAR(cus_created_date) = YEAR(CURDATE()) 
                        GROUP BY month,year
                        ORDER BY month,year';
               
               
               return  !empty($this->longtime)?$cmd_leads['month']['total'].' AND  cus_created_date BETWEEN '.$this->longtime.
                     ' GROUP BY month,year
                       ORDER BY month,year ':$cmd_leads['month']['total'].
                     '  
                        AND YEAR(cus_created_date) = YEAR(CURDATE())-1
                        GROUP BY month,year
                        ORDER BY year,month';
           }
           else if ( $index=='ago' )
           {
               $this->series_ = $w->series_ref;
               
                //echo ' size = '.sizeof($w->series_ref);
               //echo ' start date : '.$this->startdate; 
                   
               $p = new Formula();
               $this->opportunity =   $cmd_leads['ago'][$ago]['opportunity'];
               $this->sourcetype  =   $cmd_leads['ago'][$ago]['source'];    
               if ( $back=='1week' )
                  $this->detail      =   $cmd_leads['ago']['detail'];
               else
                  $this->detail      =   $cmd_leads['ago']['detail'];
               
              
               if ( $back=='1week'  )  
                   $where = ' GROUP BY
                            created,day,dayname
                             ORDER BY created,day,dayname';
                else if ( $back=='1month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
               else if ( $back=='3month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
                   
                  // echo $back;
                 //echo $ago."-".$back."<p>";
                $this->cmd = $cmd_leads['ago'][$ago][$back].$where;
                    //echo $this->cmd;
                   //echo $cmd_leads['ago'][$ago][$back];
                //echo 'sql = '.$this->cmd;   
                   //echo $p->fromdat;
                //$this->backdate    = $p->fromdat;
                //$this->enddate     = $p->todat;
                //$this->begin_date  = $p->begindate;
                //$this->begin_month = $p->start_3month;
                //echo "sql = ".$this->cmd; 
                //   echo $this->backdate.'-'.$this->enddate;
               // echo $this->cmd;
                return  $this->cmd;
                
           }
           else if ( $index=='today')
           {
               $this->detail =  $cmd_leads['today']['detail'];
               return  $cmd_leads['today']['total'];
           }
          
             
       }
    public function Customers($index='day',$ago='',$back='')
    {
        
        $p=new Termago();
        $curweek = $p->getTermCurweek();
        $this->startdate = $p->weekstart;
        
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )     $w = new Intervaltime($interval='week',"cus_created_date");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"cus_created_date");
            
                $this->startdate    = $back !== '1week'?$w->begindate_ref:$p->sevendayago_startdate();
        }
        
        $cmd_customer = array(
          "day"=>array(
            "total"=>
              "SELECT
                    DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,
                    DAY( cus_created_date ) AS day , 
                    DAYNAME( cus_created_date ) AS dayname ,                          
                    COUNT( cus_id ) AS total_cust
                FROM 
                 ".$this->CI->db->database.".tb_customer, 
                 ".$this->CI->db->database.".tb_customer_personal_info
               WHERE 
                 pers_id = cus_pers_id 
                 AND cus_sts_active !=  'off'
                 AND cus_flag != 'leads'
                 AND DATE_FORMAT(cus_created_date,'%Y%m%d')   $curweek ", 
               "age"=>
                "SELECT  
                    date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                    (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as ages,
                    COUNT(cus_id) as total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads' 
                    AND DATE_FORMAT(cus_created_date,'%Y%m%d')   $curweek ", 
            "nationality"=>
                "SELECT  nt_nationality, COUNT(cus_id) as total_cust
                FROM 
                      ".$this->CI->db->database.".tb_customer, 
                      ".$this->CI->db->database.".tb_customer_personal_info,
                      tb_nationality
                WHERE
                      pers_id = cus_pers_id 
                      AND cus_sts_active !=  'off'
                      AND  cus_flag != 'leads' 
                      AND nt_id = pers_nationality
                      AND DATE_FORMAT(cus_created_date,'%Y%m%d')   $curweek ", 
          ),
          "week"=>array(
            "total"=>"
                SELECT 
                 CASE 
                    WHEN DAYOFMONTH( cus_created_date) < 8      THEN  CONCAT('7.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 15   THEN  CONCAT('14.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  CONCAT('21.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )                   
                      WHEN DAYOFMONTH( cus_created_date) < 29   THEN  CONCAT('28.', DATE_FORMAT( cus_created_date ,  '%m.%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(cus_created_date) , 2 ),DATE_FORMAT( cus_created_date ,  '.%m.%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH( cus_created_date) < 8   THEN  '1'
                      WHEN DAYOFMONTH( cus_created_date) < 15  THEN  '2'
                      WHEN DAYOFMONTH( cus_created_date) < 22   THEN  '3' 
                      WHEN DAYOFMONTH( cus_created_date) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                    COUNT( cus_id ) AS total_cust
                FROM 
                   ".$this->CI->db->database.".tb_customer, 
                   ".$this->CI->db->database.".tb_customer_personal_info
                WHERE 
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads'",     
              
            "age"=>"SELECT  date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                    (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as ages,
                    COUNT(cus_id) as total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads' ",                     
           "nationality"=>"SELECT  nt_nationality, COUNT(cus_id) as total_cust
                FROM 
                      ".$this->CI->db->database.".tb_customer, 
                      ".$this->CI->db->database.".tb_customer_personal_info,
                      tb_nationality
                WHERE
                      pers_id = cus_pers_id 
                      AND cus_sts_active !=  'off'
                      AND  cus_flag != 'leads' 
                      AND nt_id = pers_nationality"                      
            
          ),
          "month"=>array(
            "total"=>"
                SELECT 
                     MONTH( cus_created_date) AS month,
                     YEAR( cus_created_date) AS year,
                     COUNT( cus_id ) AS total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer,
                    ".$this->CI->db->database.".tb_customer_personal_info                  
                WHERE 
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads'",
            "age"=>"SELECT  date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                    (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as ages,
                    COUNT(cus_id) as total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads' ",
            "nationality"=>"SELECT  nt_nationality, COUNT(cus_id) as total_cust
                FROM 
                      ".$this->CI->db->database.".tb_customer, 
                      ".$this->CI->db->database.".tb_customer_personal_info,
                      ".$this->CI->db->database.".tb_nationality
                WHERE
                      pers_id = cus_pers_id 
                      AND cus_sts_active !=  'off'
                      AND  cus_flag != 'leads' 
                      AND nt_id = pers_nationality" 
          ),
          "ago"=>array(
              "week"=>array(
                  "1week" =>
                       "SELECT 
                          DATE_FORMAT(cus_created_date,'%Y-%m-%d' ) AS  created,
                         DAY( cus_created_date ) AS day , 
                         DAYNAME( cus_created_date ) AS dayname ,                          
                         COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_customer_personal_info, 
                          ".$this->CI->db->database.".tb_nationality
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'
                          AND nt_id = pers_nationality 
                          AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago(),             
                  "2week" =>
                       "SELECT 
                          cus_created_date,
                          DAY( cus_created_date ) AS day , 
                          DAYNAME( cus_created_date ) AS dayname , 
                          COUNT( cus_id ) AS total_cust
                        FROM       
                           ".$this->CI->db->database.".tb_customer, 
                           ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'",
                  
               "age"=>"SELECT  date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                    (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as ages,
                    COUNT(cus_id) as total_cust
                    FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info,
                    ".$this->CI->db->database.".tb_nationality
               WHERE
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads' 
                    AND nt_id = pers_nationality
                    AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago(). " GROUP BY ages  ",             
               "nationality"=>"SELECT  nt_nationality, COUNT(cus_id) as total_cust
                FROM 
                      ".$this->CI->db->database.".tb_customer, 
                      ".$this->CI->db->database.".tb_customer_personal_info,
                      ".$this->CI->db->database.".tb_nationality
                WHERE
                      pers_id = cus_pers_id 
                      AND cus_sts_active !=  'off'
                      AND  cus_flag != 'leads' 
                      AND nt_id = pers_nationality
                      AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN ".$p->sevendayago(). " GROUP BY  nt_nationality "),
               "month"=> array(
                  "1month" =>
                       "SELECT 
                           
                           CASE".$w->when.
                             
                           " END  AS  week, COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'
                          AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "3month" =>
                       "SELECT                                                      
                           CASE".$w->when.
                           " END  AS  week, COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'
                          AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "6month" =>
                       "SELECT 
                           CASE".$w->when.
                           " END  AS  week, COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_customer_personal_info,                 
                          ".$this->CI->db->database.".tb_countries
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'
                          AND cus_created_date BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",                  
                     "age"=>"SELECT  date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                    (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as ages,
                    COUNT(cus_id) as total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE
                    pers_id = cus_pers_id 
                    AND cus_sts_active = 'on'  
                    AND cus_flag != 'leads' 
                    AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() 
                    GROUP BY ages  ",
            "nationality"=>"SELECT  nt_nationality,COUNT(cus_id) as total_cust
                FROM 
                      ".$this->CI->db->database.".tb_customer, 
                      ".$this->CI->db->database.".tb_customer_personal_info,
                      tb_nationality
                WHERE
                      pers_id = cus_pers_id 
                      AND cus_sts_active !=  'off'
                      AND  cus_flag != 'leads' 
                      AND nt_id = pers_nationality
                      AND DATE_FORMAT(cus_created_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() 
                      GROUP BY nt_nationality "),
              "year"=>array(
                  "1year" =>
                       "SELECT 
                         MONTH( cus_created_date ) AS month , 
                         MONTHNAME( cus_created_date ) AS monthname , 
                         YEAR( cus_created_date ) AS year, 
                         COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'", 
                  "3year" =>
                       "SELECT 
                         SELECT 
                         CEIL( MONTH( cus_created_date ) /6 ) AS month, 
                         YEAR( cus_created_date ) AS year, 
                         COUNT( cus_id ) AS total_cust
                        FROM       
                          ".$this->CI->db->database.".tb_customer, 
                          ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          pers_id = cus_pers_id 
                          AND cus_sts_active !=  'off'
                          AND cus_flag != 'leads'", 
                  
                    "age"=>"SELECT  date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                    (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as ages,
                    COUNT(cus_id) as total_cust
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info
                WHERE
                    pers_id = cus_pers_id 
                    AND cus_sts_active !=  'off'
                    AND cus_flag != 'leads' ",
            "nationality"=>"SELECT  nt_nationality,date_format(now(), '%Y') - date_format(pers_dob, '%Y') - 
                     (date_format(now(), '00-%m-%d') < date_format(pers_dob, '00-%m-%d')) as location,
                     COUNT(cus_id) as total_cust
                FROM 
                      ".$this->CI->db->database.".tb_customer, 
                      ".$this->CI->db->database.".tb_customer_personal_info,
                      ".$this->CI->db->database.".tb_nationality
                WHERE
                      pers_id = cus_pers_id 
                      AND cus_sts_active !=  'off'
                      AND  cus_flag != 'leads' 
                      AND nt_id = pers_nationality" 
              )
          ),
              "detail"=>
               "SELECT distinct
                    cus_created_date,
                    pers_fname,
                    pers_lname,
                    pers_mobile,
                    pers_tel,
                    pers_email
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info,                 
                    ".$this->CI->db->database.".tb_countries
                WHERE 
                    cus_pers_id = pers_id
                    AND cus_sts_active !=  'off'
                    AND country_id = pers_nationality
                    AND cus_flag !=  'leads'"
          ,
              "today"=>array(
               "total"=>"
               SELECT
                    DATE_FORMAT(cus_created_date,'%Y-%m-%d' )  AS created,                    
                    COUNT( cus_id ) AS total_cust 
                FROM 
                 ".$this->CI->db->database.".tb_customer, 
                 ".$this->CI->db->database.".tb_customer_personal_info,                 
                 ".$this->CI->db->database.".tb_countries
               WHERE 
                 cus_pers_id = pers_id
                 AND cus_sts_active !=  'off'
                 AND country_id = pers_nationality
                 AND cus_flag !=  'leads'
                 AND DATE_FORMAT(cus_created_date,'%Y%m%d') = DATE_FORMAT(CURDATE(),'%Y%m%d') 
                 GROUP BY created ",
               "detail"=>"
               SELECT distinct
                 cus_created_date,
                 pers_fname,
                 pers_lname,
                 pers_mobile,
                 pers_tel,
                 pers_email
                FROM 
                 ".$this->CI->db->database.".tb_customer, 
                 ".$this->CI->db->database.".tb_customer_personal_info,                 
                 ".$this->CI->db->database.".tb_countries
                WHERE 
                 cus_pers_id = pers_id
                 AND cus_sts_active !=  'off'
                 AND country_id = pers_nationality
                 AND cus_flag !=  'leads'
                 AND DATE_FORMAT(cus_created_date,'%Y%m%d') = DATE_FORMAT(CURDATE(),'%Y%m%d') ")
        
          
         
       );
        
       if (  $index=='day') 
       {
           $this->detail = !empty($this->longtime)?$cmd_customer['detail'].' AND cus_created_date BETWEEN '.$this->longtime:
             $cmd_customer['day']['detail'].'  ORDER BY created,day,dayname';
           $this->nationality = !empty($this->longtime)?$cmd_customer['day']['nationality'].
             ' AND cus_created_date BETWEEN '.$this->longtime.' GROUP BY nt_nationality ':
             $cmd_customer['day']['nationality'].'
               GROUP BY nt_nationality ';
           
          
           $this->ages = !empty($this->longtime)?$cmd_customer['day']['age'].' AND cus_created_date BETWEEN '.$this->longtime.
             ' GROUP BY ages ':$cmd_customer['day']['age'].'
               GROUP BY ages ';
           $this->cmd = !empty($this->longtime)?$cmd_customer['day']['total'].' AND cus_created_date BETWEEN '.$this->longtime.
            ' GROUP BY created,day,dayname ORDER BY created,day,dayname ':$cmd_customer['day']['total'].
             '   GROUP BY created,day,dayname ORDER BY created,day,dayname';
           return !empty($this->longtime)?$cmd_customer['day']['total'].' AND cus_created_date BETWEEN '.$this->longtime.
            ' GROUP BY created,day,dayname ORDER BY created,day,dayname ':$cmd_customer['day']['total'].
             '   GROUP BY created,day,dayname ORDER BY created,day,dayname';
       }
       else if (  $index=='week') 
       {
           $this->detail = !empty($this->longtime)?$cmd_customer['detail'].' AND cus_created_date BETWEEN '.$this->longtime:
             $cmd_customer['week']['detail'].' 
               AND MONTH(cus_created_date)  = MONTH(CURDATE())-1
               AND YEAR(cus_created_date)   = YEAR(CURDATE()) ';
               
           $this->nationality = !empty($this->longtime)?$cmd_customer['week']['nationality'].
             ' AND cus_created_date BETWEEN '.$this->longtime.' GROUP BY nt_nationality ':
             $cmd_customer['week']['nationality'].' 
               AND MONTH(cus_created_date)  = MONTH(CURDATE())-1
               AND YEAR(cus_created_date)   = YEAR(CURDATE()) 
               GROUP BY nt_nationality ';
           
               
           $this->ages = !empty($this->longtime)?$cmd_customer['week']['age'].' AND cus_created_date BETWEEN '.$this->longtime.
             ' GROUP BY ages ':$cmd_customer['week']['age'].
             ' 
               AND MONTH(cus_created_date)  = MONTH(CURDATE())-1
               AND YEAR(cus_created_date)   = YEAR(CURDATE()) 
               GROUP BY ages  ';
           
           $this->cmd = !empty($this->longtime)?$cmd_customer['week']['total'].' AND cus_created_date BETWEEN '.$this->longtime.' GROUP BY week,month,year ORDER BY week,month,year ':$cmd_customer['week']['total'].
             ' AND MONTH(cus_created_date) = MONTH(CURDATE())
               AND YEAR(cus_created_date) = YEAR(CURDATE())
               GROUP BY dat,weekno ORDER BY dat,weekno ';
               
           return !empty($this->longtime)?$cmd_customer['week']['total'].' AND cus_created_date BETWEEN '.$this->longtime.' GROUP BY week,month,year ORDER BY week,month,year ':$cmd_customer['week']['total'].
             ' AND MONTH(cus_created_date) = MONTH(CURDATE())-1
               AND YEAR(cus_created_date) = YEAR(CURDATE())
               GROUP BY dat,weekno ORDER BY dat,weekno ';
       }
       else if (  $index=='month') 
       {
           $this->detail = !empty($this->longtime)?$cmd_customer['detail'].' AND cus_created_date BETWEEN '.$this->longtime:
             $cmd_customer['detail'].'               
               AND YEAR(cus_created_date)   = YEAR(CURDATE()) -1';
           $this->cmd = !empty($this->longtime)?$cmd_customer['month']['total'].' AND cus_created_date BETWEEN '.$this->longtime.
             ' GROUP BY month,year
               ORDER BY month,year ':$cmd_customer['month']['total'].
             ' 
               AND YEAR(cus_created_date)   = YEAR(CURDATE()) 
               GROUP BY month,year 
               ORDER BY month,year ';
           $this->nationality = !empty($this->longtime)?$cmd_customer['month']['nationality'].
             ' AND cus_created_date BETWEEN '.$this->longtime.' GROUP BY nt_nationality ':
             $cmd_customer['month']['nationality'].' 
             
               AND YEAR(cus_created_date)   = YEAR(CURDATE()) -1
               GROUP BY nt_nationality ';
           
           
           $this->ages = !empty($this->longtime)?$cmd_customer['month']['age'].' AND cus_created_date BETWEEN '.$this->longtime.
             ' GROUP BY ages ':$cmd_customer['month']['age'].
             ' 
              
               AND YEAR(cus_created_date)   = YEAR(CURDATE())-1 
               GROUP BY ages  ';
           return !empty($this->longtime)?$cmd_customer['month']['total'].' AND cus_created_date BETWEEN '.$this->longtime.
             ' GROUP BY month,year
               ORDER BY month,year ':$cmd_customer['month']['total'].
             ' 
               AND YEAR(cus_created_date)   = YEAR(CURDATE())-1
               GROUP BY month,year 
               ORDER BY year,month ';
       }
       else if ( $index=='ago' )
       {
            $this->series_ = $w->series_ref;
            //echo 'Test size of series ? '.sizeof($this->series_);
            $p = new Formula();
            $this->nationality = $cmd_customer['ago'][$ago]['nationality'];  
            $this->ages = $cmd_customer['ago'][$ago]['age'];
           
             if ( $back=='1week')
              $this->detail =      $cmd_leadcmd_customer['ago']['detail'];
             else
              $this->detail =      $cmd_leadcmd_customer['ago']['detail'];
           
             if ( $back=='1week' )  
                  $where = ' GROUP BY
                             created,day,dayname
                             ORDER BY created,day,dayname';
             else if ( $back=='1month' )
                 $where = ' GROUP BY week
                            ORDER BY week ';
             else if ( $back=='3month' )
                 $where = ' GROUP BY week
                            ORDER BY week ';
                   
               
                //   echo 'agoes = '.$ago.',back='.$w->when;
            //    echo 'array:'. $cmd_customer['ago'][$ago][$back];
               $this->cmd =  $cmd_customer['ago'][$ago][$back].$where;      
               $this->backdate = $p->fromdat;
               $this->enddate = $p->todat;
               //echo $this->nationality;
               return  $this->cmd;
                   
       }
       else if ( $index=='today')
       {
               $this->detail =  $cmd_customer['today']['detail'];
               return  $cmd_customer['today']['total'];
       }
       
    }
    
           
    public function Quatations($index='day',$ago='',$back)
    {
        
        $p=new Termago();
        $curweek = $p->getTermCurweek();
        $this->startdate = $p->weekstart;
        
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )          $w = new Intervaltime($interval='week',"qt_date");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"qt_date");
            
            $this->startdate    = $back !== '1week'?$w->begindate_ref:$p->sevendayago_startdate();
        }
        $cmd_quatation = array(
         "day"=>array(
            "total"=>
              "SELECT 
                 DATE_FORMAT(qt_date,'%Y-%m-%d')  AS created,
                 DAY( qt_date ) AS day , 
                 DAYNAME( qt_date ) AS dayname ,                          
                 COUNT( qt_id ) AS total_qt
              FROM 
                 ".$this->CI->project_database_sel.".tb_quotation, 
                 ".$this->CI->db->database.".tb_project,
                 ".$this->CI->db->database.".tb_customer,
                 ".$this->CI->db->database.".tb_customer_personal_info
              WHERE 
                 qt_project_id = pj_id
                  AND qt_leads_id = cus_id
                  AND pers_id = cus_pers_id
                  AND cus_sts_active =  'on'
                  AND cus_flag !=  'leads'
                  AND qt_project_id = ".$this->CI->project_id_sel."
                  AND DATE_FORMAT(qt_date,'%Y%m%d')  $curweek "),
         "week"=>array(
            "total"=>
               "SELECT 
                  CASE 
                      WHEN DAYOFMONTH(qt_date) < 8   THEN  CONCAT('7.', DATE_FORMAT(qt_date,  '%m.%Y') )
                      WHEN DAYOFMONTH(qt_date) < 15  THEN  CONCAT('14.', DATE_FORMAT(qt_date,  '%m.%Y') )
                      WHEN DAYOFMONTH(qt_date) < 22  THEN  CONCAT('21.', DATE_FORMAT(qt_date,  '%m.%Y') )                   
                      WHEN DAYOFMONTH(qt_date) < 29   THEN  CONCAT('28.', DATE_FORMAT(qt_date ,  '%m.%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(qt_date) , 2 ),DATE_FORMAT(qt_date,  '.%m.%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH(qt_date) < 8   THEN  '1'
                      WHEN DAYOFMONTH(qt_date) < 15  THEN  '2'
                      WHEN DAYOFMONTH(qt_date) < 22  THEN  '3' 
                      WHEN DAYOFMONTH(qt_date) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                  COUNT(qt_id) AS total_qt
               FROM 
                  ".$this->CI->project_database_sel.".tb_quotation, 
                  ".$this->CI->db->database.".tb_project,
                  ".$this->CI->db->database.".tb_customer,
                  ".$this->CI->db->database.".tb_customer_personal_info
               WHERE 
                  qt_project_id = pj_id
                  AND qt_leads_id = cus_id
                  AND pers_id = cus_pers_id
                  AND cus_sts_active =  'on'
                  AND qt_project_id = ".$this->CI->project_id_sel."
                  AND cus_flag !=  'leads' ",            
          ),
         "month"=>array(
            "total"=>
               "SELECT 
                  COUNT(qt_id) AS total_qt,
                  MONTH(qt_date) AS month,
                  YEAR(qt_date) AS year
               FROM 
                  ".$this->CI->project_database_sel.".tb_quotation, 
                  ".$this->CI->db->database.".tb_project,
                  ".$this->CI->db->database.".tb_customer,
                  ".$this->CI->db->database.".tb_customer_personal_info
               WHERE 
                  qt_project_id = pj_id
                  AND qt_leads_id = cus_id
                  AND pers_id = cus_pers_id
                  AND cus_sts_active =  'on'
                  AND qt_project_id = ".$this->CI->project_id_sel."
                  AND cus_flag !=  'leads'"),
           "ago"=>array(
              "week"=>array(
                  "1week"=>
                    "SELECT 
                       DATE_FORMAT(qt_date,'%Y-%m-%d')  AS created,
                       DAY( qt_date ) AS day , 
                       DAYNAME( qt_date ) AS dayname , 
                       COUNT( qt_id ) AS total_qt
                     FROM 
                       ".$this->CI->project_database_sel.".tb_quotation, 
                       ".$this->CI->db->database.".tb_project,
                       ".$this->CI->db->database.".tb_customer,
                       ".$this->CI->db->database.".tb_customer_personal_info
                     WHERE 
                       qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                          AND cus_flag !=  'leads'
                           AND qt_project_id = ".$this->CI->project_id_sel."
                       AND DATE_FORMAT(qt_date,'%Y%m%d') BETWEEN ".$p->sevendayago() ,
                  "2week"=>
                     "SELECT 
                       qt_date,
                       DAY( qt_date ) AS day , 
                       DAYNAME( qt_date ) AS dayname , 
                       COUNT( qt_id ) AS total_qt
                     FROM 
                       ".$this->CI->project_database_sel.".tb_quotation, 
                       ".$this->CI->db->database.".tb_project,
                       ".$this->CI->db->database.".tb_customer,
                       ".$this->CI->db->database.".tb_customer_personal_info
                     WHERE 
                       qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                          AND cus_flag !=  'leads'
                          AND qt_project_id = ".$this->CI->project_id_sel."
                          AND DATE_FORMAT(qt_date,'%Y%m%d') BETWEEN ".$p->sevendayago() ,
              ),
              "month"=>array(
                  "1month"=>
                      "SELECT                            
                           CASE ".$w->when.
                           " END AS  week, COUNT( cus_id ) AS total_qt
                       FROM 
                         ".$this->CI->project_database_sel.".tb_quotation, 
                         ".$this->CI->db->database.".tb_project,
                         ".$this->CI->db->database.".tb_customer,
                         ".$this->CI->db->database.".tb_customer_personal_info
                       WHERE 
                         qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                          AND cus_flag !=  'leads'
                           AND qt_project_id = ".$this->CI->project_id_sel."
                         AND DATE_FORMAT(qt_date,'%Y%m%d') BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "3month"=>
                      "SELECT 
                           CASE  ".$w->when.                          
                           " END  AS  week, COUNT( cus_id ) AS total_qt
                        FROM       
                           ".$this->CI->project_database_sel.".tb_quotation, 
                         ".$this->CI->db->database.".tb_project,
                         ".$this->CI->db->database.".tb_customer,
                         ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                          AND cus_flag !=  'leads'
                           AND qt_project_id = ".$this->CI->project_id_sel."
                          AND qt_date BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "6month"=>
                      "SELECT 
                           MONTH( qt_date ) AS month,
                           YEAR( qt_date ) AS year,
                           COUNT( cus_id ) AS total_cust
                        FROM       
                           ".$this->CI->project_database_sel.".tb_quotation, 
                         ".$this->CI->db->database.".tb_project,
                         ".$this->CI->db->database.".tb_customer,
                         ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                           AND qt_project_id = ".$this->CI->project_id_sel."
                          AND cus_flag !=  'leads'"
              ),
              "year"=>array(
                  "1year"=>
                    "SELECT 
                         MONTH( qt_date ) AS month , 
                         MONTHNAME( qt_date ) AS monthname , 
                         YEAR( qt_date ) AS year, 
                         COUNT( cus_id ) AS total_cust
                        FROM       
                           ".$this->CI->project_database_sel.".tb_quotation, 
                         ".$this->CI->db->database.".tb_project,
                         ".$this->CI->db->database.".tb_customer,
                         ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                           AND qt_project_id = ".$this->CI->project_id_sel."
                          AND cus_flag !=  'leads'",
                  "3year"=>"SELECT 
                         SELECT 
                         CEIL( MONTH( qt_date ) /6 ) AS month, 
                         YEAR( qt_date ) AS year, 
                         COUNT( cus_id ) AS total_cust
                        FROM       
                           ".$this->CI->project_database_sel.".tb_quotation, 
                         ".$this->CI->db->database.".tb_project,
                         ".$this->CI->db->database.".tb_customer,
                         ".$this->CI->db->database.".tb_customer_personal_info
                        WHERE 
                          qt_project_id = pj_id
                          AND qt_leads_id = cus_id
                          AND pers_id = cus_pers_id
                          AND cus_sts_active =  'on'
                           AND qt_project_id = ".$this->CI->project_id_sel."
                          AND cus_flag !=  'leads'", 
              )
           ),
           
         "detail"=> 
           "SELECT 
              qt_date,
              qt_code,
              pj_name,
              pers_fname,
              pers_lname,
              pers_mobile,
              pers_tel,
              pers_email,
              nt_nationality,              
              building_name,
              fl_name,
              un_number,
              un_name,
              unit_type_name,
              unit_type_area_sqm,
              unit_type_area_sqft,
              un_direction,
              qt_sale_id
           FROM 
              ".$this->CI->project_database_sel.".tb_quotation
                  INNER JOIN 
              ".$this->CI->db->database.".tb_customer
                  ON ( (qt_leads_id = cus_id )
                   LEFT JOIN 
                  ".$this->CI->db->database.".tb_customer_personal_info
                   ON (cus_id = pers_id)
                  ".$this->CI->db->database.".tb_nationality
                   ON (pers_nationality = nt_id) )
                  INNER JOIN 
                  $databasename.tb_building 
                  ON (( qt_buliding_id = building_id )
                  INNER JOIN 
                  $databasename.tb_floor
                  ON ((fl_build_id=building_id)
                  INNER JOIN 
                  $databasename.tb_unit_number
                  ON (un_build_id = building_id)
                  AND (un_floor_id =fl_id ) )
                  INNER JOIN 
                  $databasename.tb_unit_type
                  ON (un_unit_type_id=unit_type_id))
                  WHERE  
                    qt_project_id = ".$this->CI->project_id_sel."
                   AND DATE_FORMAT(qt_date,'%Y%m%d') BETWEEN ".$p->getFormula($ago,$back),
            "today"=>array(
               "total"=>"SELECT 
                 DATE_FORMAT(qt_date,'%Y-%m-%d')  AS created,
                 COUNT( qt_id ) AS total_qt
              FROM 
                 ".$this->CI->project_database_sel.".tb_quotation, 
                 ".$this->CI->db->database.".tb_project,
                 ".$this->CI->db->database.".tb_customer,
                 ".$this->CI->db->database.".tb_customer_personal_info
              WHERE 
                 pers_id = cus_pers_id 
                 AND cus_sts_active = 'on'  
                 AND qt_leads_id = cus_id 
                  AND qt_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( qt_date,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' )
                 GROUP BY created ",                 
               "detail"=>"
                SELECT 
                 qt_date,
                 qt_code,
                 pj_name,
                 pers_fname,
                 pers_lname,
                 pers_mobile,
                 pers_tel,
                 pers_email,
                 nt_nationality,              
                 building_name,
                 fl_name,
                 un_number,
                 un_name,
                 unit_type_name,
                 unit_type_area_sqm,
                 unit_type_area_sqft,
                 un_direction,
                 qt_sale_id
                FROM 
                  ".$this->CI->project_database_sel.".tb_quotation
                  INNER JOIN 
                  ".$this->CI->db->database.".tb_customer
                  ON ( (qt_leads_id = cus_id )
                   LEFT JOIN 
                  ".$this->CI->db->database.".tb_customer_personal_info
                   ON (cus_id = pers_id)
                  ".$this->CI->db->database.".tb_nationality
                   ON (pers_nationality = nt_id) )
                  INNER JOIN 
                  $databasename.tb_building 
                  ON (( qt_buliding_id = building_id )
                  INNER JOIN 
                  $databasename.tb_floor
                  ON ((fl_build_id=building_id)
                  INNER JOIN 
                  $databasename.tb_unit_number
                  ON (un_build_id = building_id)
                  AND (un_floor_id =fl_id ) )
                  INNER JOIN 
                  $databasename.tb_unit_type
                  ON (un_unit_type_id=unit_type_id))
                  WHERE  
                   qt_project_id = ".$this->CI->project_id_sel."
                   AND DATE_FORMAT( qt_date,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' ) " )
           
       );
       
       if ( $index=='day' )
       {
           $this->detail = !empty($this->longtime)?$cmd_quatation['detail'].
               ' WHERE qt_date BETWEEN '.$this->longtime:
               $cmd_quatation['detail'].' ORDER BY created,day,dayname ';
           $this->cmd = 
               !empty($this->longtime)?$cmd_quatation['day']['total'].
               ' AND qt_date BETWEEN '.$this->longtime.' GROUP BY week,dat ORDER BY  week,dat ':
               $cmd_quatation['day']['total'].'
                 GROUP BY created,day,dayname ORDER BY created,day,dayname  ';
           
           return !empty($this->longtime)?$cmd_quatation['day']['total'].
               ' AND qt_date BETWEEN '.$this->longtime.' GROUP BY week,dat ORDER BY  week,dat ':
               $cmd_quatation['day']['total'].'
                 GROUP BY created,day,dayname ORDER BY created,day,dayname  ';
       }
       else if ( $index=='week' )
       {
           $this->detail = !empty($this->longtime)?$cmd_quatation['detail'].
               ' WHERE qt_date BETWEEN '.$this->longtime:
               $cmd_quatation['detail'].' WHERE                 
                 MONTH(qt_date) = MONTH(CURDATE())-1
                 AND YEAR(qt_date)  = YEAR(CURDATE())';
           $this->cmd = 
               !empty($this->longtime)?$cmd_quatation['week']['total'].
               ' AND qt_date BETWEEN '.$this->longtime.' GROUP BY week,month,year ORDER BY week,month,year ':
               $cmd_quatation['week']['total'].' 
                   AND MONTH(qt_date) = MONTH(CURDATE())
                   AND YEAR(qt_date)  = YEAR(CURDATE())
                 GROUP BY dat,weekno ORDER BY dat,weekno';
           
           return !empty($this->longtime)?$cmd_quatation['week']['total'].
               ' AND qt_date BETWEEN '.$this->longtime.' GROUP BY week,month,year ORDER BY week,month,year ':
               $cmd_quatation['week']['total'].' 
                   AND MONTH(qt_date) = MONTH(CURDATE())-1
                   AND YEAR(qt_date)  = YEAR(CURDATE())
                 GROUP BY dat,weekno ORDER BY dat,weekno';
       }
       else if ( $index=='month' )
       {
           $this->detail = !empty($this->longtime)?$cmd_quatation['detail'].
               ' WHERE qt_date BETWEEN '.$this->longtime:
               $cmd_quatation['detail'].' WHERE 
                
                
                  YEAR(qt_date)  = YEAR(CURDATE())';
           $this->cmd = 
               !empty($this->longtime)?$cmd_quatation['month']['total'].
               ' AND qt_date BETWEEN '.$this->longtime.' GROUP BY month,year ORDER BY month,year ':
               $cmd_quatation['month']['total'].'
                   
                   AND YEAR(qt_date)  = YEAR(CURDATE())
                 GROUP BY month,year ORDER BY month,year ';
           return !empty($this->longtime)?$cmd_quatation['month']['total'].
               ' AND qt_date BETWEEN '.$this->longtime.' GROUP BY month,year ORDER BY month,year ':
               $cmd_quatation['month']['total'].' 
                   
                   AND YEAR(qt_date)  = YEAR(CURDATE())-1
                 GROUP BY month,year ORDER BY year,month ';
       }    
       else if ( $index=='ago' )
       {
           $this->series_ = $w->series_ref;
           ///$p = new Formula();
           $this->detail = $cmd_quatation['detail'];// ' AND  qt_date BETWEEN '.$p->getFormula($ago,$back);
           if ( $back=='1week' )  
                  $where = ' GROUP BY
                             created,day,dayname
                             ORDER BY created,day,dayname';
               else if ( $back=='1month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
               else if ( $back=='3month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
               //echo     $cmd_quatation['ago'][$ago][$back];
               $this->cmd =   $cmd_quatation['ago'][$ago][$back].$where;        
               $this->backdate = $p->fromdat;
               $this->enddate = $p->todat;
                 
               //echo $this->cmd;
               return  $this->cmd;
                   
       }
       else if ( $index=='today')
       {
               $this->detail =  $cmd_quatation['today']['detail'];
               return  $cmd_quatation['today']['total'];
       }
        
    }
    
    
    public function Bookings($index='day',$ago='',$back)
    {                 
        
        $p=new Termago();
        $curweek = $p->getTermCurweek();
        $this->startdate = $p->weekstart;
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )          $w = new Intervaltime($interval='week',"bk_date_booking");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"bk_date_booking");
            
            $this->startdate    = $back !== '1week'?$w->begindate_ref:$p->sevendayago_startdate();
        }
        
        $cmd_booking = array(
         "day"=>array(
            "total"=>
                "SELECT  
                 DATE_FORMAT(bk_date_booking,'%Y-%m-%d' )  AS created,
                 DAY(bk_date_booking) AS day , 
                 DAYNAME(bk_date_booking) AS dayname ,                                           
                 COUNT( bk_booking_id ) AS total_booking
				FROM 
                 ".$this->CI->project_database_sel.".tb_booking, 
                 ".$this->CI->db->database.".tb_customer, 
				 ".$this->CI->db->database.".tb_customer_personal_info 
				WHERE 
                 pers_id = cus_pers_id 
                 AND bk_leads_id = cus_id 
                 AND bk_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( bk_date_booking,  '%Y%m%d' )   $curweek ", 
                 ),         
         "week"=>array(
            "total"=>
                "SELECT 
                  CASE 
                    WHEN DAYOFMONTH(bk_date_booking) < 8     THEN  CONCAT('7.',  DATE_FORMAT(bk_date_booking,  '%m.%Y') )
                      WHEN DAYOFMONTH(bk_date_booking) < 15  THEN  CONCAT('14.', DATE_FORMAT(bk_date_booking,  '%m.%Y') )
                      WHEN DAYOFMONTH(bk_date_booking) < 22  THEN  CONCAT('21.', DATE_FORMAT(bk_date_booking,  '%m.%Y') )                   
                      WHEN DAYOFMONTH(bk_date_booking) < 29  THEN  CONCAT('28.', DATE_FORMAT(bk_date_booking ,  '%m.%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(bk_date_booking) , 2 ),DATE_FORMAT(bk_date_booking,  '.%m.%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH(bk_date_booking) < 8   THEN  '1'
                      WHEN DAYOFMONTH(bk_date_booking) < 15  THEN  '2'
                      WHEN DAYOFMONTH(bk_date_booking) < 22  THEN  '3' 
                      WHEN DAYOFMONTH(bk_date_booking) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                  COUNT(bk_booking_id) AS total_booking
				FROM 
                  ".$this->CI->project_database_sel.".tb_booking, 
                  ".$this->CI->db->database.".tb_customer, 
				  ".$this->CI->db->database.".tb_customer_personal_info 
				WHERE 
                  pers_id = cus_pers_id 
                  AND bk_leads_id =  cus_id "),         
         "month"=>array(
            "total"=>
                "SELECT 
                  COUNT(bk_booking_code) AS total_booking,
                  MONTH(bk_date_booking) AS month,
                  YEAR(bk_date_booking) AS year
				FROM 
                  ".$this->CI->project_database_sel.".tb_booking, 
                  ".$this->CI->db->database.".tb_customer, 
				  ".$this->CI->db->database.".tb_customer_personal_info 
				WHERE 
                  pers_id = cus_pers_id 
                  AND bk_project_id = ".$this->CI->project_id_sel."
                  AND bk_leads_id =  cus_id "), 
            "ago"=>array(
              "week"=>array(
                  "1week"=>
                    "SELECT 
                       DATE_FORMAT(bk_date_booking,'%Y-%m-%d')  AS created,
                       DAY( bk_date_booking ) AS day , 
                       DAYNAME( bk_date_booking ) AS dayname , 
                       COUNT( bk_booking_id ) AS total_booking
                   FROM 
                     ".$this->CI->project_database_sel.".tb_booking, 
                     ".$this->CI->db->database.".tb_customer, 
				     ".$this->CI->db->database.".tb_customer_personal_info 
				   WHERE 
                     pers_id = cus_pers_id 
                     AND bk_leads_id = cus_id
                     AND bk_project_id = ".$this->CI->project_id_sel."
                     AND DATE_FORMAT( bk_date_booking,  '%Y%m%d' ) BETWEEN ".$p->sevendayago() ,         
                  "2week"=>
                     "SELECT 
                       bk_date_booking,
                       DAY( bk_date_booking ) AS day , 
                       DAYNAME( bk_date_booking ) AS dayname , 
                       COUNT( bk_booking_id ) AS total_booking
                   FROM 
                     ".$this->CI->project_database_sel.".tb_booking, 
                     ".$this->CI->db->database.".tb_customer, 
				     ".$this->CI->db->database.".tb_customer_personal_info 
				   WHERE 
                     pers_id = cus_pers_id 
                     AND bk_project_id = ".$this->CI->project_id_sel."
                     AND bk_leads_id = cus_id"       
               
              ),
              "month"=>array(
                  "1month"=>
                      "SELECT 
                           CASE ".$w->when.
                           " END  AS  week, COUNT( bk_booking_id ) AS total_booking
                     FROM 
                        ".$this->CI->project_database_sel.".tb_booking, 
                        ".$this->CI->db->database.".tb_customer, 
				        ".$this->CI->db->database.".tb_customer_personal_info 
				     WHERE 
                        pers_id = cus_pers_id 
                        AND bk_leads_id = cus_id
                        AND bk_project_id = ".$this->CI->project_id_sel."
                        AND DATE_FORMAT( bk_date_booking,  '%Y%m%d' ) BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",         
                  "3month"=>
                      "SELECT 
                           CASE ".$w->when.
                           " END  AS  week, COUNT( bk_booking_id ) AS total_booking
                      FROM 
                        ".$this->CI->project_database_sel.".tb_booking, 
                        ".$this->CI->db->database.".tb_customer, 
				        ".$this->CI->db->database.".tb_customer_personal_info 
				     WHERE 
                        pers_id = cus_pers_id 
                        AND bk_leads_id = cus_id
                        AND bk_project_id = ".$this->CI->project_id_sel."
                        AND DATE_FORMAT( bk_date_booking,  '%Y%m%d' ) BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",         
                  "6month"=>
                      "SELECT 
                           MONTH( bk_date_booking ) AS month,
                           YEAR( bk_date_booking ) AS year,
                           COUNT( bk_booking_id ) AS total_booking
                        FROM 
                        ".$this->CI->project_database_sel.".tb_booking, 
                        ".$this->CI->db->database.".tb_customer, 
				        ".$this->CI->db->database.".tb_customer_personal_info 
				     WHERE 
                        pers_id = cus_pers_id 
                        AND bk_project_id = ".$this->CI->project_id_sel."
                        AND bk_leads_id = cus_id",         
              ),
              "year"=>array(
                  "1year"=>
                    "SELECT 
                         MONTH( bk_date_booking ) AS month , 
                         MONTHNAME( bk_date_booking ) AS monthname , 
                         YEAR( bk_date_booking ) AS year, 
                         COUNT( bk_booking_id ) AS total_booking
                    FROM 
                        ".$this->CI->project_database_sel.".tb_booking, 
                        ".$this->CI->db->database.".tb_customer, 
				        ".$this->CI->db->database.".tb_customer_personal_info 
				     WHERE 
                        pers_id = cus_pers_id 
                        AND bk_project_id = ".$this->CI->project_id_sel."
                        AND bk_leads_id = cus_id",         
                  "3year"=>"SELECT 
                         SELECT 
                         CEIL( MONTH( bk_date_booking ) /6 ) AS month, 
                         YEAR( bk_date_booking ) AS year, 
                         COUNT( bk_booking_id ) AS total_booking
                     FROM 
                        ".$this->CI->project_database_sel.".tb_booking, 
                        ".$this->CI->db->database.".tb_customer, 
				        ".$this->CI->db->database.".tb_customer_personal_info 
				     WHERE 
                        pers_id = cus_pers_id 
                        AND bk_project_id = ".$this->CI->project_id_sel."
                        AND bk_leads_id = cus_id"         
               ),
            ),
            "detail"=>
              "SELECT 
                bk_date_booking,
                bk_booking_code,            
                bk_money_amount,
                bk_type_payment,
                qt_date,
                qt_code,
                pers_fname,
                pers_lname, 
                pers_mobile                  
              FROM 
                ".$this->CI->project_database_sel.".tb_booking
                INNER JOIN 
                ".$this->CI->project_database_sel.".tb_quotation
                ON (bk_quotation_code=qt_code)
                INNER JOIN 
                ".$this->CI->db->database.".tb_customer
                ON (bk_leads_id =  cus_id)
                INNER JOIN 
				".$this->CI->db->database.".tb_customer_personal_info 
                ON (pers_id = cus_pers_id) ",
            "today"=>array(
               "total"=>"SELECT  
                 DATE_FORMAT(bk_date_booking,'%Y-%m-%d' )  AS created,                           
                 COUNT( bk_booking_id ) AS total_booking
				FROM 
                 ".$this->CI->project_database_sel.".tb_booking, 
                 ".$this->CI->db->database.".tb_customer, 
				 ".$this->CI->db->database.".tb_customer_personal_info 
				WHERE 
                 pers_id = cus_pers_id 
                 AND bk_leads_id = cus_id 
                 AND bk_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( bk_date_booking,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' )
                 GROUP BY created ",
            "detail"=>
                "SELECT 
                  bk_date_booking,
                  bk_booking_code,            
                  bk_money_amount,
                  bk_type_payment,
                  qt_date,
                  qt_code,
                  pers_fname,
                  pers_lname, 
                  pers_mobile                  
              FROM 
                  ".$this->CI->project_database_sel.".tb_booking
                  INNER JOIN 
                  ".$this->CI->project_database_sel.".tb_quotation
                  ON (bk_quotation_code=qt_code)
                  INNER JOIN 
                  ".$this->CI->db->database.".tb_customer
                  ON (bk_leads_id =  cus_id)
                  INNER JOIN 
				  ".$this->CI->db->database.".tb_customer_personal_info 
                  ON (pers_id = cus_pers_id)
              WHERE
                bk_project_id = ".$this->CI->project_id_sel."
                AND  DATE_FORMAT( bk_date_booking,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' )")
                  
         );
        
        if ( $index=='day') 
        {
            $this->detail = !empty($this->longtime)?$cmd_booking['detail'].
            " WHERE 
            bk_project_id = ".$this->CI->project_id_sel."
            AND bk_date_booking BETWEEN ".$this->longtime:
            $cmd_booking['detail'].' ORDER BY created,day,dayname';    
            $this->cmd =  !empty($this->longtime)?$cmd_booking['day']['total'].
             ' AND bk_date_booking BETWEEN '.$this->longtime.' GROUP BY week,dat  ORDER BY week,dat':
             $cmd_booking['day']['total'].' GROUP BY created,day,dayname ORDER BY created,day,dayname'; 
            
            return 
             !empty($this->longtime)?$cmd_booking['day']['total'].
             ' AND bk_date_booking BETWEEN '.$this->longtime.' GROUP BY week,dat  ORDER BY week,dat':
             $cmd_booking['day']['total'].' GROUP BY created,day,dayname ORDER BY created,day,dayname';    
        }
        else if ( $index=='week') 
        {
            $this->detail = !empty($this->longtime)?$cmd_booking['detail'].
            ' WHERE bk_date_booking BETWEEN '.$this->longtime:
            $cmd_booking['detail'].' WHERE 
               MONTH(bk_date_booking) = MONTH(CURDATE())-1
              AND YEAR(bk_date_booking)  = YEAR(CURDATE())';    
            
            $this->cmd =
             !empty($this->longtime)?$cmd_booking['week']['total'].
             ' AND bk_date_booking BETWEEN '.$this->longtime.' GROUP BY week,month,year':
             $cmd_booking['week']['total'].'
               AND MONTH(bk_date_booking) = MONTH(CURDATE())-1
               AND YEAR(bk_date_booking)  = YEAR(CURDATE())
               GROUP BY dat,weekno ORDER BY dat,weekno';    
            
            return 
             !empty($this->longtime)?$cmd_booking['week']['total'].
             ' AND bk_date_booking BETWEEN '.$this->longtime.' GROUP BY week,month,year':
             $cmd_booking['week']['total'].'
               AND MONTH(bk_date_booking) = MONTH(CURDATE()) -1
               AND YEAR(bk_date_booking)  = YEAR(CURDATE())
               GROUP BY dat,weekno ORDER BY dat,weekno';    
        }
        else if ( $index=='month') 
        {
            $this->detail = !empty($this->longtime)?$cmd_booking['detail'].
              ' WHERE bk_date_booking BETWEEN '.$this->longtime:
            $cmd_booking['detail'].
              ' WHERE MONTH(bk_date_booking) = MONTH(CURDATE())-1
                AND YEAR(bk_date_booking)  = YEAR(CURDATE())';    
            
            $this->cmd = !empty($this->longtime)?$cmd_booking['month']['total'].
              ' AND bk_date_booking BETWEEN '.$this->longtime.' GROUP BY month,year':
             $cmd_booking['month']['total'].
              ' AND YEAR(bk_date_booking)  = YEAR( CURDATE())
                GROUP BY month,year ORDER BY year,month';   
                
            return 
             !empty($this->longtime)?$cmd_booking['month']['total'].
              ' AND bk_date_booking BETWEEN '.$this->longtime.' GROUP BY month,year':
             $cmd_booking['month']['total'].
              ' AND YEAR(bk_date_booking)  = YEAR( CURDATE()) -1
                GROUP BY month,year ORDER BY year,month';    
        }    
        else if ( $index=='ago' )
        {
              $this->series_ = $w->series_ref;
              //$p = new Formula();
              $this->detail = $cmd_booking['detail']." 
              
              AND  bk_date_booking BETWEEN ".$p->getFormula($ago,$back);
              if ( $back=='1week' )  
                  $where = ' GROUP BY
                               created,day,dayname
                             ORDER BY created,day,dayname';
               else if ( $back=='1month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
               else if ( $back=='3month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
                   
               $this->cmd =   $cmd_booking['ago'][$ago][$back]. $where;        
               $this->backdate = $p->fromdat;
               $this->enddate = $p->todat;
               //echo "sql = ".$this->cmd;
               return  $this->cmd;
                   
        }
        else if ( $index=='today')
        {
               $this->detail =  $cmd_booking['today']['detail'];
               return  $cmd_booking['today']['total'];
        }
        
    }
    
    
    public function Receipts($index='day',$billing='',$ago='',$back)
    {        
         
        $p=new Termago();
        $curweek = $p->getTermCurweek();
        $this->startdate = $p->weekstart;
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )          $w = new Intervaltime($interval='week',"rc_time_stamp");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"rc_time_stamp");
            
            $this->startdate    = $back !== '1week'?$w->begindate_ref:$p->sevendayago_startdate();
        }
        
        if ( $billing=='print' ) 
           $billstatus =  " AND rc_receipt_code not like 'wait%'";
        else if ( $billing=='wait%' ) 
           $billstatus =  " AND rc_receipt_code like 'wait%'";
        else $billstatus =  '';
        
       // echo $billstatus;
        $cmd_receipt = array(
        "day"=>array(
           "total"=>
              "SELECT                  
                 DATE_FORMAT(rc_time_stamp,'%Y-%m-%d' )  AS created,
                 DAY(rc_time_stamp) AS day , 
                 DAYNAME(rc_time_stamp) AS dayname ,                                           
                 COUNT(rc_receipt_id) AS total_rct
              FROM                  
                 ".$this->CI->project_database_sel.".tb_booking,
                 ".$this->CI->project_database_sel.".tb_receipt, 
                 ".$this->CI->db->database.".tb_customer,
                 ".$this->CI->db->database.".tb_customer_personal_info 
              WHERE 
                 rc_customer_id = cus_id 
                 AND pers_id = cus_pers_id 
                 AND rc_payfor_booking_id = bk_booking_code 
                 AND bk_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( rc_time_stamp,  '%Y%m%d' )   $curweek  "),
       "week"=>array(
            "total"=>
               "SELECT                   
                  CASE 
                    WHEN DAYOFMONTH(rc_time_stamp) < 8     THEN  CONCAT('7.',  DATE_FORMAT(rc_time_stamp,  '%m.%Y') )
                      WHEN DAYOFMONTH(rc_time_stamp) < 15  THEN  CONCAT('14.', DATE_FORMAT(rc_time_stamp,  '%m.%Y') )
                      WHEN DAYOFMONTH(rc_time_stamp) < 22  THEN  CONCAT('21.', DATE_FORMAT(rc_time_stamp,  '%m.%Y') )                   
                      WHEN DAYOFMONTH(rc_time_stamp) < 29  THEN  CONCAT('28.', DATE_FORMAT(rc_time_stamp,  '%m.%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(rc_time_stamp) , 2 ),DATE_FORMAT(rc_time_stamp,  '.%m.%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH(rc_time_stamp) < 8   THEN  '1'
                      WHEN DAYOFMONTH(rc_time_stamp) < 15  THEN  '2'
                      WHEN DAYOFMONTH(rc_time_stamp) < 22  THEN  '3' 
                      WHEN DAYOFMONTH(rc_time_stamp) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,
                    COUNT(rc_receipt_id) AS total_rct
				FROM  
                  ".$this->CI->project_database_sel.".tb_booking,
                  ".$this->CI->project_database_sel.".tb_receipt, 
                  ".$this->CI->db->database.".tb_customer,
                  ".$this->CI->db->database.".tb_customer_personal_info
				WHERE 
                  rc_customer_id = cus_id
                  AND pers_id = cus_pers_id
                  AND bk_project_id = ".$this->CI->project_id_sel."
                  AND rc_payfor_booking_id = bk_booking_code "),
         "month"=>array(
           "total"=>
                "SELECT 
                  MONTH(rc_time_stamp) AS month,
                  YEAR(rc_time_stamp) AS year,
                  COUNT(rc_receipt_id) AS total_rct
				FROM  
                  ".$this->CI->project_database_sel.".tb_booking,
                  ".$this->CI->project_database_sel.".tb_receipt, 
                  ".$this->CI->db->database.".tb_customer,
                  ".$this->CI->db->database.".tb_customer_personal_info
				WHERE 
                  rc_customer_id = cus_id
                  AND pers_id = cus_pers_id
                  AND bk_project_id = ".$this->CI->project_id_sel."
                  AND rc_payfor_booking_id = bk_booking_code "),
           "ago"=>array(
              "week"=>array(
                  "1week"=>
                    "SELECT 
                       DATE_FORMAT(rc_time_stamp,'%Y-%m-%d' )  AS created,
                       DAY( rc_time_stamp ) AS day , 
                       DAYNAME( rc_time_stamp ) AS dayname , 
                       COUNT(rc_receipt_id) AS total_rct
                     FROM 
                      ".$this->CI->project_database_sel.".tb_booking,
                      ".$this->CI->project_database_sel.".tb_receipt, 
                      ".$this->CI->db->database.".tb_customer,
                      ".$this->CI->db->database.".tb_customer_personal_info 
                     WHERE 
                      rc_customer_id = cus_id 
                      AND pers_id = cus_pers_id 
                      AND rc_payfor_booking_id = bk_booking_code 
                      AND bk_project_id = ".$this->CI->project_id_sel."
                      AND DATE_FORMAT( rc_time_stamp,  '%Y%m%d' ) BETWEEN ".$p->sevendayago() ,
                  "2week"=>
                     "SELECT 
                       rc_time_stamp,
                       DAY( rc_time_stamp ) AS day , 
                       DAYNAME( rc_time_stamp ) AS dayname , 
                       COUNT(rc_receipt_id) AS total_rct
                     FROM 
                      ".$this->CI->project_database_sel.".tb_booking,
                      ".$this->CI->project_database_sel.".tb_receipt, 
                      ".$this->CI->db->database.".tb_customer,
                      ".$this->CI->db->database.".tb_customer_personal_info 
                     WHERE 
                      rc_customer_id = cus_id 
                      AND pers_id = cus_pers_id 
                      AND bk_project_id = ".$this->CI->project_id_sel."
                      AND rc_payfor_booking_id = bk_booking_code ",
              ),
              "month"=>array(
                  "1month"=>
                      "SELECT 
                           CASE ".$w->when. 
                           " END AS  week, COUNT(rc_receipt_id) AS total_rct
                     FROM 
                      ".$this->CI->project_database_sel.".tb_booking,
                      ".$this->CI->project_database_sel.".tb_receipt, 
                      ".$this->CI->db->database.".tb_customer,
                      ".$this->CI->db->database.".tb_customer_personal_info 
                     WHERE 
                      rc_customer_id = cus_id 
                      AND pers_id = cus_pers_id 
                      AND rc_payfor_booking_id = bk_booking_code 
                      AND bk_project_id = ".$this->CI->project_id_sel."
                      AND DATE_FORMAT( rc_time_stamp,  '%Y%m%d' ) BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "3month"=>
                      "SELECT 
                           CASE ".$w->when. 
                           " END  AS  week, COUNT(rc_receipt_id) AS total_rct
                      FROM 
                       ".$this->CI->project_database_sel.".tb_booking,
                       ".$this->CI->project_database_sel.".tb_receipt, 
                       ".$this->CI->db->database.".tb_customer,
                       ".$this->CI->db->database.".tb_customer_personal_info 
                      WHERE 
                       rc_customer_id = cus_id 
                       AND pers_id = cus_pers_id 
                       AND rc_payfor_booking_id = bk_booking_code 
                       AND bk_project_id = ".$this->CI->project_id_sel."
                       AND rc_time_stamp BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "6month"=>
                      "SELECT 
                           MONTH( rc_time_stamp ) AS month,
                           YEAR( rc_time_stamp ) AS year,
                           COUNT(rc_receipt_id) AS total_rct
                      FROM 
                       ".$this->CI->project_database_sel.".tb_booking,
                       ".$this->CI->project_database_sel.".tb_receipt, 
                       ".$this->CI->db->database.".tb_customer,
                       ".$this->CI->db->database.".tb_customer_personal_info 
                      WHERE 
                       rc_customer_id = cus_id 
                       AND pers_id = cus_pers_id 
                       AND bk_project_id = ".$this->CI->project_id_sel."
                       AND rc_payfor_booking_id = bk_booking_code ",
              ),
              "year"=>array(
                  "1year"=>
                    "SELECT 
                         MONTH( rc_time_stamp ) AS month , 
                         MONTHNAME( rc_time_stamp ) AS monthname , 
                         YEAR( rc_time_stamp ) AS year, 
                         COUNT(rc_receipt_id) AS total_rct
                     FROM 
                       ".$this->CI->project_database_sel.".tb_booking,
                       ".$this->CI->project_database_sel.".tb_receipt, 
                       ".$this->CI->db->database.".tb_customer,
                       ".$this->CI->db->database.".tb_customer_personal_info 
                      WHERE 
                       rc_customer_id = cus_id 
                       AND pers_id = cus_pers_id 
                       AND bk_project_id = ".$this->CI->project_id_sel."
                       AND rc_payfor_booking_id = bk_booking_code ",
                  "3year"=>"SELECT 
                         SELECT 
                         CEIL( MONTH( rc_time_stamp ) /6 ) AS month, 
                         YEAR( rc_time_stamp ) AS year, 
                         COUNT(rc_receipt_id) AS total_rct
                    FROM 
                       ".$this->CI->project_database_sel.".tb_booking,
                       ".$this->CI->project_database_sel.".tb_receipt, 
                       ".$this->CI->db->database.".tb_customer,
                       ".$this->CI->db->database.".tb_customer_personal_info 
                      WHERE 
                       rc_customer_id = cus_id 
                       AND pers_id = cus_pers_id 
                       AND bk_project_id = ".$this->CI->project_id_sel."
                       AND rc_payfor_booking_id = bk_booking_code ",
              ),
            ),
           "detail"=>
             "SELECT  
                 DATE_FORMAT(rc_time_stamp,'%d-%b-%Y' ) AS created, rc_receipt_code, 
                 rc_payfor_type, pers_fname, pers_lname , pers_dob,pers_mobile,pers_tel,pers_email,
                 FORMAT(rc_money_amount ,3) as amount 
             FROM 
                 ".$this->CI->project_database_sel.".tb_receipt AS receipt 
                 INNER JOIN ".$this->CI->db->database.".tb_customer AS cust ON (receipt.rc_customer_id = cust.cus_id ) 
                 INNER JOIN ".$this->CI->db->database.".tb_customer_personal_info as perinfo ON (perinfo.pers_id = cust.cus_pers_id ) 
                 INNER JOIN ".$this->CI->project_database_sel.".tb_booking AS book ON (receipt.rc_payfor_booking_id = book.bk_booking_code ) 
                 INNER JOIN ".$this->CI->project_database_sel.".tb_quotation AS qt ON (qt.qt_code = book.bk_quotation_code) ",
            "today"=>array(
               "total"=>"SELECT                  
                 DATE_FORMAT(rc_time_stamp,'%Y-%m-%d' )  AS created,
                 rc_receipt_code,
                 COUNT(rc_receipt_id) AS total_rct
              FROM 
                 ".$this->CI->project_database_sel.".tb_booking,
                 ".$this->CI->project_database_sel.".tb_receipt, 
                 ".$this->CI->db->database.".tb_customer,
                 ".$this->CI->db->database.".tb_customer_personal_info 
              WHERE 
                 rc_customer_id = cus_id 
                 AND pers_id = cus_pers_id 
                 AND rc_payfor_booking_id = bk_booking_code 
                 AND bk_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( rc_time_stamp,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' ) "
                 .$billstatus."    GROUP BY rc_receipt_code,created ",
             "detail"=>
             "SELECT  
                 DATE_FORMAT(rc_time_stamp,'%d-%b-%Y' ) AS created, rc_receipt_code, 
                 rc_payfor_type, pers_fname, pers_lname , pers_dob,pers_mobile,pers_tel,pers_email,
                 FORMAT(rc_money_amount ,3) as amount 
             FROM 
                 ".$this->CI->project_database_sel.".tb_receipt AS receipt 
                 INNER JOIN ".$this->CI->db->database.".tb_customer AS cust ON (receipt.rc_customer_id = cust.cus_id ) 
                 INNER JOIN ".$this->CI->db->database.".tb_customer_personal_info as perinfo ON (perinfo.pers_id = cust.cus_pers_id ) 
                 INNER JOIN ".$this->CI->project_database_sel.".tb_booking AS book ON (receipt.rc_payfor_booking_id = book.bk_booking_code ) 
                 INNER JOIN ".$this->CI->project_database_sel.".tb_quotation AS qt ON (qt.qt_code = book.bk_quotation_code) 
              WHERE 
              bk_project_id = ".$this->CI->project_id_sel."
              DATE_FORMAT( rc_time_stamp,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' ) " 
              .$billstatus)
               
				
       );  
      
       if ( $index=='day' ) 
       {
           
           $this->detail = !empty($this->longtime)?$cmd_receipt['detail'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus:
              $cmd_receipt['detail']."  AND rc_time_stamp   $curweek  ".$billstatus;
           
           $this->cmd = !empty($this->longtime)?$cmd_receipt['day']['total'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus.
               ' GROUP BY week,dat ':$cmd_receipt['day']['total'].
               $billstatus.' GROUP BY created,day,dayname ORDER BY created,day,dayname ';
               
           return !empty($this->longtime)?$cmd_receipt['day']['total'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus.
               ' GROUP BY week,dat ':$cmd_receipt['day']['total'].
               $billstatus.' GROUP BY created,day,dayname ORDER BY created,day,dayname ';
       }
       else if ( $index=='week' ) 
       {
           $this->detail = !empty($this->longtime)?$cmd_receipt['detail'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus:
              $cmd_receipt['detail'].'
               AND MONTH(rc_time_stamp) = MONTH(CURDATE()) -1
               AND YEAR(rc_time_stamp)  = YEAR( CURDATE()) '.$billstatus;
           
           
           $this->cmd = !empty($this->longtime)?$cmd_receipt['week']['total'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus.
               ' GROUP BY week,month,year ':$cmd_receipt['week']['total'].' AND MONTH(rc_time_stamp) = MONTH(CURDATE()) -1 
               AND YEAR(rc_time_stamp) = YEAR(CURDATE())'.
               $billstatus.' GROUP BY dat,weekno ';
           
          
               
           return !empty($this->longtime)?$cmd_receipt['week']['total'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus.
               ' GROUP BY week,month,year ':$cmd_receipt['week']['total'].' AND MONTH(rc_time_stamp) = MONTH(CURDATE()) -1
               AND YEAR(rc_time_stamp) = YEAR(CURDATE())'.
               $billstatus.' GROUP BY dat,weekno ';
       }
       else  if ( $index=='month' ) 
       {
           $this->detail = !empty($this->longtime)?$cmd_receipt['detail'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus:
              $cmd_receipt['detail'].
               ' 
                 AND YEAR(rc_time_stamp)  = YEAR( CURDATE())-1 '.$billstatus;
           
           $this->cmd = !empty($this->longtime)?$cmd_receipt['month']['total'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus.
               ' GROUP BY month,year ':$cmd_receipt['month']['total'].
               ' AND YEAR(rc_time_stamp) = YEAR(CURDATE()) -1 '.
                 $billstatus.' GROUP BY month,year ORDER BY year,month ';
               
           return !empty($this->longtime)?$cmd_receipt['month']['total'].' AND rc_time_stamp BETWEEN '.$this->longtime.$billstatus.
               ' GROUP BY month,year ':$cmd_receipt['month']['total'].
               ' AND YEAR(rc_time_stamp) = YEAR(CURDATE()) -1 '.
                 $billstatus.' GROUP BY month,year ORDER BY year,month ';
       }
       else if ( $index=='ago' )
       {
           $this->series_ = $w->series_ref;
           
           if ( $back=='1week')
           $this->detail = $cmd_receipt['detail']." AND rc_time_stamp BETWEEN ".$p->sevendayago().$billstatus;
           else     
           $this->detail = $cmd_receipt['detail']." AND rc_time_stamp BETWEEN '".$w->begindate_ref. "' AND CURDATE() ".$billstatus;
           
               if ( $back=='1week' )  
                  $where = ' GROUP BY
                             created,day,dayname
                             ORDER BY created,day,dayname';
               else if ( $back=='1month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
               else if ( $back=='3month' )
                 $where = ' GROUP BY
                               week
                             ORDER BY 
                              week ';
                   
               $this->cmd =   $cmd_receipt['ago'][$ago][$back].$billstatus.' ' .$where;        
                   
               //echo $this->detail;
               //$this->backdate = $p->fromdat;
               //$this->enddate  = $p->todat;
               
               return  $this->cmd;
        }
        else if ( $index=='today')
        {
               $this->detail =  $cmd_receipt['today']['detail'];
               return  $cmd_receipt['today']['total'];
        }
    }
    
    
    
    public function topUnits($index='day',$top,$ago,$back)
    {
        
        $p=new Termago();
        $curweek = $p->getTermCurweek();
        $this->startdate = $p->weekstart;
        if ( $index == 'ago' )
        {            
            
            if ( $back=='1month' )          $w = new Intervaltime($interval='week',"qt_date");
            else if ( $back=='3month' )     $w = new Intervaltime($interval='3month',"qt_date");
            
            $this->startdate    = $back !== '1week'?$w->begindate_ref:$p->sevendayago_startdate();
        }

        $cmd_units   = array(
        "day"=>array(
            "total"=>
              "SELECT 
                  building.building_name, 
                  unit_no.un_name, 
                  COUNT(quatation.qt_id) AS total_qt 
               FROM 
                 ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                 INNER JOIN 
                 $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                 INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id ) 
				WHERE         
                 quatation.qt_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( quatation.qt_date,  '%Y%m%d' )   $curweek "),
        "week"=>array(
             "total"=>
                "SELECT 
                    building.building_name, 
                    unit_no.un_name, 
                  CASE 
                      WHEN DAYOFMONTH(quatation.qt_date) < 8   THEN  CONCAT('7.',  DATE_FORMAT(quatation.qt_date,  '%m.%Y') )
                      WHEN DAYOFMONTH(quatation.qt_date) < 15  THEN  CONCAT('14.', DATE_FORMAT(quatation.qt_date,  '%m.%Y') )
                      WHEN DAYOFMONTH(quatation.qt_date) < 22  THEN  CONCAT('21.', DATE_FORMAT(quatation.qt_date,  '%m.%Y') )                   
                      WHEN DAYOFMONTH(quatation.qt_date) < 29  THEN  CONCAT('28.', DATE_FORMAT(quatation.qt_date,  '%m.%Y') )                   
                      ELSE CONCAT(RIGHT( LAST_DAY(quatation.qt_date) , 2 ),DATE_FORMAT(quatation.qt_date,  '.%m.%Y') )  
                    END  AS  dat,
                    CASE 
                      WHEN DAYOFMONTH(quatation.qt_date) < 8   THEN  '1'
                      WHEN DAYOFMONTH(quatation.qt_date) < 15  THEN  '2'
                      WHEN DAYOFMONTH(quatation.qt_date) < 22  THEN  '3' 
                      WHEN DAYOFMONTH(quatation.qt_date) < 29  THEN  '4'                            
                      ELSE '5'
                    END  AS  weekno,COUNT(quatation.qt_id) AS total_qt
               FROM 
                 ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                 INNER JOIN 
                 $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                 INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id ) 
				WHERE        
                 quatation.qt_project_id = ".$this->CI->project_id_sel."
                 AND DATE_FORMAT( quatation.qt_date,  '%Y%m%d' )   $curweek "
        ),
        "month"=>array(
             "total"=>
               "SELECT 
                  building.building_name, 
                  unit_no.un_name, 
                  COUNT(quatation.qt_id) AS total_qt 
               FROM                  
                 ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                 INNER JOIN 
                 $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                 INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id )   WHERE quatation.qt_project_id = ".$this->CI->project_id_sel),
            "ago"=>array(
              "week"=>array(
                  "1week"=>
                    "SELECT 
                       building.building_name, 
                       unit_no.un_name, 
                       COUNT(quatation.qt_id) AS total_qt 
                     FROM 
                      ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                      INNER JOIN 
                      $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                      INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id ) 
				    WHERE 
                       quatation.qt_project_id = ".$this->CI->project_id_sel."
                       AND DATE_FORMAT( quatation.qt_date,  '%Y%m%d' ) BETWEEN ".$p->sevendayago() ,
                  "2week"=>
                     "SELECT project.pj_name, 
                       building.building_name,
                       floor.fl_name, 
                       unit_type.unit_type_name, 
                       unit_no.un_name, 
                       unit_no.un_number,
                       unit_no.un_direction,
                       unit_no.un_view,
                       unit_type.unit_type_area_sqm, 
                       unit_type.unit_type_area_sqft,
                       quatation.qt_date,
                       DAY( quatation.qt_date ) AS day , 
                       DAYNAME( quatation.qt_date ) AS dayname , 
                       COUNT(quatation.qt_id) AS total_qt
                     FROM 
                      ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                      INNER JOIN $databasename.tb_project AS project 
                      ON (quatation.qt_project_id=project.pj_id) 
                      INNER JOIN $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                      INNER JOIN $databasename.tb_floor AS floor ON (floor.fl_build_id=building.building_id) 
                      INNER JOIN $databasename.tb_unit_number AS unit_no ON ( unit_no.un_floor_id=floor.fl_id ) 
                      INNER JOIN $databasename.tb_unit_type as unit_type ON (unit_type.unit_type_id=unit_no.un_unit_type_id)
				    WHERE 
                      quatation.qt_buliding_id  =floor.fl_build_id
                      AND quatation.qt_floor_id = floor.fl_id
                      AND quatation.qt_unit_number_id = unit_no.un_id
                      AND quatation.qt_project_id = ".$this->CI->project_id_sel."
                      AND unit_no.un_sts_active = 'on' ",
              ),
              "month"=>array(
                  "1month"=>
                      "SELECT 
                           building.building_name, 
                           unit_no.un_name, 
                           CASE ".$w->when.
                           "  END  AS  week, COUNT(quatation.qt_id) AS total_qt
                     FROM                      
                      ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                      INNER JOIN 
                      $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                      INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id ) 
				    WHERE 
                       quatation.qt_project_id = ".$this->CI->project_id_sel."
                       AND DATE_FORMAT( quatation.qt_date,  '%Y%m%d' ) BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "3month"=>
                      "SELECT 
                            building.building_name, 
                            unit_no.un_name,
                           CASE  ".$w->when.
                           " END  AS  week, COUNT(quatation.qt_id) AS total_qt
                      FROM 
                       ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                       INNER JOIN 
                       $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                       INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id ) 
				     WHERE 
                       quatation.qt_project_id = ".$this->CI->project_id_sel."
                       AND DATE_FORMAT( quatation.qt_date,  '%Y%m%d' ) BETWEEN '".$w->begindate_ref. "' AND CURDATE() ",
                  "6month"=>
                      "SELECT 
                           project.pj_name, 
                           building.building_name,
                           floor.fl_name, 
                           unit_type.unit_type_name, 
                           unit_no.un_name, 
                           unit_no.un_number,
                           unit_no.un_direction,
                           unit_no.un_view,
                           unit_type.unit_type_area_sqm, 
                           unit_type.unit_type_area_sqft,
                           MONTH( quatation.qt_date ) AS month,
                           YEAR( quatation.qt_date ) AS year,
                           COUNT(quatation.qt_id) AS total_qt
                      FROM 
                      ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                      INNER JOIN $databasename.tb_project AS project 
                      ON (quatation.qt_project_id=project.pj_id) 
                      INNER JOIN $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                      INNER JOIN $databasename.tb_floor AS floor ON (floor.fl_build_id=building.building_id) 
                      INNER JOIN $databasename.tb_unit_number AS unit_no ON ( unit_no.un_floor_id=floor.fl_id ) 
                      INNER JOIN $databasename.tb_unit_type as unit_type ON (unit_type.unit_type_id=unit_no.un_unit_type_id)
				    WHERE 
                      quatation.qt_buliding_id  =floor.fl_build_id
                      AND quatation.qt_floor_id = floor.fl_id
                      AND quatation.qt_unit_number_id = unit_no.un_id
                      AND quatation.qt_project_id = ".$this->CI->project_id_sel."
                      AND unit_no.un_sts_active = 'on' ",
              ),
              "year"=>array(
                  "1year"=>
                    "SELECT 
                         project.pj_name, 
                           building.building_name,
                           floor.fl_name, 
                           unit_type.unit_type_name, 
                           unit_no.un_name, 
                           unit_no.un_number,
                           unit_no.un_direction,
                           unit_no.un_view,
                           unit_type.unit_type_area_sqm, 
                           unit_type.unit_type_area_sqft,
                         MONTH( quatation.qt_date ) AS month , 
                         MONTHNAME( quatation.qt_date ) AS monthname , 
                         YEAR( quatation.qt_date ) AS year, 
                         COUNT(quatation.qt_id) AS total_qt
                     FROM 
                      ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                      INNER JOIN $databasename.tb_project AS project 
                      ON (quatation.qt_project_id=project.pj_id) 
                      INNER JOIN $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                      INNER JOIN $databasename.tb_floor AS floor ON (floor.fl_build_id=building.building_id) 
                      INNER JOIN $databasename.tb_unit_number AS unit_no ON ( unit_no.un_floor_id=floor.fl_id ) 
                      INNER JOIN $databasename.tb_unit_type as unit_type ON (unit_type.unit_type_id=unit_no.un_unit_type_id)
				    WHERE 
                      quatation.qt_buliding_id  =floor.fl_build_id
                      AND quatation.qt_floor_id = floor.fl_id
                      AND quatation.qt_unit_number_id = unit_no.un_id
                      AND quatation.qt_project_id = ".$this->CI->project_id_sel."
                      AND unit_no.un_sts_active = 'on' ",
                  "3year"=>"SELECT 
                         SELECT 
                         project.pj_name, 
                           building.building_name,
                           floor.fl_name, 
                           unit_type.unit_type_name, 
                           unit_no.un_name, 
                           unit_no.un_number,
                           unit_no.un_direction,
                           unit_no.un_view,
                           unit_type.unit_type_area_sqm, 
                           unit_type.unit_type_area_sqft,
                         CEIL( MONTH( quatation.qt_date ) /6 ) AS month, 
                         YEAR( quatation.qt_date ) AS year, 
                         COUNT(quatation.qt_id) AS total_qt
                    FROM 
                      ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                      INNER JOIN $databasename.tb_project AS project 
                      ON (quatation.qt_project_id=project.pj_id) 
                      INNER JOIN $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                      INNER JOIN $databasename.tb_floor AS floor ON (floor.fl_build_id=building.building_id) 
                      INNER JOIN $databasename.tb_unit_number AS unit_no ON ( unit_no.un_floor_id=floor.fl_id ) 
                      INNER JOIN $databasename.tb_unit_type as unit_type ON (unit_type.unit_type_id=unit_no.un_unit_type_id)
				    WHERE 
                      quatation.qt_buliding_id  =floor.fl_build_id
                      AND quatation.qt_floor_id = floor.fl_id
                      AND quatation.qt_unit_number_id = unit_no.un_id
                      AND quatation.qt_project_id = ".$this->CI->project_id_sel."
                      AND unit_no.un_sts_active = 'on' ",
              ),
            ),
            "detail"=>
               "SELECT 
                  quatation.qt_date,
                  quatation.qt_code,
                  project.pj_name, 
                  building.building_name,
                  floor.fl_name, 
                  unit_type.unit_type_name, 
                  unit_no.un_name, 
                  unit_no.un_number, 
                  unit_no.un_direction,
                  unit_no.un_view,
                  unit_type.unit_type_area_sqm, 
                  unit_type.unit_type_area_sqft
               FROM 
                 ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                 INNER JOIN $databasename.tb_project AS project 
                 ON (quatation.qt_project_id=project.pj_id) 
                 INNER JOIN $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                 INNER JOIN $databasename.tb_floor AS floor ON (floor.fl_build_id=building.building_id) 
                 INNER JOIN $databasename.tb_unit_number AS unit_no ON ( unit_no.un_floor_id=floor.fl_id ) 
                 INNER JOIN $databasename.tb_unit_type as unit_type ON (unit_type.unit_type_id=unit_no.un_unit_type_id)
				WHERE 
                 quatation.qt_buliding_id  =floor.fl_build_id
                 AND quatation.qt_floor_id = floor.fl_id
                 AND quatation.qt_unit_number_id = unit_no.un_id
                 AND quatation.qt_project_id = ".$this->CI->project_id_sel."
                 AND unit_no.un_sts_active = 'on' ",
            "today"=>array(
               "total"=>"SELECT 
                  DATE_FORMAT(quatation.qt_date,'%Y-%m-%d')  AS created,
                  COUNT(quatation.qt_id) AS total_qt
               FROM 
                 ".$this->CI->project_database_sel.".tb_quotation AS quatation 
                 INNER JOIN 
                 $databasename.tb_building AS building ON (building.building_id = quatation.qt_buliding_id ) 
                 INNER JOIN $databasename.tb_unit_number AS unit_no ON ( qt_unit_number_id = unit_no.un_id ) 
				WHERE 
                  quatation.qt_project_id = ".$this->CI->project_id_sel."
                  AND DATE_FORMAT( quatation.qt_date,  '%Y%m%d' ) = DATE_FORMAT( CURDATE( ) ,  '%Y%m%d' ) 
                 GROUP BY created ",
               "detail"=>"")
            
        );
        
        if ( $index=='day' )
        {
            $this->detail = !empty($this->longtime)?$cmd_units['detail'].' AND qt_date BETWEEN '.$this->longtime:
                $cmd_units['detail'].'  OREDER BY 
                quatation.qt_date,
                  quatation.qt_code,
                  project.pj_name, 
                  building.building_name,
                  floor.fl_name, 
                  unit_type.unit_type_name, 
                  unit_no.un_name, 
                  unit_no.un_number, 
                  unit_no.un_direction,
                  unit_no.un_view,
                  unit_type.unit_type_area_sqm, 
                  unit_type.unit_type_area_sqft ';
            
            $this->cmd = !empty($this->longtime)?$cmd_units['day']['total'].' AND qt_date BETWEEN '.$this->longtime.' GROUP BY day ':
                $cmd_units['day']['total']." 
                 GROUP BY  
                   building_name,unit_no.un_name
                 ORDER BY 
                   total_qt   DESC ,
                   building_name,unit_no.un_name limit 0,$top";
            //echo $this->cmd;
                
            return !empty($this->longtime)?$cmd_units['day']['total'].' AND qt_date BETWEEN '.$this->longtime.' GROUP BY day ':
                $cmd_units['day']['total']." 
                 GROUP BY  
                   building_name,unit_no.un_name
                 ORDER BY 
                   total_qt   DESC ,
                   building_name,unit_no.un_name limit 0,$top";
        }
        else if ( $index=='week' )
        {
            $this->detail = !empty($this->longtime)?$cmd_units['detail'].' AND qt_date BETWEEN '.$this->longtime:
                $cmd_units['detail'].'
                  AND MONTH(qt_date) = MONTH(CURDATE()) -1
                  AND YEAR(qt_date)  = YEAR(CURDATE())';
            
            $this->cmd = !empty($this->longtime)?$cmd_units['week']['total'].' AND qt_date BETWEEN '.$this->longtime.
                ' GROUP BY week,month,year ':
                $cmd_units['week']['total']." 
                  AND MONTH(qt_date) = MONTH(CURDATE()) -1
                  AND YEAR(qt_date)  = YEAR(CURDATE())
                GROUP BY  building_name,unit_no.un_name,dat
                ORDER BY 
                  total_qt   DESC ,
                  building_name,unit_no.un_name,dat limit 0,$top ";
            //echo $this->cmd;
                
            return !empty($this->longtime)?$cmd_units['week']['total'].' AND qt_date BETWEEN '.$this->longtime.
                ' GROUP BY week,month,year ':
                $cmd_units['week']['total']." 
                  AND MONTH(qt_date) = MONTH(CURDATE()) -1
                  AND YEAR(qt_date)  = YEAR(CURDATE())
                GROUP BY  building_name,unit_no.un_name,dat
                ORDER BY 
                  total_qt   DESC ,
                  building_name,unit_no.un_name,dat limit 0,$top ";
        }
        else if ( $index=='month' )
        {
            $this->detail = !empty($this->longtime)?$cmd_units['detail'].' AND qt_date BETWEEN '.$this->longtime:
                $cmd_units['detail'].
                 ' 
                  AND YEAR(qt_date)  = YEAR(CURDATE()) -1 ';
            
            $this->cmd = !empty($this->longtime)?$cmd_units['month']['total'].' AND qt_date BETWEEN '.$this->longtime.
                ' GROUP BY month,year ':
                $cmd_units['month']['total'].
                 " AND YEAR(qt_date)  = YEAR(CURDATE()) -1
                  GROUP BY  
                    building_name, 
                    unit_no.un_name
                  ORDER BY 
                   total_qt   DESC ,
                   building_name, 
                   unit_no.un_name  limit 0,$top";
            //echo $this->cmd;
            
            return !empty($this->longtime)?$cmd_units['month']['total'].' AND qt_date BETWEEN '.$this->longtime.
                ' GROUP BY month,year ':
                $cmd_units['month']['total'].
                 " AND YEAR(qt_date)  = YEAR(CURDATE()) -1
                  GROUP BY  
                    building_name, 
                    unit_no.un_name
                  ORDER BY 
                   total_qt   DESC ,
                   building_name, 
                   unit_no.un_name  limit 0,$top";
        }
        else if ( $index=='ago' )
        {
            $this->series_ = $w->series_ref;            
            if ( $back=='1week')
            $this->detail = $cmd_receipt['detail']." AND qt_date BETWEEN  BETWEEN ".$p->sevendayago() ;
            else     
            $this->detail = $cmd_receipt['detail']." AND qt_date BETWEEN  BETWEEN '".$w->begindate_ref. "' AND CURDATE()  ";
            
               if ( $back=='1week' )  
                  $where = " GROUP BY
                               building_name, 
                               unit_no.un_name
                             ORDER BY 
                             total_qt   DESC ,
                             un_name limit 0,$top";
               else if ( $back=='1month' )
                 $where = " GROUP BY
                               building_name, 
                               unit_no.un_name
                             ORDER BY 
                             total_qt   DESC ,
                             un_name limit 0,$top";
               else if ( $back=='3month' )
                 $where = " GROUP BY
                               building_name, 
                               unit_no.un_name
                             ORDER BY 
                             total_qt   DESC ,
                             un_name limit 0,$top";
                   
               $this->cmd      = $cmd_units['ago'][$ago][$back].$where; 
               //echo $this->cmd;
               $this->backdate = $p->fromdat;
               $this->enddate  = $p->todat;
               return  $this->cmd;
                   
        }
        
        
    }
    public function MessageToCustom($dob,$ago='today')
    {        
        //echo $dob['from'].','.$dob['to'];
        
        if ( $ago == 'week' )
        {
                $query = "SELECT ADDDATE( CURDATE( ) , INTERVAL 1 - DAYOFWEEK( CURDATE( ) ) 
                          DAY ) WeekStart, ADDDATE( CURDATE( ) , INTERVAL 7 - DAYOFWEEK( CURDATE( ) ) 
                          DAY ) WeekEnd ";
                
                $query = mysql_query($query);             
                $get = mysql_fetch_array($query);               
                $dob = array("from"=>$get['WeekStart'],"to"=>$get['WeekEnd'] );                 
                $this->startdate = date('d-M-Y',strtotime($get['WeekStart'])).' To '.date('d-M-Y',strtotime($get['WeekEnd']));
        }
        //echo '<p> from '.$dob['from'].':'.$dob['to'];
       
        $hbd = new Dob($dob,$ago,'ORDER BY pers_fname, 
                    pers_lname, 
                    pers_email, 
                    pers_mobile, 
                    pers_tel, 
                    nt_nationality');
       // echo $hbd->cmd;
        
        return $hbd->cmd;
    }
    
    public function setArrangeSeriestoPlotChart($interval='day',$chart)
    {
         if ( $interval=='day' )
         {
            foreach ($this->lang_day_eng_abbreviation as $abv )
                $this->xAxis .= !empty($this->xAxis)?",'".$abv."'":"'".$abv."'";
            foreach ($this->series_value as $value )
                $this->series_total  .= $value !==''?','.$value:$value;                      
         }
         else 
         {
             if ( $chart=='line' )
             {             
                // echo ' Temp = size of temp = '.sizeof($this->series_);
                 //echo ' size = '.sizeof($this->series_column);
                 foreach ($this->series_ as $key_xAxis )
                  {                                  
                      $flag=false;
                      
                      $no=0;       
                     
                      foreach ($this->series_column  as $key=>$value) 
                      {
                                                  
                          if ( $key == $key_xAxis )
                            {
                             
                                $this->xAxis .= !empty($this->xAxis)?",'".date('d-M-y',strtotime($key_xAxis))."'":"'".date('d-M-y',strtotime($key_xAxis))."'";
                                $this->deta  .= $this->deta!==''?','.$value:$value;     
                                $flag=true;break;
                            }                                                        
                      
                      }
                      
                      
                       if ( $flag==false )
                       {
                           $this->xAxis .= !empty($this->xAxis)?",'".date('d-M-y',strtotime($key_xAxis))."'":"'".date('d-M-y',strtotime($key_xAxis))."'";
                           $this->deta  .= $this->deta !==''?',0':0;     
                       }                      
                      
                      //echo '<p> xAxis = '.$this->xAxis;
                      //echo '<p> deta = '.$this->deta;
                  }
                 
             }
             
         }
         
         
     }
    
     public function setArrangeSeriesCustomer_LeadtoPlotChart($interval='day',$chart)
     {
         if ( $interval=='day' )
         {
            foreach ($this->lang_day_eng_abbreviation as $abv )
                $this->xAxis .= !empty($this->xAxis)?",'".$abv."'":"'".$abv."'";
            foreach ($this->series_value as $value )
                $this->series_total  .= $value !==''?','.$value:$value;                      
         }
         else 
         {
             if ( $chart=='line' )
             {             
                // echo ' Temp = size of temp = '.sizeof($this->series_);
                 //echo ' size = '.sizeof($this->series_column);
                 foreach ($this->series_ as $key_xAxis )
                  {                                  
                      $flag=false;
                      
                      $no=0;       
                     
                      foreach ($this->series_cust  as $key=>$value) 
                      {
                                                  
                          if ( $key == $key_xAxis )
                            {                             
                                $this->xAxis_cust .= !empty($this->xAxis_cust)?",'".date('d-M-y',strtotime($key_xAxis))."'":"'".date('d-M-y',strtotime($key_xAxis))."'";
                                $this->deta_cust  .= $this->deta_cust!==''?','.$value:$value;     
                                $flag=true;break;
                            }                                                        
                      
                      }
                      
                      
                       if ( $flag==false )
                       {
                           $this->xAxis_cust .= !empty($this->xAxis_cust)?",'".date('d-M-y',strtotime($key_xAxis))."'":"'".date('d-M-y',strtotime($key_xAxis))."'";
                           $this->deta_cust  .= $this->deta_cust !==''?',0':0;     
                       }                      
                      
                     
                      //echo '<p> xAxis = '.$this->xAxis;
                      //echo '<p> deta = '.$this->deta;
                  }
                 
                  foreach ($this->series_ as $key_xAxis )
                  {                                  
                      $flag=false;
                      
                      $no=0;       
                     
                      foreach ($this->series_lead  as $key=>$value) 
                      {
                                                  
                          if ( $key == $key_xAxis )
                            {                             
                                $this->xAxis_lead .= !empty($this->xAxis_lead)?",'".date('d-M-y',strtotime($key_xAxis))."'":"'".date('d-M-y',strtotime($key_xAxis))."'";
                                $this->deta_lead  .= $this->deta_lead!==''?','.$value:$value;     
                                $flag=true;break;
                            }                                                        
                      
                      }
                      
                      
                       if ( $flag==false )
                       {
                           $this->xAxis_lead .= !empty($this->xAxis_lead)?",'".date('d-M-y',strtotime($key_xAxis))."'":"'".date('d-M-y',strtotime($key_xAxis))."'";
                           $this->deta_lead  .= $this->deta_lead !==''?',0':0;     
                       }                      
                      
                     
                      //echo '<p> xAxis = '.$this->xAxis;
                      //echo '<p> deta = '.$this->deta;
                  }
                 
             }
             
         }
         
         
     }
    
   
}
?>