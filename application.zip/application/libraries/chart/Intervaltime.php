<?php
 class Intervaltime {
     
     public $CI = NULL;
     public $series_ref = array();//Refer Interval in class
     public $series_total=array();// Refer array from sql Command use only  search by Day
     
      // key   = Interval Date;
      // value = total 
     public $length_day;
     public $when;
     public $begindate;
     public $begindate_ref;

     public function __construct($interval='day',$field) {  
        $this->CI =& get_instance();
         $this->when =  $this->setAddIntervaltime($interval,$field);
     }
     function setAddIntervaltime($interval,$field)
     {
          
         
         $curdate = date("Y-m-d");    
         //echo "interval".$interval;
           if (  $interval== 'day' )
           {
             $series_time = array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+1 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+2 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+3 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+4 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+5 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+6 days",strtotime($this->begindate))) );
           }
           else if (  $interval== 'week' )
           {
               $this->begindate = date("m")==1?(intval(date("Y"))-1).'-12-'.date("d"):date("Y").'-'.(intval(date("m"))-1).'-'.date("d");    
         $this->begindate_ref = $this->begindate;
              
               $series_time = array(                        
                       date("Y-m-d",strtotime("+0 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+7 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+14 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+21 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+28 days",strtotime($this->begindate))),
                       $curdate );
           }
           else if (  $interval== '2week' )
           {
             $series_time = array( 
                       date("Y-m-d",strtotime("0 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+15 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+30 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+45 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+60 days",strtotime($this->begindate))),
                       $curdate );
           }
           else if (  $interval== '3month' )
           {                           
              $this->begindate = date("m")<=3?(intval(date("Y"))-3).'-'.(12-3+(intval(date("m")))).'-'.date("d"):date("Y").'-'.(intval(date("m"))-3).'-'.date("d");    
         $this->begindate_ref = $this->begindate;
               //echo "intervalue = ".$interval;
               $series_time = array(                      
                       date("Y-m-d",strtotime("+0 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+15 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+30 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+45 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+60 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+75 days",strtotime($this->begindate))),
                       $curdate );               
           }
           else if (  $interval== '6month' )
           {                           
             $series_time = array(                      
                       date("Y-m-d",strtotime("+30 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+60 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+90 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+120 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+150 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+180 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+210 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+240 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+270 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+300 days",strtotime($this->begindate))),
                       date("Y-m-d",strtotime("+330 days",strtotime($this->begindate))),
                       $curdate );               
           }
           else if ( $interval == 'dynamic' )
           {
                $term = $startday - $endday;
                if ( $term <= 7 )
                {
                        $series_time = array( 
                           date("Y-m-d",strtotime("0 days",strtotime($this->begindate))),
                           date("Y-m-d",strtotime("+1 days",strtotime($this->begindate))),
                           date("Y-m-d",strtotime("+2 days",strtotime($this->begindate))),
                           date("Y-m-d",strtotime("+3 days",strtotime($this->begindate))),
                           date("Y-m-d",strtotime("+4 days",strtotime($this->begindate))),
                           date("Y-m-d",strtotime("+5 days",strtotime($this->begindate))),
                           date("Y-m-d",strtotime("+6 days",strtotime($this->begindate))) );                    
                }
                else if ( $term <= 30 )
                {
                    while (  $this->begindate < $endday )
                    {
                        $series_time[] = 
                          date("d.m.Y",strtotime("+$this->length_day days",strtotime($this->begindate)));
                        $this->begindate += $this->length_day;
                    }  
                    $series_time[] = $curdate;
                }
                else if ( $term <= 90 )
                {                    
                    while (  $this->begindate < $endday )
                    {
                        $series_time[] = 
                          date("d.m.Y",strtotime("+$this->length_day days",strtotime($this->begindate)));
                        $this->begindate += $this->length_day;
                    }
                    $series_time[] = $curdate;
                        
                }
                else if ( $term >= 365 )
                {
                    while (  $this->begindate <= $endday )
                    {
                        $series_time[] = 
                          date("d.m.Y",strtotime("$this->length_day days",strtotime($this->begindate)));
                        $this->begindate += $this->range;
                    }
                    $series_time[] = $curdate;
                    
                }
               
               
           }
         
           $this->series_ref = sizeof($series_time)>0 ?$series_time:isset($this->series_ref);
         
           //$when = "";
           //$when =  $interval." size = ".sizeof($series_time);
           foreach ( $series_time  as $value )
              // $when .= !empty($when)?" WHEN $field  <= ".$value." THEN ".date_format($value,'dd-mm'):"";
            $when .= $when !== ''?" WHEN  DATE_FORMAT($field,'%Y-%m-%d')  <= '".$value."' THEN '".$value."'":"";
            $this->series_ref = $series_time;
            //echo '<sz>: '.$series_time;
        //echo $when;
           return $when;
         
     }
     
 }
?>