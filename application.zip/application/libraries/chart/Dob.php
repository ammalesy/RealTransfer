<?php

   class Dob   {
    public $CI = NULL;
     public $FROM_YEAR;
     public $TO_YEAR;
     public $from_month;
     public $to_month;
     public $from_date;
     public $to_date;
     public $term='today';
     public $sortby = '';
     public $cmd =  '';
       
    public function __construct($dob_value,$ago,$orderby) {  

        $this->CI =& get_instance();

      $this->term = $ago;
      $this->sortby = $orderby;
      if ( sizeof($dob_value) > 0 )
      {
         
         $this->FROM_YEAR   =   date("Y", strtotime($dob_value['from'])) ; 
         $this->TO_YEAR     =   date("Y", strtotime($dob_value['to'])) ; 
         $this->from_month  =   date("n", strtotime($dob_value['from'])) ; 
         $this->to_month    =   date("n", strtotime($dob_value['to'])) ; 
         $this->from_date   =   date("j", strtotime($dob_value['from'])) ; 
         $this->to_date     =   date("j", strtotime($dob_value['to'])) ;         
      }
      $this->cmd =   $this->Calculate_Dob();
   }
   public function Calculate_Dob()
   {

       $qheader = 
           "SELECT 
                    DISTINCT 
                    DATE_FORMAT(pers_dob,'%e-%c-%y') as hbd,
                    pers_fname, 
                    pers_lname, 
                    pers_email, 
                    pers_mobile, 
                    pers_tel, 
                    nt_nationality
                FROM 
                    ".$this->CI->db->database.".tb_customer, 
                    ".$this->CI->db->database.".tb_customer_personal_info, 
                    ".$this->CI->db->database.".tb_nationality
                WHERE 
                    cus_pers_id = pers_id
                    AND pers_nationality = nt_id
                    AND cus_sts_active =  'on'
                    AND cus_flag !=  'leads '  ";
       if ( $this->term == 'today' )
           $cmd_dob = $qheader.' AND DAY(pers_dob) = DAY(CURDATE())
                                 AND MONTH(pers_dob) = MONTH(CURDATE()) '.$this->sortby;
                            
       
           
       else if ( $this->term == 'month' )
           $cmd_dob = $qheader.' 
                  AND MONTH(pers_dob) = MONTH(CURDATE()) '.$this->sortby;
           
       else if ( $this->term == 'term' || $this->term=='week' )
       {
           
           
           if ( $this->TO_YEAR-$this->FROM_YEAR == 0 )
           {
              
              if ( $this->to_month - $this->from_month == 2 )
                 $cmd_dob = $qheader."
                           AND ( ( MONTH(pers_dob) = ".($this->from_month+1).") 
                                 OR 
                                 (  MONTH(pers_dob) = $this->from_month
                                    AND   DAY(pers_dob)  >= $this->from_date 
                                 )
                                 OR
                                 (  MONTH(pers_dob) = $this->to_month
                                    AND DAY(pers_dob) <= $this->to_date 
                                 )
                               )  ".$this->sortby;
              else if ( $this->to_month - $this->from_month > 1 )              
                        
                  $cmd_dob = $qheader."
                           AND ( ( MONTH(pers_dob) IN ( ".($this->from_month+1).",".($this->to_month-1).") 
                                 OR 
                                 (  MONTH(pers_dob) = $this->from_month
                                    AND   DAY(pers_dob)  >= $this->from_date 
                                 )
                                 OR
                                 (  MONTH(pers_dob) = $this->to_month
                                    AND DAY(pers_dob) <= $this->to_date 
                                 )
                               ) ".$this->sortby;
              else  if ( $this->to_month - $this->from_month == 1 )
                 $cmd_dob = $qheader."
                         AND ( ( MONTH(pers_dob) = $this->from_month
                                 AND  DAY(pers_dob)  >= $this->from_date ) 
                               OR
                               ( MONTH(pers_dob) = $this->to_month
                                 AND  DAY(pers_dob) <= $this->to_date 
                               )
                             ) ".$this->sortby;
       
              else if ( $this->from_month - $this->to_month == 0 )
                $cmd_dob = $qheader."
                        AND ( MONTH(pers_dob) = $this->from_month
                              AND  
                              DAY(pers_dob) BETWEEN $this->from_date AND $this->to_date )   ".$this->sortby;
           }
           else  if ( $this->TO_YEAR-$this->FROM_YEAR  > 1 )
             $cmd_dob = $qheader;
           else if ( $this->TO_YEAR-$this->FROM_YEAR == 1 )
           {
               if ( $this->from_month == 12 )
               {
                  $cmd_dob = 
                  $qheader."
                    AND ( ( MONTH(pers_dob) = $this->from_month AND  DAY(pers_dob)  >= ".$this->from_date." ) ";
                  if ( $this->to_month == 1 )
                    $cmd_dob .=  " OR  ( MONTH(pers_dob) = ".$this->to_month."  AND  DAY(pers_dob) <=" .$this->to_date." ) ) ".$this->sortby;
                  else  " OR
                          ( MONTH(pers_dob) < ".--$this->to_month.")  
                          OR
                          ( MONTH(pers_dob) = $this->to_month        
                            AND  DAY(pers_dob)  <= $this->to_date )
                        ) ".$this->sortby;
               }
               else 
               {
                   $cmd_dob = 
                  $qheader."
                    AND (  ( MONTH(pers_dob) >= ".++$this->from_month.")
                            OR  
                           ( MONTH(pers_dob) = ".$this->from_month." AND  DAY(pers_dob)  >= ".$this->from_date." ) ";
                  if ( $this->to_month == 1 )
                    $cmd_dob .=  " OR  ( MONTH(pers_dob) = ".$this->to_month." AND  DAY(pers_dob) <=" .$this->to_date." ) ) ".$this->sortby;
                  else $cmd_dob .= " OR 
                          ( MONTH(pers_dob) < ".--$this->to_month.")  
                          OR
                          ( MONTH(pers_dob) = $this->to_month        
                            AND  DAY(pers_dob)  <= $this->to_date )
                        ) ".$this->sortby;
               }
                   
               
           }
           
       }
       
       return $cmd_dob;
   }
  }
?>



   
