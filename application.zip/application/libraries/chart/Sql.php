<?php
require '../config.php';
require '../defind.php';
require '';
class Sql extends Join  {
    private $cmd='';
    private function Where($arr_where=array())
    {
        $cmd_where = ''; 
        if ( $arr_where != null  )
         {    
            foreach ( $ar_where as $vector )
            $cmd_where .=  !empty($cmd_where)?"  ".$vector['relate']."  ".$vector['fieldname']." ". $vector['operate']. "'".$vector['fieldvalue']."'":" WHERE  ".$vector['fieldname']."  ".$vector['operate']."'".$vector['fieldvalue']."'" ;
         }
         return $cmd_where;
    }
    public function InsertTb($ar_insert=array() ,$tablename='')
    {
       if ( $arr_insert != null  && !empty($tablename) )
       {
           $fieldname  =  '';
           $fieldvalue =  '';
           foreach ( $ar_insert as $field = $value )
           {
             $fieldname  .=    !empty($fieldname)?','.$field:$field;
             $fieldvalue .=    !empty($fieldvalue)?",'".$value."'":"'".$value."'";  
           }
           $this->cmd =  " INSERT INTO  $tablename   ($fieldname ) value ( $fieldvalue ) "; 
           
       }   
       return !empty($this->cmd)?$this->cmd:false;
        
    }
    public function DeleteTb($ar_delete=array() ,$tablename='')
    {
       if ( $ar_delete != null  && !empty($tablename) )
       {
           foreach ( $ar_delete as $vector )
            $query .=  !empty($cmd)?"  ".$vector['relate']."  ".$vector['fieldname']." ". $vector['operate']. "'".$vector['fieldvalue']."'":" WHERE  ".$vector['fieldname']."  ".$vector['operate']."'".$vector['fieldvalue']."'";
           $this->cmd  =  " DELETE FROM  $tablename    ".$query; 
           
       }   
       return !empty($this->cmd)?$this->cmd:false; 
        
    }
    public function EditTb($ar_edit=array() ,$ar_where=array() ,$tablename='')
    {
       if ( $ar_edit != null  && !empty($tablename) )
       {
           $cmd_set = '';
           
           foreach ( $ar_edit as $vector )
            $cmd_set .=  !empty($cmd_set)?",".$vector['fieldname']." = '".$vector['fieldvalue']."'":" SET  ".$vector['fieldname']." = '".$vector['fieldvalue']."'";
        
           $this->cmd  =  " UPDATE  $tablename    ".$cm_set." ".$this->Where($ar_where); 
           
       }   
       return !empty($this->cmd)?$this->cmd:false;  
    }
    
    public function SelectTb($arr_select=array,
                             $arr_where=array(),
                             $arr_when=array(),
                             $param,
                             $arr_group=array(),
                             $arr_having=array(),
                             $arr_order=array(),
                             $fieldlimit,$startlimit,
                             $endlimit)
    {
        //SELECT column_name, aggregate_function(column_name)
        //FROM table_name
        //WHERE column_name operator value
        //GROUP BY column_name
        //HAVING aggregate_function(column_name) operator value;
        $cmd_field='';
        foreach ( $arr_select as $vector )
           $cmd_field .=  !empty($cmd_field)?','.$vector['fieldname']:$vector['fieldname']; 
        if ( $cmd_field != '' )
        $this->cmd  = ' SELECT '$cmd_field.$this->InJoin().
                      $this->when($arr_when=array(),$param).
                      $this->LJoin().
                      RJoin().
                      $this->Where($arr_where).                      
                      $this->Groupby($arr_group).
                      $this->Having($arr_having).
                      $this->Orderby($arr_order).
                      $this->Limited($fieldlimit,$startlimit,$endlimit); 
                      
        return !empty($this->cmd)?$this->cmd:false;  
    }
    private function when($arr_when=array(),$param)
    {
        $field='';
        if ( $arr_when != null )
        {
           foreach ( $arr_when as $fieldname )           
             $field  .=    !empty($field)?$' WHEN  '.$arr_when['fieldname']. ' '.$arr_when['operate'].' '.$arr_when['fieldvalue'].' THEN '.$arr_when['answer']:
            ', CASE WHEN  '.$arr_when['fieldname']. ' '.$arr_when['operate'].' '.$arr_when['fieldvalue'].' THEN '.$arr_when['answer'];
        }        
        return !empty($field)?' END  AS '.$param:''; 
    }
    public function InJoin()
    {
        
    }
    public function LJoin()
    {
        
    }
    public function RJoin()
    {
        
    }
    private function Groupby($arr_group=array())
    {
        $field='';
        if ( $arr_group != null )
        {
           foreach ( $arr_group as $fieldname )           
             $field  .=    !empty($field)?','.$fieldname:$fieldname;
        }
        return $field; 
    }
    private function Having($arr_having = array())
    {        
       $cmd_having = '';
       if (  $arr_having != null )
       {
          foreach ( $arr_having as $vector )
           $cmd_having .=  !empty($cmd_having)?"  ".$vector['relate']."  ".$vector['fieldname']." ". $vector['operate']. "'".$vector['fieldvalue']."'":" HAVING  ".$vector['fieldname']."  ".$vector['operate']."'".$vector['fieldvalue']."'" ;
       }
       return $cmd_having;
    }
    public function Orderby($arr_order=array())
    {
        $field='';
        if ( $arr_order != null )
        {
           foreach ( $arr_order as $fieldname )           
             $field  .=    !empty($field)?','.$fieldname:$fieldname;
        }
        return $field; 
    }
    private function Limited($field,$startlimit,$endlimit)
    {         
        return ( !empty($filed) && isset($startlimit) && isset($endlimit))?' LIMIT '.$startlimit.','.$endlimit:'';
    }
    
    public function Transaction()
    {
       /*start transaction;
 
         select @orderNumber := max(orderNUmber) 
         from orders;

         set @orderNumber = @orderNumber  + 1;
 

         insert into orders(orderNumber,
                   orderDate,
                   requiredDate,
                   shippedDate,
                   status,
                   customerNumber)
         values(@orderNumber,
           now(),
           date_add(now(), INTERVAL 5 DAY),
           date_add(now(), INTERVAL 2 DAY),'In Process',145);

    
         insert into orderdetails(orderNumber,
                         productCode,
                         quantityOrdered,
                         priceEach,
                         orderLineNumber)
         values(@orderNumber,'S18_1749', 30, '136', 1),
         (@orderNumber,'S18_2248', 50, '55.09', 2);          
        
         commit;       
         */
            $msg = true;            
            mysql_query("BEGIN");
             // insert
             $this->InsertTb($ar_insert=array() ,$tablename='');
             $this->DeleteTb($ar_delete=array() ,$tablename='');
             $this->EditTb($ar_edit=array() ,$ar_where=array() ,$tablename='');
             // delete
             // update            
            $result = mysql_query($query);
            if(!$result)
            {
               mysql_query("ROLLBACK");               
               exit;
            }
            else
            {
               mysql_query("COMMIT");
               $msg = false;
            }
            return $msg;//True/False
        
    }

}
?>
