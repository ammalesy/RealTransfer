<?php
 // bin/class.currency.php
 // class Currency โดย http://www.goragod.com (กรกฎ วิริยะ)
 // สงวนลิขสิทธ์ ห้ามซื้อขาย ให้นำไปใช้ได้ฟรีเท่านั้น
 class Currency {
  public function bahtEng($thb) {
   list($thb, $ths) = explode('.', $thb);
   $ths = substr($ths.'00', 0, 2);
   $thb = Currency::engFormat(intval($thb)).' Baht';
   if (intval($ths) > 0) {
    $thb .= ' and '.Currency::engFormat(intval($ths)).' Satang';
   }
   return $thb;
  }
  // ตัวเลขเป็นตัวหนังสือ (ไทย)
  public function bahtThai($thb) {
   list($thb, $ths) = explode('.', $thb);
   $ths = substr($ths.'00', 0, 2);
   $thaiNum = array('', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า');
   $unitBaht = array('บาท', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน');
   $unitSatang = array('สตางค์', 'สิบ');
   $THB = '';
   $j = 0;
   for ($i = strlen($thb) - 1; $i >= 0; $i--, $j++) {
    $num = $thb[$i];
    $tnum = $thaiNum[$num];
    $unit = $unitBaht[$j];
    switch (true) {
     case $j == 0 && $num == 1 && strlen($thb) > 1:
      $tnum = 'เอ็ด';
      break;
     case $j == 1 && $num == 1:
      $tnum = '';
      break;
     case $j == 1 && $num == 2:
      $tnum = 'ยี่';
      break;
     case $j == 6 && $num == 1 && strlen($thb) > 7:
      $tnum = 'เอ็ด';
      break;
     case $j == 7 && $num == 1:
      $tnum = '';
      break;
     case $j == 7 && $num == 2:
      $tnum = 'ยี่';
      break;
     case $j != 0 && $j != 6 && $num == 0:
      $unit = '';
      break;
    }
    $S = $tnum.$unit;
    $THB = $S.$THB;
   }
   if ($ths == '00') {
    $THS = 'ถ้วน';
   } else {
    $j = 0;
    $THS = '';
    for ($i = strlen($ths) - 1; $i >= 0; $i--, $j++) {
     $num = $ths[$i];
     $tnum = $thaiNum[$num];
     $unit = $unitSatang[$j];
     switch (true) {
      case $j == 0 && $num == 1 && strlen($ths) > 1:
       $tnum = 'เอ็ด';
       break;
      case $j == 1 && $num == 1:
       $tnum = '';
       break;
      case $j == 1 && $num == 2:
       $tnum = 'ยี่';
       break;
      case $j != 0 && $j != 6 && $num == 0:
       $unit = '';
       break;
     }
     $S = $tnum.$unit;
     $THS = $S.$THS;
    }
   }
   return $THB.$THS;
  }
  // ตัวเลขเป็นตัวหนังสือ (eng)
  private function engFormat($number) {
   list($thb, $ths) = explode('.', $thb);
   $ths = substr($ths.'00', 0, 2);
   $max_size = pow(10, 18);
   if (!$number)
    return "zero";
   if (is_int($number) && $number < abs($max_size)) {
    switch ($number) {
     case $number < 0:
      $prefix = "negative";
      $suffix = Currency::engFormat(-1 * $number);
      $string = $prefix." ".$suffix;
      break;
     case 1:
      $string = "One";
      break;
     case 2:
      $string = "Two";
      break;
     case 3:
      $string = "Three";
      break;
     case 4:
      $string = "Four";
      break;
     case 5:
      $string = "Five";
      break;
     case 6:
      $string = "Six";
      break;
     case 7:
      $string = "Seven";
      break;
     case 8:
      $string = "Eight";
      break;
     case 9:
      $string = "Nine";
      break;
     case 10:
      $string = "Ten";
      break;
     case 11:
      $string = "Eleven";
      break;
     case 12:
      $string = "Twelve";
      break;
     case 13:
      $string = "Thirteen";
      break;
     case 15:
      $string = "Fifteen";
      break;
     case $number < 20:
      $string = Currency::engFormat($number % 10);
      if ($number == 18) {
       $suffix = "een";
      } else {
       $suffix = "teen";
      }
      $string .= $suffix;
      break;
     case 20:
      $string = "Twenty";
      break;
     case 30:
      $string = "Thirty";
      break;
     case 40:
      $string = "Forty";
      break;
     case 50:
      $string = "Fifty";
      break;
     case 60:
      $string = "Sixty";
      break;
     case 70:
      $string = "Seventy";
      break;
     case 80:
      $string = "Eighty";
      break;
     case 90:
      $string = "Ninety";
      break;
     case $number < 100:
      $prefix = Currency::engFormat($number - $number % 10);
      $suffix = Currency::engFormat($number % 10);
      $string = $prefix."-".$suffix;
      break;
     case $number < pow(10, 3):
      $prefix = Currency::engFormat(intval(floor($number / pow(10, 2))))." Hundred";
      if ($number % pow(10, 2))
       $suffix = " and ".Currency::engFormat($number % pow(10, 2));
      $string = $prefix.$suffix;
      break;
     case $number < pow(10, 6):
      $prefix = Currency::engFormat(intval(floor($number / pow(10, 3))))." Thousand";
      if ($number % pow(10, 3))
       $suffix = Currency::engFormat($number % pow(10, 3));
      $string = $prefix." ".$suffix;
      break;
     case $number < pow(10, 9):
      $prefix = Currency::engFormat(intval(floor($number / pow(10, 6))))." Million";
      if ($number % pow(10, 6))
       $suffix = Currency::engFormat($number % pow(10, 6));
      $string = $prefix." ".$suffix;
      break;
     case $number < pow(10, 12):
      $prefix = Currency::engFormat(intval(floor($number / pow(10, 9))))." Billion";
      if ($number % pow(10, 9))
       $suffix = Currency::engFormat($number % pow(10, 9));
      $string = $prefix." ".$suffix;
      break;
     case $number < pow(10, 15):
      $prefix = Currency::engFormat(intval(floor($number / pow(10, 12))))." Trillion";
      if ($number % pow(10, 12))
       $suffix = Currency::engFormat($number % pow(10, 12));
      $string = $prefix." ".$suffix;
      break;
     case $number < pow(10, 18):
      $prefix = Currency::engFormat(intval(floor($number / pow(10, 15))))." Quadrillion";
      if ($number % pow(10, 15))
       $suffix = Currency::engFormat($number % pow(10, 15));
      $string = $prefix." ".$suffix;
      break;
    }
   }
   return $string;
  }
 }
?>