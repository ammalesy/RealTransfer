<?php 

class Leads extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Leads';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
        $this->load->model('log_lead_remark');
        
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_leads'] = $this->fetch_leads();
        $data['userid'] = $this->user_id;
        
        $this->LoadView('Leads/leads',$data);
	}
	public function adding()
	{
		
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_budget'] = $this->fetch_all_budget();
		$data['list_visit_type'] = $this->fetch_all_visit_type();
		$data['list_media_type'] = $this->fetch_all_media_type();
		$data['list_opportunity_stages'] = $this->fetch_opportunity_stages();
        $data['list_nationality'] = $this->fetch_all_nationality();
        $data['type'] = 'adding';
        
		$data['list_countries'] = $this->fetch_all_countries();
        $this->load->model('tb_province');
		$provinces = $this->tb_province->fetch_all_province();
		foreach($provinces as $row):
			$province .= $comma.'{value: "'.$row->pv_id.'",label: "'.$row->pv_name_th.'"}';
			if($comma==='') $comma = ',';
		endforeach;
		$data['province'] = '['. $province. ']';
        $province = '<option value="">------- Select ------</option>';
        foreach($provinces as $row):
            $selected = (trim($row->pv_name_th) == 'กรุงเทพมหานคร')?'selected':'';
			$province .= '<option '.$selected.'>'.$row->pv_name_th.'</option>';
		endforeach;
		$data['optionProvince'] = $province;
 
		$this->LoadView('Leads/leads_form',$data);
      
		
	}
	/////
	/////
	public function generate_customer(){
		$file = fopen("PEOPLE2.csv","r");
		$list = $this->unique_people($file);
		foreach ($list as $key => $value) {
			$this->record_dummy($value);
		}
	}
	public function unique_people($file){
		$i = 0;
		$list = array();
		$temp_list = array();
	 	while(! feof($file))
	  	{
		     $object = fgetcsv($file);
		     if (empty($object[1])) {
		     	continue;
		     }
		     $key = $object[1];
		     $array_name = explode(" ", $object[1]);
		     $object[1] = $array_name;

		     $list[$key] = $object;
		     $i++;
		}
		fclose($file);
		return $list;
	}
	public function record_dummy($object)
	{
	 	$cus_id = $this->get_new_customer_id();
		$pers_id = $this->get_new_customer_personal_id();
		$addr_id = $this->get_new_customer_address_info_id();
		$addr_cur_id = $this->get_new_customer_address_current_info_id();
		$work_id = $this->get_new_customer_working_info_id();
		$con_id = $this->get_new_customer_contact_info_id();
		$addr_lastest_id = $this->get_new_customer_address_lastest_id();

		if (count($object[1]) == 2) {
			$fname = $object[1][0];
			$lname = $object[1][1];
		}else if(count($object[1]) == 3){
			$fname = $object[1][0];
			$lname = $object[1][1].$object[1][2];
		}else if(count($object[1]) == 4){
			$fname = $object[1][0];
			$lname = $object[1][1].$object[1][2].$object[1][3];
		}else if(count($object[1]) == 5){
			$fname = $object[1][0];
			$lname = $object[1][1].$object[1][2].$object[1][3].$object[1][4];
		}else{
			foreach ($object[1] as $key => $value) {
				$fname .= $value." ";
			}
		}


		
	 	$mobile = $object[3];
	 	$mail = $object[4];

	 	if ($object[0] == 'นาย') {
	 		$sex = "Male";
	 	}else if ($object[0] == 'นาง') {
	 		$sex = "Female";
	 	}else if ($object[0] == 'นางสาว') {
	 		$sex = "Female";
	 	}else{
	 		$sex = '';
	 	}
	 	$tel = $object[3];
	 	$prefix = $object[0];

	 	$stages = '6';
		$budget = '1';
		if (!empty($object[9])) {
			if ($object[9] == 'Booth') {
				$type = 'Other';
				$other_type = 'Booth';
			}else{
				$type = $object[9];
			}
		}else{
			$type = 'Other';
			$other_type = 'Others';
		}
		
		$etctype = '';
    	$type_other = '';


	 	/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();

	 	$data_pers = array(
	 		'pers_id' => $pers_id,
	 		'pers_prefix' => $prefix,
	 		'pers_fname' => $fname,
	 		'pers_lname' => $lname,
	 		'pers_card_id' => '',
	 		'pers_dob' => '',
	 		'pers_mobile' => $mobile,
	 		'pers_tel' => $tel,
	 		'pers_email' => $mail,
	 		'pers_id_cus' => $cus_id,
	 		'pers_nationality' => '171',
	 		'pers_identification_flag' => 'IDCard',
	 		'pers_sex' => $sex
		);
		$this->load->model('tb_customer_personal_info');
		$this->tb_customer_personal_info->record($data_pers);

		$data_addr_info = array(
			'addr_id' => $addr_id,
			'addr_id_cus' => $cus_id,
			'addr_country' => '213'
		);
		$this->load->model('tb_customer_address_info');
		$this->tb_customer_address_info->record($data_addr_info);	
		
		$data_addr_cur_info = array(
			'addr_cur_id' => $addr_cur_id,
			'addr_cur_id_cus' => $cus_id,
			'addr_cur_country' => '213'
		);
		$this->load->model('tb_customer_address_current_info');
		$this->tb_customer_address_current_info->record($data_addr_cur_info);
	
		$data_working = array(
			'work_id' => $work_id,
			'work_cus_id' => $cus_id,
			'work_country' => '213'
		);	
		$this->load->model('tb_customer_working_info');
		$this->tb_customer_working_info->record($data_working);
		
		$data_con = array(
			'con_id' => $con_id,
			'con_id_cus' => $cus_id
		);
		$this->load->model('tb_customer_contact_info');
		$this->tb_customer_contact_info->record($data_con);

		$data_addr_last = array(
			'addr_lastest_id' => $addr_lastest_id,
			'addr_lastest_id_cus' => $cus_id,
			'addr_lastest_country' => '213'
		);
		$this->load->model('tb_customer_address_lastest');
		$this->tb_customer_address_lastest->record($data_addr_last);

		
    	if(!empty($other_type))
	    {
	    	foreach($other_type as $checkbox)  $type_other .= !empty($type_other)?','.$checkbox:$checkbox;
	    }
	   
	    $group_type =  !empty($type_other)?'Other':$type;
	    
	    $type_other = !empty($etctype)?( !empty($type_other)?$type_other.','.$etctype:$etctype):'';
	    
	        
	    $type  = !empty($type_other)?$type_other:$type;

		$sale = $this->user_id;
		$data_leads = array(
			'cus_id' => $cus_id,
			'cus_pers_id' => $pers_id,
			'cus_addr_id' => $addr_id,
			'cus_addr_cur_id' => $addr_cur_id,
			'cus_con_id' => $con_id,
			'cus_work_id' => $work_id,
			'cus_stages_id' => $stages,
			'cus_budget' => $budget,
			'cus_type' => $type,
			'cus_created_by' => $sale,
			'cus_sts_active' => 'on',
			'cus_addr_lastest_id' => $addr_lastest_id,
			'cus_group_type' => $group_type,
			'cus_flag' => 'cus'
		);
		$this->recordLeads($data_leads);

		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
        	//alert_redirect('Add Leads Fail!!','/leads/view');
		}
		else{
		    $this->db->trans_commit();
		    //alert_redirect('Add Leads Success','/leads/view');
		}
		
	}
	//////
	/////
	public function record()
	{
	 	$cus_id = $this->get_new_customer_id();
		$pers_id = $this->get_new_customer_personal_id();
		$addr_id = $this->get_new_customer_address_info_id();
		$addr_cur_id = $this->get_new_customer_address_current_info_id();
		$work_id = $this->get_new_customer_working_info_id();
		$con_id = $this->get_new_customer_contact_info_id();
		$addr_lastest_id = $this->get_new_customer_address_lastest_id();

		$fname = $this->input->get('firstname');
	 	$lname = $this->input->get('lastname');
	 	$mobile = $this->input->get('mobile');
	 	$mail = $this->input->get('mail');
	 	$sex = $this->input->get('sex');
	 	$prefix =$this->input->get('Prefix');
	 	$Nationality = $this->input->get('Nationality');
	 	$remark = $this->input->get('remark');
		$form = $this->input->get('form');
		$interest = $this->input->get('interest');
		$salary = $this->input->get('salary');
		$pj_id = $this->input->get('pj_id');
		$url_ref = $this->input->get('url_ref');
		$regis_id = $this->input->get('regis_id');
        
        $addr_address = $this->input->get('address');
        $addr_sub_district = $this->input->get('sub_district');
        $addr_district = $this->input->get('district');
        $addr_province = $this->input->get('province');
        $addr_post_code  = $this->input->get('post');
        
        
        if ($form == "webregis"){
            $tel = "";
        }
        else {
            $tel = $this->input->get('tel');
        }
 
        $this->load->model('tb_customer_personal_info');
        if($this->tb_customer_personal_info->check_cus_name($fname,$lname)) {
            if ($form == "webregis"){
              echo '<script>
                    alert("Sorry: This first and last name are already in the database. Please check again!!");
                    window.history.back(-2);
                </script>';
            }
            else {
                echo '<script>alert("This first and last name are already in the database. Please check again!!");window.location.href="'.BASE_DOMAIN.'leads/view";</script>';
            }
            exit;
        }

	 	/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();

        if ($Nationality == 171) {
            if ($prefix == 'Mr.') {
                $prefix = 'นาย';
            } else if ($prefix == 'Miss') {
                $prefix = 'นางสาว';
            } else if ($prefix == 'Mrs.') {
                $prefix = 'นาง';
            } else {
                $prefix = 'คุณ';
            }
            $identificationFlag = "IDCard";
        } else {
        	$identificationFlag = "passport";
        }
        
	 	$data_pers = array(
	 		'pers_id' => $pers_id,
	 		'pers_prefix' => $prefix,
	 		'pers_fname' => $fname,
	 		'pers_lname' => $lname,
	 		'pers_card_id' => '',
	 		'pers_dob' => '',
	 		'pers_mobile' => $mobile,
	 		'pers_tel' => $tel,
	 		'pers_email' => $mail,
	 		'pers_id_cus' => $cus_id,
            'pers_nationality' => $Nationality,
	 		'pers_identification_flag' => $identificationFlag,
	 		'pers_sex' => $sex
		);
		$this->tb_customer_personal_info->record($data_pers);

		$data_addr_info = array(
			'addr_id' => $addr_id,
            'addr_address' => $addr_address,
            'addr_sub_district' => $addr_sub_district,
            'addr_district' => $addr_district,
            'addr_province' => $addr_province,
            'addr_post_code' => $addr_post_code,
			'addr_country' => '213',
			'addr_id_cus' => $cus_id,
		);//Thailand = 213
		$this->load->model('tb_customer_address_info');
		$this->tb_customer_address_info->record($data_addr_info);	
		
		$data_addr_cur_info = array(
			'addr_cur_id' => $addr_cur_id,
			'addr_cur_id_cus' => $cus_id,
			'addr_cur_country' => '213'
		);
		$this->load->model('tb_customer_address_current_info');
		$this->tb_customer_address_current_info->record($data_addr_cur_info);
	
		$data_working = array(
			'work_id' => $work_id,
			'work_cus_id' => $cus_id,
			'work_country' => '213'
		);	
		$this->load->model('tb_customer_working_info');
		$this->tb_customer_working_info->record($data_working);
		
		$data_con = array(
			'con_id' => $con_id,
			'con_id_cus' => $cus_id
		);
		$this->load->model('tb_customer_contact_info');
		$this->tb_customer_contact_info->record($data_con);

		$data_addr_last = array(
			'addr_lastest_id' => $addr_lastest_id,
			'addr_lastest_id_cus' => $cus_id,
			'addr_lastest_country' => '213'
		);
		$this->load->model('tb_customer_address_lastest');
		$this->tb_customer_address_lastest->record($data_addr_last);

		$this->load->model('tb_opportunity_stages');
		$stages = $this->input->get('stages');
        $rates = $this->tb_opportunity_stages->get_by_id($stages)->op_rates;
        
		$budget = $this->input->get('Budget');
		$visitType = $this->input->get('visitType');
		$form = $this->input->get('form');
        
        if ($form == "webregis"){
		  $mediaType = $this->input->get('mediaType');
        }
        else {
            $mediaType = implode(',', $this->input->get('mediaType'));
        }
		//$etctype = $this->input->post('etcother'); 
		$sale = $this->user_id;
		$data_leads = array(
			'cus_id' => $cus_id,
			'cus_pers_id' => $pers_id,
			'cus_addr_id' => $addr_id,
			'cus_addr_cur_id' => $addr_cur_id,
			'cus_con_id' => $con_id,
			'cus_work_id' => $work_id,
			'cus_stages_id' => $stages,
			'cus_budget' => $budget,
			'cus_visit_type' => $visitType,
            'cus_media_type' => $mediaType,
			'cus_created_by' => $sale,
			'cus_sts_active' => 'on',
			'cus_addr_lastest_id' => $addr_lastest_id,
			'cus_remark' => $remark
		);
		$this->recordLeads($data_leads);
        
		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
                if ($form == "webregis"){
                    echo '<script>
                    alert("Registered Fail!!!");
                    window.history.back(-2);
                </script>';
                    //window.location.href="https://kitha.realsmart.in.th/RealCondo/RealCondo.html";
                  //alert_redirect('Add Leads Success','https://kitha.realsmart.in.th/RealCondo/RealCondo.html');
                }
                else {
                    alert_redirect('Add Leads Fail!!','/leads/view');
                }
		}
		else{
		    $this->db->trans_commit();
            if(!empty($this->input->get('becus'))) {
            	echo '<script>window.location.href = "'.BASE_DOMAIN.'customer/editing/'.$cus_id.'"</script>';
            }else if(!empty($this->input->get('newQuotation'))) {
                alert_redirect('Add Leads Success','/quotation/adding/'.$cus_id);
            } else if ($rates=='100') {
				alert_redirect("Next To Add Customer","/customer/editing/".$cus_id."");
            } else {
                
                $this->updateRegisStatus($regis_id);
                
                if ($form == "webregis"){
                    alert_redirect('Approve Leads Success','/regis_from_web/view');
                }
                else {
                    alert_redirect('Add Leads Success','/leads/view');
                }
			}
		}
		
	}
	public function editing($cid)
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$lead = $this->get_detail_leads($cid);
		$data['lead'] = $lead;
		$data['cid'] = $cid;
		$data['list_budget'] = $this->fetch_all_budget();
		$data['list_opportunity_stages'] = $this->fetch_opportunity_stages();
		$data['list_visit_type'] = $this->fetch_all_visit_type();
		$data['list_media_type'] = $this->fetch_all_media_type();
        $data['lead_visit_type'] = explode(',', $lead->cus_visit_type);
        $data['lead_media_type'] = explode(',', $lead->cus_media_type);
        $data['type'] = 'editing';
        $flafIsOther = TRUE;
	    $data['isother'] = $flafIsOther;
        $data['list_nationality'] = $this->fetch_all_nationality();
        
		$this->LoadView('Leads/leads_form',$data);
	}
	public function update($cid)
	{
		$prefix = $this->input->get('Prefix');
	  	$fname = $this->input->get('firstname');
	 	$lname = $this->input->get('lastname');
	 	$mobile = $this->input->get('mobile');
 		$mail = $this->input->get('mail');
	 	$sex = $this->input->get('sex');
	 	$tel = $this->input->get('tel');
        $Nationality = $this->input->get('Nationality');
        $remark = $this->input->get('remark');
	 	//$cus_status = $this->input->get('cus_status');
	 	$pers_id = $cid;
	 	$userEdit = $this->user_id;	

	 	/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();
        
       
        if ($Nationality == 171) {
            if ($prefix == 'Mr.') {
                $prefix = 'นาย';
            } else if ($prefix == 'Miss') {
                $prefix = 'นางสาว';
            } else if ($prefix == 'Mrs.') {
                $prefix = 'นาง';
            }
            $identificationFlag = "IDCard";
        } else {
        	$identificationFlag = "passport";
        }
        
	 	$data_pers = array(
	 		'pers_prefix' => $prefix,
	 		'pers_fname' => $fname,
	 		'pers_lname' => $lname,
	 		'pers_mobile' => $mobile,
	 		'pers_email' => $mail,
	 		'pers_id_cus' => $pers_id,
            'pers_nationality' => $Nationality,
            'pers_identification_flag' => $identificationFlag,
	 		'pers_sex' => $sex,
	 		'pers_tel' => $tel
	 	);
	 	$this->load->model('tb_customer_personal_info');
	 	$this->tb_customer_personal_info->update($data_pers,$pers_id);

		
		$stages = $this->input->get('stages');
		$budget = $this->input->get('Budget');
		
		$visitType = $this->input->get('visitType');
		$form = $this->input->get('form');
        
        if ($form == "webregis"){
		  $mediaType = $this->input->get('mediaType');
        }
        else {
            $mediaType = implode(',', $this->input->get('mediaType'));
        }
		//$etctype = $this->input->post('etcother'); 

		$data_leads = array(
			'cus_pers_id' => $pers_id,
			'cus_stages_id' => $stages,
			'cus_budget' => $budget,
			'cus_visit_type' => $visitType,
            'cus_media_type' => $mediaType,
            'cus_remark' => $remark
			//'cus_sts_active' => $cus_status
		);
		$this->updateLeads($data_leads,$cid);

		////// KEEP LOG ////
		$obj_pers = $this->tb_customer_personal_info->get_detail_by_id($pers_id);
		$data_log_pers = array(
			'pers_id' => $obj_pers->pers_id,
            'pers_prefix' => $obj_pers->pers_prefix,
			'pers_fname' => $obj_pers->pers_fname,
			'pers_lname' => $obj_pers->pers_lname,
			'pers_sex' => $obj_pers->pers_sex,
			'pers_nationality' => $obj_pers->pers_nationality,
			'pers_identification_flag' => $obj_pers->pers_identification_flag,
			'pers_passport' => $obj_pers->pers_passport,
			'pers_card_id' => $obj_pers->pers_card_id,
			'pers_dob' => $obj_pers->pers_dob,
			'pers_mobile' => $obj_pers->pers_mobile,
			'pers_tel' => $obj_pers->pers_tel,
			'pers_email' => $obj_pers->pers_email,
			'pers_id_cus' => $obj_pers->pers_id_cus,
			'pers_update_by' => $this->user_id
		);
		$this->record_log_customer_personal_info($data_log_pers);

		////// KEEP LOG ////
		$this->load->model('tb_customer');
		$obj_leads = $this->tb_customer->get_detail_by_id($cid);
		$data_log_leads = array(
			'cus_id' => $obj_leads->cus_id,
			'cus_pers_id' => $obj_leads->cus_pers_id,
			'cus_addr_id' => $obj_leads->cus_addr_id,
			'cus_addr_cur_id' => $obj_leads->cus_addr_cur_id,
			'cus_con_id' => $obj_leads->cus_con_id,
			'cus_work_id' => $obj_leads->cus_work_id,
			'cus_stages_id' => $obj_leads->cus_stages_id,
			'cus_budget' => $obj_leads->cus_budget,
			'cus_visit_type' => $obj_leads->cus_visit_type,
            'cus_media_type' => $obj_leads->cus_media_type,
			'cus_flag' => $obj_leads->cus_flag,
			'cus_created_by' => $obj_leads->cus_created_by,
			'cus_created_date' => $obj_leads->cus_created_date,
			//'cus_sts_active' => $obj_leads->cus_sts_active,
			'cus_update_by' => $this->user_id
		);
		$this->record_log_leads($data_log_leads);
        
        $this->load->model('tb_customer_address_info');
        $obj_addr = $this->tb_customer_address_info->get_detail_by_addr_id_cus($cid);
        $data_log_addr_info = array(
            'addr_id' => $obj_addr->addr_id,
            'addr_sub_district' => $obj_addr->addr_sub_district,
            'addr_district' => $obj_addr->addr_district,
            'addr_province' => $obj_addr->addr_province,
            'addr_post_code' => $obj_addr->addr_post_code,
            'addr_country' => $obj_addr->addr_country,
            'addr_id_cus' => $obj_addr->addr_id_cus,
            'addr_update_by' => $this->user_id
        );
        $this->record_log_customer_address_info($data_log_addr_info);
        
        $this->load->model('tb_customer_address_current_info');
        $obj_addr_cur = $this->tb_customer_address_current_info->get_detail_by_addr_cur_id_cus($cid);
        $data_log_addr_cur = array(
            'addr_cur_id' => $obj_addr_cur->addr_cur_id,
            'addr_cur_sub_district' => $obj_addr_cur->addr_cur_sub_district,
            'addr_cur_district' => $obj_addr_cur->addr_cur_district,
            'addr_cur_province' => $obj_addr_cur->addr_cur_province,
            'addr_cur_post_code' => $obj_addr_cur->addr_cur_post_code,
            'addr_cur_country' => $obj_addr_cur->addr_cur_country,
            'addr_cur_id_cus' => $obj_addr_cur->addr_cur_id_cus,
            'addr_cur_update_by' => $this->user_id
        );
        $this->record_log_customer_address_current_info($data_log_addr_cur);
        
        $this->load->model('tb_customer_working_info');
        $obj_working = $this->tb_customer_working_info->get_detail_by_work_cus_id($cid);
        $data_log_working = array(
            'work_id' => $obj_working->work_id,
            'work_position' => $obj_working->work_position,
            'work_company' => $obj_working->work_company,
            'work_house_no' => $obj_working->work_house_no,
            'work_road' => $obj_working->work_road,
            'work_sub' => $obj_working->work_sub,
            'work_district' => $obj_working->work_district,
            'work_province' => $obj_working->work_province,
            'work_post_code' => $obj_working->work_post_code,
            'work_country' => $obj_working->work_country,
            'work_cus_id' => $obj_working->work_cus_id,
            'work_update_by' => $this->user_id
        );
        $this->record_log_customer_working_info($data_log_working);
        
        $this->load->model('tb_customer_contact_info');
        $obj_contact = $this->tb_customer_contact_info->get_detail_by_con_id_cus($cid);
        $data_log_contact = array(
            'con_id' => $obj_contact->con_id,
            'con_fname' => $obj_contact->con_fname,
            'con_lname' => $obj_contact->con_lname,
            'con_email' => $obj_contact->con_email,
            'con_tel' => $obj_contact->con_tel,
            'con_id_cus' => $obj_contact->con_id_cus,
            'con_update_by' => $this->user_id
        );
        $this->record_log_customer_contact_info($data_log_contact);
        
        $this->load->model('tb_customer_address_lastest');
        $obj_cus_addr_lastest = $this->tb_customer_address_lastest->get_detail_by_addr_lastest_id_cus($cid);
        $data_log_addr_lastest = array(
             'addr_lastest_id' => $obj_cus_addr_lastest->addr_lastest_id,
             'addr_lastest_address' => $obj_cus_addr_lastest->addr_lastest_address,
             'addr_lastest_sub_district' => $obj_cus_addr_lastest->addr_lastest_sub_district,
             'addr_lastest_district' => $obj_cus_addr_lastest->addr_lastest_district,
             'addr_lastest_province' => $obj_cus_addr_lastest->addr_lastest_province,
             'addr_lastest_post_code' => $obj_cus_addr_lastest->addr_lastest_post_code,
             'addr_lastest_country' => $obj_cus_addr_lastest->addr_lastest_country,
             'addr_lastest_id_cus' => $obj_cus_addr_lastest->addr_lastest_id_cus,
             'addr_cur_update_by' => $this->user_id
        );
        $this->record_log_customer_address_lastest($data_log_addr_lastest);

		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
        	alert_redirect("Edit Leads fail!","/leads/view");	
		}
		else{
		    $this->db->trans_commit();
            if(!empty($this->input->get('becus'))) {
            	echo '<script>window.location.href = "'.BASE_DOMAIN.'customer/editing/'.$cid.'"</script>';
            } else if ($stages=='6') {
				alert_redirect("Next To Add Customer","/customer/editing/".$cid."");			
			} else {
				alert_redirect("Edit Leads Success","/leads/view");		
			}
		}
	
		
	}
	public function deleting($cid){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_leads,'4') === FALSE) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');		
		}
		$data_leads = array(
			'cus_sts_active' => 'off'
		);
		$this->updateLeads($data_leads,$cid);
		alert_redirect('Delete Leads Success','/leads/view');
	}

	/**
	* -------------------------------------
	* Scope [PRIVATE METHOD]
	* -------------------------------------
	*/
	//////// LEADS ////////////
	//////////////////////////
	private function get_detail_leads($cid){
		$this->load->model('tb_customer');
		return $this->tb_customer->get_detail_leads($cid);
	}
	private function fetch_leads(){
		$this->load->model('tb_customer');
		$this->load->model('tb_visit_type');
		$this->load->model('log_lead_remark');
        $leadList = $this->tb_customer->fetch_leads_ignorActive();
        foreach ($leadList as $key=>$lead) {
            $lead->type = $this->tb_visit_type->get_name_by_id($lead->cus_visit_type);
			
			$lastLead = $this->log_lead_remark->Lastest($lead->cus_id);
            $lead->lr_timestamp = $lastLead->lr_timestamp;
            $lead->lr_remark = $lastLead->lr_remark;
			
        }
		return $leadList;
	}
	private function fetch_all_budget(){
		$this->load->model('tb_budget');
		return $this->tb_budget->fetch_all();
	}
	private function fetch_all_visit_type(){
		$this->load->model('tb_visit_type');
		return $this->tb_visit_type->fetch_all();
	}
    private function fetch_all_media_type(){
		$this->load->model('tb_media_type');
		return $this->tb_media_type->fetch_all();
	}
	private function fetch_opportunity_stages(){
		$this->load->model('tb_opportunity_stages');
		return $this->tb_opportunity_stages->fetch_opportunity_stages();
	}
	private function get_new_customer_id(){
		$this->load->model('tb_customer');
		return $this->tb_customer->get_new_customer_id();
	}
	private function get_new_customer_address_lastest_id(){
		$this->load->model('tb_customer_address_lastest');
		return $this->tb_customer_address_lastest->get_new_customer_address_lastest_id();
	}
	private function get_new_customer_personal_id(){
		$this->load->model('tb_customer_personal_info');
		return $this->tb_customer_personal_info->get_new_customer_personal_id();
	}
	private function get_new_customer_address_info_id(){
		$this->load->model('tb_customer_address_info');
		return $this->tb_customer_address_info->get_new_customer_address_info_id();
	}
	private function get_new_customer_address_current_info_id(){
		$this->load->model('tb_customer_address_current_info');
		return $this->tb_customer_address_current_info->get_new_customer_address_current_info_id();
	}
	private function get_new_customer_working_info_id(){
		$this->load->model('tb_customer_working_info');
		return $this->tb_customer_working_info->get_new_customer_working_info_id();	
	}
	private function get_new_customer_contact_info_id(){
		$this->load->model('tb_customer_contact_info');
		return $this->tb_customer_contact_info->get_new_customer_contact_info_id();
	}
    private function fetch_all_nationality(){
		$this->load->model('tb_nationality');
		return $this->tb_nationality->fetch_all_nationality();
	}

	//////// RECORD //////////
	//////////////////////////
	private function recordLeads($data)
	{
		$this->load->model('tb_customer');
		$this->tb_customer->record($data);
        
	}

	//////// UPDATE //////////
	//////////////////////////
	private function updateLeads($data,$cid)
	{
		$this->load->model('tb_customer');
		$this->tb_customer->update($data,$cid);
	}

	/**
	* -------------------------------------
	* Log Management [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function record_log_customer_personal_info($data)
	{
		$this->load->model('log_customer_personal_info');
		$this->log_customer_personal_info->record($data);
	}
	private function record_log_leads($data)
	{
		$this->load->model('log_customer');
		$this->log_customer->record($data);
	}
//	private function record_log_leads_info($data)
//	{
//		$this->load->model('log_customer_personal_info');
//		$this->log_customer_personal_info->record($data);
//	}
    
    //////////////////////// MODAL /////////////////////////////
    public function modal_new_lead()
	{
	 	$cus_id = $this->get_new_customer_id();
		$pers_id = $this->get_new_customer_personal_id();
		$addr_id = $this->get_new_customer_address_info_id();
		$addr_cur_id = $this->get_new_customer_address_current_info_id();
		$work_id = $this->get_new_customer_working_info_id();
		$con_id = $this->get_new_customer_contact_info_id();
		$addr_lastest_id = $this->get_new_customer_address_lastest_id();

		$fname = $this->input->post('modal-firstname');
	 	$lname = $this->input->post('modal-lastname');
        $sex = $this->input->post('modal-sex');
        $prefix =$this->input->post('modal-prefix');
        $Nationality = $this->input->post('modal-nationality');
	 	$mobile = $this->input->post('modal-mobile');
        $mail = $this->input->post('modal-mail');
        $tel = $this->input->post('modal-tel');
	 	$remark = $this->input->post('modal-remark');
	 	$url = $this->input->post('modal-url');
        
        $this->load->model('tb_customer_personal_info');
        if($this->tb_customer_personal_info->check_cus_name($fname,$lname)) {
            echo '
                <script>
                    alert("Lead name already.");
                    window.location.href="'.$url.'";
                </script>';
            exit;
        }

	 	/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();

	 	$data_pers = array(
	 		'pers_id' => $pers_id,
	 		'pers_prefix' => $prefix,
	 		'pers_fname' => $fname,
	 		'pers_lname' => $lname,
	 		'pers_card_id' => '',
	 		'pers_dob' => '',
	 		'pers_mobile' => $mobile,
	 		'pers_tel' => $tel,
	 		'pers_email' => $mail,
	 		'pers_id_cus' => $cus_id,
            'pers_nationality' => $Nationality,
	 		'pers_identification_flag' => 'IDCard',
	 		'pers_sex' => $sex
		);
		$this->tb_customer_personal_info->record($data_pers);

		$data_addr_info = array(
			'addr_id' => $addr_id,
			'addr_id_cus' => $cus_id,
			'addr_country' => '213'
		);
		$this->load->model('tb_customer_address_info');
		$this->tb_customer_address_info->record($data_addr_info);	
		
		$data_addr_cur_info = array(
			'addr_cur_id' => $addr_cur_id,
			'addr_cur_id_cus' => $cus_id,
			'addr_cur_country' => '213'
		);
		$this->load->model('tb_customer_address_current_info');
		$this->tb_customer_address_current_info->record($data_addr_cur_info);
	
		$data_working = array(
			'work_id' => $work_id,
			'work_cus_id' => $cus_id,
			'work_country' => '213'
		);	
		$this->load->model('tb_customer_working_info');
		$this->tb_customer_working_info->record($data_working);
		
		$data_con = array(
			'con_id' => $con_id,
			'con_id_cus' => $cus_id
		);
		$this->load->model('tb_customer_contact_info');
		$this->tb_customer_contact_info->record($data_con);

		$data_addr_last = array(
			'addr_lastest_id' => $addr_lastest_id,
			'addr_lastest_id_cus' => $cus_id,
			'addr_lastest_country' => '213'
		);
		$this->load->model('tb_customer_address_lastest');
		$this->tb_customer_address_lastest->record($data_addr_last);

		$stages = $this->input->post('modal-stages');
		$budget = $this->input->post('modal-budget');
		$visitType = implode(',', $this->input->post('modal-visitType'));
		$mediaType = implode(',', $this->input->post('modal-mediaType'));
		//$etctype = $this->input->post('etcother'); 
		$sale = $this->user_id;
		$data_leads = array(
			'cus_id' => $cus_id,
			'cus_pers_id' => $pers_id,
			'cus_addr_id' => $addr_id,
			'cus_addr_cur_id' => $addr_cur_id,
			'cus_con_id' => $con_id,
			'cus_work_id' => $work_id,
			'cus_stages_id' => $stages,
			'cus_budget' => $budget,
			'cus_visit_type' => $visitType,
            'cus_media_type' => $mediaType,
			'cus_created_by' => $sale,
			'cus_sts_active' => 'on',
			'cus_addr_lastest_id' => $addr_lastest_id,
			'cus_remark' => $remark
		);
		$this->recordLeads($data_leads);

		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
        	echo '
                <script>
                    alert("Add Leads Fail.");
                    window.location.href="'.$url.'";
                </script>';
            exit;
		}
		else{
		    $this->db->trans_commit();
            
            echo '
                <script>
                    alert("Add Leads Success.");
                    window.location.href="'.$url.'";
                </script>';
            exit;
		}
		
	}
    
    private function fetch_all_countries(){
		$this->load->model('tb_countries');
		return $this->tb_countries->fetch_all_countries();
	}
    
    function LastRemark($id) {
        $this->load->model('log_lead_remark');
        $data = $this->log_lead_remark->Lastest($id);
        
        echo json_encode($data);
    }
    
    
	public function updateRegisStatus($regis_id){
		$data_regis = array(
			'regis_status' => 'approve'
		);
        $this->load->model('tb_regis_from_web');
		$this->tb_regis_from_web->update_regis($data_regis,$regis_id);
		//alert_redirect('Delete Success','/regis_from_web/view');
	}
    
	private function record_log_customer_contact_info($data)
	{
		$this->load->model('log_customer_contact_info');
		$this->log_customer_contact_info->record($data);
	}
	private function record_log_customer_address_info($data)
	{
		$this->load->model('log_customer_address_info');
		$this->log_customer_address_info->record($data);
	}
	private function record_log_customer_address_current_info($data)
	{
		$this->load->model('log_customer_address_current_info');
		$this->log_customer_address_current_info->record($data);
	}
	private function record_log_customer_working_info($data)
	{
		$this->load->model('log_customer_working_info');
		$this->log_customer_working_info->record($data);
	}
	private function record_log_customer_address_lastest($data)
	{
		$this->load->model('log_customer_address_lastest');
		$this->log_customer_address_lastest->record($data);
	}
}

/* End of file leads.php */
/* Location: ./application/controllers/leads.php */