<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Receipt extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Receipt';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
    
	public function view($type,$option) 
    {
        
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['list_receipt'] = $this->fetch_receipt($type,$option);
        $data['project_database_sel'] = $this->project_database_sel;
		$data['type'] = $type;
        $data['month'] = $option;
		$this->LoadView('Receipt/receipt',$data);

    }
    
	public function confirm_tranfer($type) 
    {
		$prj = $this->project_name_sel;
	    $receiptcode =  '';
	    $receiptcode = $this->input->post('rcvid');
	    $reason      = $this->input->post('reason');

        if ( $receiptcode != '' )
        {
        	$data = array(
        		'rc_confirm' => 'yes',
        		'rc_remark' => $reason
        	);
        	$this->load->model('tb_receipt_temporary');
        	$this->tb_receipt_temporary->update_where($data,"rc_code = '".$receiptcode."'");
        }
        if($type === 'overdue')
            echo "<script>window.location.href = '".BASE_DOMAIN."overdue/installment';</script>";
        else if(!empty($type))
            echo "<script>window.location.href = '".BASE_DOMAIN."installment/listInstallment/$type';</script>";
        else
            echo "<script>window.location.href = '".BASE_DOMAIN."receipt/view/wait';</script>";
//        redirect('/receipt/view/wait');
	}
    
	public function adding($code,$val,$flag,$ctCode) 
    {
//        echo "code : ".$code;
//        echo "+++val : ".$val;
//        echo "+++flag : ".$flag;
//        echo "+++ctCode : ".$ctCode; 
//        exit();
		$this->checkSessionTimeout();
        $this->load->library('encrypt');
        $this->load->model('tb_receipt_temporary');
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$recid =0;
		$paymentid = '0';
		if ($flag=='1') {
 			$selBooking ='checked="checked"';
			$selContract ='';
			$selIns ='';
			$disBooking ='';
			$disContract ='disabled="disabled"';
			$disIns ='disabled="disabled"';
		}  else if ($flag=='2') {
			$selBooking ='';
			$selContract ='checked="checked"';
			$selIns ='';
			$disBooking ='disabled="disabled"';
			$disContract ='';
			$disIns ='disabled="disabled"';			
		} else if ($flag=='3') {
			$selBooking ='';
			$selContract ='';
			$selIns ='checked="checked"';
			$disBooking ='disabled="disabled"';
			$disContract ='disabled="disabled"';
			$disIns ='';
		} else if ($flag=='4') {
			$selBooking ='';
			$selContract ='';
			$selIns ='checked="checked"';
			$disBooking ='disabled="disabled"';
			$disContract ='disabled="disabled"';
			$disIns ='';
            $data['prePage'] = $ctCode;
		} else if ($flag=='5') {
			$selBooking ='';
			$selContract ='';
			$selIns ='checked="checked"';
			$disBooking ='disabled="disabled"';
			$disContract ='disabled="disabled"';
			$disIns ='';
            $data['prePage'] = 'overdue';
		}
		$disCus ='';
		$definefee = '';
		if ($code == 'pmid') {
            $getreceipt = $this->tb_receipt_temporary->get_detail_booking($val);
            $imcode = $getreceipt->rc_installment_code;
			$this->load->model('tb_installment');
			$getpmid 	= $this->tb_installment->get_full_detail_by_code($imcode);
			$disCus 	='disabled="disabled"';
            $bookid     = $getreceipt->rc_booking_code;
			$conid  	= $getpmid->im_contract_code;
			$installment  = $getpmid->im_installment_time;	
            $installment_code = $getpmid->im_code;
			$customer_name  = $getreceipt->pers_fname.' '.$getreceipt->pers_lname;				
			$paymentid 	  = $getpmid->im_id; 
			$recid = $getreceipt->rc_id;
			$projectid = $this->project_id_sel;        
            
            $this->load->model('tb_contract');
            $installment_detail = $this->tb_contract->get_installment_detail_by_code($conid);
            $this->load->model('tb_receipt_temporary');
            $get_total_amount = $this->tb_receipt_temporary->get_temp_receipt_by_rc_id($recid);
            $this->load->library('payment');
            // echo "$get_total_amount->rc_total_amount";
            // exit();
            $definefee    = $this->payment->getDefinefee($installment, (array)$installment_detail,$get_total_amount->rc_total_amount);
			$getcontract = $this->tb_contract->get_detail_by_ct_code($conid);
            
            $data['remark'] = $getpmid->im_remark;
//            $data['user_signature'] = "";
            $data['pmid'] = 'yes';
		} 
		else if ($code == 'rcid') {
			$getreceipt 	= $this->tb_receipt_temporary->get_detail_receipt($val);
			$disCus 	='disabled="disabled"';
            $bookid     = $getreceipt->rc_booking_code;
			$conid  	= $getreceipt->rc_contract_code;	
			$installment  	= $getreceipt->rc_installment_code;	
			$definefee  	= $getreceipt->rc_total_amount;				
			$recid = $val; 
			$paymentid = '0';		
            $customer_name  = $getreceipt->pers_fname.' '.$getreceipt->pers_lname;
            // get Project 
            $this->load->model('tb_booking'); 
            $getpj 	= $this->tb_booking->get_detail_by_bk_booking_code(trim($getreceipt->rc_booking_code));
            $projectid = $getpj->bk_project_id;	
                            
            $this->load->model('tb_contract');
			$getcontract = $this->tb_contract->get_detail_by_ct_code($conid);
//            $data['user_signature']   = trim($getcontract->ct_authorized_user);
            $data['remark'] = $getcontract->ct_remark;
		} 
		else if ($code== 'bkid') {
			$getreceipt 	= $this->tb_receipt_temporary->get_detail_booking($val);
			$disCus 	='disabled="disabled"';
			$bookid  	= $getreceipt->rc_booking_code;	
			$installment  = $getreceipt->rc_installment_code;	
			$definefee  = $getreceipt->rc_total_amount;				
			$recid = $val; 
			$paymentid = '0';	
            $customer_name  = $getreceipt->pers_fname.' '.$getreceipt->pers_lname;

            $data['projectid'] = $getreceipt->bk_project_id;                           
                                
            // get Project

            $this->load->model('tb_booking'); 
            $getcontract = $this->tb_booking->get_detail_by_bk_booking_code(trim($bookid));  
            $projectid = $getcontract->bk_project_id;
            $data['remark'] = $getcontract->bk_remark;
		} 
        
        $rcDetail = $this->tb_receipt_temporary->get_by_id($recid);
        if(empty($rcDetail))
        {
            alert_redirect('Add receipt Fail','/receipt/view/wait');
        }
        
        $this->load->model('tb_payment');
        $paymentlist = $this->tb_payment->get_by_temp_receipt($getreceipt->rc_code);

        $i=0;
        foreach($paymentlist as $value) {
            if($value->pm_type == 'Cash') {
                $data['pmCash']     = $value->pm_id;
                $data['cashpaid']   = 'yes';
                $data['cashamount'] =  $value->pm_amount;
            }
            else if($value->pm_type == 'Credit') {
                $data['creditcardpaid']        = 'yes';
                $data['pmCard'][$i]            = $value->pm_id;
                $data['creditcardbank'][$i]    = $value->pm_cr_bank;
                $data['creditcardno'][$i]      = $value->pm_cr_number;
                $data['creditcardtype'][$i]    = $value->pm_cr_type;
                $data['creditcardapprove'][$i] = $value->pm_cr_approve_code;
                $expire = explode('/', $value->pm_cr_expire);
                $data['expiremonth'][$i]       = $expire[0];
                $data['expireyear'][$i]        = $expire[1];
                $data['creditcardholder'][$i]  = $value->pm_cr_holder;
                $data['creditcardamount'][$i]  = $value->pm_amount;
                $i++;
            }
            else {
                $data['pmOther']     = $value->pm_id;
                $data['paidother']          = 'yes';
                $data['padidotherby']       = $value->pm_type;
                $data['padidotheramount']   = $value->pm_amount;
            }
        }
        $this->load->model('tb_receipt_offical');
        if(!empty($getreceipt->rc_refer_form)){
            $data['receiptpaid'] = 'yes';
            $data['allReceipt'] = $this->tb_receipt_offical->get_by_ids($getreceipt->rc_refer_form);
        }

		$this->load->model('tb_customer_personal_info');
		$list_customer = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        
        $this->load->model('tb_bank_account');
        $bankAccount = $this->tb_bank_account->get_all_bank_account();
        $data['bankAccount'] = $bankAccount;

		$data['permission'] = $this->get_user_permission();
        if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled_all_status();
        }
		$data['list_customer'] = $list_customer;
		$data['disCus'] = $disCus;
		$data['getpmid'] = $getreceipt;
		$data['selBooking'] = $selBooking;
		$data['disBooking'] = $disBooking;
		$data['paymentid'] = $paymentid;
		$data['bookid'] = $bookid;
		$data['recid'] = $recid;
		$data['selContract'] = $selContract;
		$data['disContract'] = $disContract;
		$data['conid'] = $conid;
		$data['selIns'] = $selIns;
		$data['disIns'] = $disIns;
		$data['installment'] = $installment;
        $data['installment_code'] = $installment_code;
        $data['definefee'] = $definefee;
		//$data['val'] = $val;
		$data['projectid'] = $projectid;
		$data['customer_name'] = $customer_name;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;

//		$this->load->model('tb_authorize_user');
//		$typedoc = $code=='rcid'?"Contract":"Receipt";
//		$data['signature'] = $this->tb_authorize_user->get_info_by_au_document($typedoc);

		$this->LoadView('Receipt/receipt_form',$data);
	}
    
	public function record() 
    {
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();
	 	$this->pdb->trans_begin();
	 	
		$recid = $this->input->post('recid');
		$projectid  =	$this->input->post('projectid');
		$cusid  =	$this->input->post('cusid');
		$Type  =	$this->input->post('Type');
		$payfor  =	$this->input->post('Payfor');
		$contract  =	$this->input->post('conid');
		$Booking  =	$this->input->post('bookid');
		$InstallmentTime =	$this->input->post('instime');
        $InstallmentCode =	$this->input->post('inscode');
		$usersignature	 =	$this->input->post('authorize');
        $official_date   =  $this->input->post('OfficialDate');
//		$MoneyAmount  =	'';
//		$cardBank  =	'';
//		$cardno   =	'';
//		$cardDate   =	'';
//		$OtherBy  =	'';
//		$Remark = $this->input->post('Remark');
//		//Last Update Multi Paid     
//        $rc_type_payment = '';
//        $rc_pay_crcard   = '';
//        $rc_pay_other    = '';
        
        $this->load->model('tb_payment');
        $this->load->model('tb_receipt_temporary');
        $rcDetail = $this->tb_receipt_temporary->get_by_id($recid);
        if(empty($rcDetail))
        {
            alert_redirect('Add receipt Fail','/receipt/view/wait');
        }
	   
//	    if(!empty($Type))
//	       {
//	         foreach($Type as $check) {
//	            if ( trim($check) == 'Cash' )   $rc_type_payment = 'yes';
//	            if ( trim($check) == 'CrCard' ) $rc_pay_crcard = 'yes';
//	            if ( trim($check) == 'Other' )  $rc_pay_other  = 'yes';              
//	       }
//	    }
//        $rc_cash_amount    =	$this->input->post('Cashamount');
//        $rc_crcard_bank    =	$this->input->post('CardBank');
//        $rc_crcard_no      =	$this->input->post('Cardno');
//        $expiremonth_      =    $this->input->post('expiremonth');
//        $expireyear_       =	$this->input->post('expireyear');
//        $rc_crcard_date    =	(!empty($expiremonth_) && !empty($expireyear_))?$expiremonth_.'/'.$expireyear_:"";
//        $rc_crcard_amount  =	$this->input->post('Cardamount');
//        $rc_crcard_fname   =	$this->input->post('Cardfname');
//        $rc_other_by       =	$this->input->post('OtherBy');
//        $rc_other_amount   =	$this->input->post('Otheramount');
//	    
//        $MoneyAmount  =	$this->input->post('definefee');

	
		if ($payfor!='Booking Fee') {
			$this->load->model('tb_contract');
			$get = $this->tb_contract->get_detail_by_ct_code($contract);
			$Booking = $get->ct_booking_code;
		}
		$today = date("Y-m-d"); 
		
		//////////////////////////////////////////
		//////////////////////////////////////////
        $this->load->model('tb_receipt_offical');
		$newid= $this->tb_receipt_offical->get_next_id();
		$tmp = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($projectid);
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) { 
			$tmpIDP .= '0';
		}
		$dateQuo = date_format(date_create($official_date),"ymd"); 
		$newid ='R'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid; 

		///////////////////////////////////////////
        
		$paymentid = $this->input->post('paymentid');
		if ($paymentid!='0') {
			$data_payment = array(
				'im_received_date' => $today
			);
			$this->load->model('tb_installment');
			$this->tb_installment->update($data_payment,$paymentid);
			
		}

		if ($recid!='0') {
			$data_receipt = array(
				'rc_code' => $newid,
                'rc_refer_form' => $rcDetail->rc_refer_form,
                'rc_temp_code' => $rcDetail->rc_code,
                'rc_payfor' => $rcDetail->rc_payfor,
                'rc_booking_code' => $rcDetail->rc_booking_code,
                'rc_contract_code' => $rcDetail->rc_contract_code,
                'rc_installment_code' => $rcDetail->rc_installment_code,
                'rc_installment_time' => $rcDetail->rc_installment_time,
                'rc_transfer_code' => $rcDetail->rc_transfer_code,
				'rc_total_amount' => $rcDetail->rc_total_amount,
				'rc_official_date' => $official_date,
				'rc_staff_official' => $this->user_id,
                'rc_confirm' => $rcDetail->rc_confirm,
                'rc_remark' => $rcDetail->rc_remark,
                'rc_customer_id' => $rcDetail->rc_customer_id,
                'rc_un_name' => $rcDetail->rc_un_name
//                'rc_edited' => $rcDetail->rc_edited
			);
            $this->tb_receipt_offical->record($data_receipt);
            $data_receipt = array(
                'rc_status' => 'off'
            );
			$this->tb_receipt_temporary->update($data_receipt,$recid);
            
            $payment_list = $this->tb_payment->get_by_temp_receipt($rcDetail->rc_code);
            foreach($payment_list as $payment) {
                $data_payment = array('pm_receipt_code' => $newid);
                $this->tb_payment->update($data_payment,$payment->pm_id);
            }
		}

		$this->load->model('tb_quotation');
		$get = $this->tb_quotation->getDetail_by_bk_booking_code_withBookingTable($Booking);
		$unitnumberid = $get->qt_unit_number_id;
		$cus = $get->qt_leads_id;
		
		$data_room_sts = array(
			'rs_unit_number' => $unitnumberid,
			'rs_cus_id' => $cus,
			'rs_status' => $payfor,
			'rs_staff_id' => $this->user_id
		);
		$this->load->model('tb_room_status');
		$this->tb_room_status->record($data_room_sts);
		//echo "<script>  window.open('receipt_reportView.php?rid=$newid','_blank'); </script>";
        
        $pmCash         = $this->input->post('pmCash');
        $cashToAccount  = $this->input->post('cashToAccount');
        $pmCard         = $this->input->post('pmCard');
        $cardFee         = $this->input->post('cardFee');
        $cardToAccount  = $this->input->post('cardToAccount');
        $pmOther        = $this->input->post('pmOther');
        $otherToAccount = $this->input->post('otherToAccount');
        
        if(!empty($pmCash)) {
            $data_payment = array(
                'pm_account' => $cashToAccount
            );
            $this->tb_payment->update($data_payment, $pmCash);
        }
        if(!empty($pmCard)) {
            foreach($pmCard as $key=>$id) {
                $data_payment = array(
                    'pm_cr_fee' => $cardFee[$key],
                    'pm_account' => $cardToAccount[$key]
                );
                $this->tb_payment->update($data_payment, $id);
            }
        }
        if(!empty($pmOther)) {
            $data_payment = array(
                'pm_account' => $otherToAccount
            );
            $this->tb_payment->update($data_payment, $pmOther);
        }
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->db->trans_status() === FALSE && $this->pdb->trans_status() === FALSE){
     		$this->db->trans_rollback();
     		$this->pdb->trans_rollback();
 			alert_redirect('Add receipt Fail','/receipt/view/wait');
		}
		else{
		  	$this->db->trans_commit();
		  	$this->pdb->trans_commit();
            $page = $this->input->post('prePage');
            if($page === 'overdue') {
                echo "<script>  window.open('".BASE_DOMAIN."receipt/report/th/$newid','_blank');";
                echo "window.location.href = '".BASE_DOMAIN."overdue/installment';</script>";
            } else if(!empty($page)) {
                echo "<script>  window.open('".BASE_DOMAIN."receipt/report/th/$newid','_blank');";
                echo "window.location.href = '".BASE_DOMAIN."installment/listInstallment/$page';</script>";
            } else {
                echo "<script>  window.open('".BASE_DOMAIN."receipt/report/th/$newid','_blank');";
                echo "window.location.href = '".BASE_DOMAIN."receipt/view/wait';</script>";
            }
//		   	alert_redirect('Add receipt Success','/receipt/view/all');
		}
		
	}
    
    function UpdateOffical() 
    {
        /*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();
	 	$this->pdb->trans_begin();
        
        $this->load->model('tb_payment');
        $this->load->model('tb_receipt_offical');
        
        $recid          =  $this->input->post('recid');
        $officialDate   =  $this->input->post('OfficialDate');
        $pmCash         = $this->input->post('pmCash');
        $cashToAccount  = $this->input->post('cashToAccount');
        $pmCard         = $this->input->post('pmCard');
        $cardFee         = $this->input->post('cardFee');
        $cardToAccount  = $this->input->post('cardToAccount');
        $pmOther        = $this->input->post('pmOther');
        $otherToAccount = $this->input->post('otherToAccount');
        
        $receipt = $this->tb_receipt_offical->get_one_by(array('rc_id'=>$recid));
        
        $data = array(
            'rc_official_date' => $officialDate,
            'rc_edited' => 'yes'
        );
        $this->tb_receipt_offical->update($data,$recid);
        
        $payment = $this->tb_payment->get_payment_by_receipt_code($receipt->rc_code);
        $key = 0;
        foreach($payment as $val)
        {
            $tempCode = $val->pm_temp_code;
            $data_payment = array(
                'pm_temp_code' => $val->pm_temp_code,
                'pm_receipt_code' => $val->pm_receipt_code,
                // 'pm_date' => $val->pm_date,
                'pm_date' => $officialDate,
                'pm_type' => $val->pm_type,
                'pm_amount' => $val->pm_amount,
                'pm_cr_bank' => $val->pm_cr_bank,
                'pm_cr_type' => $val->pm_cr_type,
                'pm_cr_holder' => $val->pm_cr_holder,
                'pm_cr_number' => $val->pm_cr_number,
                'pm_cr_approve_code' => $val->pm_cr_approve_code,
                'pm_cr_expire' => $val->pm_cr_expire,
                'pm_check_number' => $val->pm_check_number,
                'pm_check_date' => $val->pm_check_date,
                'pm_check_bank' => $val->pm_check_bank,
                'pm_confirm' => $val->pm_confirm,
                'pm_status' => 0,
                'pm_remark' => $val->pm_remark,
                'pm_editor' => $this->user_id
            );
            if($val->pm_type == 'Cash') {
                $data_payment['pm_account'] = $cashToAccount;
                $this->tb_payment->record($data_payment);
            }
            else if($val->pm_type == 'Credit') {
                $data_payment['pm_cr_fee']  = $cardFee[$key];
                $data_payment['pm_account'] = $cardToAccount[$key++];
                $this->tb_payment->record($data_payment);
            }
            else {
                $data_payment['pm_account'] = $otherToAccount;
                $this->tb_payment->record($data_payment);
            }
        }
        
        /*////////////////////////////////////////////////
        if payment older then payment status 
        older payment status more than younger payment status
        receipt group by payment status
        ////////////////////////////////////////////////*/
        $payment = $this->tb_payment->get_by_temp_code($tempCode);
        foreach($payment as $val) {
            $update['pm_status'] = $val->pm_status+1;
            $this->tb_payment->update($update,$val->pm_id);
        }
//            if(!empty($pmCash)) {
//                $data_payment = array(
//                    'pm_account' => $cashToAccount
//                );
//                $this->tb_payment->update($data_payment, $pmCash);
//            }
//            if(!empty($pmCard)) {
//                foreach($pmCard as $key=>$id) {
//                    $data_payment = array(
//                        'pm_cr_fee' => $cardFee[$key],
//                        'pm_account' => $cardToAccount[$key]
//                    );
//                    $this->tb_payment->update($data_payment, $id);
//                }
//            }
//            if(!empty($pmOther)) {
//                $data_payment = array(
//                    'pm_account' => $otherToAccount
//                );
//                $this->tb_payment->update($data_payment, $pmOther);
//            }
        
        /*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->db->trans_status() === FALSE && $this->pdb->trans_status() === FALSE){
     		$this->db->trans_rollback();
     		$this->pdb->trans_rollback();
 			alert_redirect('Edit receipt Fail','/receipt/view/offical/1');
		}
		else{
		  	$this->db->trans_commit();
		  	$this->pdb->trans_commit();
            alert_redirect('Edit receipt success','/receipt/view/offical/1');
		}
    }
    
    function editing($code,$val,$flag,$option) 
    {
        
        $this->checkSessionTimeout();
        $this->load->library('encrypt');
        
        $this->load->model('tb_receipt_offical');
        if(strpos($option,'T') !== false) {
            $this->load->model('tb_receipt_temporary');
			$data['confirm'] = true;
		}
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$recid =0;
		$paymentid = '0';
		if ($flag=='1') {
 			$selBooking ='checked="checked"';
			$selContract ='';
			$selIns ='';
			$disBooking ='';
			$disContract ='disabled="disabled"';
			$disIns ='disabled="disabled"';
		}  else if ($flag=='2') {
			$selBooking ='';
			$selContract ='checked="checked"';
			$selIns ='';
			$disBooking ='disabled="disabled"';
			$disContract ='';
			$disIns ='disabled="disabled"';			
		} else if ($flag=='3') {
			$selBooking ='';
			$selContract ='';
			$selIns ='checked="checked"';
			$disBooking ='disabled="disabled"';
			$disContract ='disabled="disabled"';
			$disIns ='';
		} else if ($flag=='4') {
			$selBooking ='';
			$selContract ='';
			$selIns ='checked="checked"';
			$disBooking ='disabled="disabled"';
			$disContract ='disabled="disabled"';
			$disIns ='';
            $data['prePage'] = $option;
		} else if ($flag=='5') {
			$selBooking ='';
			$selContract ='';
			$selIns ='checked="checked"';
			$disBooking ='disabled="disabled"';
			$disContract ='disabled="disabled"';
			$disIns ='';
            $data['prePage'] = 'overdue';
		}
		$disCus ='';
		$definefee = '';
        if(strpos($option,'T') === false)
            $getreceipt = $this->tb_receipt_offical->get_detail_booking($val);
        else
            $getreceipt = $this->tb_receipt_temporary->get_detail_booking($val);
		if ($code == 'pmid') {
            $imcode = $getreceipt->rc_installment_code;
			$this->load->model('tb_installment');
			$getpmid 	= $this->tb_installment->get_full_detail_by_code($imcode);
			$disCus 	='disabled="disabled"';
            $bookid     = $getreceipt->rc_booking_code;
			$conid  	= $getpmid->im_contract_code;
			$installment  = $getpmid->im_installment_time;	
            $installment_code = $getpmid->im_code;
			$customer_name  = $getreceipt->pers_fname.' '.$getreceipt->pers_lname;				
			$paymentid 	  = $getpmid->im_id; 
			$recid = $getreceipt->rc_id;
			$projectid = $this->project_id_sel;        
            
            $this->load->model('tb_contract');
            $installment_detail = $this->tb_contract->get_installment_detail_by_code($conid);
            $this->load->library('payment');
            $definefee    = $this->payment->getDefinefee($installment, (array)$installment_detail);
			$getcontract = $this->tb_contract->get_detail_by_ct_code($conid);
            
            $data['remark'] = $getpmid->im_remark;
//            $data['user_signature'] = "";
            $data['pmid'] = 'yes';
		} 
		else if ($code == 'rcid') {
            if(strpos($option,'T') === false)
                $getreceipt = $this->tb_receipt_offical->get_full_detail($option);
            else
                $getreceipt = $this->tb_receipt_temporary->get_detail_receipt($val);
			$disCus 	='disabled="disabled"';
            $bookid     = $getreceipt->rc_booking_code;
			$conid  	= $getreceipt->rc_contract_code;	
			$installment  	= $getreceipt->rc_installment_code;	
			$definefee  	= $getreceipt->rc_total_amount;				
			$recid = $val; 
			$paymentid = '0';		
            $customer_name  = $getreceipt->pers_fname.' '.$getreceipt->pers_lname;
            // get Project 
            $this->load->model('tb_booking'); 
            $getpj 	= $this->tb_booking->get_detail_by_bk_booking_code(trim($getreceipt->rc_booking_code));
            $projectid = $getpj->bk_project_id;	
                            
            $this->load->model('tb_contract');
			$getcontract = $this->tb_contract->get_detail_by_ct_code($conid);
//            $data['user_signature']   = trim($getcontract->ct_authorized_user);
            $data['remark'] = $getcontract->ct_remark;
		} 
		else if ($code== 'bkid') {
			$disCus 	='disabled="disabled"';
			$bookid  	= $getreceipt->rc_booking_code;	
			$installment  = $getreceipt->rc_installment_code;	
			$definefee  = $getreceipt->rc_total_amount;				
			$recid = $val; 
			$paymentid = '0';	
            $customer_name  = $getreceipt->pers_fname.' '.$getreceipt->pers_lname;

            $data['projectid'] = $getreceipt->bk_project_id;                           
                                
            // get Project

            $this->load->model('tb_booking'); 
            $getcontract = $this->tb_booking->get_detail_by_bk_booking_code(trim($bookid));  
            $projectid = $getcontract->bk_project_id;
            $data['remark'] = $getcontract->bk_remark;
		} 
        if(strpos($option,'T') === false) {
            $rcDetail = $this->tb_receipt_offical->get_one_by(array('rc_id'=>$recid));
        }else
            $rcDetail = $this->tb_receipt_temporary->get_by_id($recid);
        if(empty($rcDetail))
        {
            alert_redirect('Add receipt Fail','/receipt/view/wait');
        }
        
        $this->load->model('tb_payment');
        if(strpos($option,'T') === false) {
            $paymentlist = $this->tb_payment->get_payment_by_receipt_code($getreceipt->rc_code);
            $officialDate = explode(' ',$getreceipt->rc_official_date)[0];
            $data['officialDate'] = $officialDate;
            $data['edit'] = 'UpdateOffical';
        }else
            $paymentlist = $this->tb_payment->get_by_temp_receipt($getreceipt->rc_code);

        $i=0;
        foreach($paymentlist as $value) {
            if($value->pm_type == 'Cash') {
                $data['pmCash']     = $value->pm_id;
                $data['cashpaid']   = 'yes';
                $data['cashamount'] =  $value->pm_amount;
                if(strpos($option,'T') === false) {
                    $data['cashToAccount'] = $value->pm_account;
                }
            }
            else if($value->pm_type == 'Credit') {
                $data['creditcardpaid']        = 'yes';
                $data['pmCard'][$i]            = $value->pm_id;
                $data['creditcardbank'][$i]    = $value->pm_cr_bank;
                $data['creditcardno'][$i]      = $value->pm_cr_number;
                $data['creditcardtype'][$i]    = $value->pm_cr_type;
                $data['creditcardapprove'][$i] = $value->pm_cr_approve_code;
                $expire = explode('/', $value->pm_cr_expire);
                $data['expiremonth'][$i]       = $expire[0];
                $data['expireyear'][$i]        = $expire[1];
                $data['creditcardholder'][$i]  = $value->pm_cr_holder;
                $data['creditcardamount'][$i]  = $value->pm_amount;
                if(strpos($option,'T') === false) {
                    $data['cardFee'][$i] = $value->pm_cr_fee;
                    $data['cardToAccount'][$i] = $value->pm_account;
                }
                $i++;
            }
            else {
                $data['pmOther']     = $value->pm_id;
                $data['paidother']          = 'yes';
                $data['padidotherby']       = $value->pm_type;
                $data['chequeNumber']       = $value->pm_check_number;
                $data['CheckBank']     		= $value->pm_check_bank;
                $data['CheckDate']     		= $value->pm_check_date;
                $data['padidotheramount']   = $value->pm_amount;
                if(strpos($option,'T') === false) {
                    $data['otherToAccount'] = $value->pm_account;
                }
//				print_r($value);exit;
            }
        }
        if(!empty($getreceipt->rc_refer_form)){
            $data['receiptpaid'] = 'yes';
            $data['allReceipt'] = $this->tb_receipt_offical->get_by_ids($getreceipt->rc_refer_form);
        }

		$this->load->model('tb_customer_personal_info');
		$list_customer = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        
        $this->load->model('tb_bank_account');
        $bankAccount = $this->tb_bank_account->get_all_bank_account();
        $data['bankAccount'] = $bankAccount;

		$data['permission'] = $this->get_user_permission();
        if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled_all_status();
        }
		$data['list_customer'] = $list_customer;
		$data['disCus'] = $disCus;
		$data['getpmid'] = $getreceipt;
		$data['selBooking'] = $selBooking;
		$data['disBooking'] = $disBooking;
		$data['paymentid'] = $paymentid;
		$data['bookid'] = $bookid;
		$data['recid'] = $recid;
		$data['selContract'] = $selContract;
		$data['disContract'] = $disContract;
		$data['conid'] = $conid;
		$data['selIns'] = $selIns;
		$data['disIns'] = $disIns;
		$data['installment'] = $installment;
        $data['installment_code'] = $installment_code;
        $data['definefee'] = $definefee;
		$data['projectid'] = $projectid;
		$data['customer_name'] = $customer_name;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        if(strpos($option,'T') === false)
            $this->LoadView('Receipt/receipt_form',$data);
        else
            $this->LoadView('Receipt/receipt_editing',$data);
    }
    
    function update() 
    {
        $this->load->database();
	 	$this->db->trans_begin();
	 	$this->pdb->trans_begin();
        
        $recid = $this->input->post('recid');
        $this->load->model('tb_receipt_temporary');
        $this->load->model('tb_payment');
        $this->load->model('tb_bank');
        $rcDetail = $this->tb_receipt_temporary->get_by_id($recid);
        $tempCode = $rcDetail->rc_code;
        $payment  = $this->tb_payment->get_by_temp_code($tempCode);
        
        $receiptID         =    implode(',', $this->input->post('receiptID'));
		$update = array('rc_edited' => 'yes', 'rc_refer_form' => $receiptID);
        $this->tb_receipt_temporary->update($update, $recid);
        /*////////////////////////////////////////////////
        if payment older then payment status 
        older payment status more than younger payment status
        receipt group by payment status
        ////////////////////////////////////////////////*/
        foreach($payment as $val) {
            $data['pm_status'] = $val->pm_status+1;
            $this->tb_payment->update($data,$val->pm_id);
        }
        
        $Type  = $this->input->post('Type');
        $cardBank  =	'';
        $cardno   =	'';
        $cardDate   =	'';
        $OtherBy  =	'';

        //Muti paid waiting Booking fee

        $bk_type_payment = '';
        $bk_pay_crcard   = '';
        $bk_pay_other    = '';              

        if(!empty($Type))
        {
            foreach($Type as $checkbox):
                if ( trim($checkbox) == 'Cash' )   $bk_type_payment = 'yes';
                if ( trim($checkbox) == 'CrCard' ) $bk_pay_crcard = 'yes';
                if ( trim($checkbox) == 'Other' )  $bk_pay_other  = 'yes';              
            endforeach;
        }
        $cash_amount       =	$this->input->post('Cashamount');
        $crcard_bank    =	$this->input->post('CardBank');
        $BankName          =	$this->input->post('BankName');
        $credit_type_credit    =	$this->input->post('CardType');
        $credit_approve_code    =	$this->input->post('ApproveCode');
        $crcard_no      =	$this->input->post('Cardno');
        $expiremonth_ = $this->input->post('expiremonth');
        $expireyear_ = $this->input->post('expireyear');


        $crcard_amount  =	$this->input->post('Cardamount');
        $crcard_fname   =	$this->input->post('CardHolder');
        $other_by       =	$this->input->post('OtherBy');
        $other_amount   =	$this->input->post('Otheramount');
        $pm_check_number   =    $this->input->post('CheckNo');
        $pm_check_date     =    $this->input->post('CheckDate');
        $pm_check_bank     =    $this->input->post('CheckBank');
		
		
        $today = date("Y-m-d H:i:s"); 
        
        if($bk_type_payment == 'yes') {
            $data_payment = array(
                'pm_temp_code' => $tempCode,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $cash_amount,
                'pm_editor' => $this->user_id
            );
            $this->tb_payment->record($data_payment);
        }
        if($bk_pay_crcard == 'yes') {
            $this->load->library('encrypt');
            $bankCount = 0;
            for($i=0;$i<count($crcard_amount);$i++) {
                $crcard_date = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";

                if($crcard_bank[$i] == 0) {
                    $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
                    echo $b_id;
                    if(empty($b_id)) {
                        $b_id = $this->tb_bank->get_next_id();
                        $data = array(
                            'b_id' => $b_id,
                            'bank_name_th' => $BankName[$bankCount]
                        );
                        $this->tb_bank->record($data);
                    }
                    $bankCount++;
                }else $b_id = $crcard_bank[$i];

                $data_payment = array(
                    'pm_temp_code' => $tempCode,
                    'pm_date' => $today,
                    'pm_type' => 'Credit',
                    'pm_amount' => $crcard_amount[$i],
                    'pm_cr_bank' => $b_id,
                    'pm_cr_type' => $credit_type_credit[$i],
                    'pm_cr_holder' => $crcard_fname[$i],
                    'pm_cr_number' => $this->encrypt->encode($crcard_no[$i]),
                    'pm_cr_approve_code' => $credit_approve_code[$i],
                    'pm_cr_expire' => $crcard_date,
                    'pm_editor' => $this->user_id
                );
                $this->tb_payment->record($data_payment);
                if($i == 0) {
                    $this->load->library('creditlog');
                    $this->creditlog->update($data_payment, $rcDetail->rc_customer_id);
                }
            }
        }
        if($bk_pay_other == 'yes') {
//            if($other_by == 'Check'){
                $data_payment = array(
                    'pm_temp_code' => $tempCode,
                    'pm_date' => $today,
                    'pm_type' => 'Check',
                    'pm_amount' => $other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank,
                    'pm_editor' => $this->user_id
                );
//            }else
//                $data_payment = array(
//                    'pm_temp_code' => $tempCode,
//                    'pm_date' => $today,
//                    'pm_type' => $other_by,
//                    'pm_amount' => $other_amount,
//                    'pm_editor' => $this->user_id
//                );
           $this->tb_payment->record($data_payment);
        }
        
        if ($this->db->trans_status() === FALSE && $this->pdb->trans_status() === FALSE){
     		$this->db->trans_rollback();
     		$this->pdb->trans_rollback();
 			alert_redirect('Edit receipt Fail','/receipt/view/wait');
		}
		else{
		  	$this->db->trans_commit();
		  	$this->pdb->trans_commit();
            echo "<script>window.open('".BASE_DOMAIN."receipt/report/th/$tempCode','_blank');";
            echo "window.location.href = '".BASE_DOMAIN."receipt/view/wait';</script>";
        }
    }
    
	public function report($language,$rid,$status)
    {
		$this->load->model('tb_payment');
        $this->load->model('tb_transfer_ownership');
        $this->load->model('tb_contract_promotion');
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_user_personal_info');
        $this->load->model('tb_contract');
        if(strpos($rid,'T') !== false) {
            $this->load->model('tb_receipt_temporary');
            $getreceipt = $this->tb_receipt_temporary->get_full_detail($rid);
            $rid = $getreceipt->rc_code;
            $typeReceipt = 'temp';
            $date_receipt = $getreceipt->rc_temporary_date;
            if(empty($status))
                $payment_list = $this->tb_payment->get_by_temp_receipt($rid);
            else
                $payment_list = $this->tb_payment->get_by_temp_and_status($rid,$status);
            $type_receipt = 'ใบเสร็จรับเงินชั่วคราว';
            
            $nameSale = $getreceipt->rc_staff_temporary;
            
            $payee = array('สำหรับลูกค้า / Customer Copy','สำหรับบัญชี / Accounting Department Copy','สำหรับฝ่ายขาย / Sales and Leasing Department Copy');
            
            $this->load->model('tb_customer_personal_info');
            $getCusDetail = $this->tb_customer_personal_info->get_detail_by_id($getreceipt->rc_customer_id);
            $prefix = $getCusDetail->pers_prefix;
            $fname = $getCusDetail->pers_fname;
            $lname = $getCusDetail->pers_lname;
            
            $user = $this->tb_user_personal_info->get_detail_personal($nameSale);
            $loginname = $user->user_pers_fname." ".$user->user_pers_lname;

            $get_ct_mapping = $this->tb_contract->get_contract_mapping($getreceipt->rc_contract_code);
            
            $type_licence = '
            <br>
            <table border="0" width="100%" style="font-size:12">
                <tr>
                    <td width="5%">ลงชื่อ</td>
                    <td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width="10%">ผู้ซื้อ</td>
                    <td width="10%"></td>
                    <td width="5%">ลงชื่อ</td>
                    <td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width="10%">ผู้รับเงิน</td>
                </tr>
                <tr>
                <td></td>
                </tr>
                <tr>
                    <td align="right">(</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$prefix.' '.$fname.' '.$lname.'</td>
                    <td align="left">)</td>
                    <td></td>
                    <td align="right">(</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$loginname.'</td>
                    <td align="left">)</td>
                </tr>
            </table>
            ';
        }else {
            $getreceipt = $this->tb_receipt_offical->get_full_detail($rid);
            $typeReceipt = 'Official';
            $date_receipt = $getreceipt->rc_official_date;
            if(empty($status))
                $payment_list = $this->tb_payment->get_payment_by_receipt_code($rid);
            else
                $payment_list = $this->tb_payment->get_by_receipt_and_status($rid,$status);
            $type_receipt = 'ใบเสร็จรับเงิน';
            $payee = array(' ');
            
            $getstaff = $this->tb_user_personal_info->get_detail_personal($getreceipt->rc_staff_official);
            $nameStaff = $getstaff->user_pers_fname.' '.$getstaff->user_pers_lname;
           
            $get_ct_mapping = $this->tb_contract->get_contract_mapping($getreceipt->rc_contract_code);

            $type_licence = '
            <br>

            <table border="0" width="280px" align="right">
                <tr>
                    <td colspan="3" align="center">ในนาม '.$companyName.'</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" width="280px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
                </tr>
                <tr>
                <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                    <td width="40px" align="right">(</td>
                    <td width="200px" align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$nameStaff.'</td>
                    <td width="40px" align="left">)</td>
                </tr>
                <tr>
                <td colspan="3"></td>
                </tr>
                <tr>
                    <td colspan="3" align="center">เจ้าหน้าที่การเงิน</td>
                </tr>
            </table>
            <div class="footer">
            <table align="center" width="700px" border="" class="tablefone" style="font-size:12">
                <tr>
                    <td>
                        หมายเหตุ: กรณีชำระเงินตัวเช็ค/แคชเชียร์เช็ค จะถือว่าได้รับชำระครบถ้วนก็ต่อเมื่อได้สามารถเรียกเก็บเงินตามที่ระบุไว้ในเช็คแล้ว
                    </td>
                </tr>
            </table>
            </div>
            ';
        }

        if (!empty($get_ct_mapping)){
        	$get_ct_mapping = "  (".$get_ct_mapping.")";
        }else{
        	$get_ct_mapping = "";
        }

        if(!empty($getreceipt->rc_refer_form)) {
            $data['refer'] = $this->tb_receipt_offical->get_by_ids($getreceipt->rc_refer_form);
        }
		$bid = $getreceipt->rc_booking_code;
		 //
    	$authorizeid = $getreceipt->rc_authorized_user;
        $remark = $getreceipt->rc_remark;
        if($remark != null)
            $htmlRemark = '<td colspan="3" height="50" valign="top">หมายเหตุ : '.$remark.'</td>';
        
    	$this->load->model('tb_authorize_user');
    	$data['getauthorize'] = $this->tb_authorize_user->get_info_by_au_user_id($authorizeid);

		$receiptText = '';
        $total_price = $getreceipt->rc_total_amount;
        
		if ($getreceipt->rc_payfor == 'Contract Fee' ) {
			$receiptText = 'Contract Fee  : '.$getreceipt->rc_contract_code.$get_ct_mapping;
		}else if ($getreceipt->rc_payfor == 'Booking Fee'){
			$receiptText = 'Booking Fee  : '.$getreceipt->rc_booking_code;
		}else if($getreceipt->rc_payfor == 'Transfer Ownership'){
            $receiptText = 'Transfer Ownership  : '.$getreceipt->rc_transfer_code;
            $getTransferOwner = $this->tb_transfer_ownership->get_by_code($getreceipt->rc_transfer_code);
            $total_price = $getTransferOwner->tr_amount;
        }else{
			$receiptText = 'Installment Fee # '.$getreceipt->rc_installment_time.' of Contract '.$getreceipt->rc_contract_code.$get_ct_mapping;
		}	
	
		$moneyCash= '';
		$moneyCrCard= '';
		$moneyOther= '';
		$flagCash= '';
		$flagCrCard= '';
		$flagOther= '';
		
        
        foreach($payment_list as $payment){
            if ($payment->pm_type === 'Cash') {
                $moneyCash[] = $payment->pm_amount;
                $flagCash ='checked="checked"';
            } else if ($payment->pm_type === 'Credit') {
                $moneyCrCard[] = $payment->pm_amount;
                $flagCrCard = 'checked="checked"';
                $credit_bank[] = $payment->bank_name_th;
                $credit_no[] = $payment->pm_cr_number;
		        $credit_holder[] = $payment->pm_cr_holder;
                $crdate[] = $payment->pm_cr_expire;
            } else {
                $moneyOther= $payment->pm_amount;
                $flagOther ='checked="checked"';
                $other_by = $payment->pm_type;
            }
            $date_receipt = $payment->pm_date;
        }
        if(empty($payment_list[0]->pm_editor)) {
            if(typeReceipt == 'temp')
                $staff  = $getreceipt->rc_staff_temporary;
            else
                $staff  = $getreceipt->rc_staff_official;
        }else {
            $staff = $payment_list[0]->pm_editor;
        }
		
		$bid = $getreceipt->rc_booking_code;
		$this->load->model('tb_booking');
		$getbooking = $this->tb_booking->get_fullDetail_by_bk_booking_code($bid);		

		$cid = $getreceipt->rc_customer_id;
		$addr_booking = $getbooking->cus_addr_default;
	    //
//	    if ( $addr_booking == 1 )
//	    {
//		    $this->load->model('tb_customer_address_info');
//		    $getaddrCur= $this->tb_customer_address_info->get_detail_by_cus_id($cid);   
//	        
//	        $data['doc_addr'] = $getaddrCur->addr_address;
//	        $data['doc_sub_district'] = $getaddrCur->addr_sub_district;
//	        $data['doc_district'] = $getaddrCur->addr_district;
//	        $data['doc_province'] = $getaddrCur->addr_province;
//	        $data['doc_zipcode'] = $getaddrCur->addr_post_code;
//	    }
//	    else if ( $addr_booking == 3 )    
//	    {
//		    $this->load->model('tb_customer_address_lastest');
//		    $getaddrCur= $this->tb_customer_address_lastest->get_detail_by_cus_id($cid);  
//	        
//	        $data['doc_addr'] = $getaddrCur->addr_lastest_address;
//	        $data['doc_sub_district'] = $getaddrCur->addr_lastest_sub_district;
//	        $data['doc_district'] = $getaddrCur->addr_lastest_district;
//	        $data['doc_province'] = $getaddrCur->addr_lastest_province;
//	        $data['doc_zipcode'] = $getaddrCur->addr_lastest_post_code;
//	    }
//	    else 
//	    {
		    $this->load->model('tb_customer_address_current_info');
		    $getaddrCur= $this->tb_customer_address_current_info->get_detail_by_customerID($cid);
	        
	        $data['doc_addr'] = $getaddrCur->addr_cur_address;
	        $data['doc_sub_district'] = $getaddrCur->addr_cur_sub_district;
	        $data['doc_district'] = $getaddrCur->addr_cur_district;
	        $data['doc_province'] = $getaddrCur->addr_cur_province;
	        $data['doc_zipcode'] = $getaddrCur->addr_cur_post_code;
//	    }
		$this->load->model('tb_customer_address_current_info');
		$getaddrCur= $this->tb_customer_address_current_info->get_detail_by_customerID($cid);
	
		$staff  = $getbooking->bk_staff_id;
		$getstaff = $this->tb_user_personal_info->get_detail_personal($staff);
	
		$quoCode = $getbooking->bk_quotation_code;
		$this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$Project = 	$getQuo->qt_project_id;
		$Building =$getQuo->qt_buliding_id;
		$Number =$getQuo->qt_unit_number_id;
	
		$this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_detail_unit_by_un_id($Number);
		$un_name 	= $getRoom->un_name;
		
		$this->load->model('tb_project');
		$get = $this->tb_project->get_detail_project_ignoreStatusActive($Project);
		
        $projectImg = $get->pj_image;
        // $companyName = 'บริษัท กีธา พร็อพเพอร์ตี้ส์ จำกัด';
        $getProjectPdb = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($Project);
        $pj_name =$getProjectPdb->pj_name_th.' '.$getProjectPdb->pj_location_th;
        $companyName = $getProjectPdb->pj_owner;
        $compAddr = $getProjectPdb->pj_owner_address;
		// echo "test".$companyName;
		// exit();
		$id = $rid;
		$prefix = $getreceipt->pers_prefix;
		$fname = $getreceipt->pers_fname;
		$lname = $getreceipt->pers_lname;
		
		
		$cash_amount = $moneyCash;
		$credit_amount = $moneyCrCard;
		$other_amount = $moneyOther;

		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$this->load->library('currency');
		$data['Currency'] = $this->currency;
		$data['getbooking'] = $getbooking;
		$data['getreceipt'] = $getreceipt;
		$data['id'] = $id;
		$data['getaddrCur'] = $getaddrCur;
		$data['building_name'] = $building_name;
		$data['un_name'] = $un_name;
		$data['total_price'] = $total_price;
		$data['flagCash'] = $flagCash;
		$data['flagCrCard'] = $flagCrCard;
		$data['flagOther'] = $flagOther;
		$data['cash_amount'] = $cash_amount;
		$data['other_amount'] = $other_amount;
		$data['credit_amount'] = $credit_amount;
		$data['getstaff'] = $getstaff;
		$data['receiptText'] = $receiptText;
		$data['payee'] = $payee;
		$data['prefix'] = $prefix;
		$data['fname'] = $fname;
		$data['lname'] = $lname;
		$data['credit_bank'] = $credit_bank;
		$data['credit_no'] = $credit_no;
		$data['credit_holder'] = $credit_holder;
		$data['other_by'] = $other_by;
		$data['crdate'] =   !empty($crdate)?$crdate:'';
		$data['type_receipt'] = $type_receipt;
		$data['pj_name'] = $pj_name;
		$data['type_licence'] = $type_licence;
		$data['date_receipt'] = $date_receipt;
        $data['htmlRemark'] = $htmlRemark;
        $data['projectImage'] = $projectImg;
        $data['getTransferOwner'] = $getTransferOwner;
        $data['companyName'] = $companyName;
        $data['compAddr'] = $compAddr;
		
		$this->load->view('Receipt/receipt_report',$data);
	}
    
	private function fetch_receipt($type,$option)
    {
		$this->load->model('tb_quotation');
		$this->load->model('tb_building');
		$this->load->model('tb_unit_number');
        if($type=='offical'){
            $this->load->model('tb_receipt_offical');
            if(empty($option)){
                $list_receipt = $this->tb_receipt_offical->fetch_full($this->project_id_sel);
            }else
                $list_receipt = $this->tb_receipt_offical->fetch_month($this->project_id_sel, $option);
        }else {
            $this->load->model('tb_receipt_temporary');
            $list_receipt = $this->tb_receipt_temporary->fetch_full($type, $this->project_id_sel);
        }
		foreach($list_receipt as $receipt):
			$qcode = $receipt->bk_quotation_code;
			$receipt->quotation = $this->tb_quotation->getDetail_by_id_withProjectTable($qcode);
			$receipt->building = $this->tb_building->get_detail_building_by_building_id($receipt->quotation->qt_buliding_id);
			$receipt->unit_number = $this->tb_unit_number->get_detail_unit_by_un_id($receipt->quotation->qt_unit_number_id);
		endforeach;
		return $list_receipt;
	}
}

/* End of file receipt.php */
/* Location: ./application/controllers/receipt.php */