<?php 

class Regis_from_web extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Regis_from_web';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{  
//        $this->load->model('tb_regis_from_web');
        $this->load->model('tb_customer_personal_info');
        
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['regisList'] = $this->fetch_regis();
        $data['userid'] = $this->user_id;
        $data['lead_already'] = $lead_already;
        
        $this->LoadView('Regis_from_web/regis_from_web',$data);
//        $this->LoadView('Regis_from_web/regis_from_web');
	}
	//////
	/////
	public function record()
	{
	 	$regis_id = $this->get_new_regis_id();

		$fname = $this->input->get('firstname');
	 	$lname = $this->input->get('lastname');
	 	$mobile = $this->input->get('mobile');
	 	$mail = $this->input->get('mail');
	 	$remark = $this->input->get('remark');
		$interest = $this->input->get('interest');
		$salary = $this->input->get('salary');
		$pj_id = $this->input->get('pj_id');
		$url_ref = $this->input->get('url_ref');
        $mediaType = $this->input->get('mediaType');
        $budget = $this->input->get('Budget');
        $visitType = $this->input->get('visitType');
        $stages = $this->input->get('stages');
		$form = $this->input->get('form');
        
        
        $curr_timestamp = date('Y-m-d H:i:s');
        
//	 	echo "fname : ".$fname;
//        echo " +++lname : ".$lname;
//        echo " +++mobile : ".$mobile;
//        echo " +++mail : ".$mail;
//        echo " +++remark : ".$remark;
//        echo " +++interest : ".$interest;
//        echo " +++salary : ".$salary;
//        echo " +++media : ".$mediaType;
//        echo " +++visitType : ".$visitType;
//        echo " +++bugged : ".$budget;
//        echo " +++stages : ".$stages;
//        echo " +++pj_id : ".$pj_id;
//        echo " +++url_ref : ".$url_ref;
//        echo " +++curr_timestamp : ".$curr_timestamp;
//        exit(); 
        
	 	$data_regis = array(
	 		'regis_id' => $regis_id,
	 		'regis_fname' => $fname,
	 		'regis_lname' => $lname,
	 		'regis_mobile' => $mobile,
	 		'regis_email' => $mail,
	 		'regis_interest' => $interest,
            'regis_budget' => $budget,
	 		'regis_salary' => $salary,
	 		'regis_remark' => $remark,
	 		'regis_project_id' => $pj_id,
	 		'regis_url_ref' => $url_ref,
	 		'regis_media_type_id' => $mediaType,
	 		'regis_visit_type_id' => $visitType,
	 		'regis_stages_id' => $stages,
            'regis_status' => 'normal',
            'regis_date' => $curr_timestamp
        );
		$this->recordRegis($data_regis);
        

		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
            echo '<script>alert("Registered Fail!!!");window.history.back(-2);</script>';
            //window.location.href="https://kitha.realsmart.in.th/RealCondo/RealCondo.html";
                  //alert_redirect('Add Leads Success','https://kitha.realsmart.in.th/RealCondo/RealCondo.html');
		}
		else{
		    $this->db->trans_commit();
            echo '<script>alert("Registered Successfully");
            window.location.href="/RealCondo/RealCondo.php";
            </script>';
//            window.history.back(-2);
            //alert_redirect('Add Leads Success','https://kitha.realsmart.in.th/RealCondo/RealCondo.html');
		}
		
	}
    
	private function recordRegis($data)
	{
		$this->load->model('tb_regis_from_web');
		$this->tb_regis_from_web->record($data);
        
	}
    
	private function get_new_regis_id(){
		$this->load->model('tb_regis_from_web');
		return $this->tb_regis_from_web->get_new_regis_id();
	}

	private function fetch_regis(){
		$this->load->model('tb_regis_from_web');
//		$this->load->model('tb_visit_type');
//		$this->load->model('log_lead_remark');
        $regisList = $this->tb_regis_from_web->fetch_regis_normal();
		return $regisList;
	}
    
	public function approve($regis_id)
	{
	 	$userApprove = $this->user_id;	
        
        
        
        $fname = $this->input->get('firstname');
	 	$lname = $this->input->get('lastname');
	 	$mobile = $this->input->get('mobile');
	 	$mail = $this->input->get('mail');
	 	$remark = $this->input->get('remark');
		$interest = $this->input->get('interest');
		$salary = $this->input->get('salary');
		$pj_id = $this->input->get('pj_id');
		$url_ref = $this->input->get('url_ref');
        $mediaType = $this->input->get('mediaType');
        $budget = $this->input->get('Budget');
        $visitType = $this->input->get('visitType');
        $stages = $this->input->get('stages');
        
        
        $curr_timestamp = date('Y-m-d H:i:s');
        
	 	echo "fname : ".$fname;
        echo " +++lname : ".$lname;
        echo " +++mobile : ".$mobile;
        echo " +++mail : ".$mail;
        echo " +++remark : ".$remark;
        echo " +++interest : ".$interest;
        echo " +++salary : ".$salary;
        echo " +++media : ".$mediaType;
        echo " +++visitType : ".$visitType;
        echo " +++bugged : ".$budget;
        echo " +++stages : ".$stages;
        echo " +++pj_id : ".$pj_id;
        echo " +++url_ref : ".$url_ref;
        //echo " +++curr_timestamp : ".$curr_timestamp;
        echo " +++userApprove : ".$userApprove;
        echo " +++regis_id : ".$regis_id;
        exit();

	 	/*================================*/
	 	/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();
        
       
        if ($Nationality == 171) {
            if ($prefix == 'Mr.') {
                $prefix = 'นาย';
            } else if ($prefix == 'Miss') {
                $prefix = 'นางสาว';
            } else if ($prefix == 'Mrs.') {
                $prefix = 'นาง';
            }
            $identificationFlag = "IDCard";
        } else {
        	$identificationFlag = "passport";
        }
        
	 	$data_pers = array(
	 		'pers_prefix' => $prefix,
	 		'pers_fname' => $fname,
	 		'pers_lname' => $lname,
	 		'pers_mobile' => $mobile,
	 		'pers_email' => $mail,
	 		'pers_id_cus' => $pers_id,
            'pers_nationality' => $Nationality,
            'pers_identification_flag' => $identificationFlag,
	 		'pers_sex' => $sex,
	 		'pers_tel' => $tel
	 	);
	 	$this->load->model('tb_customer_personal_info');
	 	$this->tb_customer_personal_info->update($data_pers,$pers_id);

		
		$stages = $this->input->get('stages');
		$budget = $this->input->get('Budget');
		$visitType = $this->input->get('visitType');
		$form = $this->input->get('form');
        
        if ($form == "webregis"){
		  $mediaType = $this->input->get('mediaType');
        }
        else {
            $mediaType = implode(',', $this->input->get('mediaType'));
        }
		//$etctype = $this->input->post('etcother'); 

		$data_leads = array(
			'cus_pers_id' => $pers_id,
			'cus_stages_id' => $stages,
			'cus_budget' => $budget,
			'cus_visit_type' => $visitType,
            'cus_media_type' => $mediaType,
            'cus_remark' => $remark
			//'cus_sts_active' => $cus_status
		);
		$this->updateLeads($data_leads,$cid);

		////// KEEP LOG ////
		$obj_pers = $this->tb_customer_personal_info->get_detail_by_id($pers_id);
		$data_log_pers = array(
			'pers_id' => $obj_pers->pers_id,
			'pers_fname' => $obj_pers->pers_fname,
			'pers_lname' => $obj_pers->pers_lname,
			'pers_sex' => $obj_pers->pers_sex,
			'pers_nationality' => $obj_pers->pers_nationality,
			'pers_identification_flag' => $obj_pers->pers_identification_flag,
			'pers_passport' => $obj_pers->pers_passport,
			'pers_card_id' => $obj_pers->pers_card_id,
			'pers_dob' => $obj_pers->pers_dob,
			'pers_mobile' => $obj_pers->pers_mobile,
			'pers_tel' => $obj_pers->pers_tel,
			'pers_email' => $obj_pers->pers_email,
			'pers_id_cus' => $obj_pers->pers_id_cus,
			'pers_update_by' => $this->user_id
		);
		$this->record_log_customer_personal_info($data_log_pers);

		////// KEEP LOG ////
		$this->load->model('tb_customer');
		$obj_leads = $this->tb_customer->get_detail_by_id($cid);
		$data_log_leads = array(
			'cus_id' => $obj_leads->cus_id,
			'cus_pers_id' => $obj_leads->cus_pers_id,
			'cus_addr_id' => $obj_leads->cus_addr_id,
			'cus_addr_cur_id' => $obj_leads->cus_addr_cur_id,
			'cus_con_id' => $obj_leads->cus_con_id,
			'cus_work_id' => $obj_leads->cus_work_id,
			'cus_stages_id' => $obj_leads->cus_stages_id,
			'cus_budget' => $obj_leads->cus_budget,
			'cus_visit_type' => $obj_leads->cus_visit_type,
            'cus_media_type' => $obj_leads->cus_media_type,
			'cus_flag' => $obj_leads->cus_flag,
			'cus_created_by' => $obj_leads->cus_created_by,
			'cus_created_date' => $obj_leads->cus_created_date,
			//'cus_sts_active' => $obj_leads->cus_sts_active,
			'cus_update_by' => $this->user_id
		);
		$this->record_log_leads($data_log_leads);

		/*=======================================*/
	 	/*======= check status transaction ======*/
	 	/*=======================================*/
		if ($this->db->trans_status() === FALSE){
        	$this->db->trans_rollback();
        	alert_redirect("Edit Leads fail!","/leads/view");	
		}
		else{
		    $this->db->trans_commit();
		    if ($stages=='6') {
				alert_redirect("Next To Add Customer","/customer/editing/".$cid."");			
			} else {
				alert_redirect("Edit Leads Success","/leads/view");		
			}
		}
	
		
	}
	public function delete($regis_id){
//		$permission = $this->get_user_permission();
//		if (strpos($permission->pm_leads,'4') === FALSE) {
//			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');		
//		}
		$data_regis = array(
			'regis_status' => 'delete'
		);
        $this->load->model('tb_regis_from_web');
		$this->tb_regis_from_web->update_regis($data_regis,$regis_id);
		alert_redirect('Delete Success','/regis_from_web/view');
	}
	private function get_detail_leads($cid){
		$this->load->model('tb_customer');
		return $this->tb_customer->get_detail_leads($cid);
	}

	//////// UPDATE //////////
	//////////////////////////
	private function updateLeads($data,$cid)
	{
		$this->load->model('tb_customer');
		$this->tb_customer->update($data,$cid);
	}
    
    
  public function toExcel()
  {
//        $this->load->model('tb_regis_from_web');
        $this->load->model('tb_customer_personal_info');
        
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['regisList'] = $this->fetch_regis();
        $data['userid'] = $this->user_id;
        $data['lead_already'] = $lead_already;
        $data['project_name_sel'] = $this->project_name_sel;
		$data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
        
//        $this->LoadView('Regis_from_web/regis_from_web',$data);
        $this->load->view('Regis_from_web/export_register_to_excel',$data);
  }
    
}

/* End of file leads.php */
/* Location: ./application/controllers/leads.php */