<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_info extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Project Info';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$this->load->model('project_model/tb_project','',TRUE);
		$data['list_project'] = $this->tb_project->fetch_all_active_project();
		$data['pjname'] = $this->project_name_sel;
		$this->LoadView('Project_detail/Project_info/project_info_view',$data);
	}
	public function editing($pj_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->model('project_model/tb_project','',TRUE);
		$data['pjid'] = $pj_id;
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$data['project'] = $this->tb_project->get_detail_project($pj_id);
		$this->LoadView('Project_detail/Project_info/project_info_editing',$data);
	}
	public function update($pj_id)
	{
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();

		$userEdit = $this->user_id;
		$pjnameEN 			= $this->input->post('pjnameEN');
        $pjnameTH           = $this->input->post('pjnameTH');
		$pjtype 			= $this->input->post('pjtype');
		$pjlocation 		= $this->input->post('pjlocation');
        $pjlocationTH       = $this->input->post('pjlocationTH');
		$pjarea 			= $this->input->post('pjarea');
		$pjareaEN 			= $this->input->post('pjareaEN');
		$pjowner 			= $this->input->post('pjowner');
		$pjownerEN    		= $this->input->post('pjownerEN');
        $startMonth 		= $this->input->post('startMonth');
        $endMonth 	     	= $this->input->post('endMonth');
        $pjStart            = $this->input->post('pjstart');
        $pjCompany          = $this->input->post('pjcompany');
        $pjcompanyEN        = $this->input->post('pjcompanyEN');
        $pjAddrCompany      = $this->input->post('pjaddrcompany');
        $pjAddrCompanyEN    = $this->input->post('pjaddrcompanyEN');
        $dateOwnerAppr      = $this->input->post('dateownerappr');
        $pjAddr             = $this->input->post('pjaddr');
        $pjAddrEN           = $this->input->post('pjaddrEN');
        $pjDeed             = $this->input->post('pjdeed');
        $pjDeedEN           = $this->input->post('pjdeedEN');
        $pjtel              = $this->input->post('pjtel');
        $pjcof              = $this->input->post('pjcof');
        $pjame              = $this->input->post('pjame');
        
        /*------------------*/
		/*----KEEP LOG------*/
		/*------------------*/
        $this->load->model('project_model/tb_project','',TRUE);
		$projectObj = $this->tb_project->get_detail_project($pj_id);
		$data_log = array(
			'pj_id' => $projectObj->pj_id,
			'pj_name' => $projectObj->pj_name,
			'pj_name_th' => $projectObj->pj_name_th,
			'pj_type' => $projectObj->pj_type,
			'pj_location' => $projectObj->pj_location,
			'pj_location_th' => $projectObj->pj_location_th,
			'pj_decoration' => $projectObj->pj_decoration,
			'pj_facilities' => $projectObj->pj_facilities,
			'pj_security' => $projectObj->pj_security,
			'pj_area' => $projectObj->pj_area,
			'pj_area_en' => $projectObj->pj_area_en,
			'pj_owners' => $projectObj->pj_owner,
			'pj_owners_en' => $projectObj->pj_owner_en,
            'pj_start_downpayment' => $projectObj->pj_start_downpayment,
            'pj_end_downpayment' => $projectObj->pj_end_downpayment,
            'pj_date_project' => $projectObj->pj_date_project,
			'pj_owner' => $projectObj->pj_owner,
			'pj_owner_en' => $projectObj->pj_owner_en,
			'pj_owner_address' => $projectObj->pj_owner_address,
			'pj_owner_address_en' => $projectObj->pj_owner_address_en,
			'pj_ownership_date' => $projectObj->pj_ownership_date,
			'pj_address' => $projectObj->pj_address,
			'pj_address_en' => $projectObj->pj_address_en,
			'pj_land' => $projectObj->pj_land,
			'pj_land_en' => $projectObj->pj_land_en,
			'pj_quotation_tel' => $projectObj->pj_quotation_tel,
			'pj_coffers_fee' => $projectObj->pj_coffers_fee,
			'pj_amenities_fee' => $projectObj->pj_amenities_fee,
			'pj_expected' => $projectObj->pj_expected,
			'pj_common' => $projectObj->pj_common,
			'pj_commencement' => $projectObj->pj_commencement,
			'pj_sinking' => $projectObj->pj_sinking,
			'pj_active' => $projectObj->pj_active,
			'pj_date_promotion' => $projectObj->pj_date_promotion,
			'pj_cannot_transfer_date' => $projectObj->pj_cannot_transfer_date,
			'pj_update_by' => $userEdit
		);
		$this->load->model('project_model/log_project','',TRUE);
		$this->log_project->record($data_log);
        
		$data_update = array(
			'pj_name'                => trim($pjnameEN),
            'pj_name_th'             => trim($pjnameTH),
			'pj_type'                => trim($pjtype),
			'pj_location'            => trim($pjlocation),
            'pj_location_th'         => trim($pjlocationTH),
			'pj_area'                => trim($pjarea),
			'pj_area_en'             => trim($pjareaEN),
			'pj_owners'              => trim($pjowner),
			'pj_owners_en'           => trim($pjownerEN),
            'pj_start_downpayment'   => $startMonth,
            'pj_end_downpayment'     => $endMonth,
            'pj_date_project'        => $pjStart,
            'pj_owner'               => $pjCompany,
            'pj_owner_en'            => $pjcompanyEN,
            'pj_owner_address'       => $pjAddrCompany,
            'pj_owner_address_en'    => $pjAddrCompanyEN,
            'pj_ownership_date'      => $dateOwnerAppr,
            'pj_address'             => $pjAddr,
            'pj_address_en'          => $pjAddrEN,
            'pj_land'                => $pjDeed,
            'pj_land_en'             => $pjDeedEN,
            'pj_quotation_tel'       => $pjtel,
			'pj_coffers_fee'         => $pjcof,
			'pj_amenities_fee'       => $pjame
		);
		$this->tb_project->update($data_update,$pj_id);

		if ($this->pdb->trans_status() === FALSE){
	       $this->pdb->trans_rollback();
	       alert_redirect('Edit project Fail','/project_info/view');
		}
		else{
		   $this->pdb->trans_commit();
		   alert_redirect('Edit project Success','/project_info/view');
		}
	}
	public function adding(){
		$data['pjid'] = $pj_id;
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$this->LoadView('Project_detail/Project_info/project_info_adding',$data);
	}
	public function record(){
		
		$pjname 			= $this->input->post('pjname');
		$pjtype 			= $this->input->post('pjtype');
		$pjunit 			= $this->input->post('pjunit');
		$pjlocation 		= $this->input->post('pjlocation');
		$pjdecoration 		= $this->input->post('pjdecoration');
		$pjfacilities 		= $this->input->post('pjfacilities');
		$pjsecurity 		= $this->input->post('pjsecurity');
		$pjarea 			= $this->input->post('pjarea');
		$pjowner 			= $this->input->post('pjowner');
		$pjcommencement 	= $this->input->post('pjcommencement');
		$pjexpected 		= $this->input->post('pjexpected');
		$pjcommon 			= $this->input->post('pjcommon');
		$pjsinking 			= $this->input->post('pjsinking');
        $startMonth 		= $this->input->post('startMonth');
        $endMonth 	     	= $this->input->post('endMonth');
        
		$array_add = array(
			'pj_id'  => '0',
			'pj_name'  => $pjname,
			'pj_type'  => $pjtype,
			'pj_unit'  => $pjunit,
			'pj_location'  => $pjlocation,
			'pj_decoration'  => $pjdecoration,
			'pj_facilities'  => $pjfacilities,
			'pj_security'  => $pjsecurity,
			'pj_area'  => $pjarea,
			'pj_owner'  => $pjowner,
			'pj_commencement'  => $pjcommencement,
			'pj_expected'  => $pjexpected,
			'pj_common'  => $pjcommon,
			'pj_sinking'  => $pjsinking,
            'pj_start_downpayment' => $startMonth,
            'pj_end_downpayment' => $endMonth
		);
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		$this->load->model('project_model/tb_project','',TRUE);
		$this->tb_project->record($array_add);
		
		if ($this->pdb->trans_status() === FALSE){
	       $this->pdb->trans_rollback();
	       alert_redirect('Add Project Fail','/project_info/view');
		}
		else{
		   $this->pdb->trans_commit();
		   alert_redirect('Add Project Success','/project_info/view');
		}
		
	}
	public function deleting($pj_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'pj_active' => 'off'
		);
		$this->load->model('project_model/tb_project','',TRUE);
		$this->tb_project->update($data_delete,$pj_id);
		
		alert_redirect('Delete Project Success','/project_info/view');
	}
	
}

/* End of file project_info.php */
/* Location: ./application/controllers/project_info.php */