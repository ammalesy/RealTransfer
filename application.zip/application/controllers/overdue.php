<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class overdue extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->booking();
	}
	public function booking()
	{
		$data['title'] = "Overdue Booking";
		$data['page'] = "OverdueBooking";
		$data['list_booking'] = $this->processFetchBooking($this->project_id_sel);
        $data['project_database_sel'] = $this->project_database_sel;
        
        
		$this->LoadView('Overdue/booking_overdue',$data);
	}
	public function installment()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = "OverdueInstallment";
		$data['permission'] = $this->get_user_permission();

		$this->load->model('tb_installment');
		$this->load->model('tb_receipt_temporary');
        $data['list_installment'] = $this->tb_installment->fetch_filtering_installment();
        $data['project_database_sel'] = $this->project_database_sel;

        $this->load->view('header',$data);
        $this->load->view('menu', $data);
		$this->load->view('Overdue/installment_overdue',$data);
        $this->load->view('footer', $data);
	}
    public function remark() {
        $type   = $this->input->post('type');
        $remark = $this->input->post('remark');
        $bkCode = $this->input->post('bkCode');
        $callData = false;
        $page   = '';
        
        if($type == 'installment') {
            $inCode = $this->input->post('inCode');
            $ctCode = $this->input->post('ctCode');
            $page = '/overdue/installment';
            $callData = true;
            $this->load->model('tb_installment');
            $this->tb_installment->update_where(array('im_call_remark'=>'yes'), array('im_code'=>$inCode));
        }
        if($type == 'booking') {
            $page = '/overdue/booking';
            $callData = true;
            $this->load->model('tb_booking');
            $this->tb_booking->update(array('bk_call_remark'=>'yes'), $bkCode);
            
        }
        
        if($callData){
            $data = array(
                'or_booking_code' => $bkCode,
                'or_contract_code' => $ctCode,
                'or_installment_code' => $inCode,
                'or_remark' => $remark);
            //print_r($data);

            $this->load->model('tb_overdue_remark');
            $this->tb_overdue_remark->record($data);
            alert_redirect('Call remark Success.', $page);
        }else
            alert_redirect('Call remark Fail.', '/overdue/');
    }
	private function processFetchBooking($pj_id){
		$this->load->model('tb_booking');
		$list_booking = $this->tb_booking->fetch_all_BookingInfo_Overdue_byProjectID($pj_id);
		foreach($list_booking as $booking):
			if ( trim($booking->bk_transfer_from) == 'book' ){
				$this->load->model('tb_transfer_booking');
				$booking->letter = $this->tb_transfer_booking->get_detail_by_tf_code($booking->bk_transfer_letter);
			}else if ( trim($booking->bk_transfer_from) == 'contract' ){
				$this->load->model('tb_transfer_contract');
				$booking->letter = $this->tb_transfer_contract->get_detail_by_tf_code($booking->bk_transfer_letter);
			}
			

			$booking->transferdate =  !empty($booking->letter->tf_timestamp)?date('d/m/Y',strtotime($booking->letter->tf_timestamp)):'';

			$this->load->model('tb_customer_personal_info');
			$booking->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($booking->tf_to_cus);

			$this->load->model('tb_contract');
			$booking->contact =$this->tb_contract->get_detail_by_ct_booking_code($booking->bk_booking_code);

			$this->load->model('tb_quotation');
			$quotation = $this->tb_quotation->getDetail_by_id_withProjectTable($booking->bk_quotation_code);
			$booking->quotation = $quotation;

			$this->load->model('tb_building');
			$building = $this->tb_building->get_detail_building_by_building_id($quotation->qt_buliding_id);
			$booking->building_name = $building->building_name;

			$this->load->model('tb_unit_number');
			$room = $this->tb_unit_number->get_detail_unit_by_un_id($quotation->qt_unit_number_id);
			$booking->un_name = $room->un_name;

		endforeach;
		return $list_booking;
	}
}

