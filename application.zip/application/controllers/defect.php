<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Defect extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Defect';
    var $json = "";
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
        $this->json = json_decode(file_get_contents("../Service/Category/category.json"), true);

    }
	public function index()
	{

		$this->view();
	}
	public function view()
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_room'] = $this->fetch_room_defect();

		//getDetail($df_room_id)
		$data['isGuarantee'] = FALSE;
		$this->LoadView('Defect/defect',$data);
	}
	public function viewGuarantee()
	{
		$data['title'] = $this->title_page;
		$data['page'] = "DefectGuarantee";
		$data['list_room'] = $this->fetch_room_defect();
		$data['isGuarantee'] = TRUE;
		$this->LoadView('Defect/defect',$data);
	}


	private function fetch_room_defect(){
		$this->load->model('tb_unit_defect');

		$list_defect_room = $this->tb_unit_defect->fetch_all_defect_room($this->project_id_sel);
		foreach ($list_defect_room as $obj) {
				$obj->user = $this->tb_unit_defect->get_user_by_un_id($obj->df_un_id);
		}
		//print_r($list_defect_room);
		return $list_defect_room;
	}
	public function unlock($df_id)
	{
		$this->load->model('tb_unit_defect');
		$this->tb_unit_defect->unlock($df_id);
		alert_redirect('เปลี่ยนแปลงสถานะการซิงค์สู่ค่าเริ่มต้น','/defect/view');

	}
	public function fetchViewDefect($df_room_id,$un_id,$isGuarantee){
		////
	 $this->load->model('tb_defect');
	 $data['title'] = $this->title_page;
	 $data['page'] = $this->page_var;
	 $data['df_room_id'] = $df_room_id;
	 if ($isGuarantee == TRUE) {
			$list_defect = $this->tb_defect->fetch_guarantee_defect_by_df_room_id($df_room_id);
	 }else{
		 $list_defect = $this->tb_defect->fetch_defect_by_df_room_id($df_room_id);
	 }

	 foreach ($list_defect as $defect) {
			 $cate_title = $this->getCategoryTitleByCateID($defect->df_category);
			 $sub_cate_title = $this->getSubCategoryTitle($defect->df_category, $defect->df_sub_category);
			 if($sub_cate_title == "OTHER"){
					 $sub_cate_title = "อื่นๆ";
			 }else{

					 $detail = $this->getDetailCategoryTitle($defect->df_category, $defect->df_sub_category, $defect->df_detail);
					 $defect->df_detail = $detail;

			 }
			 $defect->df_category = $cate_title;
			 $defect->df_sub_category = $sub_cate_title;
	 }

		$data['list_defect'] = $list_defect;
		$data['pj_db'] = $this->project_database_sel;
		$data['pj_name'] = $this->project_name_sel;
		$data['un_id'] = $un_id;
		$data['project_img_path'] = $this->project_image_sel;
		$data['unit_type_img_path'] = $this->getUnitTypeImgPath($un_id);

		return $data;
	}
	public function viewDefectGuarantee($df_room_id,$un_id){
		$data = $this->fetchViewDefect($df_room_id,$un_id,TRUE);
		////

		$data['title'] = $this->title_page;
		$data['page'] = "DefectGuarantee";
		$data['isGuarantee'] = TRUE;
		$this->LoadView('Defect/view',$data);
	}
	public function viewDefect($df_room_id,$un_id)
	{
		$data = $this->fetchViewDefect($df_room_id,$un_id,FALSE);
		////

		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['isGuarantee'] = FALSE;
		$this->LoadView('Defect/view',$data);
	}
    public function report($language,$df_room_id,$un_id,$date)
    {
			  $date = str_replace("-slash-","/",$date);

        $this->load->model('tb_defect');
				$this->load->model('tb_unit_defect');
				$this->load->model('project_model/tb_project','',TRUE);
				$data = $this->getReport($language,$df_room_id,$un_id,FALSE);
				$this->tb_unit_defect->updateLastPrint($df_room_id,$date);

        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['df_room_id'] = $df_room_id;
				$data['date'] = $date;

				 if ($language == 'th') {
				 		$this->load->view('Defect/report_th',$data);
				 }else{
					 $this->load->view('Defect/report_en',$data);
				 }
    }
		public function reportGuarantee($language,$df_room_id,$un_id,$date)
    {
				$date = str_replace("-slash-","/",$date);
        $this->load->model('tb_defect');
				$this->load->model('tb_unit_defect');
				$this->load->model('project_model/tb_project','',TRUE);
				$data = $this->getReport($language,$df_room_id,$un_id,TRUE);
				$this->tb_unit_defect->updateLastPrint($df_room_id,$date);

        $data['title'] = $this->title_page;
        $data['page'] = "DefectGuarantee";
        $data['df_room_id'] = $df_room_id;
				$data['date'] = $date;

				 if ($language == 'th') {
				 		$this->load->view('Defect/report_th',$data);
				 }else{
					 $this->load->view('Defect/report_en',$data);
				 }
    }
		private function getReport($language,$df_room_id,$un_id,$isGuarantee){

			if ($isGuarantee == TRUE) {
	 			$list_defect = $this->tb_defect->fetch_guarantee_defect_by_df_room_id($df_room_id);
	 	 }else{
	 		 $list_defect = $this->tb_defect->fetch_defect_by_df_room_id($df_room_id);
	 	 }

			foreach ($list_defect as $defect) {
					$cate_title = $this->getCategoryTitleByCateID($defect->df_category);
					$sub_cate_title = $this->getSubCategoryTitle($defect->df_category, $defect->df_sub_category);
					if($sub_cate_title == "OTHER"){
							$sub_cate_title = "อื่นๆ";
					}else{

							$detail = $this->getDetailCategoryTitle($defect->df_category, $defect->df_sub_category, $defect->df_detail);
							$defect->df_detail = $detail;

					}
					$defect->df_category = $cate_title;
					$defect->df_sub_category = $sub_cate_title;
			}

			 $data['list_defect'] = $list_defect;
			 $data['pj_db'] = $this->project_database_sel;
			 $data['pj_name'] = $this->project_name_sel;
			 $data['un_id'] = $un_id;
			 $data['project_img_path'] = $this->project_image_sel;
			 $data['unit_type_img_path'] = $this->getUnitTypeImgPath($un_id);
			 $user = $this->tb_unit_defect->get_user_by_un_id($un_id);

			 ///////EMAIL//////
			 $user->email = $user->pers_email;
			 if ($user->pers_email == "") {
						$user->email = "N/A";
			 }
			 ///////NAME///////
			 $user->name = $user->pers_prefix.$user->pers_fname." ".$user->pers_lname;
			 if ($user->pers_fname == "") {
				 $user->name = "N/A";
			 }
			 //////PHONE//////////
			 $user->phone = $user->pers_mobile;
			 if ($user->pers_mobile == "") {
				 $user->phone = "N/A";
				 if ($user->pers_tel != "") {
						$user->phone = $user->pers_tel;
				 }
			 }
			 /////
			 $data['user'] = $user;

			 $defectInfo = $this->tb_unit_defect->getDefectInfo($un_id);
			 $roomInfo = $this->tb_unit_defect->roomDefectInfo($un_id);
			 $defectRoom = $this->tb_unit_defect->getUnitAndRoomByDefectRoomID($df_room_id);

			 $date = explode("|",$defectInfo->df_check_date);
			 $defectInfo->date = $date[0]." ".$date[1];

			 $data['qcCheckerInfo'] = $this->tb_unit_defect->getUserByID($defectInfo->df_user_id);

			 $cs_id = $defectInfo->df_user_id_cs;
			 $df_user_id_cs_list = explode(",",$cs_id);
			 if (count($df_user_id_cs_list) > 1) {
					 $cs_id = $df_user_id_cs_list[count($df_user_id_cs_list) - 1];
			 }

			 $data['csInfo'] = $this->tb_unit_defect->getUserByID($cs_id);
			 $data['defectInfo'] = $defectInfo;
			 $data['roomInfo'] = $roomInfo;
			 $data['defectRoom'] = $defectRoom;


			 $data['project'] = $this->tb_project->get_detail_project($this->project_id_sel);
				// print_r($data['project']);

				return $data;
		}
    private function getUnitTypeImgPath($un_id){
        $this->load->model('tb_unit_number');
        $detail = $this->tb_unit_number->_get_detail_unit_withUnitTypeRoomType_by_un_id($un_id);
        return $detail->unit_type_image;
    }
    private function getCategoryTitleByCateID($category_id){
        foreach ($this->json['list'] as $level1) {

            if($level1['id'] == $category_id){
                return $level1['title'];
            }
        }
    }
    private function getSubCategoryTitle($category_id, $sub_category_id){
        foreach ($this->json['list'] as $level1) {

            if($level1['id'] == $category_id){

                foreach ($level1['list'] as $subCate) {
                    if($subCate['id'] == $sub_category_id){
                        return $subCate['title'];
                    }
                }

            }
        }
        return "OTHER";
    }
    private function getDetailCategoryTitle($category_id, $sub_category_id, $detail_id){
        foreach ($this->json['list'] as $level1) {

            if($level1['id'] == $category_id){

                foreach ($level1['list'] as $level2) {
                    if($level2['id'] == $sub_category_id){

                        foreach ($level2['list'] as $level3) {
                            if($level3['id'] == $detail_id){
                                return $level3['title'];
                            }
                        }

                    }
                }

            }
        }
    }

}
