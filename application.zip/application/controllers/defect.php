<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Defect extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Defect';
    var $json = "";
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
        $this->json = json_decode(file_get_contents("../Service/Category/category.json"), true);

    }
	public function index()
	{

		$this->view();
	}
	public function view()
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_room'] = $this->fetch_room_defect();
		$this->LoadView('Defect/defect',$data);
	}

	
	private function fetch_room_defect(){
		$this->load->model('tb_unit_defect');

		$list_defect_room = $this->tb_unit_defect->fetch_all_defect_room($this->project_id_sel);
		return $list_defect_room;
	}

    public function report($language,$df_room_id,$un_id)
    {
        $this->load->model('tb_defect');
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['df_room_id'] = $df_room_id;
        $list_defect = $this->tb_defect->fetch_defect_by_df_room_id($df_room_id);

        

        foreach ($list_defect as $defect) {
            $cate_title = $this->getCategoryTitleByCateID($defect->df_category);
            $sub_cate_title = $this->getSubCategoryTitle($defect->df_category, $defect->df_sub_category);
            if($sub_cate_title == "OTHER"){
                $sub_cate_title = "อื่นๆ";
            }else{

                $detail = $this->getDetailCategoryTitle($defect->df_category, $defect->df_sub_category, $defect->df_detail);
                $defect->df_detail = $detail;

            }
            $defect->df_category = $cate_title;
            $defect->df_sub_category = $sub_cate_title;
        }

         $data['list_defect'] = $list_defect;
         $data['pj_db'] = $this->project_database_sel;
         $data['pj_name'] = $this->project_name_sel;
         $data['un_id'] = $un_id;
         $data['project_img_path'] = $this->project_image_sel;
         $data['unit_type_img_path'] = $this->getUnitTypeImgPath($un_id);
         $this->load->view('Defect/report_th',$data);
    }
    private function getUnitTypeImgPath($un_id){
        $this->load->model('tb_unit_number');
        $detail = $this->tb_unit_number->_get_detail_unit_withUnitTypeRoomType_by_un_id($un_id);
        return $detail->unit_type_image;
    }
    private function getCategoryTitleByCateID($category_id){
        foreach ($this->json['list'] as $level1) {

            if($level1['id'] == $category_id){
                return $level1['title'];
            }
        }
    }
    private function getSubCategoryTitle($category_id, $sub_category_id){
        foreach ($this->json['list'] as $level1) {

            if($level1['id'] == $category_id){
                
                foreach ($level1['list'] as $subCate) {
                    if($subCate['id'] == $sub_category_id){
                        return $subCate['title'];
                    }
                }

            }
        }
        return "OTHER";
    }
    private function getDetailCategoryTitle($category_id, $sub_category_id, $detail_id){
        foreach ($this->json['list'] as $level1) {

            if($level1['id'] == $category_id){
                
                foreach ($level1['list'] as $level2) {
                    if($level2['id'] == $sub_category_id){
                        
                        foreach ($level2['list'] as $level3) {
                            if($level3['id'] == $detail_id){
                                return $level3['title'];
                            }
                        }

                    }
                }

            }
        }
    }
    
}
