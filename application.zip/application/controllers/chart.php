<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Chart extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Chart';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
	public function index()
	{
		$this->lead();
	}
	public function lead($typeChart) {
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'lead';
        
		$type = !empty($typeChart)?$typeChart:'month';
		$typeQuery = 'lead';
        
		$result = $this->getData($type, $typeQuery);
		$data['date_cut'] = !empty($result['date_cut'])?$result['date_cut']:'0';
		$data['format_chart'] = $result['format_chart'];
		$data['count_cus'] = $result['count_cus'];
		$data['xAxis'] = $result['xAxis'];
		$data['date_show'] = $result['date_show'];
		$data['rotation'] = $result['rotation'];
		$data['type_name'] = 'Leads';

		$data['time_index'] = $result['type'];
        $data['visit'] = $result['visit'];
        $data['budget'] = $result['budget'];
        $data['sex'] = $result['sex'];
        $data['stage'] = $result['stage'];
        $data['mediaCategories'] = $result['mediaCategories'];
        $data['mediaDatas'] = $result['mediaDatas'];
        
        
		$this->LoadView('Chart/chart_lead',$data);
	}

	public function customer($typeChart) {
		/*echo('<script>alert("'.$result['count_cus'].'")</script>');*/
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'customer';
		
		$type = !empty($typeChart)?$typeChart:'month';
		$typeQuery = 'customer';

		$result = $this->getData($type, $typeQuery);

		$data['date_cut'] = $result['date_cut'];
		$data['format_chart'] = $result['format_chart'];
		$data['count_cus'] = $result['count_cus'];
		$data['xAxis'] = $result['xAxis'];
		$data['date_show'] = $result['date_show'];
		$data['rotation'] = $result['rotation'];
		$data['type_name'] = 'Customers';

		$data['time_index'] = $result['type'];
        $data['sex'] = $result['sex'];
        $data['xAxisAge'] = $result['xAxisAge'];
        $data['dataAge'] = $result['dataAge'];
        $data['districtName'] = $result['districtName'];
        $data['districtCount'] = $result['districtCount'];
        $data['subDistrictName'] = $result['subDistrictName'];
        $data['subDistrictCount'] = $result['subDistrictCount'];
//        $data['provinceName'] = $result['provinceName'];
//        $data['provinceCount'] = $result['provinceCount'];
        $data['districtNameWork'] = $result['districtNameWork'];
        $data['districtCountWork'] = $result['districtCountWork'];
        $data['subDistrictNameWork'] = $result['subDistrictNameWork'];
        $data['subDistrictCountWork'] = $result['subDistrictCountWork'];
//        $data['provinceNameWork'] = $result['provinceNameWork'];
//        $data['provinceCountWork'] = $result['provinceCountWork'];
        $data['provinceDetails'] = $result['provinceDetails'];
        $data['provinceDetailsWork'] = $result['provinceDetailsWork'];
        
//        print_r($result['budget']);exit();
        
        $data['visit'] = $result['visit'];
        $data['budget'] = $result['budget'];
        $data['mediaCategories'] = $result['mediaCategories'];
        $data['mediaDatas'] = $result['mediaDatas'];
        
        
        
        $this->LoadView('Chart/chart_customer',$data);
	}

	public function quotation($typeChart) {
		/*echo('<script>alert("'.$result['count_cus'].'")</script>');*/
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'quotation';
		
		$type = !empty($typeChart)?$typeChart:'month';
		$typeQuery = 'quotation';

		$result = $this->getData($type, $typeQuery);

		$data['date_cut'] = $result['date_cut'];
		$data['format_chart'] = $result['format_chart'];
		$data['count_cus'] = $result['count_cus'];
		$data['xAxis'] = $result['xAxis'];
		$data['date_show'] = $result['date_show'];
		$data['rotation'] = $result['rotation'];
		$data['type_name'] = 'Quotations';
		$data['time_index'] = $result['type'];
        $data['tableTopPromotion'] = $result['tableTopPromotion'];
        $data['tableTopUnit'] = $result['tableTopUnit'];
        $data['topEmpQout'] = $result['topEmpQout'];

		$this->LoadView('Chart/chart_quotation',$data);
	}

	public function booking($typeChart)	{
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'booking';

		$type = !empty($typeChart)?$typeChart:'month';
		$typeQuery = 'booking';

		$result = $this->getData($type, $typeQuery);

		$data['date_cut'] = $result['date_cut'];
		$data['format_chart'] = $result['format_chart'];
		$data['count_cus'] = $result['count_cus'];
		$data['xAxis'] = $result['xAxis'];
		$data['date_show'] = $result['date_show'];
		$data['rotation'] = $result['rotation'];
		$data['type_name'] = 'Bookings';
		$data['time_index'] = $result['type'];

		$this->LoadView('Chart/chart_booking',$data);
	}

	public function contract($typeChart) {
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'contract';

		$type = !empty($typeChart)?$typeChart:'month';
		$typeQuery = 'contract';

		$result = $this->getData($type, $typeQuery);

		$data['date_cut'] = $result['date_cut'];
		$data['format_chart'] = $result['format_chart'];
		$data['count_cus'] = $result['count_cus'];
		$data['xAxis'] = $result['xAxis'];
		$data['date_show'] = $result['date_show'];
		$data['rotation'] = $result['rotation'];
		$data['type_name'] = 'Contracts';
		$data['time_index'] = $result['type'];

		$this->LoadView('Chart/chart_contract',$data);
	}

	public function receipt($typeChart)	{
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'receipt';
		
		$type = !empty($typeChart)?$typeChart:'month';
		$typeQuery = 'receipt';

		$result = $this->getData($type, $typeQuery);

		$data['date_cut'] = $result['date_cut'];
		$data['format_chart'] = $result['format_chart'];
		$data['count_cus'] = $result['count_cus'];
		$data['xAxis'] = $result['xAxis'];
		$data['date_show'] = $result['date_show'];
		$data['rotation'] = $result['rotation'];
		$data['type_name'] = 'Receipts';
		$data['time_index'] = $result['type'];

		$this->LoadView('Chart/chart_receipt',$data);
	}

	public function income($typeChart, $exBeginDate, $exEndDate, $exCusID, $exBuildID, $exFloorID, $exUnID)	{
		/*echo('<script>alert("'.$result['count_cus'].'")</script>');*/
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'income';

		$this->load->model('tb_receipt_offical');
        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_payment');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_building');
        $this->load->model('tb_payment');
        $this->load->model('tb_floor');
        $this->load->model('tb_unit_type');
        $this->load->model('tb_price');
        $this->load->model('tb_quotation');
        $this->load->model('tb_booking');
        
        $this->load->library('DateFormat');
		
        if($typeChart == "")
        {
            $beginDate  = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
            $endDate    = !empty($this->input->post('endDate'))?$this->input->post('endDate'):date('Y-m-d');
            $cusID      = !empty($this->input->post('cusID'))?$this->input->post('cusID'):'all';
            $floorID    = !empty($this->input->post('floorID'))?$this->input->post('floorID'):'all';
            $unID       = !empty($this->input->post('unID'))?$this->input->post('unID'):'all';
            $buildID    = !empty($this->input->post('buildID'))?$this->input->post('buildID'):'all';
        }
        else
        {
            $beginDate  = $exBeginDate;
            $endDate    = $exEndDate;
            $cusID      = $exCusID;
            $floorID    = $exFloorID;
            $unID       = $exUnID;
            $buildID    = $exBuildID;
        }
        $start = $beginDate.' 00:00:00';
        $end = $endDate.' 23:59:59';
        
        if($cusID != 'all')
        {
            $sqlCusID = 'AND rc_customer_id = '.$cusID.'';
        }
        else
        {
            $sqlCusID = '';
        }
        
        if($floorID != 'all')
        {
            if($unID != 'all')
            {
                $getUnNumber = $this->tb_unit_number->get_detail_unit_by_un_id_andBuildingID($unID, $buildID);
                if($getUnNumber->un_name != null)
                    $sqlUnID = 'AND rc_un_name = '.$getUnNumber->un_name.'';
                else
                    echo('<script>alert("error : sqlUnID = null")</script>');
            }
            else
            {
                $sqlUnID = ' AND un_floor_id = '.$floorID.'
				            AND un_name = rc_un_name';
//                echo('<script>alert("error : sqlUnID = '.$floorID.'")</script>');
            }
        }
        else
        {
            $sqlUnID = '';
        }
        //ดึงข้อมูลห้องโดยไม่ซ้ำกัน
        $getDistinctRoom = $this->tb_receipt_offical->get_distinct_un_name_for_income($start, $end, $sqlCusID, $sqlUnID);
                
        $numSeq = 0;
        foreach($getDistinctRoom as $_getDistinctRoom)
        {
            $numSeq++;
            
            $getReceipt = $this->tb_receipt_offical->get_detail_status_on_by_un_name($_getDistinctRoom->rc_un_name);
            $installmentTime = 0;
            
            foreach($getReceipt as $_getReceipt)
            {                
                $getDeUnNumber  = $this->tb_unit_number->get_detail_by_un_name($_getReceipt->rc_un_name);
                $getDeUnType    = $this->tb_unit_type->get_detail_by_unit_type_id($getDeUnNumber->un_unit_type_id);
                $getFloor       = $this->tb_floor->get_detail_by_id($getDeUnNumber->un_floor_id);
                $getDeBuilding  = $this->tb_building->get_detail_building_by_building_id($getDeUnNumber->un_build_id);
//                echo('<script>alert("error : customerID = '.$_getReceipt->rc_customer_id.'")</script>');
                $getDeCus       = $this->tb_customer_personal_info->get_detail_by_id($_getReceipt->rc_customer_id);
                $getPrice       = $this->tb_price->get_detail_by_buildingID_UnitNumberID($getDeUnNumber->un_build_id, $getDeUnNumber->un_id);
                $getBooking     = $this->tb_booking->get_detail_by_bk_booking_code($_getReceipt->rc_booking_code);
                $getQuotation   = $this->tb_quotation->getDetail_by_id_withStatus_OFF($getBooking->bk_quotation_code);
                $getPayment     = $this->tb_payment->get_payment_by_receipt_code($_getReceipt->rc_code);
                
                foreach($getPayment as $_getPayment)
                {
                    $realTotalAmount[$numSeq] += ($_getPayment->pm_amount - $_getPayment->pm_cr_fee);
                    
                }
                
                if($_getReceipt->rc_payfor == 'Booking Fee')
                {
                    $bookingAmount[$numSeq] += $_getReceipt->rc_total_amount;
                    $bookingDate = $_getReceipt->rc_official_date;
                }
                else if($_getReceipt->rc_payfor == 'Contract Fee')
                {
                    $contractAmount[$numSeq] += $_getReceipt->rc_total_amount;
                    $contractDate = $_getReceipt->rc_official_date;
                }
                else if($_getReceipt->rc_payfor == 'Installment Fee')
                {
                    $installmentAmount[$numSeq] += $_getReceipt->rc_total_amount;
                    $installmentTime++;
                }
            }
            
            $totalRealTotalAmount += $realTotalAmount[$numSeq];
            $totalTotalDownPayment += $getQuotation->qt_total_down_payment;
            $totalBalance += ($getQuotation->qt_total_down_payment - $bookingAmount[$numSeq] - $contractAmount[$numSeq] - $installmentAmount[$numSeq]);
    
            $html .= '
            <tr>
                <td class="general-td">'.$numSeq.'</td>
                <td class="general-td">'.$getFloor->fl_name.'</td>
                <td class="general-td">'.$getDeBuilding->building_name.$_getReceipt->rc_un_name.'</td>
                <td class="customer-td">'.$getDeCus->pers_fname.' '.$getDeCus->pers_lname.'</td>
                <td class="general-td">'.$getDeUnType->unit_type_area_sqm.'</td>
                <td class="price-td">'.number_format(floatval(str_replace(',', '', str_replace('.', '', $getPrice->pr_asking_price))),2).'</td>
                <td class="price-td">'.number_format(($bookingAmount[$numSeq]),2).'</td>
                <td>'.date('d/m/Y', strtotime($bookingDate)).'</td>
                <td class="price-td">'.number_format(($contractAmount[$numSeq]),2).'</td>
                <td>'.date('d/m/Y', strtotime($contractDate)).'</td>
                <td class="general-td">'.$installmentTime.' / '.$getQuotation->qt_total_months.'</td>
                <td class="price-td">'.number_format(($installmentAmount[$numSeq]),2).'</td>
                <td class="price-td">'.number_format($realTotalAmount[$numSeq],2).'</td>
                <td class="price-td">'.number_format(($getQuotation->qt_total_down_payment),2).'</td>
                <td class="price-td">'.number_format(($getQuotation->qt_total_down_payment - $bookingAmount[$numSeq] - $contractAmount[$numSeq] - $installmentAmount[$numSeq]),2).'</td>
            </tr>
            ';    
        }
        
        $data['html'] = $html;
        $data['DateFormat'] = $this->DateFormat;
        $data['typeDr'] = 'charge';
        $data['totalDownPay'] = $totalDownPay;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['list_building'] = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
        $data['beginDate'] = $beginDate;
        $data['endDate'] = $endDate;
        $data['exBeginDate'] = $beginDate;
        $data['exEndDate'] = $endDate;
        $data['exBuildID'] = $buildID;
        $data['exCusID'] = $cusID;
        $data['exFloorID'] = $floorID;
        $data['exUnID'] = $unID;
        $data['totalRealTotalAmount'] = $totalRealTotalAmount;
        $data['totalTotalDownPayment'] = $totalTotalDownPayment;
        $data['totalBalance'] = $totalBalance;

		if($typeChart == "")
            $this->LoadView('Chart/chart_income',$data);
        else
            $this->LoadView('Excel/excel_income',$data);
	}
    
    public function overdueContract($typeChart, $exBeginDate, $exEndDate, $exCusID, $exBuildID, $exFloorID, $exUnID) {
		/*echo('<script>alert("'.$result['count_cus'].'")</script>');*/
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'overdueContract';

        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_building');
        $this->load->model('tb_floor');
        $this->load->model('tb_unit_type');
        $this->load->model('tb_price');
        $this->load->model('tb_quotation');
        $this->load->model('tb_booking');
        $this->load->model('tb_contract');
        $this->load->model('tb_receipt_offical');
        
        $this->load->library('DateFormat');
		
        if($typeChart == "")
        {
            $beginDate  = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
            $endDate    = !empty($this->input->post('endDate'))?$this->input->post('endDate'):date('Y-m-d');
            $cusID      = !empty($this->input->post('cusID'))?$this->input->post('cusID'):'all';
            $floorID    = !empty($this->input->post('floorID'))?$this->input->post('floorID'):'all';
            $unID       = !empty($this->input->post('unID'))?$this->input->post('unID'):'all';
            $buildID    = !empty($this->input->post('buildID'))?$this->input->post('buildID'):'all';
        }
        else
        {
            $beginDate  = $exBeginDate;
            $endDate    = $exEndDate;
            $cusID      = $exCusID;
            $floorID    = $exFloorID;
            $unID       = $exUnID;
            $buildID    = $exBuildID;
        }
        
        $start = $beginDate.' 00:00:00';
        $end = $endDate.' 23:59:59';
        
        if($cusID != 'all')
        {
            $sqlCusID = 'AND bk_leads_id = '.$cusID.'';
        }
        else
        {
            $sqlCusID = '';
        }
        
        if($floorID != 'all')
        {
            if($unID != 'all')
            {
                $getUnNumber = $this->tb_unit_number->get_detail_unit_by_un_id_andBuildingID($unID, $buildID);
                if($getUnNumber->un_name != null)
                    $sqlUnID = 'AND qt_unit_number_id = '.$getUnNumber->un_name.'';
                else
                    echo('<script>alert("error : sqlUnID = null")</script>');
            }
            else
            {
                $sqlUnID = 'AND qt_floor_id = '.$floorID.'';
//                echo('<script>alert("error : sqlUnID = '.$floorID.'")</script>');
            }
        }
        else
        {
            $sqlUnID = '';
        }
        
        $getDetailBooking = $this->tb_booking->get_detail_for_chart_overdue_contract($start, $end, $sqlCusID, $sqlUnID);
        
        $numSeq = 0;
        foreach($getDetailBooking as $_getDetailBooking)
        {
            $numSeq++;
            $getFloor = $this->tb_floor->get_detail_by_id($_getDetailBooking->qt_floor_id);
            $getBuild = $this->tb_building->get_detail_building_by_building_id($_getDetailBooking->qt_buliding_id);
            $getDeUnitNumber = $this->tb_unit_number->get_detail_unit_by_un_id($_getDetailBooking->qt_unit_number_id);
            $getDeCus = $this->tb_customer_personal_info->get_detail_by_id($_getDetailBooking->bk_leads_id);
            $getUnitType = $this->tb_unit_type->get_detail_by_unit_type_id($getDeUnitNumber->un_unit_type_id);
            $getContract = $this->tb_contract->get_detail_by_ct_booking_code($_getDetailBooking->bk_booking_code);
            $getReceipt = $this->tb_receipt_offical->get_by_booking($_getDetailBooking->bk_booking_code);
            
            $checkPayContract = false;
            foreach($getReceipt as $_getReceipt)
            {
                if($_getReceipt->rc_payfor == 'Contract Fee' && $_getReceipt->rc_contract_code != null)
                {
                    $checkPayContract = true;
                }
            }
            
            if($checkPayContract != true)
            {
                $diffContractDate[$numSeq] = ceil(( strtotime(date('Y-m-d')) - strtotime(date('Y-m-d', strtotime($_getDetailBooking->bk_contract_date))) ) / ( 60 * 60 * 24 ));
            }
            else
            {
                $diffContractDate[$numSeq] = 0;
            }
            
            $totalContractAmount += $_getDetailBooking->qt_contract_fee;
            
//            $diffContractDate = ( strtotime(date('Y-m-d', strtotime($getContract->ct_date))) - strtotime(date('Y-m-d', $_getDetailBooking->bk_contract_date)) ) / ( 60 * 60 * 24 );
            
            $html .= '
            <tr>
                <td class="general-td">'.$numSeq.'</td>
                <td class="general-td">'.$getFloor->fl_name.'</td>
                <td class="general-td">'.$getBuild->building_name.$getDeUnitNumber->un_name.'</td>
                <td class="customer-td">'.$getDeCus->pers_fname.' '.$getDeCus->pers_lname.'</td>
                <td class="general-td">'.$getUnitType->unit_type_area_sqm.'</td>
                <td class="price-td">'.number_format($_getDetailBooking->qt_unit_price,2).'</td>
                <td class="price-td">'.number_format($_getDetailBooking->qt_contract_fee,2).'</td>
                <td class="general-td">'.date('d/m/Y', strtotime($_getDetailBooking->bk_contract_date)).'</td>
                <td class="general-td">'.$diffContractDate[$numSeq].'</td>
            </tr>
            ';    
        }
        
        $data['html'] = $html;
        $data['DateFormat'] = $this->DateFormat;
        $data['typeDr'] = 'overdueContract';
        $data['totalDownPay'] = $totalDownPay;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['list_building'] = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
        $data['beginDate'] = $beginDate;
        $data['endDate'] = $endDate;
        $data['exBeginDate'] = $beginDate;
        $data['exEndDate'] = $endDate;
        $data['exBuildID'] = $buildID;
        $data['exCusID'] = $cusID;
        $data['exFloorID'] = $floorID;
        $data['exUnID'] = $unID;
        $data['totalContractAmount'] = $totalContractAmount;

		if($typeChart == "")
            $this->LoadView('Chart/chart_overdue_contract',$data);
        else
            $this->LoadView('Excel/excel_overdue_contract',$data);
	}
    
    public function survey($typeChart) {
        $this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'survey';
        
        $this->load->model('tb_chart');
        $this->load->model('tb_survey_answer');
        $this->load->model('tb_survey_choice');
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_question');
        
        $duration = !empty($typeChart)?$typeChart:'today';
        $group = 1;
        $dataSur = $this->getDataSurvey($group, $duration);
        
        $getSurGr = $this->tb_survey_group->get_detail_by_id($group);
        $questionTemp = split(",", $getSurGr->sg_question);
    
        $numDeChart = 0;
        $numCh = 0;
        $sumAns = $dataSur['sumAns'];
        foreach($questionTemp as $_questionTemp){
            $getDeByQu = $this->tb_survey_choice->get_detail_by_question_id($_questionTemp);
            foreach($getDeByQu as $_getDeByQu){
                $chartDetail[$numDeChart] .= '["'.$_getDeByQu->sc_name.'", '.$sumAns[$numCh].'],';
                $numCh++;
            }
            
            /*$chart[$numDeChart] = '
                $(function () {
                    $(document).ready(function () {
                        // Build the chart
                        $("#pi'.($numDeChart+1).'").highcharts({
                            chart: {
                                plotBackgroundColor: null,
                                plotBorderWidth: null,
                                plotShadow: false
                            },
                            title: {
                                text: ""
                            },
                            tooltip: {
                                pointFormat: "{series.name}: <b>{point.y}</b> คน"
                            },
                            plotOptions: {
                                pie: {
                                    allowPointSelect: true,
                                    cursor: "pointer",
                                    dataLabels: {
                                        enabled: false
                                    },
                                    showInLegend: true
                                }
                            },
                            series: [{
                                type: "pie",
                                name: "มีลูกค้าเลือก",
                                data: [
                                        '.$chartDetail[$numDeChart].',
                                ]
                            }]
                        });
                    });

                });
            ';*/
            $chart[$numDeChart] = '
                $(function () {
                    $("#pi'.($numDeChart+1).'").highcharts({
                        chart: {
                            plotBackgroundColor: null,
                            plotBorderWidth: null,
                            plotShadow: false
                        },
                        title: {
                            text: ""
                        },
                        tooltip: {
                            pointFormat: "{series.name}: <b>{point.y}</b> คน"
                        },
                        plotOptions: {
                            pie: {
                                allowPointSelect: true,
                                cursor: "pointer",
                                dataLabels: {
                                    enabled: true,
                                    format: "<b>{point.name}</b>: {point.y} คน",
                                    style: {
                                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || "black"
                                    }
                                }
                            }
                        },
                        series: [{
                            type: "pie",
                            name: "มีลูกค้าเลือก",
                            data: [
                                    '.$chartDetail[$numDeChart].',
                            ]
                        }]
                    });
                });
            ';
            $numDeChart++;
        }

        $getSurGr = $this->tb_survey_group->get_detail_by_id($group);
        $questionTemp = split(",", $getSurGr->sg_question);
        $numChart = 0;
        foreach($questionTemp as $_questionTemp){
            $getDeByQu = $this->tb_survey_question->get_detail_by_id($_questionTemp);
            $createChart[$numChart] = '
                <div class="widget widget-inverse">
                    <div class="widget widget-inverse">
                        <!-- Widget heading -->
                        <div class="widget-head">
                            <h4 class="heading">'.($numChart+1).'. '.$getDeByQu->sq_name.'</h4>
                        </div>
                        <!-- // Widget heading END -->
                        <div class="widget-body">
                            <script src="../../js/highcharts.js"></script>
                            <script src="../../js/modules/exporting.js"></script>
                            <!-- Pie Chart -->
                            <div id="pi'.($numChart+1).'" style="min-width: 310px;max-width:100%; height: 300px; margin:3px 0 auto"></div>
                        </div>
                    </div>
                </div>
            ';
            $numChart++;
            
        }
        
        $data['time_index'] = $duration;
        $data['sumAns'] = $sumAns;
        $data['chartDetail'] = $chartDetail;
        $data['createChart'] = $createChart;
        $data['chart'] = $chart;
        $data['numChart'] = $numChart;
        $data['numDeChart'] = $numDeChart;
                
//        echo '<script>alert("'.$test.'")</script>';
        
//        $this->LoadView('Chart/chart_survey',$data);
        $this->LoadView('Chart/doc11',$data);
    }

    public function getDataSurvey($group, $duration) {
        $maxCh = 68;
        //today
		if($duration == 'today')
		{
            $start = date("Y-m-d"). ' 00:00:00';
            $end = date("Y-m-d"). ' 23:59:59';

            $getSurAns = $this->tb_survey_answer->get_detail_by_date($group,$start,$end);
            $numCS = 0;
            foreach($getSurAns as $_getSurAns)
            {
                $ansCus = split(",", $_getSurAns->sa_answer);
                $getSurGr = $this->tb_survey_group->get_detail_by_id($_getSurAns->sa_group);

                $questionTemp = split(",", $getSurGr->sg_question);
                $numAns=0;
                foreach($questionTemp as $_questionTemp){
                    $getDeByQu = $this->tb_survey_choice->get_detail_by_question_id($_questionTemp);

                    foreach($getDeByQu as $_getDeByQu){
                        foreach($ansCus as $_ansCus){
                            if($_getDeByQu->sc_id == $_ansCus){
                                $sumAns[$numAns]++;
                            }
                            else if($_getDeByQu->sc_id != $_ansCus && $sumAns[$numAns] == null){
                                $sumAns[$numAns] = 0;
                            }
                            $nameCh[$numAns] = $_getDeByQu->sc_name;
                        }
                        $numAns++;
                    }
                }
                $numCus++;
            }
		}
        else if($duration == 'week')
		{
            $start = date("Y-m-d",strtotime("-6 days",strtotime(date("Y-m-d")))). ' 00:00:00';
            $end = date("Y-m-d"). ' 23:59:59';
            $getSurAns = $this->tb_survey_answer->get_detail_by_date($group,$start,$end);
            $numCS = 0;
            foreach($getSurAns as $_getSurAns)
            {
                $ansCus = split(",", $_getSurAns->sa_answer);
                $getSurGr = $this->tb_survey_group->get_detail_by_id($_getSurAns->sa_group);

                $questionTemp = split(",", $getSurGr->sg_question);
                $numAns=0;
                foreach($questionTemp as $_questionTemp){
                    $getDeByQu = $this->tb_survey_choice->get_detail_by_question_id($_questionTemp);

                    foreach($getDeByQu as $_getDeByQu){
                        foreach($ansCus as $_ansCus){
                            if($_getDeByQu->sc_id == $_ansCus){
                                $sumAns[$numAns]++;
                            }
                            else if($_getDeByQu->sc_id != $_ansCus && $sumAns[$numAns] == null){
                                $sumAns[$numAns] = 0;
                            }
                            $nameCh[$numAns] = $_getDeByQu->sc_name;
                        }
                        $numAns++;
                    }
                }
                $numCus++;
            }
		}
        else if($duration == 'month')
		{
            $start = date("Y-m-d",strtotime("-29 days",strtotime(date("Y-m-d")))). ' 00:00:00';
            $end = date("Y-m-d"). ' 23:59:59';
            $getSurAns = $this->tb_survey_answer->get_detail_by_date($group,$start,$end);
            $numCS = 0;
            foreach($getSurAns as $_getSurAns)
            {
                $ansCus = split(",", $_getSurAns->sa_answer);
                $getSurGr = $this->tb_survey_group->get_detail_by_id($_getSurAns->sa_group);

                $questionTemp = split(",", $getSurGr->sg_question);
                $numAns=0;
                foreach($questionTemp as $_questionTemp){
                    $getDeByQu = $this->tb_survey_choice->get_detail_by_question_id($_questionTemp);

                    foreach($getDeByQu as $_getDeByQu){
                        foreach($ansCus as $_ansCus){
                            if($_getDeByQu->sc_id == $_ansCus){
                                $sumAns[$numAns]++;
                            }
                            else if($_getDeByQu->sc_id != $_ansCus && $sumAns[$numAns] == null){
                                $sumAns[$numAns] = 0;
                            }
                            $nameCh[$numAns] = $_getDeByQu->sc_name;

                        }
                        $numAns++;
                    }
                }
                $numCus++;
            }
		}
        else if($duration == 'custom')
		{
            $start = $this->input->post('start'). ' 00:00:00';
            $end = $this->input->post('end'). ' 23:59:59';

            $getSurAns = $this->tb_survey_answer->get_detail_by_date($group,$start,$end);
            $numCS = 0;
            foreach($getSurAns as $_getSurAns)
            {
                $ansCus = split(",", $_getSurAns->sa_answer);
                $getSurGr = $this->tb_survey_group->get_detail_by_id($_getSurAns->sa_group);

                $questionTemp = split(",", $getSurGr->sg_question);
                $numAns=0;
                foreach($questionTemp as $_questionTemp){
                    $getDeByQu = $this->tb_survey_choice->get_detail_by_question_id($_questionTemp);

                    foreach($getDeByQu as $_getDeByQu){
                        foreach($ansCus as $_ansCus){
                            if($_getDeByQu->sc_id == $_ansCus){
                                $sumAns[$numAns]++;
                            }
                            else if($_getDeByQu->sc_id != $_ansCus && $sumAns[$numAns] == null){
                                $sumAns[$numAns] = 0;
                            }
                            $nameCh[$numAns] = $_getDeByQu->sc_name;

                        }
                        $numAns++;
                    }
                }
                $numCus++;
            }
		}
        else if($duration == 'total')
        {
            $getBeDate = $this->tb_survey_answer->get_min_date();
            $maxCh = 68;
            $start = $getBeDate->minDate. ' 00:00:00';
            $end = date('Y-m-d'). ' 23:59:59';

            $getSurAns = $this->tb_survey_answer->get_detail_by_date($group,$start,$end);
            $numCS = 0;
            foreach($getSurAns as $_getSurAns)
            {
                $ansCus = split(",", $_getSurAns->sa_answer);
                $getSurGr = $this->tb_survey_group->get_detail_by_id($_getSurAns->sa_group);

                $questionTemp = split(",", $getSurGr->sg_question);
                $numAns=0;
                foreach($questionTemp as $_questionTemp){
                    $getDeByQu = $this->tb_survey_choice->get_detail_by_question_id($_questionTemp);

                    foreach($getDeByQu as $_getDeByQu){
                        foreach($ansCus as $_ansCus){
                            if($_getDeByQu->sc_id == $_ansCus){
                                $sumAns[$numAns]++;
                            }
                            else if($_getDeByQu->sc_id != $_ansCus && $sumAns[$numAns] == null){
                                $sumAns[$numAns] = 0;
                            }
                            $nameCh[$numAns] = $_getDeByQu->sc_name;
                        }
                        $numAns++;
                    }
                }
                $numCus++;
            }
        }
        $dataSur['sumAns'] = $sumAns;
        return $dataSur;
	}
    
	public function getData($type, $typeQuery) {
        //today
		if($type == 'today') {
			$formatChart = 'column';
			$rotation = 'rotation: 270,';
			$timeShow = array(
				'00:00 - 00:59',
				'01:00 - 01:59',
				'02:00 - 02:59',
				'03:00 - 03:59',
				'04:00 - 04:59',
				'05:00 - 05:59',
				'06:00 - 06:59',
				'07:00 - 07:59',
				'08:00 - 08:59',
				'09:00 - 09:59',
				'10:00 - 10:59',
				'11:00 - 11:59',
				'12:00 - 12:59',
				'13:00 - 13:59',
				'14:00 - 14:59',
				'15:00 - 15:59',
				'16:00 - 16:59',
				'17:00 - 17:59',
				'18:00 - 18:59',
				'19:00 - 19:59',
				'20:00 - 20:59',
				'21:00 - 21:59',
				'22:00 - 22:59',
				'23:00 - 23:59');

			$timesStart = array(
				'00:00:00',
				'01:00:00',
				'02:00:00',
				'03:00:00',
				'04:00:00',
				'05:00:00',
				'06:00:00',
				'07:00:00',
				'08:00:00',
				'09:00:00',
				'10:00:00',
				'11:00:00',
				'12:00:00',
				'13:00:00',
				'14:00:00',
				'15:00:00',
				'16:00:00',
				'17:00:00',
				'18:00:00',
				'19:00:00',
				'20:00:00',
				'21:00:00',
				'22:00:00',
				'23:00:00');

			$timesEnd = array(
				'00:59:00',
				'01:59:00',
				'02:59:00',
				'03:59:00',
				'04:59:00',
				'05:59:00',
				'06:59:00',
				'07:59:00',
				'08:59:00',
				'09:59:00',
				'10:59:00',
				'11:59:00',
				'12:59:00',
				'13:59:00',
				'14:59:00',
				'15:59:00',
				'16:59:00',
				'17:59:00',
				'18:59:00',
				'19:59:00',
				'20:59:00',
				'21:59:00',
				'22:59:00',
				'23:59:00');
			$i = 0;
            
            $customerArr = array();
            $dobArr = array();
			foreach ($timesStart as $_timeStart) {
				$dateStart = date("Y-m-d");
				$dateEnd = date("Y-m-d");
				$timeStart = $_timeStart; 
				$timeEnd = $timesEnd[$i];

				$start = $dateStart . ' ' . $timeStart;
				$end = $dateEnd . ' ' . $timeEnd;

				$this->load->model('tb_chart');
                $this->load->model('tb_survey_answer');
                
				if($typeQuery == 'lead'){
                    $getDetail_cus = $this->tb_chart->get_detail_lead_by_date_report($start, $end);
                    $countCus=0;
                    $dateCus = array();
                    foreach($getDetail_cus as $detail_cus){
                        $customer[$detail_cus->qt_leads_id]++;
                        
                        if ($customer[$detail_cus->qt_leads_id] == 1) {
                            $dateCus[$detail_cus->qt_leads_id] = date('Y-m-d', strtotime($detail_cus->qt_date));
                            $customerArr[] = $detail_cus->qt_leads_id;
                            $countCus++;
                        }
                    }
				}
				else if($typeQuery == 'customer'){
                    $getDetail_cus = $this->tb_chart->get_detail_customer_by_date_report($start, $end);
                    $countCus=0;
                    $dateCus = array();
//                    print_r($getDetail_cus);
//                    echo 'test'.$detail_cus->bk_leads_id;
                    foreach($getDetail_cus as $detail_cus){
                        $customer[$detail_cus->bk_leads_id]++;
                        
                        if ($customer[$detail_cus->bk_leads_id] == 1) {
                            
                            $dateCus[$detail_cus->bk_leads_id] = date('Y-m-d', strtotime($detail_cus->bk_date_booking));
                            $dobArr[] = $detail_cus->pers_dob;
                            $customerArr[] = $detail_cus->bk_leads_id;
                            $countCus++;
                        }
                    }
				}
                else if($typeQuery == 'quotation'){
                    $getCount_cus = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
                }
                else if($typeQuery == 'booking'){
                    $getCount_cus = $this->tb_chart->get_count_booking_by_date_report($start, $end);
                }
                else if($typeQuery == 'contract'){
                    $getCount_cus = $this->tb_chart->get_count_contract_by_date_report($start, $end);
                }
                else if($typeQuery == 'receipt'){
                    $getCount_cus = $this->tb_chart->get_count_receipt_by_date_report($start, $end);
                }
                else if($typeQuery == 'income'){
                    $getCount_cus = $this->tb_chart->get_total_price_by_date_report($start, $end);
                }
                else if($typeQuery == 'survey'){
                    $getSurvey = $this->tb_survey_answer->get_detail_by_date($start,$end);
                }
                if ($typeQuery=='lead' || $typeQuery=='customer') {
                    if ($countCus!=null) {
                        $count=$countCus;
                    } else {
                        $count=0;
                    }
                } else {
                    if($getCount_cus->count_cus != null) {
                        $count=$getCount_cus->count_cus;
                    } else {
                        $count = 0;
                    }
                }
                
				if($time == '23:00:00')
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime($dateStart)).' - '.date("d/m/Y",strtotime($dateEnd));
                
			}
            if ($typeQuery == 'lead' || $typeQuery == 'customer') {
                $visit = $this->getVisit(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"),$typeQuery);
                $budget = $this->getBudget(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"),$typeQuery);
                $sex = $this->getSex(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), $typeQuery);
                $stage = $this->getStage(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"));
                $district = $this->getTopTenAddress(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), 'district');
                $subDistrict = $this->getTopTenAddress(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), 'subDistrict');
                $province = $this->getTopTenAddress(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), 'province');
                $districtWork = $this->getTopTenAddress(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), 'districtWork');
                $subDistrictWork = $this->getTopTenAddress(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), 'subDistrictWork');
                $provinceWork = $this->getTopTenAddress(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"), 'provinceWork');
                $age = $this->getAge($dobArr);
                $media = $this->getMedia($customerArr,$typeQuery);
            } else if ($typeQuery == 'quotation') {
                $promotion = $this->getTopTenPromotion(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"));
                $unit = $this->getTopTenUnit(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"));
                $employee = $this->getTopFiveQout(date("Y-m-d 00:00:00"), date("Y-m-d 23:59:59"));
            }

            $result['mediaCategories'] = $media['mediaCategories'];
            $result['mediaDatas'] = $media['mediaDatas'];
            $result['xAxisAge'] = $age['xAxisAge'];
            $result['dataAge'] = $age['dataAge'];
            $result['stage'] = $stage;
            $result['sex'] = $sex;
            $result['budget'] = $budget;
            $result['visit'] = $visit;
			$result['format_chart'] = $formatChart;
			$result['count_cus'] = $count_cus;
			$result['xAxis'] = $xAxis;
			$result['date_show'] = $date_show;
			$result['rotation'] = $rotation;
			$result['type'] = $type;
            $result['tableTopPromotion'] = $promotion;
            $result['tableTopUnit'] = $unit;
            $result['districtName'] = $district['districtName'];
            $result['districtCount'] = $district['districtCount'];
            $result['subDistrictName'] = $subDistrict['subDistrictName'];
            $result['subDistrictCount'] = $subDistrict['subDistrictCount'];
//            $result['provinceName'] = $province['provinceName'];
//            $result['provinceCount'] = $province['provinceCount'];
            $result['districtNameWork'] = $districtWork['districtNameWork'];
            $result['districtCountWork'] = $districtWork['districtCountWork'];
            $result['subDistrictNameWork'] = $subDistrictWork['subDistrictNameWork'];
            $result['subDistrictCountWork'] = $subDistrictWork['subDistrictCountWork'];
//            $result['provinceNameWork'] = $provinceWork['provinceNameWork'];
//            $result['provinceCountWork'] = $provinceWork['provinceCountWork'];
            $result['provinceDetails'] = $province['provinceDetails'];
            $result['provinceDetailsWork'] = $provinceWork['provinceDetails'];
            $result['topEmpQout'] = $employee;
            
			return $result;
		}
		else if($type == 'week') {
			$formatChart = 'column';
			$dateStart = date("Y-m-d");

			$timeShow = array(
				date("d/m/Y",strtotime("-6 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-5 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-4 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-3 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-2 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-1 days",strtotime($dateStart))),
				date("d/m/Y",strtotime($dateStart)));

			$timesStart = array(
				date("Y-m-d",strtotime("-6 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-5 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-4 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-3 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-2 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-1 days",strtotime($dateStart))),
				date("Y-m-d",strtotime($dateStart)));

			$i = 0;
            
            $customerArr = array();
            $dobArr = array();
            foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				if($typeQuery == 'lead'){
					$getDetail_cus = $this->tb_chart->get_detail_lead_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $customerArr[] = $detail_cus->qt_leads_id;
                        $countCus++;
                    }
				}
				else if($typeQuery == 'customer'){
					$getDetail_cus = $this->tb_chart->get_detail_customer_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $dobArr[] = $detail_cus->pers_dob;
                        $customerArr[] = $detail_cus->bk_leads_id;
                        $countCus++;
                    }
				}
				else if($typeQuery == 'quotation')
					$getCount_cus = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
				else if($typeQuery == 'booking')
					$getCount_cus = $this->tb_chart->get_count_booking_by_date_report($start, $end);
				else if($typeQuery == 'contract')
					$getCount_cus = $this->tb_chart->get_count_contract_by_date_report($start, $end);
				else if($typeQuery == 'receipt')
					$getCount_cus = $this->tb_chart->get_count_receipt_by_date_report($start, $end);
				else if($typeQuery == 'income'){
					$getCount_cus = $this->tb_chart->get_total_price_by_date_report($start, $end);
				}
					
				if ($typeQuery=='lead' || $typeQuery=='customer') {
                    if ($countCus!=null) {
                        $count=$countCus;
                    } else {
                        $count=0;
                    }
                } else {
                    if($getCount_cus->count_cus != null) {
                        $count=$getCount_cus->count_cus;
                    } else {
                        $count = 0;
                    }
                }
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime("-6 days",strtotime($dateStart))).' - '.date("d/m/Y",strtotime($dateStart));
			}
            if ($typeQuery == 'lead' || $typeQuery == 'customer') {
                $visit = $this->getVisit(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $budget = $this->getBudget(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $sex = $this->getSex(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), $typeQuery);
                $stage = $this->getStage(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $district = $this->getTopTenAddress(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'district');
                $subDistrict = $this->getTopTenAddress(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrict');
                $province = $this->getTopTenAddress(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'province');
                $districtWork = $this->getTopTenAddress(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'districtWork');
                $subDistrictWork = $this->getTopTenAddress(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrictWork');
                $provinceWork = $this->getTopTenAddress(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'provinceWork');
                $age = $this->getAge($dobArr);
                $media = $this->getMedia($customerArr,$typeQuery);
            } else if ($typeQuery == 'quotation') {
                $promotion = $this->getTopTenPromotion(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $unit = $this->getTopTenUnit(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $employee = $this->getTopFiveQout(date("Y-m-d",strtotime("-6 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
            }

            $result['mediaCategories'] = $media['mediaCategories'];
            $result['mediaDatas'] = $media['mediaDatas'];
            $result['xAxisAge'] = $age['xAxisAge'];
            $result['dataAge'] = $age['dataAge'];
            $result['stage'] = $stage;
            $result['sex'] = $sex;
            $result['budget'] = $budget;
            $result['visit'] = $visit;
			$result['format_chart'] = $formatChart;
			$result['count_cus'] = $count_cus;
			$result['xAxis'] = $xAxis;
			$result['date_show'] = $date_show;
			$result['rotation'] = $rotation;
			$result['type'] = $type;
            $result['tableTopPromotion'] = $promotion;
            $result['tableTopUnit'] = $unit;
            $result['districtName'] = $district['districtName'];
            $result['districtCount'] = $district['districtCount'];
            $result['subDistrictName'] = $subDistrict['subDistrictName'];
            $result['subDistrictCount'] = $subDistrict['subDistrictCount'];
//            $result['provinceName'] = $province['provinceName'];
//            $result['provinceCount'] = $province['provinceCount'];
            $result['districtNameWork'] = $districtWork['districtNameWork'];
            $result['districtCountWork'] = $districtWork['districtCountWork'];
            $result['subDistrictNameWork'] = $subDistrictWork['subDistrictNameWork'];
            $result['subDistrictCountWork'] = $subDistrictWork['subDistrictCountWork'];
//            $result['provinceNameWork'] = $provinceWork['provinceNameWork'];
//            $result['provinceCountWork'] = $provinceWork['provinceCountWork'];
            $result['provinceDetails'] = $province['provinceDetails'];
            $result['provinceDetailsWork'] = $provinceWork['provinceDetails'];
            $result['topEmpQout'] = $employee;
			
			return $result;
		}
		else if($type == 'month') {
			$formatChart = 'column';
			$dateStart = date("Y-m-d");
			$rotation = '
                rotation: 270,
            ';

			$timeShow = array();
			$temp = 0;
			for($temp = 0;$temp<30;$temp++)
			{
				$timeShow[$temp] = date("d/m",strtotime("- ".(29-$temp)." days",strtotime($dateStart)));
			}
			
			$timesStart = array();
			$temp = 0;
			for($temp = 0;$temp<30;$temp++)
			{
				$timesStart[$temp] = date("Y-m-d",strtotime("- ".(29-$temp)." days",strtotime($dateStart)));
			}

			$i = 0;
            
            $customerArr = array();
            $dobArr = array();
            foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				if($typeQuery == 'lead'){
					$getDetail_cus = $this->tb_chart->get_detail_lead_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $customerArr[] = $detail_cus->qt_leads_id;
                        $countCus++;
                    }
				}
				else if($typeQuery == 'customer'){
                    $getDetail_cus = $this->tb_chart->get_detail_customer_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $dobArr[] = $detail_cus->pers_dob;
                        $customerArr[] = $detail_cus->bk_leads_id;
                        $countCus++;
                    }
				}
				else if($typeQuery == 'quotation')
					$getCount_cus = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
				else if($typeQuery == 'booking')
					$getCount_cus = $this->tb_chart->get_count_booking_by_date_report($start, $end);
				else if($typeQuery == 'contract')
					$getCount_cus = $this->tb_chart->get_count_contract_by_date_report($start, $end);
				else if($typeQuery == 'receipt')
					$getCount_cus = $this->tb_chart->get_count_receipt_by_date_report($start, $end);
				else if($typeQuery == 'income'){
					$getCount_cus = $this->tb_chart->get_total_price_by_date_report($start, $end);
				}

				if ($typeQuery=='lead' || $typeQuery=='customer') {
                    if ($countCus!=null) {
                        $count=$countCus;
                    } else {
                        $count=0;
                    }
                } else {
                    if($getCount_cus->count_cus != null) {
                        $count=$getCount_cus->count_cus;
                    } else {
                        $count = 0;
                    }
                }
				
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime("-29 days",strtotime($dateStart))).' - '.date("d/m/Y",strtotime($dateStart));

			}
            if ($typeQuery == 'lead' || $typeQuery == 'customer') {
                $visit = $this->getVisit(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $budget = $this->getBudget(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                
                $sex = $this->getSex(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), $typeQuery);
                $stage = $this->getStage(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $district = $this->getTopTenAddress(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'district');
                $subDistrict = $this->getTopTenAddress(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrict');
                $province = $this->getTopTenAddress(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'province');
                $districtWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'districtWork');
                $subDistrictWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrictWork');
                $provinceWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'provinceWork');
                $age = $this->getAge($dobArr);
                $media = $this->getMedia($customerArr,$typeQuery);
            } else if ($typeQuery == 'quotation') {
                $promotion = $this->getTopTenPromotion(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $unit = $this->getTopTenUnit(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $employee = $this->getTopFiveQout(date("Y-m-d",strtotime("- 29 days",strtotime($dateStart))).' 00:00:00' ,date("Y-m-d 23:59:59"));
            }

            $result['mediaCategories'] = $media['mediaCategories'];
            $result['mediaDatas'] = $media['mediaDatas'];
            $result['xAxisAge'] = $age['xAxisAge'];
            $result['dataAge'] = $age['dataAge'];
            $result['stage'] = $stage;
            $result['sex'] = $sex;
            $result['budget'] = $budget;
            $result['visit'] = $visit;
			$result['format_chart'] = $formatChart;
			$result['count_cus'] = $count_cus;
			$result['xAxis'] = $xAxis;
			$result['date_show'] = $date_show;
			$result['rotation'] = $rotation;
			$result['type'] = $type;
            $result['tableTopPromotion'] = $promotion;
            $result['tableTopUnit'] = $unit;
            $result['districtName'] = $district['districtName'];
            $result['districtCount'] = $district['districtCount'];
            $result['subDistrictName'] = $subDistrict['subDistrictName'];
            $result['subDistrictCount'] = $subDistrict['subDistrictCount'];
//            $result['provinceName'] = $province['provinceName'];
//            $result['provinceCount'] = $province['provinceCount'];
            $result['districtNameWork'] = $districtWork['districtNameWork'];
            $result['districtCountWork'] = $districtWork['districtCountWork'];
            $result['subDistrictNameWork'] = $subDistrictWork['subDistrictNameWork'];
            $result['subDistrictCountWork'] = $subDistrictWork['subDistrictCountWork'];
//            $result['provinceNameWork'] = $provinceWork['provinceNameWork'];
//            $result['provinceCountWork'] = $provinceWork['provinceCountWork'];
            $result['provinceDetails'] = $province['provinceDetails'];
            $result['provinceDetailsWork'] = $provinceWork['provinceDetails'];
            $result['topEmpQout'] = $employee;
            
			return $result;
		}
		else if($type == 'custom') {
			$formatChart = 'column';
			$dateStart = date("Y-m-d");
			$rotation = '
                rotation: 270,
            ';
			//echo '<script>alert("'.$this->input->post('end').'")</script>';

			$get_start = $this->input->post('start');
			$get_end = $this->input->post('end');

			$date_dif = ceil((strtotime($get_end) - strtotime($get_start)) / ( 60 * 60 * 24 )) ;
			
			if($date_dif > 30)
			{
				$date_cut = ceil($date_dif/30);
				$formatChart = '';
			}

			$timeShow = array();
			$temp = 0;
			for($temp = 0;$temp <= $date_dif;$temp++)
			{	
				$timeShow[$temp] = date("d/m",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
			}
//echo '<script>alert("'.$timeShow[0].'")</script>';
			$timesStart = array();
			$temp = $date_dif;
			for($temp = 0;$temp <= $date_dif;$temp++)
			{
				$timesStart[$temp] = date("Y-m-d",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
			}
			
			$i = 0;
            
            $customerArr = array();
            $dobArr = array();
            foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$type_text = array('Website','Call in','Walk in','SMS','Online Media', 'Project Poster','Billboard','Booth','Friends','Newspaper','Leaflet','Others');
				if($typeQuery == 'lead'){
					$getDetail_cus = $this->tb_chart->get_detail_lead_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $customerArr[] = $detail_cus->qt_leads_id;
                        $countCus++;
                    }
				}
				else if($typeQuery == 'customer'){
					$getDetail_cus = $this->tb_chart->get_detail_customer_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $customerArr[] = $detail_cus->bk_leads_id;
                        $dobArr[] = $detail_cus->pers_dob;
                        $countCus++;
                    }
				}
				else if($typeQuery == 'quotation')
					$getCount_cus = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
				else if($typeQuery == 'booking')
					$getCount_cus = $this->tb_chart->get_count_booking_by_date_report($start, $end);
				else if($typeQuery == 'contract')
					$getCount_cus = $this->tb_chart->get_count_contract_by_date_report($start, $end);
				else if($typeQuery == 'receipt')
					$getCount_cus = $this->tb_chart->get_count_receipt_by_date_report($start, $end);
				else if($typeQuery == 'income'){
					$getCount_cus = $this->tb_chart->get_total_price_by_date_report($start, $end);
				}

				if ($typeQuery=='lead' || $typeQuery=='customer') {
                    if ($countCus!=null) {
                        $count=$countCus;
                    } else {
                        $count=0;
                    }
                } else {
                    if($getCount_cus->count_cus != null) {
                        $count=$getCount_cus->count_cus;
                    } else {
                        $count = 0;
                    }
                }
                
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($date_dif));
				else
					$date_show = date("d/m/Y",strtotime($timesStart[0])).' - '.date("d/m/Y",strtotime($timesStart[$date_dif]));

			}
            if ($typeQuery == 'lead' || $typeQuery == 'customer') {
                $visit = $this->getVisit(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $budget = $this->getBudget(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $sex = $this->getSex(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), $typeQuery);
                $stage = $this->getStage(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $district = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'district');
                $subDistrict = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrict');
                $province = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'province');
                $districtWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'districtWork');
                $subDistrictWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrictWork');
                $provinceWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'provinceWork');
                $age = $this->getAge($dobArr);
                $media = $this->getMedia($customerArr,$typeQuery);
            } else if ($typeQuery == 'quotation') {
                $promotion = $this->getTopTenPromotion(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $unit = $this->getTopTenUnit(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $employee = $this->getTopFiveQout(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
            }

            $result['mediaCategories'] = $media['mediaCategories'];
            $result['mediaDatas'] = $media['mediaDatas'];
            $result['xAxisAge'] = $age['xAxisAge'];
            $result['dataAge'] = $age['dataAge'];
            $result['stage'] = $stage;
            $result['sex'] = $sex;
            $result['budget'] = $budget;
            $result['visit'] = $visit;
			$result['date_cut'] = $date_cut;
			$result['count_cus'] = $count_cus;
			$result['xAxis'] = $xAxis;
			$result['date_show'] = $date_show;
			$result['rotation'] = $rotation;
			$result['format_chart'] = $formatChart;
			$result['type'] = $type;
            $result['tableTopPromotion'] = $promotion;
            $result['tableTopUnit'] = $unit;
            $result['districtName'] = $district['districtName'];
            $result['districtCount'] = $district['districtCount'];
            $result['subDistrictName'] = $subDistrict['subDistrictName'];
            $result['subDistrictCount'] = $subDistrict['subDistrictCount'];
//            $result['provinceName'] = $province['provinceName'];
//            $result['provinceCount'] = $province['provinceCount'];
            
            
            $result['districtNameWork'] = $districtWork['districtNameWork'];
            $result['districtCountWork'] = $districtWork['districtCountWork'];
            $result['subDistrictNameWork'] = $subDistrictWork['subDistrictNameWork'];
            $result['subDistrictCountWork'] = $subDistrictWork['subDistrictCountWork'];
//            $result['provinceNameWork'] = $provinceWork['provinceNameWork'];
//            $result['provinceCountWork'] = $provinceWork['provinceCountWork'];
            
            $result['provinceDetails'] = $province['provinceDetails'];
            $result['provinceDetailsWork'] = $provinceWork['provinceDetails'];
            $result['topEmpQout'] = $employee;
			
			return $result;
		}
        else if($type == 'total') {
            $this->load->model('tb_chart');
            
            $formatChart = 'column';
			$dateStart = date('Y-m-d');
			$rotation = 'rotation: 270,';
            
            $getMinDate = $this->tb_chart->getMinDate($typeQuery);
            // echo "getMinDate : $getMinDate->min_date";
            // exit();

            $get_start = $getMinDate->min_date;
			$get_end = date('Y-m-d');
            
			$date_dif = ceil((strtotime($get_end) - strtotime($get_start)) / ( 60 * 60 * 24 )) ;
			
			if($date_dif > 30)
			{
				$date_cut = ceil($date_dif/30);
				$formatChart = '';
			}

			$timeShow = array();
			$temp = 0;
			for($temp = 0;$temp <= $date_dif;$temp++)
			{	
				$timeShow[$temp] = date("d/m",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
			}

			$timesStart = array();
			$temp = $date_dif;
			for($temp = 0;$temp <= $date_dif;$temp++)
			{
				$timesStart[$temp] = date("Y-m-d",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
			}
			
			$i = 0;
            
            $customerArr = array();
            $dobArr = array();
            foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';
				
				if($typeQuery == 'lead'){
					$getDetail_cus = $this->tb_chart->get_detail_lead_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $customerArr[] = $detail_cus->qt_leads_id;
                        $countCus++;
                    }
				} else if($typeQuery == 'customer'){
					$getDetail_cus = $this->tb_chart->get_detail_customer_by_date_report($start, $end);
                    $countCus=0;
                    
                    foreach($getDetail_cus as $detail_cus){
                        $customerArr[] = $detail_cus->bk_leads_id;
                        $dobArr[] = $detail_cus->pers_dob;
                        $countCus++;
                    }
				} else if($typeQuery == 'quotation') {
					$getCount_cus = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
				} else if ($typeQuery == 'booking') {
                    $getCount_cus = $this->tb_chart->get_count_booking_by_date_report($start, $end);
                } else if ($typeQuery === 'contract') {
                    $getCount_cus = $this->tb_chart->get_count_contract_by_date_report($start, $end);
                } else if ($typeQuery === 'receipt') {
                    $getCount_cus = $this->tb_chart->get_count_receipt_by_date_report($start, $end);
                }

				if ($typeQuery=='lead' || $typeQuery=='customer') {
                    if ($countCus!=null) {
                        $count=$countCus;
                    } else {
                        $count=0;
                    }
                } else {
                    if($getCount_cus->count_cus != null) {
                        $count=$getCount_cus->count_cus;
                    } else {
                        $count = 0;
                    }
                }
                
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($date_dif));
				else
					$date_show = date("d/m/Y",strtotime($timesStart[0])).' - '.date("d/m/Y",strtotime($timesStart[$date_dif]));

			}
            if ($typeQuery == 'lead' || $typeQuery == 'customer') {
                $visit = $this->getVisit(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $budget = $this->getBudget(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"),$typeQuery);
                $sex = $this->getSex(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), $typeQuery);
                $stage = $this->getStage(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $district = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'district');
                $subDistrict = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrict');
                $province = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'province');
                $districtWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'districtWork');
                $subDistrictWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'subDistrictWork');
                $provinceWork = $this->getTopTenAddress(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"), 'provinceWork');
                $age = $this->getAge($dobArr);
                $media = $this->getMedia($customerArr,$typeQuery);
            } else if ($typeQuery == 'quotation') {
                $promotion = $this->getTopTenPromotion(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $unit = $this->getTopTenUnit(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
                $employee = $this->getTopFiveQout(date("Y-m-d",strtotime("- ".($date_dif)." days",strtotime($get_end))).' 00:00:00' ,date("Y-m-d 23:59:59"));
            }
            // echo("test".$sex);
            // exit();
            $result['mediaCategories'] = $media['mediaCategories'];
            $result['mediaDatas'] = $media['mediaDatas'];
            $result['xAxisAge'] = $age['xAxisAge'];
            $result['dataAge'] = $age['dataAge'];
            $result['stage'] = $stage;
            $result['sex'] = $sex;
            $result['budget'] = $budget;
            $result['visit'] = $visit;
			$result['date_cut'] = $date_cut;
			$result['count_cus'] = $count_cus;
			$result['xAxis'] = $xAxis;
			$result['date_show'] = $date_show;
			$result['rotation'] = $rotation;
			$result['format_chart'] = $formatChart;
			$result['type'] = $type;
            $result['tableTopPromotion'] = $promotion;
            $result['tableTopUnit'] = $unit;
            $result['districtName'] = $district['districtName'];
            $result['districtCount'] = $district['districtCount'];
            $result['subDistrictName'] = $subDistrict['subDistrictName'];
            $result['subDistrictCount'] = $subDistrict['subDistrictCount'];
            $result['districtNameWork'] = $districtWork['districtNameWork'];
            $result['districtCountWork'] = $districtWork['districtCountWork'];
            $result['subDistrictNameWork'] = $subDistrictWork['subDistrictNameWork'];
            $result['subDistrictCountWork'] = $subDistrictWork['subDistrictCountWork'];
            $result['provinceDetails'] = $province['provinceDetails'];
            $result['provinceDetailsWork'] = $provinceWork['provinceDetails'];
            $result['topEmpQout'] = $employee;
			
			return $result;
        }
	}
    function getMedia($id,$typeQuery) {
        $this->load->model('tb_media_type');
        $this->load->model('tb_chart');
        $medias = $this->tb_media_type->fetch_all();
        if($typeQuery == 'customer'){
            $typeQuery = 'cus';
        } else if ($typeQuery == 'lead'){
            $typeQuery = 'leads';
        }
        foreach ($medias as $_medias) {
            $count = 0;
            foreach ($id as $_id) {
                $countMedia = $this->tb_chart->getCountMediaByDate($_id,$typeQuery);
                
                foreach ($countMedia as $_countMedia) {
                    if ($_medias->mt_name == $_countMedia->mt_name) {
                        $count += $_countMedia->count_media;
                    }
                    
                }
            }
            $mediaName .= "'".$_medias->mt_name."',";
            $mediaCount .= $count.",";
        }

        $result['mediaCategories'] = '['.$mediaName.'],';
        $result['mediaDatas'] = $mediaCount;
        return $result;
    }
    function getVisit ($start, $end,$typeQuery) {
        $this->load->model('tb_visit_type');
        $this->load->model('tb_chart');
        $visits = $this->tb_visit_type->fetch_all();
        if($typeQuery == 'customer'){
            $typeQuery = 'cus';
        } else if ($typeQuery == 'lead'){
            $typeQuery = 'leads';
        }
        foreach ($visits as $_visits) {
            $countVisit = $this->tb_chart->getCountVisitByDate($start, $end, $_visits->vt_id,$typeQuery);
            $count = 0;
            foreach ($countVisit as $_countVisit) {
                $count += $_countVisit->visit;
            }
            $visitDetail .= "['".$_visits->vt_name."',".$count."],";
        }
        
        return $visitDetail;
    }
    function getBudget($start, $end,$typeQuery) {
        $this->load->model('tb_budget');
        $this->load->model('tb_chart');
        $budgets = $this->tb_budget->fetch_all();
        if($typeQuery == 'customer'){
            $typeQuery = 'cus';
        } else if ($typeQuery == 'lead'){
            $typeQuery = 'leads';
        }
        foreach ($budgets as $_budgets) {
            $countBudget = $this->tb_chart->getCountBudgetByDate($start, $end, $_budgets->budget_name,$typeQuery);
            $count = 0;
            foreach ($countBudget as $_countBudget) {
                $count += $_countBudget->budget;
            }
            $budgetDetail .= "['".$_budgets->budget_name."',".$count."],";
        }
//        print_r($budgetDetail);exit();
        return $budgetDetail;
    }
    function getSex($start, $end, $type) {
        $sexes = array('Male','Female','Other');
        $this->load->model('tb_chart');
        foreach ($sexes as $_sexes) {
            $countSex = $this->tb_chart->getCountSexByDate($start, $end, $_sexes, $type);
            $count = 0;
            foreach ($countSex as $_countSex) {
                $count += $_countSex->sex;
            }
            $sexDetails .= "['".$_sexes."',".$count."],";
        }
        return $sexDetails;
    }
    function getStage($start, $end) {
        $this->load->model('tb_opportunity_stages');
        $this->load->model('tb_chart');
        $stages = $this->tb_opportunity_stages->fetch_opportunity_stages();
        foreach ($stages as $_stages) {
            $countStage = $this->tb_chart->getCountStageByDate($start, $end, $_stages->op_id);
            $count = 0;
            foreach ($countStage as $_countStage) {
                $count += $_countStage->stages;
            }
            $stageDetails .= "['".$_stages->op_name."',".$count."],";
        }
        
        return $stageDetails;
    }
    function getAge($dob) {
        $durationAge = array(0,0,0,0,0,0);
        foreach ($dob as $_dob) {
            $birthday = date('Y-m-d', strtotime($_dob));
            $today = date("Y-m-d");
            list($byear, $bmonth, $bday)= explode("-",$birthday);
            list($tyear, $tmonth, $tday)= explode("-",$today);
            $mbirthday = mktime(0, 0, 0, $bmonth, $bday, $byear);
            $mnow = mktime(0, 0, 0, $tmonth, $tday, $tyear );
            $mage = ($mnow - $mbirthday);
            $age=date("Y", $mage)-1970;
            
            if ($age>17 && $age<31) {
                $durationAge[0]++;
            } else if ($age>30 && $age<41) {
                $durationAge[1]++;
            } else if ($age>40 && $age<51) {
                $durationAge[2]++;
            } else if ($age>50 && $age<61) {
                $durationAge[3]++;
            } else if ($age>60 && $age<71) {
                $durationAge[4]++;
            } else if ($age>70) {
                $durationAge[5]++;
            }
        }
        $result['xAxisAge'] = "categories: ['18-30','31-40','41-50','51-60','61-70','above 70'],";
        $result['dataAge'] = "data: [".$durationAge[0].", ".$durationAge[1].", ".$durationAge[2].", ".$durationAge[3].", ".$durationAge[4].", ".$durationAge[5]."]";
        
        return $result;
    }
    function getTopTenAddress($start, $end, $type) {
        $this->load->model('tb_chart');
        if ($type == 'district' || $type == 'districtWork') {
            $listDistrict = $this->tb_chart->getTopTenAddressByDate($start, $end, $type);
            foreach ($listDistrict as $_listDistrict) {
                $districtName .= "'".$_listDistrict->district."',";
                $districtCount .= $_listDistrict->count_district.",";
            }
            if ($type === 'district') {
                $result['districtName'] = $districtName;
                $result['districtCount'] = $districtCount;
            } else if ($type === 'districtWork') {
                $result['districtNameWork'] = $districtName;
                $result['districtCountWork'] = $districtCount;
            }
            
            return $result;
        } else if ($type == 'subDistrict' || $type == 'subDistrictWork') {
            $listSubDistrict = $this->tb_chart->getTopTenAddressByDate($start, $end, $type);
            foreach ($listSubDistrict as $_listSubDistrict) {
                $subDistrictName .= "'".$_listSubDistrict->sub_district."',";
                $subDistrictCount .= $_listSubDistrict->count_sub_district.",";
            }
            if ($type === 'subDistrict') {
                $result['subDistrictName'] = $subDistrictName;
                $result['subDistrictCount'] = $subDistrictCount;
            } else if ($type === 'subDistrictWork') {
                $result['subDistrictNameWork'] = $subDistrictName;
                $result['subDistrictCountWork'] = $subDistrictCount;
            }
            
            return $result;
        } else if ($type == 'province' || $type == 'provinceWork') {
            $listProvince = $this->tb_chart->getTopTenAddressByDate($start, $end, $type);
            foreach ($listProvince as $_listProvince) {
                $provinceDetails .= "['".$_listProvince->province."',".$_listProvince->count_province."],";
//                $provinceName .= "'".$_listProvince->province."',";
//                $provinceCount .= $_listProvince->count_province.",";
            }
            if ($type === 'province') {
                $result['provinceDetails'] = $provinceDetails;
//                $result['provinceName'] = $provinceName;
//                $result['provinceCount'] = $provinceCount;
            } else if ($type === 'provinceWork') {
                $result['provinceDetails'] = $provinceDetails;
//                $result['provinceNameWork'] = $provinceName;
//                $result['provinceCountWork'] = $provinceCount;
            }
            
            return $result;
        }
    }
    function getTopFiveQout($start, $end) {
        $this->load->model('tb_chart');
        $listCount = $this->tb_chart->getTopFiveQoutByDate($start, $end);
        foreach ($listCount as $_listCount) {
            $detailForTable .= '<tr><td>'.$_listCount->employee.'</td><td style="text-align:right">'.$_listCount->countQout.'</td></tr>';
        }
        return $detailForTable;
    }
    function getTopTenPromotion($start, $end) {
        $this->load->model('tb_chart');
        $listCount = $this->tb_chart->getTopTenPromotionQuoByDate($start, $end);
        foreach ($listCount as $_listCount) {
            $detailForTable .= '<tr><td>'.$_listCount->pm_name.'</td><td style="text-align:right">'.$_listCount->count_promotion.'</td></tr>';
        }
        return $detailForTable;
    }
    function getTopTenUnit($start, $end) {
        $this->load->model('tb_chart');
        $listCount = $this->tb_chart->getTopTenUnitQuoByDate($start, $end);
        foreach ($listCount as $_listCount) {
            $detailForTable .= '<tr><td>'.$_listCount->unit.'</td><td style="text-align:right">'.$_listCount->count_unit.'</td></tr>';
        }
        return $detailForTable;
    }
    
    public function saleFunnel($typeChart) {
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'SaleFunnel';
        $type = !empty($typeChart)?$typeChart:'today';
        if ($type === 'today') {
            $start = date('Y-m-d 00:00:00');
            $end = date('Y-m-d 23:59:59');
        } else if ($type === 'week') {
            $start = date("Y-m-d",strtotime("-6 days",strtotime(date('Y-m-d')))).' 00:00:00';
            $end = date('Y-m-d 23:59:59');
        } else if ($type === 'month') {
            $start = date("Y-m-d",strtotime("- 29 days",strtotime(date('Y-m-d')))).' 00:00:00';
            $end = date('Y-m-d 23:59:59');
        } else if ($type === 'custom') {
            $start = date("Y-m-d",strtotime($this->input->post('start'))).' 00:00:00';
            $end = date("Y-m-d",strtotime($this->input->post('end'))).' 23:59:59';  
        }

        $this->load->model('tb_chart');
        $countQuotation = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
        $countBooking = $this->tb_chart->get_count_booking_by_date_report($start, $end);
        $conutContract = $this->tb_chart->get_count_contract_by_date_report($start, $end);

        $data['totalQuotation'] = $countQuotation->count_cus;
        $data['totalBooking'] = $countBooking->count_cus;
        $data['totalContract'] = $conutContract->count_cus;
		$this->LoadView('Chart/chart_sales_funnel',$data);
	}
    
	public function proportion($typeChart)
	{
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'proportion';

		$type = !empty($typeChart)?$typeChart:'today';
		$dateStart = '';
		$dateEnd = '';
		$date_show = '';
		$formatChart = 'column';
		

		if($type == 'today')
		{
			$timeShow = array(
				'00:00 - 03:59',
				/*'01:00',
				'02:00',
				'03:00',*/
				'04:00 - 07:59',
				/*'05:00',
				'06:00',
				'07:00',*/
				'08:00 - 11:59',
				/*'09:00',
				'10:00',
				'11:00',*/
				'12:00 - 15:59',
				/*'13:00',
				'14:00',
				'15:00',*/
				'16:00 - 19:59',
				/*'17:00',
				'18:00',
				'19:00',*/
				'20:00 - 23:59',
				/*'21:00',
				'22:00',
				'23:00'*/);

			$timesStart = array(
				'00:00:00',
				/*'01:00:00',
				'02:00:00',
				'03:00:00',*/
				'04:00:00',
				/*'05:00:00',
				'06:00:00',
				'07:00:00',*/
				'08:00:00',
				/*'09:00:00',
				'10:00:00',
				'11:00:00',*/
				'12:00:00',
				/*'13:00:00',
				'14:00:00',
				'15:00:00',*/
				'16:00:00',
				/*'17:00:00',
				'18:00:00',
				'19:00:00',*/
				'20:00:00',
				/*'21:00:00',
				'22:00:00',
				'23:00:00'*/);

			$timesEnd = array(
				/*'00:59:00',
				'01:59:00',
				'02:59:00',*/
				'03:59:00',
				/*'04:59:00',
				'05:59:00',
				'06:59:00',*/
				'07:59:00',
				/*'08:59:00',
				'09:59:00',
				'10:59:00',*/
				'11:59:00',
				/*'12:59:00',
				'13:59:00',
				'14:59:00',*/
				'15:59:00',
				/*'16:59:00',
				'17:59:00',
				'18:59:00',*/
				'19:59:00',
				/*'20:59:00',
				'21:59:00',
				'22:59:00',*/
				'23:59:00');
			$i = 0;
			foreach ($timesStart as $time) {
				$dateStart = date("Y-m-d");
				$dateEnd = date("Y-m-d");
				$timeStart = $time; 
				$timeEnd = $timesEnd[$i];

				$start = $dateStart . ' ' . $timeStart;
				$end = $dateEnd . ' ' . $timeEnd;

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_lead_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == '23:00:00')
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime($dateStart)).' - '.date("d/m/Y",strtotime($dateEnd));

			}

			$i = 0;
			foreach ($timesStart as $time) {
				$dateStart = date("Y-m-d");
				$dateEnd = date("Y-m-d");
				$timeStart = $time; 
				$timeEnd = $timesEnd[$i];

				$start = $dateStart . ' ' . $timeStart;
				$end = $dateEnd . ' ' . $timeEnd;

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_customer_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == '23:00:00')
				{
					$count_cus_2 .= $count;
				}
				else
				{
					$count_cus_2 .= $count.',';
				}
				++$i;
			}

			
		}
		else if($type == 'week')
		{
			$dateStart = date("Y-m-d");

			$timeShow = array(
				date("d/m/Y",strtotime("-6 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-5 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-4 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-3 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-2 days",strtotime($dateStart))),
				date("d/m/Y",strtotime("-1 days",strtotime($dateStart))),
				date("d/m/Y",strtotime($dateStart)));

			$timesStart = array(
				date("Y-m-d",strtotime("-6 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-5 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-4 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-3 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-2 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-1 days",strtotime($dateStart))),
				date("Y-m-d",strtotime($dateStart)));

			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_lead_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime("-6 days",strtotime($dateStart))).' - '.date("d/m/Y",strtotime($dateStart));

			}

			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_customer_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus_2 .= $count; 
				}
				else
				{
					$count_cus_2 .= $count.',';
				}
				++$i;
			}
		}

		else if($type == 'month')
		{
			$dateStart = date("Y-m-d");
			$rotation = '
                rotation: 270,
            ';

			$timeShow = array();
			$temp = 0;
			for($temp = 0;$temp<30;$temp++)
			{
				$timeShow[$temp] = date("d/m",strtotime("- ".(29-$temp)." days",strtotime($dateStart)));
			}
			
			$timesStart = array();
			$temp = 0;
			for($temp = 0;$temp<30;$temp++)
			{
				$timesStart[$temp] = date("Y-m-d",strtotime("- ".(29-$temp)." days",strtotime($dateStart)));
			}

			
			
			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_lead_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime("-29 days",strtotime($dateStart))).' - '.date("d/m/Y",strtotime($dateStart));

			}

			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_customer_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus_2 .= $count;
				}
				else
				{
					$count_cus_2 .= $count.',';
				}
				++$i;
			}

			
		}

		else if($type == 'custom')
		{
			$formatChart = '';
			$dateStart = date("Y-m-d");
			$rotation = '
                rotation: 270,
            ';
			//echo '<script>alert("'.$this->input->post('end').'")</script>';

			$get_start = $this->input->post('start');
			$get_end = $this->input->post('end');

			$date_dif = ceil((strtotime($get_end) - strtotime($get_start)) / ( 60 * 60 * 24 )) ;
			
			if($date_dif > 30)
			{
				$date_cut = ceil($date_dif/30);
			}

			$timeShow = array();
			$temp = 0;
			for($temp = 0;$temp <= $date_dif;$temp++)
			{
				/*if($date_dif <= 30)*/
					$timeShow[$temp] = date("d/m",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
				/*else
				{
					if($temp%$date_cut == 0)
						$timeShow[$temp] = date("d/m",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
					else
						$timeShow[$temp] = '';
				}*/
			}

			$timesStart = array();
			$temp = $date_dif;
			for($temp = 0;$temp <= $date_dif;$temp++)
			{
				$timesStart[$temp] = date("Y-m-d",strtotime("- ".($date_dif-$temp)." days",strtotime($get_end)));
			}
			

			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_lead_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;

				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($date_dif));
				else
					$date_show = date("d/m/Y",strtotime($timesStart[0])).' - '.date("d/m/Y",strtotime($timesStart[$date_dif]));

			}

			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				$getCount_cus = $this->tb_chart->get_count_customer_by_date_report($start, $end);
				$count = $getCount_cus->count_cus;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus_2 .= $count;
				}
				else
				{
					$count_cus_2 .= $count.',';
				}
				++$i;
			}
		}

		$data['format_chart'] = $formatChart;
		$data['date_dif'] = $date_dif;
		$data['date_cut'] = $date_cut;
		$data['date_end'] = $date_end;
		$data['end'] = $end;
		$data['count'] = $count;
		$data['count_cus'] = $count_cus;
		$data['count_cus_2'] = $count_cus_2;
		$data['xAxis'] = $xAxis;
		$data['date_show'] = $date_show;
		$data['test'] = date("Y-m-d",strtotime("-7 days",strtotime($dateStart)));
		$data['rotation'] = $rotation;
		$data['type_name'] = 'Leads';
		$data['type_name_2'] = 'Customers';
		$data['time_index'] = $type;

		$this->LoadView('Chart/chart_proportion',$data);
	}
    
    public function drIncome($typeChart, $getDate)
    {
        $this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'drIncome';
        
        $this->load->library('DateFormat');

		if($getDate == null)
            $beginDate = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
        else
            $beginDate = !empty($getDate)?$getDate:date('Y-m-d');

        $date = !empty($beginDate)?$beginDate:date('Y-m-d');
        $totalDownPay = $this->getTotalDownMonth();
        $details = $this->getDetailsDrIncome ($date);

        $data['beginDate'] = $beginDate;
        $data['typeDr'] = 'sale';
        $data['totalDownPay'] = $totalDownPay;
        $data['details'] = $details;
        
        if($typeChart == "")
            $this->LoadView('Chart/chart_drIncome',$data);
        else
            $this->LoadView('Excel/excel_drIncome',$data);
    }
    
    public function summary($typeChart, $getDate)
    {
        $this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'summary';
        
        $this->load->library('DateFormat');

        $dateStart  = date('Y-m-d',strtotime($this->getMinDateProject ())).' 00:00:00';
        $dateEnd    = date('Y-m-d').' 23:59:59';

        $data['start']              = $dateStart;
        $data['end']                = $dateEnd;
        $data['totalRoom']          = $this->Room('total');
        $data['soldRoom']           = $this->Room('sold');
        $data['tdArea']             = $this->Room('area');
        $data['totalSqm']           = $this->UnitType('total');
        $data['soldSqm']            = $this->UnitType('sold');
        $data['totalBasePrice']     = $this->Price('totalBase');
        $data['totalAskingPrice']   = $this->Price('totalAsking');
        $data['sumPromotion']       = $this->Promotion();
        $data['totalSold']          = $this->Sold();
        $data['booking']            = $this->Booker($dateStart, $dateEnd);
        $data['contract']           = $this->Contracter($dateStart, $dateEnd);
        $data['price']              = $this->Price('totalAsking',$dateStart, $dateEnd);

        if($typeChart == '')
            $this->LoadView('Chart/Report_summary',$data);
        else
            $this->LoadView('Excel/excel_drSale',$data);
    }
      
    public function drOverdue($typeChart, $getDate)
    {
        $this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'drOverdue';
        
        $this->load->library('DateFormat');
        
        if($getDate == null)
            $beginDate = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
        else
            $beginDate = !empty($getDate)?$getDate:date('Y-m-d');
        $date = !empty($beginDate)?$beginDate:date('Y-m-d');
        
        $this->load->model('tb_installment');
        $getConIm = $this->tb_installment->get_contract_overdue_installment($date);
        
        $this->load->model('tb_contract');
        $this->load->model('tb_booking');
        $this->load->model('tb_quotation');
        $this->load->model('tb_building');
        $this->load->model('tb_unit_number');
        
        $this->load->model('tb_customer_personal_info');
        
        $i = 0;
        $temp = 0;
        foreach($getConIm as $_getConIm){
            $getOverIm = $this->tb_installment->get_detail_by_ct_code($_getConIm->im_contract_code, $date);
            
            $j = 0;
            foreach($getOverIm as $_getOverIm){
                $totalOverdue[$i] += 1;
                $numOfIm[$i][$j] = intval($_getOverIm->im_installment_time);
                $amountOfIm[$i][$j] = intval($_getOverIm->im_fee_define);
                $j++;
            }
            
            $getContract = $this->tb_contract->get_detail_by_ct_code($_getConIm->im_contract_code);
            $getBooking = $this->tb_booking->get_detail_by_bk_booking_code($getContract->ct_booking_code);
            $getQuotation = $this->tb_quotation->getDetail_by_id($getBooking->bk_quotation_code);
            $getBuilding = $this->tb_building->get_detail_building_by_building_id($getQuotation->qt_buliding_id);
            $getUnitNumber = $this->tb_unit_number->get_detail_unit_by_un_id($getQuotation->qt_unit_number_id);
            $getCustomerInfo = $this->tb_customer_personal_info->get_detail_by_cus_id_withCustomerTable($_getConIm->im_cus_id);
            
            if($getQuotation->qt_avg_installment != null){   //avg installment
                $installment = $getQuotation->qt_avg_installment;
                $totalOverIm = $installment * $totalOverdue[$i];
            }else{   //balloon
                $installment = '';
                $tempFirstIm = 0;
                $boolBalloon = false;
                $totalOverIm = 0;
                for($tempJ=0;$tempJ<$totalOverdue[$i];$tempJ++){
                    if(intval($amountOfIm[$i][$tempJ+1]) != null){
                        if(intval($amountOfIm[$i][$tempJ]) != intval($amountOfIm[$i][$tempJ+1])){
                            $installment .= 'งวดที่ '.$tempFirstIm.' - '.$tempJ.'<br>';
                            $tempFirstIm = $tempJ;
                            $boolBalloon = true;
                        }
                    }else{
                        if($boolBalloon == true)
                            $installment .= 'งวดที่ '.($tempFirstIm+1).' - '.($tempJ+1).'';
                        else
                            $installment = $amountOfIm[$i][$tempJ];
                    }
                    $totalOverIm += $amountOfIm[$i][$tempJ];
                }
            }
            
            $html .= '
                <tr>
                    <td>'.($i+1).'</td>
                    <td align="left">'.$getCustomerInfo->pers_prefix.' '.$getCustomerInfo->pers_fname.' '.$getCustomerInfo->pers_lname.'</td>
                    <td>'.$getBuilding->building_name.'</td>
                    <td>'.$getUnitNumber->un_name.'</td>
                    <td>'.$totalOverdue[$i].'</td>
                    <td align="right">'.number_format($installment,2).'</td>
                    <td align="right">'.number_format($totalOverIm,2).'</td>
                </tr>
            ';
            
            $sumTotalOver += $totalOverIm;
            $i++;
        }
        
        $html .= '
            <tr>
                <td colspan="6">รวม</td>
                <td align="right">'.number_format($sumTotalOver,2).'</td>
            </tr>
        ';
//        echo '<script>alert("$numOfIm['.$i.']['.$j.'] : '.$numOfIm[1][0].'")</script>';
    
        $data['DateFormat'] = $this->DateFormat;
        $data['beginDate'] = $beginDate;
        $data['html'] = $html;
        $data['typeDr'] = 'overdue';
        
        if($typeChart == null)
            $this->LoadView('Chart/chart_drOverdue',$data);
        else
            $this->LoadView('Excel/excel_drOverdue',$data);
    }
    
    public function charge($typeChart, $exBeginDate, $exEndDate, $exCusID, $exBuildID, $exUnID)
    {
        $this->checkSessionTimeout();
		$data['permission']   = $this->get_user_permission();
		$data['title']        = $this->title_page;
		$data['page']         = $this->page_var;
		$data['index']        = 'charge';
        
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_payment');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_building');
        $this->load->model('tb_payment');
        $this->load->model('tb_chart');
        
        $this->load->library('DateFormat');
		
        if($typeChart == '')
        {
            $beginDate  = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
            $endDate    = !empty($this->input->post('endDate'))?$this->input->post('endDate'):date('Y-m-d');
            $cusID      = !empty($this->input->post('cusID'))?$this->input->post('cusID'):'all';
            list($buildID, $unID)       = explode(",", !empty($this->input->post('unID'))?$this->input->post('unID'):'all,all');
        }
        else
        {
            $beginDate  = $exBeginDate;
            $endDate    = $exEndDate;
            $cusID      = $exCusID;
            $unID       = $exUnID;
            $buildID    = $exBuildID;
        }
        
        
        $start = $beginDate.' 00:00:00';
        $end = $endDate.' 23:59:59';
        
        if($cusID != 'all')
        {
            $sqlCusID = 'AND rc_customer_id = '.$cusID.'';
        }
        else
        {
            $sqlCusID = '';
        }
        
        if($unID != 'all')
        {
            $getUnNumber = $this->tb_unit_number->get_detail_unit_by_un_id_andBuildingID($unID, $buildID);
            if($getUnNumber->un_name != null)
                $sqlUnID = 'AND rc_un_name = '.$getUnNumber->un_name.'';
            else
                echo('<script>alert("error : sqlUnID = null")</script>');
        }
        else
        {
            $sqUnID = '';
        }
        
        $getReceipt = $this->tb_chart->get_detail_for_chart_report($start, $end, $sqlCusID, $sqlUnID);
        $numSeq = 0;
        foreach ($getReceipt as $_getReceipt) {
            $numSeq++;
            if ($_getReceipt->pm_cr_fee != 0) {
                $html .= '
                <tr>
                    <td align="center">'.$numSeq.'</td>
                    <td>'.$_getReceipt->building_name.'</td>
                    <td>'.$_getReceipt->rc_un_name.'</td>
                    <td>'.$_getReceipt->pers_prefix.'</td>
                    <td align="left">'.$_getReceipt->pers_fname.' '.$_getReceipt->pers_lname.'</td>
                    <td>'.number_format(($_getReceipt->pm_amount),2).'</td>
                    <td>'.number_format($_getReceipt->pm_cr_fee,2).'</td>
                    <td>'.number_format(($_getReceipt->pm_amount - $_getReceipt->pm_cr_fee),2).'</td>
                </tr>
                ';
            }     
        }
//        $getReceipt = $this->tb_receipt_offical->get_receipt_for_charge($start, $end, $sqlCusID, $sqlUnID);
//        
////        foreach($getReceipt as $_getReceipt)
////        {
////            $test .= $_getReceipt->rc_code;
////        }
//                
//        $numSeq = 0;
//        foreach($getReceipt as $_getReceipt){
//            $numSeq++;
//            $buildID = $this->tb_unit_number->get_building_id_by_name($_getReceipt->rc_un_name);
//            $buildName = $this->tb_building->get_building_name_by_id($buildID);
//            $getDeCus = $this->tb_customer_personal_info->get_detail_by_id($_getReceipt->rc_customer_id);
//            $getPayment = $this->tb_payment->get_payment_by_receipt_code($_getReceipt->rc_code);
//            foreach($getPayment as $_getPayment)
//            {
//                $charge = !empty($_getPayment->pm_cr_fee)?$_getPayment->pm_cr_fee:'ไม่มีค่าธรรมเนียม';
//            }
//            
//            $html .= '
//            <tr>
//                <td align="center">'.$numSeq.'</td>
//                <td>'.$buildName.'</td>
//                <td>'.$_getReceipt->rc_un_name.'</td>
//                <td>'.$getDeCus->pers_prefix.'</td>
//                <td align="left">'.$getDeCus->pers_fname.' '.$getDeCus->pers_lname.'</td>
//                <td>'.number_format(($_getPayment->pm_amount),2).'</td>
//                <td>'.number_format($charge,2).'</td>
//                <td>'.number_format(($_getPayment->pm_amount - $charge),2).'</td>
//            </tr>
//            ';    
//        }
//        
        $data['html'] = $html;
//        $data['beginDate'] = $test;
//        $data['DateFormat'] = $this->DateFormat;
//        $data['typeDr'] = 'charge';
//        $data['totalDownPay'] = $totalDownPay;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['list_unit_number'] = $this->tb_unit_number->fetch_full_unit_number();
        $data['beginDate'] = $beginDate;
        $data['endDate'] = $endDate;
        $data['exBeginDate'] = $beginDate;
        $data['exEndDate'] = $endDate;
        $data['exBuildID'] = $buildID;
        $data['exCusID'] = $cusID;
        $data['exUnID'] = $unID;
        
        if($typeChart == "")
            $this->LoadView('Chart/chart_charges',$data);
        else
            $this->LoadView('Excel/excel_charges',$data);
    }
    
    public function overdueInstallment($typeChart, $exBeginDate, $exEndDate, $exCusID, $exBuildID, $exFloorID, $exUnID)
	{
		/*echo('<script>alert("'.$result['count_cus'].'")</script>');*/
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'overdueInstallment';

        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_building');
        $this->load->model('tb_floor');
        $this->load->model('tb_unit_type');
        $this->load->model('tb_price');
        $this->load->model('tb_quotation');
        $this->load->model('tb_booking');
        $this->load->model('tb_contract');
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_installment');
        
        
        $this->load->library('DateFormat');
		
        if($typeChart == "")
        {
            $beginDate  = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
            $endDate    = !empty($this->input->post('endDate'))?$this->input->post('endDate'):date('Y-m-d');
            $cusID      = !empty($this->input->post('cusID'))?$this->input->post('cusID'):'all';
            $floorID    = !empty($this->input->post('floorID'))?$this->input->post('floorID'):'all';
            $unID       = !empty($this->input->post('unID'))?$this->input->post('unID'):'all';
            $buildID    = !empty($this->input->post('buildID'))?$this->input->post('buildID'):'all';
        }
        else
        {
            $beginDate  = $exBeginDate;
            $endDate    = $exEndDate;
            $cusID      = $exCusID;
            $floorID    = $exFloorID;
            $unID       = $exUnID;
            $buildID    = $exBuildID;
        }
        
        $start = $beginDate.' 00:00:00';
        $end = $endDate.' 23:59:59';
        
        if($cusID != 'all')
        {
            $sqlCusID = 'AND im_cus_id = '.$cusID.'';
        }
        else
        {
            $sqlCusID = '';
        }
        
        if($floorID != 'all')
        {
            if($unID != 'all')
            {
                $getUnNumber = $this->tb_unit_number->get_detail_unit_by_un_id_andBuildingID($unID, $buildID);
                if($getUnNumber->un_name != null)
                    $sqlUnID = 'AND qt_unit_number_id = '.$getUnNumber->un_name.'';
                else
                    echo('<script>alert("error : sqlUnID = null")</script>');
            }
            else
            {
                $sqlUnID = 'AND qt_floor_id = '.$floorID.'';
//                echo('<script>alert("error : sqlUnID = '.$floorID.'")</script>');
            }
        }
        else
        {
            $sqlUnID = ''; 
        }
        
//        $getImOverdue = $this->tb_chart->get_detail_for_chart_im_overdue ($start, $end, $sqlCusID, $sqlUnID);
        
        $getListContract = $this->tb_installment->get_distinct_contract_code_for_chart_overdue_installment($start, $end, $sqlCusID, $sqlUnID);
        
        $numSeq = 0;
        foreach($getListContract as $_getListContract)
        {
            $numSeq++;
            
            $getInstallment = $this->tb_installment->get_detail_by_in_contract_id($_getListContract->im_contract_code);
            
            foreach($getInstallment as $_getInstallment)
            {
                $getContract = $this->tb_contract->get_detail_by_ct_code($_getInstallment->im_contract_code);
                $getBooking = $this->tb_booking->get_detail_by_bk_booking_code($getContract->ct_booking_code);
                $getQuotation = $this->tb_quotation->getDetail_by_id($getBooking->bk_quotation_code);
                $getFloor = $this->tb_floor->get_detail_by_id($getQuotation->qt_floor_id);
                $getDeCus = $this->tb_customer_personal_info->get_detail_by_id($_getInstallment->im_cus_id);
                $getBuild = $this->tb_building->get_detail_building_by_building_id($getQuotation->qt_buliding_id);
                $getDeUnitNumber = $this->tb_unit_number->get_detail_unit_by_un_id($getQuotation->qt_unit_number_id);
                $getUnitType = $this->tb_unit_type->get_detail_by_unit_type_id($getDeUnitNumber->un_unit_type_id);
                
                
                if(date('Y-m-d',strtotime($_getInstallment->im_duedate)) <= date('Y-m-d',strtotime($endDate)))
                {
                    if($_getInstallment->im_paid == 'no' && date('Y-m-d',strtotime($_getInstallment->im_duedate)) >= date('Y-m-d',strtotime($beginDate)))
                    {
                        $duedate[$numSeq] .= 'งวดที่ '.$_getInstallment->im_installment_time.' : '.date('Y-m-d',strtotime($_getInstallment->im_duedate)).'<br>';
                        $sumDuedate[$numSeq]++;
                        $amountDueInstallment[$numSeq] += $_getInstallment->im_fee_define;
                        $conDuedate[$numSeq-1] = $_getInstallment->im_contract_code;
//                        echo('<script>alert("error : $im_duedate['.$numSeq.'] = '.$_getInstallment->im_duedate.'\n$dueDate['.$numSeq.'] = '.$dueDate[$numSeq].'")</script>');
                    }
                }
                
            }
            
            $totalInstallmentAmount += ($getQuotation->qt_total_down_payment - $getQuotation->qt_booking_fee - $getQuotation->qt_contract_fee);
            $totalDueInstallmentAmount += $amountDueInstallment[$numSeq];
            
            foreach ($conDuedate as $_conDuedate) {
//                print_r($_conDuedate);
                if ($_conDuedate == $_getListContract->im_contract_code) {
                    $html .= '
                    <tr>
                            <td align="center">'.$numSeq.'</td>
                            <td align="center">'.$getFloor->fl_name.'</td>
                            <td>'.$getBuild->building_name.'</td>
                            <td>'.$getDeUnitNumber->un_name.'</td>
                            <td align="left">'.$getDeCus->pers_fname.' '.$getDeCus->pers_lname.'</td>
                            <td align="center">'.$getUnitType->unit_type_area_sqm.'</td>
                            <td align="left">'.number_format($getQuotation->qt_unit_price,2).'</td>
                            <td>'.number_format(($getQuotation->qt_total_down_payment - $getQuotation->qt_booking_fee - $getQuotation->qt_contract_fee),2).'</td>
                            <td>'.$getQuotation->qt_total_months.'</td>
                            <td>'.$duedate[$numSeq].'</td>
                            <td>'.number_format($amountDueInstallment[$numSeq],2).'</td>
                            <td>'.$sumDuedate[$numSeq].'</td>
                        </tr>
                    ';  
                }
            }
              
            
        }
//        
        $data['html'] = $html;
        $data['DateFormat'] = $this->DateFormat;
        $data['typeDr'] = 'overdueInstallment';
        $data['totalDownPay'] = $totalDownPay;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['list_building'] = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
        $data['beginDate'] = $beginDate;
        $data['endDate'] = $endDate;
        $data['exBeginDate'] = $beginDate;
        $data['exEndDate'] = $endDate;
        $data['exBuildID'] = $buildID;
        $data['exCusID'] = $cusID;
        $data['exFloorID'] = $floorID;
        $data['exUnID'] = $unID;
        $data['totalInstallmentAmount'] = $totalInstallmentAmount;
        $data['totalDueInstallmentAmount'] = $totalDueInstallmentAmount;

		if($typeChart == "")
            $this->LoadView('Chart/chart_overdue_installment',$data);
        else
            $this->LoadView('Excel/excel_overdue_installment',$data);
	}
    
    public function cardCustomer($typeChart, $exCusID, $exUnID)
	{
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'cardCustomer';
        $data['type'] = 'summary';
        // $this->load->model('tb_chart');
        // $data['test'] = $this->tb_chart->test10();

		if($typeChart == "")
            $this->LoadView('Chart/chart_card_customer',$data);
        else
            $this->LoadView('Excel/excel_card_customer',$data);
	}

    public function getDetailCardCustomer ($status, $date, $type, $query) {
        if ($type == 'summarycount') {
            $query = null;
        } else {
            $query = $query;
        }

        $this->load->model ('tb_chart');
        if ($type == 'summary' || $type == 'summarycount') {
            $getDetail = $this->tb_chart->get_detail_card_customer_summary ($status, $date, $query);
        } else if ($type == 'individual') {
            
        }
        
        if ($type == 'summarycount') {
            echo count($getDetail);
        } else if ($type == 'summary') {
            foreach ($getDetail as $index => $getDetail) {   
                echo "
                <tr>
                    <td>$getDetail->row</td>
                    <td>$getDetail->unitNumber</td>
                    <td>$getDetail->prefix $getDetail->fname  $getDetail->lname</td>
                    <td>$getDetail->contractCode</td>
                    <td>".number_format($getDetail->contractValue,2)."</td>
                    <td>".number_format($getDetail->allValue,2)."</td>
                    <td>".number_format($getDetail->allPaid,2)."</td>
                    <td>".number_format($getDetail->remain,2)."</td>
                    <td>".number_format($getDetail->pro,2)."</td>
                </tr> 
                ";
            }
        }
    }

    // public function test1 ($test) {
    //     $this->load->model('tb_chart');
    //     $data = $this->tb_chart->test($test);

    //     if(!empty($data)){
    //         foreach($data as $d){
    //             echo '<tr><td>'.$d->rc_id.' '.$d->rc_code.' '.$d->rc_temp_code.' '.$d->rc_payfor.' '.$d->rc_booking_code.' '.$d->rc_contract_code.' '.$d->rc_total_amount.' '.$d->rc_official_date.' '.$d->rc_customer_id.'</td></tr>';
    //         }   
    //     }
    // }

	public function listBooking()
	{
		$this->checkSessionTimeout();
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'listBooking';

        $this->load->model('tb_chart');
        $this->load->model('tb_contract_promotion');
        $this->load->model('tb_customer');
        $this->load->model('tb_media_type');
        
        
        $this->load->library('DateFormat');
		
        if($typeChart == "")
        {
            $beginDate  = !empty($this->input->post('beginDate'))?$this->input->post('beginDate'):date('Y-m-d');
            $endDate    = !empty($this->input->post('endDate'))?$this->input->post('endDate'):date('Y-m-d');
            $cusID      = !empty($this->input->post('cusID'))?$this->input->post('cusID'):'all';
            $floorID    = !empty($this->input->post('floorID'))?$this->input->post('floorID'):'all';
            $unID       = !empty($this->input->post('unID'))?$this->input->post('unID'):'all';
            $buildID    = !empty($this->input->post('buildID'))?$this->input->post('buildID'):'all';
        }
        else
        {
            $beginDate  = $exBeginDate;
            $endDate    = $exEndDate;
            $cusID      = $exCusID;
            $floorID    = $exFloorID;
            $unID       = $exUnID;
            $buildID    = $exBuildID;
        }


        
        $start = $beginDate.' 00:00:00';
        $end = $endDate.' 23:59:59';
        
        $getListBooking = $this->tb_chart->get_list_booking($start,$end);

        foreach ($getListBooking as $_getListBooking){
        	$total_price = $_getListBooking->unit_price;
	        $numSeq++;
	        $getPromotion = $this->tb_contract_promotion->get_promotion_cash_only($_getListBooking->bk_booking_code);
	        foreach ($getPromotion as $_getPromotion) {
	        	$promotion[$numSeq] .= '- '.$_getPromotion->pm_name.'<br>';
	        	$sum_pm_value[$numSeq] += $_getPromotion->pm_value;
	        }

	        $getCustomer = $this->tb_customer->get_detail_by_id($_getListBooking->bk_leads_id);

	        // 
	        $result_price = $_getListBooking->unit_price - $sum_pm_value[$numSeq];

	        $media = split(",",$getCustomer->cus_media_type);

	        foreach ($media as $_media) {

	        	$getMediaType = $this->tb_media_type->get_media_type($_media);
	        	foreach ($getMediaType as $_getMediaType) {
	        		$mediaType[$numSeq] .= '- '.$_getMediaType->mt_name.'<br>';
	        	}

		        
	        	
	        } 

	        $html .= '
	            <tr>
	                <td align="center">'.$numSeq.'</td>
	                <td align="left">'.$_getListBooking->booking_date.'</td>
	                <td align="left">'.$_getListBooking->room.'</td>
	                <td align="left">'.$_getListBooking->cus_name.'</td>
	                <td align="left">'.$_getListBooking->pers_mobile.'</td>
	                <td align="left">'.$_getListBooking->work_position.'</td>
	                <td align="center">-</td>
	                <td align="left">'.$_getListBooking->cus_addr.'</td>
	                <td align="left">'.$_getListBooking->work_addr.'</td>
	                <td align="left">'.$mediaType[$numSeq].'</td>
	                <td align="center">-</td>
	                <td align="center">'.$_getListBooking->room_area.'</td>
	                <td align="right">'.number_format($_getListBooking->unit_price,2).'</td>
	                <td align="right">'.number_format($sum_pm_value[$numSeq],2).'</td>
	                <td align="right">'.number_format($result_price,2).'</td>
	                <td align="left">'.$_getListBooking->staff.'</td>
	                <td align="left">'.$promotion[$numSeq].'</td>
	                <td align="left">'.$_getListBooking->bk_remark.'</td>
	            </tr>
	            '; 

        }
        
        $data['html'] = $html;
        $data['DateFormat'] = $this->DateFormat;
        $data['typeDr'] = 'listBooking';

		if($typeChart == "")
            $this->LoadView('Chart/chart_list_booking',$data);
        else
            $this->LoadView('Excel/excel_list_booking',$data);
	}
    
    public function visit()
    {
        $this->load->model('tb_visit_type');
        $data['visittypes'] = $this->tb_visit_type->fetch_all();
        $data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['index'] = 'visitType';
        
        $this->LoadView('Chart/chart_visit',$data);
    }

    public function summarize()
    {
        $data['permission'] = $this->get_user_permission();
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['index'] = 'summarize';
        
        $this->LoadView('Chart/Summarize/chart_summarize',$data);
    }


	public function stock()
	{
	$this->checkSessionTimeout();
	$data['permission'] = $this->get_user_permission();
	$data['title'] = $this->title_page;
	$data['page'] = $this->page_var;
	$data['index'] = 'stock';

	      $this->load->model('tb_unit_number');
	      
	      $getTotalSizeRoomSold = $this->tb_unit_number->get_total_size_room_sold();
	      $getBalanceRoomSqmPrice = $this->tb_unit_number->get_balance_room_sqm_price($_getTotalSizeRoomSold->room_type_id);
	      $getTotalRoomSold = $this->tb_unit_number->get_total_room_sold();
	      //print_r($getBalanceRoomSqmPrice); exit;
	      
	      $num = 0;
	      foreach ($getBalanceRoomSqmPrice as $_getBalanceRoomSqmPrice) {
	      $Total_room_balance[$num] = $_getBalanceRoomSqmPrice->Total_room;
	      $Total_Size[$num] = $_getBalanceRoomSqmPrice->Total_Size;
	      $price_balance[$num] = $_getBalanceRoomSqmPrice->total_price;
	      $avg_pricr_sqm[$num] = $_getBalanceRoomSqmPrice->avg_pricr_sqm;
	      $num++;
	      }
	      $num = 0;
	      foreach ($getTotalRoomSold as $_getTotalRoomSold) {
	      $Total_room_sold[$num] = $_getTotalRoomSold->Total_room;
	      $num++;
	      }

	      $num = 0;
	     foreach ($getTotalSizeRoomSold as $_getTotalSizeRoomSold) {
	     	$Sold_as_percentage = ($Total_room_sold[$num]/$_getTotalSizeRoomSold->Total_room)*100;
	     	$Balance_as_percentage = ($Total_room_balance[$num]/$_getTotalSizeRoomSold->Total_room)*100;
	         $sumTotal_room += $_getTotalSizeRoomSold->Total_room;
	         $sumTotal_room_sold += $Total_room_sold[$num];
	         $sumTotal_room_balance += $Total_room_balance[$num];
	         $sumTotal_Size += $Total_Size[$num];
	         $sumprice_balance += $price_balance[$num];
	         $sumavg_pricr_sqm += $avg_pricr_sqm[$num];
	$html .= '
	         <tr>
	             <td align="center">'.$_getTotalSizeRoomSold->room_type_name.'</td>
	             <td align="right">'.number_format($_getTotalSizeRoomSold->Total_Size).'</td>
	             <td align="right">'.number_format($_getTotalSizeRoomSold->Total_room).'</td>
	             <td align="right">'.number_format($Total_room_sold[$num]).'</td>
	             <td align="right">'.number_format($Sold_as_percentage,2).'</td>
	             <td align="right">'.number_format($Total_room_balance[$num]).'</td>
	             <td align="right">'.number_format($Balance_as_percentage,2).'</td>
	             <td align="center">'.$_getTotalSizeRoomSold->min.'-'.$_getTotalSizeRoomSold->max.'</td>
	             <td align="right">'.number_format($Total_Size[$num]).'</td>
	             <td align="right">'.number_format($avg_pricr_sqm[$num],2).'</td>
	             <td align="right">'.number_format($price_balance[$num],2).'</td>
	         </tr>
	         '; 
	         $num++;
	      }

	      $Sold_percentage = ($sumTotal_room_sold/$sumTotal_room)*100;
	      $Balance_percentage = ($sumTotal_room_balance/$sumTotal_room)*100;
	     
	      $html .= '
	         <tr>
	         	 <td align="center" colspan=2 style="font-weight: bold;">TOTAL</td>
	         	 <td align="right">'.$sumTotal_room.'</td>
	         	 <td align="right">'.$sumTotal_room_sold.'</td>
	         	 <td align="right">'.number_format($Sold_percentage,2).'</td>
	         	 <td align="right">'.$sumTotal_room_balance.'</td>
	         	 <td align="right">'.number_format($Balance_percentage,2).'</td>
	         	 <td>&nbsp;</td>
	         	 <td align="right">'.number_format($sumTotal_Size).'</td>
	         	 <td align="right">'.number_format($$sumavg_pricr_sqm,2).'</td>
	         	 <td align="right">'.number_format($sumprice_balance,2).'</td>
	         </tr>
	         '; 
	      
	      $data['html'] = $html;
	      $data['DateFormat'] = $this->DateFormat;
	      $data['typeDr'] = 'stock';

	if($typeChart == "")
	          $this->LoadView('Chart/chart_stock',$data);
	      else
	          $this->LoadView('Excel/excel_stock',$data);
	}
    
    public function test () {
        $this->checkSessionTimeout();
        $data['permission'] = $this->get_user_permission();
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['index'] = 'stock';
        $this->LoadView('Chart/chart_test',$data);
    }

    //////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////  JSON  /////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    
    public function jsonvisityear($year)
    {
        $this->load->model('tb_visit_type');
        foreach($this->tb_visit_type->fetch_all() as  $val) {
            for($m=1;$m<13;$m++) {
                $month = strlen($m)<2?'0'.$m:$m;
                $data[$val->vt_name][$m] = $this->tb_visit_type->report($val->vt_id, "AND cus_created_date BETWEEN '$year-$month-01' AND '$year-$month-31'");
            }
        }

        echo json_encode($data);
    }
    
    public function jsonvisitmonth($year,$month)
    {
        $this->load->model('tb_visit_type');
        foreach($this->tb_visit_type->fetch_all() as  $val) {
            for($d=1;$d<32;$d++) {
                $day = strlen($d)<2?'0'.$d:$d;
                $data[$val->vt_name][$d] = $this->tb_visit_type->report($val->vt_id, "AND cus_created_date LIKE '$year-$month-$day%'");
            }
        }

        echo json_encode($data);
    }
    
    // Function for DrSale //
    public function Booker ($start, $end) {
        
        $this->load->model('tb_booking');
        $getBooking = $this->tb_booking->get_booking_by_date($start, $end);
        $sumBook = 0;

        foreach ($getBooking as $_getBooking) {
            $sumBook++;
        }
        
        // echo json_encode($sumBook);
        return $sumBook;
    }
    
    public function VisitType ($type, $start, $end) {
        
        $this->load->model('tb_customer');
        if ($type == 'totalWalk' || $type == 'totalCall') {
            $getTimeCustomer = $this->tb_customer->get_lead_min_date();
            $start = $getTimeCustomer->minDate;
            
        }
       
        $getCustomer = $this->tb_customer->get_lead_by_date($start, $end);
        
        foreach ($getCustomer as $_getCustomer) {
            $this->load->model('tb_visit_type');
            
            $visitType = $this->tb_visit_type->get_name_by_id($_getCustomer->cus_visit_type);
            
            if($visitType == 'Walk in') {
                $sumWalk++;
                
            } else if ($visitType == 'Call in') {
                $sumCall++;
            }
        }
        
        if ($type == 'walk' || $type == 'totalWalk') {
            $num = $sumWalk;
        } else if ($type == 'call' || $type == 'totalCall') {
            $num = $sumCall;
        } 
        
        echo json_encode(!empty($num)?$num:0);
        
//        return (!empty($num)?$num:0);
    }
    
    public function Contracter ($start, $end) {
        $this->load->model('tb_contract');
        $getContract = $this->tb_contract->get_contract_by_date($start, $end);
        $sumContract = 0;
        
        foreach ($getContract as $_getContract) {
            $sumContract++;
        }
        
        // echo json_encode($sumContract);
        return $sumContract;
    }
    
    public function Price ($type, $start, $end) {
        $this->load->model('tb_price');
        
        if ($type == 'totalAsking') {
            if ($start != null && $end != null) {
                $this->load->model('tb_chart');
                $getPrice = $this->tb_chart->get_price_contract_by_date($start, $end);
                foreach ($getPrice as $_getPrice) {
                    $price += floatval(str_replace(',', '', $_getPrice->pr_asking_price));
                }
            } else if ($start == null && $end != null) {
                $this->load->model('tb_contract');
                $getMinDate = $this->tb_contract->get_min_contract_date();
                $start = strtotime($getMinDate->min_ct_date);
                
                $this->load->model('tb_chart');
                $getPrice = $this->tb_chart->get_price_contract_by_date($start, $end);
                
                foreach ($getPrice as $_getPrice) {
                    $price += floatval(str_replace(',', '', $_getPrice->pr_asking_price));
                }
            } else {
                $getPrice = $this->tb_price->fetch_all_fullDetail();
                foreach ($getPrice as $_getPrice) {
                    $price += floatval(str_replace(',', '', $_getPrice->pr_asking_price));
                }
            }
            
        } else if ($type == 'totalBase') {
            $getPrice = $this->tb_price->fetch_all_fullDetail();
            foreach ($getPrice as $_getPrice) {
                $price += floatval(str_replace(',', '', $_getPrice->pr_base_price));
            }
        }    
        
        if ($start != null && $end != null) {
            return $price;
            // echo json_encode(!empty($price)?$price:0);
        } else {
            return $price;
        }
        
    }
    
    function Room ($type, $start, $end) {
        $this->load->model('tb_unit_number');
        
        if ($type == 'total') {
            $getUnitNumber = $this->tb_unit_number->fetch_full_unit_number();
        
            foreach ($getUnitNumber as $_getUnitNumber) {
                $room += 1;
            }
        } else if ($type == 'sold') {
            $getUnitNumber = $this->tb_unit_number->fetch_full_unit_number();
            foreach ($getUnitNumber as $_getUnitNumber) {
                if ($_getUnitNumber->un_status_room == 'Sold') {
                    $room += 1;
                }
            }
        } else if ($type == 'area') {
            $this->load->model('tb_unit_type');
            $getArea = $this->tb_unit_type->get_sqm_distinct();
            $num = 0;
            foreach ($getArea as $_getArea) {
                $html .=    '  
                            <tr id="trArea'.$num.'" style="display: none;">
                                <td align="left"><span style="padding-left:20px" id="tdSqm'.$num.'">'.$_getArea->unit_type_area_sqm.' ตร.ม.</span></td>
                                <td class="right"><font size="4px" color="black"><span id="area'.$num.'"></span>&nbsp;( <span id="percentArea'.$num.'"></span> % )</font></td>
                            </tr>
                            ';   
                $num++;
            }
            
        } else if ($type == 'soldSqmDate') {
            $this->load->model('tb_unit_type');
            $getArea = $this->tb_unit_type->get_sqm_distinct();
            $this->load->model('tb_chart');
            $getUnitNumber = $this->tb_chart->get_sqm_contract_by_date($start, $end);
            $num = 0;

            foreach ($getArea as $_getArea) {
                foreach ($getUnitNumber as $_getUnitNumber) {
                    if ($_getArea->unit_type_area_sqm == $_getUnitNumber->unit_type_area_sqm) {
                        $sumArea[$num]++;
                    }
                    $sumArea[$num] = (!empty($sumArea[$num])?$sumArea[$num]:0);

                }
                $num++;
            }
        } else if ($type == 'avail') {
            $this->load->model('tb_chart');
            $getUnitNumber = $this->tb_chart->get_sqm_contract_by_date($start, $end);

            foreach ($getUnitNumber as $_getUnitNumber) {
                $room++;
            }
        } else if ($type == 'soldDate') {
            $this->load->model('tb_chart');
            $getUnitNumber = $this->tb_chart->get_sqm_contract_by_date($start, $end);

            foreach ($getUnitNumber as $_getUnitNumber) {
                $room++;
            }
        }
        
        if ($type == 'area') {
            return $html;
        } else if ($type == 'sold' || $type == 'total') {
            return $room;
        } else if ($type == 'soldSqmDate') {
            // echo json_encode($sumArea);
            echo json_encode($sumArea);
        } else if ($type == 'soldDate') {
            echo json_encode(!empty($room)?$room:0);
        }
    }
    
    function UnitType ($type) {
        $this->load->model('tb_unit_number');
        $this->load->model('tb_unit_type');
        
        if ($type == 'total') {
            $getUnitNumber = $this->tb_unit_number->fetch_full_unit_number();
            foreach ($getUnitNumber as $_getUnitNumber) {
                $getUnitType = $this->tb_unit_type->fetch_all_with_TbRoomType();
                foreach ($getUnitType as $_getUnitType) {
                    $area += $_getUnitType->unit_type_area_sqm;
                }
            }
        } else if ($type == 'sold') {
            $getUnitNumber = $this->tb_unit_number->fetch_full_unit_number();
            foreach ($getUnitNumber as $_getUnitNumber) {
                if ($_getUnitNumber->un_status_room == 'Sold') {
                    $getUnitType = $this->tb_unit_type->get_detail_by_unit_type_id($_getUnitNumber->un_unit_type_id);
                    $area += $getUnitType->unit_type_area_sqm;
                }
            }
        }
                
        return $area;
    }
    
    function Promotion () {
        $this->load->model('tb_chart');
        $getValue = $this->tb_chart->get_value_contract_promotion();
        foreach ($getValue as $_getValue) {
            $sumValue += $_getValue->pm_value;
        }
        return $sumValue;
    }
    
    function Sold () {
        $this->load->model('tb_contract');
        $getMindate = $this->tb_contract->get_min_contract_date();
        
        $this->load->model('tb_chart');
        $getValue = $this->tb_chart->get_price_contract_by_date($getMindate->min_ct_date, date('Y-m-d'));
        
        foreach ($getValue as $_getValue) {
            $sumValue +=  floatval(str_replace(',', '', $_getValue->pr_asking_price));
        }
        
        return $sumValue;
    }
    // Function for DrSale //
    
    // Funtion for chart lead
    function AllCusByDate($start, $end, $type) {
        $typeQuery = 'AllCus';
        
        if($type == 'today') {
            $data = $this->Today($start, $end, $typeQuery);
        } else if($type == 'yesterday') {
            $data = $this->Today($start, $end, $typeQuery);
        } else if($type == '7days') {
            $data = $this->CustomDate($start, $end, $typeQuery);
        } else if($type == '30days') {
            $data = $this->CustomDate($start, $end, $typeQuery);
        } else if($type == 'thisMonth') {
            $data = $this->CustomDate($start, $end, $typeQuery);
        } else if($type == 'lastMonth') {
            $data = $this->CustomDate($start, $end, $typeQuery);
        } else if($type == 'custom') {
            $data = $this->CustomDate($start, $end, $typeQuery);
        } else {
            echo '<script>alert("error : Do not type")</script>';
        }
        
        echo json_encode($data);
    }
    
    function Today($start, $end, $type) {
        
        $timeShow = array(
            '00:00 - 00:59',
            '01:00 - 01:59',
            '02:00 - 02:59',
            '03:00 - 03:59',
            '04:00 - 04:59',
            '05:00 - 05:59',
            '06:00 - 06:59',
            '07:00 - 07:59',
            '08:00 - 08:59',
            '09:00 - 09:59',
            '10:00 - 10:59',
            '11:00 - 11:59',
            '12:00 - 12:59',
            '13:00 - 13:59',
            '14:00 - 14:59',
            '15:00 - 15:59',
            '16:00 - 16:59',
            '17:00 - 17:59',
            '18:00 - 18:59',
            '19:00 - 19:59',
            '20:00 - 20:59',
            '21:00 - 21:59',
            '22:00 - 22:59',
            '23:00 - 23:59');

        $timesStart = array(
            '00:00:00',
            '01:00:00',
            '02:00:00',
            '03:00:00',
            '04:00:00',
            '05:00:00',
            '06:00:00',
            '07:00:00',
            '08:00:00',
            '09:00:00',
            '10:00:00',
            '11:00:00',
            '12:00:00',
            '13:00:00',
            '14:00:00',
            '15:00:00',
            '16:00:00',
            '17:00:00',
            '18:00:00',
            '19:00:00',
            '20:00:00',
            '21:00:00',
            '22:00:00',
            '23:00:00');

        $timesEnd = array(
            '00:59:00',
            '01:59:00',
            '02:59:00',
            '03:59:00',
            '04:59:00',
            '05:59:00',
            '06:59:00',
            '07:59:00',
            '08:59:00',
            '09:59:00',
            '10:59:00',
            '11:59:00',
            '12:59:00',
            '13:59:00',
            '14:59:00',
            '15:59:00',
            '16:59:00',
            '17:59:00',
            '18:59:00',
            '19:59:00',
            '20:59:00',
            '21:59:00',
            '22:59:00',
            '23:59:00');
        
        $media = $this->DetailMedia();
        $num = 0; 
        foreach($timeShow as $_timeShow) {
            $startDate = $start.' '.$timesStart[$num];
            $endDate = $end.' '.$timesEnd[$num];

            if($type == 'AllCus'){
                $countCus[$num] = $this->DetailCustomer($startDate, $endDate ,'count');
                $detailCus = $this->DetailCustomer($startDate, $endDate ,'detail');
                $dataDrill = $this->DataDrill($media, $detailCus);
            }

            if($num == 0) {
                $res =  '
                        {
                        name: "'.$_timeShow.'",
                        y: '.$countCus[$num].',
                        drilldown: "'.$_timeShow.'"
                        }
                        ';
  
                $drill =    '
                            {
                                name: "'.$_timeShow.'",
                                id: "'.$_timeShow.'",
                                data: [
                                    '.$dataDrill.'
                                ]
                            }
                            ';
            } else {
                $res .=  '
                        ,{
                        name: "'.$_timeShow.'",
                        y: '.$countCus[$num].',
                        drilldown: "'.$_timeShow.'"
                        }
                        ';
                $drill .=    '
                            , {
                                name: "'.$_timeShow.'",
                                id: "'.$_timeShow.'",
                                data: [
                                    '.$dataDrill.'
                                ]
                            }
                            ';
            } 
            $num++;
        }
        
        $tesco['data'] = $res;
        $tesco['drill'] = '['.$drill.']';

        return $tesco;
    }
    
    function CustomDate($start, $end, $type) {
        
        $dateDif = ceil((strtotime($end) - strtotime($start)) / ( 60 * 60 * 24 )) ;
        
//        if($dateDif > 30)
//        {
//            $dateCut = ceil($dateDif/30);
//            $formatChart = '';
//        }
        
        $num = $dateDif;
        for($num=0; $num<=$dateDif; $num++)
        {
            $timeShow[$num] = date("d/m",strtotime("- ".($dateDif-$num)." days",strtotime($end)));
            $timesStart[$num] = date("Y-m-d",strtotime("- ".($dateDif-$num)." days",strtotime($end)));
        }
        
        $media = $this->DetailMedia();
        $num = 0;
        foreach ($timeShow as $_timeShow) {
            if($type == 'AllCus'){
                $countCus[$num] = $this->DetailCustomer($timesStart[$num].' 00:00:00', $timesStart[$num].' 23:59:59' ,'count');
                $detailCus = $this->DetailCustomer($timesStart[$num].' 00:00:00', $timesStart[$num].' 23:59:59' ,'detail');
                $dataDrill = $this->DataDrill($media, $detailCus);
            }

            if($num == 0) {
                $res =  '
                        {
                            name: "'.$_timeShow.'",
                            y: '.$countCus[$num].',
                            drilldown: "'.$_timeShow.'"
                        }
                        ';
                $drill =    '
                            {
                                name: "'.$_timeShow.'",
                                id: "'.$_timeShow.'",
                                data: [
                                    '.$dataDrill.'
                                ]
                            }
                            ';
            } else {
                $res .=  '
                        ,{
                            name: "'.$_timeShow.'",
                            y: '.$countCus[$num].',
                            drilldown: "'.$_timeShow.'"
                        }
                        ';
                $drill .=    '
                            , {
                                name: "'.$_timeShow.'",
                                id: "'.$_timeShow.'",
                                data: [
                                    '.$dataDrill.'
                                ]
                            }
                            ';
            } 
            $num++;
        }
         
        $tesco['data'] = $res;
        $tesco['drill'] = '['.$drill.']';

        return $tesco;
    }
    
    function DetailCustomer($start, $end, $type) {
        $this->load->model('tb_chart');
        $num = 0;
        $getDetail = $this->tb_chart->get_detail_lead_by_date_report($start, $end);
        
        if($type == 'count') {
            foreach($getDetail as $_getDetail) {
                $num++;
            }
            return $num;
        } else if($type == 'detail') {
            return $getDetail;
        }
    }
    
    function DetailMedia() {
        $this->load->model('tb_media_type');
        $getDetail = $this->tb_media_type->fetch_all();
        return $getDetail;
    }
    
    function DataDrill($media, $detailCus) {
        
        foreach($media as $id=>$_media) {   
            $sumMedia = 0;
            foreach($detailCus as $_detailCus) {
                $id = split(',',$_detailCus->cus_media_type);
                foreach($id as $_id) {
                    if($_media->mt_id == $_id) {
                        $sumMedia++;
                    }
                }
                $num[$id] = $_detailCus->cus_media_type;
            }
            
            $data .=    '
                        [
                            "'.$_media->mt_name.'",
                            '.$sumMedia.'
                        ],
                        '; 
        }
        
        return $data;
    }

    /* second function */
    private function getMinDateProject () {
        $this->load->model('tb_quotation');
        $date = $this->tb_quotation->get_min_date();
        return $date->minDate;
    }

    private function getTotalDownMonth () {
        $this->load->model ('tb_project');
        $project = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($this->project_id_sel);

        $getTotalmonth_temp = $this->tb_project->get_detail_project_selected($Project);

        $endYear = date('Y', strtotime($project->pj_end_downpayment ));
        $startYear = date('Y', strtotime($project->pj_start_downpayment ));
        
        $endMonth = date('m', strtotime($project->pj_end_downpayment ));
        $startMonth = date('m', strtotime($project->pj_start_downpayment ));
        
        $totalmonth = (($endYear - $startYear) * 12) + ($endMonth - $startMonth) +1;

        return $totalmonth;
    }

    function getDetailsDrIncome ($date) {
        $this->load->model ('tb_chart');
        $customer = $this->tb_chart->get_customer_id_drIncome ($date);
        $num=0;
        
        foreach ($customer as $_customer) {
            $num++;
            $installmentTime = array();
            $details = $this->tb_chart->get_details_drIncome ($_customer->cusID, $date);
            $totalDownMonth = $this->getTotalDownMonth ();
            foreach ($details as $_details) {
                if ($_details->rc_payfor == 'Booking Fee') {
                    $bookingPaid[$num] = $_details->rc_total_amount;
                } else if ($_details->rc_payfor == 'Contract Fee') {
                    $contractPaid[$num] = $_details->rc_total_amount;
                } else if ($_details->rc_payfor == 'Installment Fee') {
                    array_push($installmentTime,intval($_details->rc_installment_time));
                    for ($temp=0;$temp<$totalDownMonth;$temp++) {
                        $installmentAmount[$num][$temp] = $_details->rc_total_amount;
                    }
                }
                $unitNumber[$num] = $_details->rc_un_name;
            }
            $payment = $this->tb_chart->get_payment_drIncome ($_customer->cusID, $unitNumber[$num]);
            foreach ($payment as $_payment) {
                $totalPayment[$num] +=  $_payment->rc_total_amount;
            }
            
            for ($temp=0;$temp<$totalDownMonth;$temp++) {
                if (in_array(($temp+1), $installmentTime)) {
                    $installmentPaid[$num] .= '<td>'.number_format($installmentAmount[$num][$temp],2).'</td>';
                } else {
                    $installmentPaid[$num] .= "<td>-</td>";
                }
            }

            $html .= "
            <tr>
                <td>$num</td>
                <td>$_details->building_name$_details->rc_un_name</td>
                <td>$_details->pers_prefix $_details->pers_fname $_details->pers_lname</td>
                <td>".(empty($bookingPaid[$num])?'-':number_format($bookingPaid[$num],2))."</td>
                <td>".(empty($contractPaid[$num])?'-':number_format($contractPaid[$num],2))."</td>
                <td>".number_format($_details->qt_unit_price,2)."</td>
                <td>$_details->qt_total_months</td>
                $installmentPaid[$num]
                <td>".number_format($totalPayment[$num],2)."</td>
                <td>".number_format($_details->qt_total_down_payment,2)."</td>
                <td>".number_format($_details->qt_total_down_payment - $totalPayment[$num],2)."</td>
            </tr>
            ";
        }
        return $html;
    }
}

	

/* End of file chart.php */
/* Location: ./application/controllers/chart.php */

?>