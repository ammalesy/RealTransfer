<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_building extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Building';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$this->load->model('tb_building');
		$data['list_building'] = $this->tb_building->fetch_all_building_DESC_Name();
		$this->LoadView('Project_detail/Project_building/project_building_view',$data);
	}
	public function editing($bid)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$this->load->model('tb_building');
		$data['building'] = $this->tb_building->get_detail_building_by_building_id($bid);
		$this->LoadView('Project_detail/Project_building/project_building_editing',$data);
	}
	public function update($bid)
	{
		$this->load->model('tb_building');
		$this->load->model('log_building');
		$Name = $this->input->post('Name');
		$Info = $this->input->post('Info');
		$userEdit = $this->user_id;

		$Imagename = $_FILES["Image"]["name"] ;
		$Imagetype = $_FILES["Image"]["type"] ;
		$FileData = file_get_contents($_FILES['Image']['tmp_name'],TRUE);

		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		/*============================*/
		/*====== SELECTED IMAGE ======*/
		/*============================*/
		if(!$this->isEmptyFile('Image'))
		{
			

			$result_upload = $this->upload_image('Image',"project/".$this->project_id_sel."/building/".$bid,time());
			if($result_upload['error_status'] == FALSE){
				$data_update = array(
					'building_name' => $Name,
					'building_info' => $Info,
					'building_image' => $result_upload['image_url']
				);
				$this->tb_building->update($data_update,$bid);
				
				$buildingObj = $this->tb_building->get_detail_building_by_building_id($bid);
				$data_log = array(
						'building_id' => $buildingObj->building_id,
						'building_name' => $buildingObj->building_name,
						'building_info' => $buildingObj->building_info,
						'building_sts_active' => $buildingObj->building_sts_active,
						'building_update_by' => $this->user_id,
						'building_image' => $result_upload['image_url']
				);
				$this->log_building->record($data_log);
			}
		/*============================*/
		/*==== DON'T SELECT IMAGE ====*/
		/*============================*/
		}else{
			$data_update = array(
				'building_name' => $Name,
				'building_info' => $Info
			);
			$this->tb_building->update($data_update,$bid);

			$buildingObj = $this->tb_building->get_detail_building_by_building_id($bid);
			$data_log = array(
				'building_id' => $buildingObj->building_id,
				'building_name' => $buildingObj->building_name,
				'building_info' => $buildingObj->building_info,
				'building_sts_active' => $buildingObj->building_sts_active,
				'building_update_by' => $this->user_id
			);
			$this->log_building->record($data_log);
				
		}
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Edit Building Fail','/project_building/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Edit Building Success','/project_building/view');
		}

		
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$this->LoadView('Project_detail/Project_building/project_building_adding',$data);
	}
	public function record(){
		$this->load->model('tb_building');
		$Name = $this->input->post('Name');
		$Info = $this->input->post('Info');
		
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		foreach($Name as $index => $position ){
			$name_add = $Name[$index] ;
			$info_add = $Info[$index] ;

			$data = array(
					'building_id' => '0',
					'building_name' => $name_add,
					'building_info' => $info_add
			);
			$new_id = $this->tb_building->record($data);
			$path_upload = "project/".$this->project_id_sel."/building/".$new_id;
			$name_file = time();
			$result_upload = $this->upload_multiple_image('Image',$index,$path_upload,$name_file);	
			if($result_upload['error_status'] == FALSE){
				$data_update = array('building_image' => $result_upload['image_url']);
				$this->tb_building->update($data_update,$new_id);

			}
		}
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Add Building Fail','/project_building/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Add Building Success','/project_building/view');
		}
		
	}
	public function deleting($uid){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'building_sts_active' => 'off'
		);
		$this->load->model('tb_building');
		$this->tb_building->update($data_delete,$uid);
		
		alert_redirect('Delete Building Success','/project_building/view');
	}
}

/* End of file project_building.php */
/* Location: ./application/controllers/project_building.php */