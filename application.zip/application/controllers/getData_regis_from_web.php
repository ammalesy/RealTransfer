<?php 

class GetData_regis_from_web extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
//        $this->view();
    }

    public function view()
    {
        $this->load->view('Send/send');
    }
    
    public function regis()
    {
        $firstname = $this->input->post("firstname");
        $lastname = $this->input->post("lastname");
        $mobile  = $this->input->post("mobile");
        $mail  = $this->input->post("mail");
        $interest = $this->input->post("interest");
        $budget  = $this->input->post("budget");
        $salary = $this->input->post("salary");
        $remark  = $this->input->post("remark");
        $media  = $this->input->post("media");
        $visitType  = $this->input->post("visitType");
        $stages  = $this->input->post("stages");
        $url_ref = $this->input->post("url_ref");
        $pj_id = $this->input->post("pj_id");
        
//        $url_ref = $_SERVER["PHP_SELF"];
//        $url_ref = $_SERVER['HTTP_HOST']."?".$_SERVER['SCRIPT_NAME']."?".$_SERVER["PHP_SELF"];
//        $url_ref = $_SERVER['SCRIPT_NAME'];
        
//        echo "firstname : ".$firstname;
//        echo "+++lastname : ".$lastname;
//        echo "+++mobile : ".$mobile;
//        echo "+++mail : ".$mail;
//        echo "+++interest : ".$interest;
//        echo "+++salary : ".$salary;
//        echo "+++remark : ".$remark;
//        echo "+++media : ".$media;
//        echo "+++visitType : ".$visitType;
//        echo "+++bugged : ".$budget;
//        echo "+++stages : ".$stages;
//        echo "+++pj_id : ".$pj_id;
//        echo "+++url_ref : ".$url_ref;
        //exit();
        //echo "<script> alert ('save success');</script>";
//        $this->load->view('Send/send');
        
        
        header( 'Location: /crm/regis_from_web/record?firstname='.$firstname.'&lastname='.$lastname.'&mobile='.$mobile.'&mail='.$mail.'&interest='.$interest.'&salary='.$salary.'&remark='.$remark.'&mediaType='.$media.'&visitType='.$visitType.'&Budget='.$budget.'&stages='.$stages.'&pj_id='.$pj_id.'&url_ref='.$url_ref.'&form=webregis') ;
//        header( 'Location: /demo/regis_from_web/record?firstname='.$firstname.'&lastname='.$lastname.'&mobile='.$mobile.'&mail='.$mail.'&interest='.$interest.'&salary='.$salary.'&remark='.$remark.'&mediaType='.$media.'&visitType='.$visitType.'&Budget='.$budget.'&stages='.$stages.'&pj_id='.$pj_id.'&url_ref='.$url_ref.'&form=webregis') ;
    }
}

?>
