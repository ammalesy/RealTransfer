<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_price extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Price';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_price');
		$data['list_price'] = $this->tb_price->fetch_all_fullDetail();
		$this->LoadView('Project_detail/Project_price/project_price_view',$data);
	}
	public function confirm_adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		
		
		$this->load->model('tb_building');
		$data['building'] = $this->input->post('Building');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$this->LoadView('Project_detail/Project_price/project_price_confirm_adding',$data);

	}
	public function import_adding(){
		$this->checkSessionTimeout();
		$this->load->model('tb_building');
		/////////////////////////////
		/////////////////////////////
		$data['title'] = "Comfirm Unit Price Befor update";
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$building = $this->input->post('Building');

		$ext[0] =  pathinfo($_FILES['projectFile']['name'], PATHINFO_EXTENSION);
		if (in_array('csv',$ext))
      	{
      		$getbuilding = $this->tb_building->get_detail_building_by_building_id($building);
     		$data['buildingname'] = $getbuilding->building_name;

     		$csv_mimetypes = array(
		    'text/csv',
		    'text/plain',
		    'application/csv',
		    'text/comma-separated-values',
		    'application/excel',
		    'application/vnd.ms-excel',
		    'application/vnd.msexcel',
		    'text/anytext',
		    'application/octet-stream',
		    'application/txt',
            );
           	if (!in_array($_FILES['projectFile']['type'], $csv_mimetypes)) {
           		alert_redirect("Format File Invalid .pls convert your file be csv file",'/project_price/confirm_update');
           	} 
           	$tmpdate = date("Y_m_d_H_i_s");
		    $Str_file = explode(".",$_FILES['projectFile']['name']);  
		    $new_name="price_".$tmpdate.".".$Str_file['1'];
		    if(move_uploaded_file($_FILES["projectFile"]["tmp_name"],"csv/".$new_name)) 
		     {		
		        $objCSV = fopen("csv/".$new_name, "r");		        
                $count = 0;$ok = "";
		        while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) 
                {
                    if ( $count > 2 )
                    {
                        $b =  array(
                        $objArr[1],  
                        $objArr[4],  
                        $objArr[5],  
                        $objArr[6],  
                        $objArr[7],  
                        $objArr[8],  
                        $objArr[9],  
                        $objArr[10],  
                        $objArr[11],  
                        $objArr[12],  
                        $objArr[13],  
                        $objArr[14],  
                        $objArr[15],  
                        $objArr[16],  
                        $objArr[17],  
                        $objArr[18],  
                        $objArr[19],  
                        $objArr[20],  
                        $objArr[21]); 
                        $sessionData = array('unt' => $b);
						$this->session->set_userdata($sessionData);

                    	$this->load->model('tb_price');
                    	$unname = $this->tb_price->get_detail_withUnitNumberTable_by_un_name($objArr[1]);  
                    
                    	$cked  = !empty($unname->pr_unit_number_id)?"can't":"";
                    	$color = !empty($unname->pr_unit_number_id)?"style='color:black'":"style='color:red'";
                   
                    
	                    if ( $ok=="" )
	                    {
	                       if ( trim($cked) == "can't" ) 
	                       {
	                          $btlabel = " Back";   
	                          $cancel   = "style='visibility: hidden";   
	                          $ok = "no";
	                       }
	                       else
	                       {
	                           $btlabel = " Cancel";   
	                           $cancel   = "style='visibility:visible'";   
	                       }
	                    }
	                    else {
	                          $btlabel = " Back";   
	                          $cancel   = "style='visibility: hidden'";   
	                    }
	                    $cRed = !empty($cked)?"style=color:red":"";
	                    $html_tr .= "<tr".$cRed.">";
           				$html_tr .= "<td>".($count-2)."</td>";
            			$html_tr .= "<td align=center>";
  
                		if ( empty($cked) )
                		{
   
                			$html_tr .= "<input type='checkbox' class='checkbox' value='".$objArr[1].$cked."' checked name='ckupdate[]'>";

                 		}
                 		else 
                 		{
                     		$html_tr .= "<span style='font-size:8pt'>Exist</span>";
                 		}

			            $html_tr .= "</td>
			            <td>".$objArr[1]."</td>
			            <td>".$objArr[4]."</td>
			            <td>".$objArr[5]."</td>
			            <td>".$objArr[6]."</td>            
			            <td>".$objArr[19]."</td>
			            <td>".$objArr[20]."</td>
			            <td>".$objArr[21]."</td>            
			            <td>".$objArr[7]."</td>
			            <td>".$objArr[8]."</td>
			            <td>".$objArr[9]."</td>
			            <td>".$objArr[10]."</td>                        
			            <td>".$objArr[11]."</td>
			            <td>".$objArr[12]."</td>
			            <td>".$objArr[13]."</td>            
			            <td>".$objArr[14]."</td>
			            <td>".$objArr[15]."</td>            
			            <td>".$objArr[16]."</td>
			            <td>".$objArr[17]."</td>
			            <td>".$objArr[18]."</td></tr>";

                    }//end if $count > 2
                    ++$count;
                }// end while
                fclose($objCSV);
            } // end if move up load
            $data['table_price_row'] = $html_tr;
            $data['building'] = $building;
            $data['btlabel'] = $btlabel;
            $data['cancel'] = $cancel;
            $data['ok'] = $ok;

			$this->LoadView('Project_detail/Project_price/project_price_confirm_adding_import',$data);
      	}
      	else
      	{
      		$err_file = $_FILES['projectFile']['name'];
      		alert_redirect("You try to update price from file".$err_file."File format is invalid. Please select only csv file.",'/project_price/confirm_adding');
      	}
     	
	}
	public function price_add_process(){
		$this->load->model('tb_unit_number');
		$this->load->model('tb_room_status');
		$this->load->model('tb_price');
		$staffid = $this->user_id;
		$Building = $this->input->post('bld');

		$ch = array();
		$ckupdate = $this->input->post('ckupdate');

		if(!empty($ckupdate)) {  
		     foreach($ckupdate as $check):
		         $ch[] = $check;
		     endforeach;
		}
		$unt = $this->session->userdata('unt');

		$cnt = count($unt);

		if ( $cnt > 0 )
		{
    		if(!empty($ckupdate)) 
    		{
    			
		         $rc = 0; 

			     $untbuildings = $this->tb_unit_number->count_un_id_by_un_build_id($Building);
			     $untbuilding = count($untbuildings);
        	
      			if ( $untbuilding  >  0 )
      			{
 
         			foreach ($unt as $udt )
         			{

             			$flag = false;
              
              			foreach($ch as $check) 
              			{
                 			if ( trim($check) == trim($udt[0]) )
               				{ 
                 				$flag=true; break;
               				}     
              			}
             			
             			if ( $flag )
             			{
			               $untavailable = $this->tb_unit_number->get_un_id_by_un_buildAndun_name($Building,$udt[0]);
			               $unid = $untavailable->un_id;

 
               				if (!empty($unid))
               				{                                                           
		                      
		                      $untprices = $this->tb_price->get_detail_by_buildingID_UnitNumberID($Building,$unid);
		                      $untprice = count($untprices);
 								
		                      if ($untprice <= 0  )
		                      {	
		                      		$data_insert = array(
		                      			'pr_building_id' => $Building,
		                      			'pr_unit_number_id' => $unid,
		                      			'pr_bottom_line_price_sqm' => $udt[1],
		                      			'pr_bottom_line_price_sqft' => $udt[2],
		                      			'pr_base_price' => $udt[3],
		                      			'pr_floor' => $udt[4],
		                      			'pr_cornor' => $udt[5],
		                      			'pr_garden' => $udt[6],
		                      			'pr_swimming_pool' => $udt[7],
		                      			'pr_city' => $udt[8],
		                      			'pr_facillity_floor' => $udt[9],
		                      			'pr_t_junction' => $udt[10],
		                      			'pr_blocked_view' => $udt[11],
		                      			'pr_unattractive_view' => $udt[12],
		                      			'pr_garbage_room' => $udt[13],
		                      			'pr_bottom_line_for_internal' => $udt[14],
		                      			'pr_mark_up' => $udt[15],
		                      			'pr_selling_sqm' => $udt[16],
		                      			'pr_selling_sqft' => $udt[17],
		                      			'pr_asking_price' => $udt[18]
		                      		);	
										
		                      		$this->tb_price->record($data_insert);					

                          			$b =  array($udt[0],$udt[1],$udt[2],$udt[3],$udt[16],$udt[17],$udt[18],"Yes");
                          			$data_insert_room_sts = array(
                          				'rs_unit_number' => $unid,
                          				'rs_cus_id' => '',
                          				'rs_status' => 'Add Price',
                          				'rs_staff_id' => $staffid
                          			);
                          			
                          			$this->tb_room_status->record($data_insert_room_sts);
                      		  }
               				}
             			}
     
         			}               
      			}
    		}
		}
		//alert_redirect("จำนวนห้องที่ถุก Add price ทั้งหมด : ".$b." ห้อง",'/project_price/view');
		$this->session->unset_userdata('unt');
	}
	public function confirm_editing(){
		
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_building');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$this->LoadView('Project_detail/Project_price/project_price_adding',$data);
	}
	public function record(){

		$this->load->model('tb_unit_number');
		$this->load->model('tb_price');
		$this->load->model('tb_room_status');
		$Building = $this->input->post('Building');
		$csv_mimetypes = array(
		    'text/csv',
		    'text/plain',
		    'application/csv',
		    'text/comma-separated-values',
		    'application/excel',
		    'application/vnd.ms-excel',
		    'application/vnd.msexcel',
		    'text/anytext',
		    'application/octet-stream',
		    'application/txt',
		);
		if (!in_array($_FILES['projectFile']['type'], $csv_mimetypes)) {
			alert_redirect('Format File Invalid','/project_price/adding');
		}
		$flagInsert = TRUE;
		$strCSV[] = "";
		$strStory[] = "";
		$tmpdate = date("Y_m_d_H_i_s");
		$Str_file = explode(".",$_FILES['projectFile']['name']);  
		$new_name="price_".$tmpdate.".".$Str_file['1'];
		if(move_uploaded_file($_FILES["projectFile"]["tmp_name"],"csv/".$new_name)) 
		{
			$objCSV = fopen("csv/".$new_name, "r");
			$countflag = 0;
			$flag = 0;
			while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) {
					if ($countflag++>0) {
						$flag++;
					}
			}
			fclose($objCSV);
			
			$buildingRow = 0;
			if ($flag > 0) {
				$count_unit = $this->tb_unit_number->count_un_id_by_un_build_id($Building);
				$buildingRow = $count_unit->row;
			}
			// echo "buildingRow : $buildingRow<br>flag : $flag";exit();
			if ($flag != $buildingRow) {
				alert_redirect('Please check the Amount Information','/project_price/adding');
			}
			$count = 0;
			
			$arr=array();
			$objCSV = fopen("csv/".$new_name, "r");
			while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) {
			
				if ($count>0) {
					$row1 = 0;
					$rowTB_prices= 0;
	
					$unitname = $objArr[1];
					$unit_number = $this->tb_unit_number->get_detail_by_idAndName($Building,$unitname);
					if($unit_number != NULL){
						$row1 = 1;
					}
					if($objArr[1] !='' ){
						if (isset($arr[$objArr[1]])){
							$flagInsert = FALSE;
							break ;
						}else{
							$flagInsert = TRUE;
							$arr[$objArr[1]] = $objArr[1];
						}	
						
						if($row1>0){
							$flagInsert = TRUE;
						}else{
							$flagInsert = FALSE;
							break ;
						}
						$unid =	$unit_number->un_id;
					
						
						$price = $this->tb_price->get_detail_by_unit_id_and_building_id($unid,$Building);
						if($price != NULL){
							$rowTB_price = 1;
						}
					
						if($rowTB_price>0){
							$flagInsert = FALSE;
							break ;
						}else{
							$flagInsert = TRUE;
						}	
						
						$list_price_value_insert[] = array(
							'pr_building_id' => $Building,
							'pr_unit_number_id' => $unid,
							'pr_base_price_sqm' => trim(str_replace( ',', '', $objArr[2])),
							'pr_base_price_sqft' => trim(str_replace( ',', '', $objArr[3])),
							'pr_base_price' => trim(str_replace( ',', '', $objArr[4])),
//							'pr_floor' => $objArr[5],
//							'pr_cornor' => $objArr[6],
//							'pr_garden' => $objArr[7],
//							'pr_swimming_pool' => $objArr[8],
//							'pr_city' => $objArr[9],
//							'pr_facillity_floor' => $objArr[10],
//							'pr_t_junction' => $objArr[11],
//							'pr_blocked_view' => $objArr[12],
//							'pr_unattractive_view' => $objArr[13],
//							'pr_garbage_room' => $objArr[14],
							'pr_bottom_line_price_sqm' => trim(str_replace( ',', '', $objArr[5])),
							'pr_bottom_line_price_sqft' => trim(str_replace( ',', '', $objArr[6])),
							'pr_bottom_line_for_internal' => trim(str_replace( ',', '', $objArr[7])),
//							'pr_mark_up' => $objArr[16],
							'pr_asking_sqm' => trim(str_replace( ',', '', $objArr[8])),
							'pr_asking_sqft' => trim(str_replace( ',', '', $objArr[9])),
							'pr_asking_price' => trim(str_replace( ',', '', $objArr[10])),
							'pr_by_user' => $this->user_id
						);
						$list_story_value_insert[] = array(
							'rs_unit_number' => $unid,
							'rs_cus_id' => NULL,
							'rs_status' => 'Add Price',
							'rs_staff_id' => $this->user_id
						);
					}
					
				}
				
				$count++;
			}
			fclose($objCSV);
		}
		if ($flagInsert) {
			/*================================*/
			/*======= Transaction start ======*/
		 	/*================================*/
		 	$this->pdb->trans_begin();
			foreach ($list_price_value_insert as $value_price):
				$this->tb_price->record($value_price);	
			endforeach;

			foreach ($list_story_value_insert as  $value_story):
				$this->tb_room_status->record($value_story);	
			endforeach;
			/*=======================================*/
 			/*======= check status transaction ======*/
 			/*=======================================*/
			if ($this->pdb->trans_status() === FALSE){
	       		$this->pdb->trans_rollback();
	   			alert_redirect('Add Price Fail','/project_price/view');
			}
			else{
			   	$this->pdb->trans_commit();
			   	alert_redirect('Add Price Success','/project_price/view');
			}
			
		}else{
			alert_redirect('Please check the validity','/project_price/adding');
		}
	}
	public function editing($pid) {
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_building');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$this->LoadView('Project_detail/Project_price/project_price_editing',$data);
	}
	public function update($confirm){
        $this->load->library('session');
		/// Flag to send sumary view ///
		$countsusscess = 0;
		$unsusscess = NULL;
		$priceUpdateFlag = FALSE;
		///////////////////////////////

		$this->load->model('tb_unit_number');
		$this->load->model('tb_price');
		$this->load->model('tb_room_status');
		$this->load->model('log_price');
		$Building = $this->input->post('Building');
//        echo "curr_timestamp".$curr_timestamp;
//        exit();
		$csv_mimetypes = array(
		    'text/csv',
		    'text/plain',
		    'application/csv',
		    'text/comma-separated-values',
		    'application/excel',
		    'application/vnd.ms-excel',
		    'application/vnd.msexcel',
		    'text/anytext',
		    'application/octet-stream',
		    'application/txt',
		);
        $flagFile = FALSE;
        if($confirm == 'yes' && $this->session->userdata('updatePrice') !== FALSE) {
            $Building = $this->session->userdata('buildingPrice');
            $new_name = $this->session->userdata('updatePrice');
//            $this->session->unset_userdata('buildingPrice');
//            $this->session->unset_userdata('updatePrice');
            $flagFile = !empty($new_name);
            $flagInsert = TRUE;
        }else {
            if (!in_array($_FILES['projectFile']['type'], $csv_mimetypes)) {
                alert_redirect('Format File Invalid','/project_price/adding');
            }
            $flagInsert = TRUE;
            $strCSV[] = "";
            $strStory[] = "";
            $tmpdate = date("Y_m_d_H_i_s");
            $Str_file = explode(".",$_FILES['projectFile']['name']);  
            $new_name="price_".$tmpdate.".".$Str_file['1'];
            $this->session->set_userdata('updatePrice',$new_name);
            $this->session->set_userdata('buildingPrice',$Building);
            $flagFile = move_uploaded_file($_FILES["projectFile"]["tmp_name"],"csv/".$new_name);
        }
		if($flagFile == TRUE) 
		{
			$objCSV = fopen("csv/".$new_name, "r");
			$countflag = 0;
			$flag = 0;
			while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) {
					if ($countflag++>0) {
						$flag++;
					}
//				$countflag++;
			}
			fclose($objCSV);
			
			$buildingRow= 0;
			if ($flag>0) {
				$count_unit = $this->tb_unit_number->count_un_id_by_un_build_id($Building);
				$buildingRow = 	$count_unit->row;
			}
		
			$count = 0;
			$arr=array();
			$objCSV = fopen("csv/".$new_name, "r");
			while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) {
				if ($count>0) {

					$row1 = 0;
					$rowTB_prices= 0;
	
					$unitname = $objArr[1];
					$unit_number = $this->tb_unit_number->get_detail_by_idAndName($Building,$unitname);
                    
					if($unit_number != NULL){
						$row1 = 1;
					}
					if($objArr[1] !='' ){
						if (isset($arr[$objArr[1]])){
							$flagInsert = FALSE;
							break;
						}else{
							$flagInsert = TRUE;
							$arr[$objArr[1]] = $objArr[1];
						}
                        
						if($row1>0){
							$flagInsert = TRUE;
						}else{
							$flagInsert = FALSE;
							break ;
						}
						
						
						$price = $this->tb_price->get_detail_by_unit_id_and_building_id($unit_number->un_id,$Building);

						if($price != NULL){
							$rowTB_price = 1;
						}
					
						if($rowTB_price>0){
							$flagInsert = TRUE;
						}else{
							$flagInsert = FALSE;
							break ;
						}
                        
						$pr_id = $price->pr_id;
						$unid =	$unit_number->un_id;
						$userEdit = $this->user_id;
						$getStatusRoom = $this->tb_unit_number->get_detail_unit_by_un_id($unid);
                        
        $curr_timestamp = date('Y-m-d H:i:s');
                        //////////////////////////////////////////////////
						if($getStatusRoom->un_status_room == 'Available'){

							$list_update_price[] = array(
								'pr_base_price_sqm' => trim(str_replace( ',', '', $objArr[2])),
								'pr_base_price_sqft' => trim(str_replace( ',', '', $objArr[3])),
								'pr_base_price' => trim(str_replace( ',', '', $objArr[4])),
//								'pr_floor' => $objArr[5],
//								'pr_cornor' => $objArr[6],
//								'pr_garden' => $objArr[7],
//								'pr_swimming_pool' => $objArr[8],
//								'pr_city' => $objArr[9],
//								'pr_facillity_floor' => $objArr[10],
//								'pr_t_junction' => $objArr[11],
//								'pr_blocked_view' => $objArr[12],
//								'pr_unattractive_view' => $objArr[13],
//								'pr_garbage_room' => $objArr[14],
								'pr_bottom_line_price_sqm' => trim(str_replace( ',', '', $objArr[5])),
								'pr_bottom_line_price_sqft' => trim(str_replace( ',', '', $objArr[6])),
								'pr_bottom_line_for_internal' => trim(str_replace( ',', '', $objArr[7])),
//								'pr_mark_up' => $objArr[16],
								'pr_asking_sqm' => trim(str_replace( ',', '', $objArr[8])),
								'pr_asking_sqft' => trim(str_replace( ',', '', $objArr[9])),
								'pr_asking_price' => trim(str_replace( ',', '', $objArr[10])),
				                'pr_timestamp' => $curr_timestamp
							);
							$list_pr_id[] = $price->pr_id;
							
							$list_insert_room_status[] = array(
								'rs_unit_number' => $unid,
								'rs_cus_id' => '',
								'rs_status' => 'Update Price',
								'rs_staff_id' => $this->user_id
							);

							$old_price = $this->tb_price->get_detail_by_unit_id_and_building_id($unid, $Building);
							$list_log[] = array(
								'pr_id' => $pr_id,
						        'pr_unit_number_id' => $unid,
						        'pr_building_id' => $Building,
						        'pr_base_price_sqm' => $old_price->pr_base_price_sqm,
					            'pr_base_price_sqft' => $old_price->pr_base_price_sqft,
			   	                'pr_base_price' => $old_price->pr_base_price,
						        'pr_floor' => $old_price->pr_floor,
						        'pr_cornor' => $old_price->pr_cornor,
						        'pr_garden' => $old_price->pr_garden,
					            'pr_swimming_pool' => $old_price->pr_swimming_pool,
				                'pr_city' => $old_price->pr_city,
		                        'pr_facillity_floor' => $old_price->pr_facillity_floor,
						        'pr_t_junction' => $old_price->pr_t_junction,
						        'pr_blocked_view' => $old_price->pr_blocked_view,
				                'pr_unattractive_view' => $old_price->pr_unattractive_view,
					            'pr_garbage_room' => $old_price->pr_garbage_room,
						        'pr_bottom_line_price_sqm' => $old_price->pr_bottom_line_price_sqm,
					            'pr_bottom_line_price_sqft' => $old_price->pr_bottom_line_price_sqft,
			                    'pr_bottom_line_for_internal' => $old_price->pr_bottom_line_for_internal,
			    	            'pr_mark_up' => $old_price->pr_mark_up,
			                    'pr_asking_sqm' => $old_price->pr_asking_sqm,
					            'pr_asking_sqft' => $old_price->pr_asking_sqft,
					            'pr_asking_price' => $old_price->pr_asking_price,
				                'pr_update_by' => $old_price->pr_by_user,
				                'pr_update' => $old_price->pr_timestamp
							);
								$countsusscess++;
						}else{
								$unsusscess[] = $getStatusRoom->un_name;
						}
                        //////////////////////////////////////////////////
					}
					
				}
				
				$count++;
				}
			fclose($objCSV);
			}
            
			if ($flagInsert) {
                if($confirm == 'yes') {
					/*================================*/
					/*======= Transaction start ======*/
				 	/*================================*/
				 	$this->pdb->trans_begin();
					$i = 0;
					foreach ($list_update_price as  $value):
						$this->tb_price->update($value,$list_pr_id[$i]);	
						$i++;
					endforeach;
					
					foreach ($list_insert_room_status as  $room_sts_value):
						$this->tb_room_status->record($room_sts_value);	
					endforeach;

					foreach ($list_log as $log_value):
						$this->log_price->record($log_value);
					endforeach;

					/*=======================================*/
		 			/*======= check status transaction ======*/
		 			/*=======================================*/
					if ($this->pdb->trans_status() === FALSE){
			       		$this->pdb->trans_rollback();
			   			alert_redirect('Update Price Fail','/project_price/editing');
					}
					else{
					   	$this->pdb->trans_commit();
					   	$priceUpdateFlag=TRUE;
						$this->session->set_userdata('unsusscess', $unsusscess);
						$this->view_summary($countsusscess,$priceUpdateFlag);
					   	// alert_redirect('Update Price Success',"/project_price/view_summary/".$countsusscess."/".$priceUpdateFlag."");
					}
                }else {
                    $unsusscess = implode(', ',$unsusscess);
                    echo "<script>
                    var con = confirm('Update Success : \'$countsusscess\' Lists".'\n'."Update Unavailable is Unit Number : ".'\n'."$unsusscess');
                    if(con)
                        window.location.href = '".BASE_DOMAIN."project_price/update/yes';
                    else
                        window.location.href = '".BASE_DOMAIN."project_price';
                    </script>";
                }
			}else{
				alert_redirect('Please check the validity','/project_price/editing');	
			}
	}
	public function detail($pid){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_price');
		$data['price'] = $this->tb_price->get_full_detail_by_pr_id($pid);
		$this->LoadView('Project_detail/Project_price/project_price_view_detail',$data);
	}
	public function view_summary($countsusscess, $priceUpdateFlag){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$data['countsusscess'] = $countsusscess;
		$data['unsusscess'] = $this->session->userdata('unsusscess');
		$data['priceUpdateFlag'] = $priceUpdateFlag;
		$this->LoadView('Project_detail/Project_price/project_price_view_summary',$data);
	}
	public function download_csv(){
		$this->load->helper('download');
		$data = file_get_contents("csvTemplate/tmpplatePrice.xlsx"); 
		$name = 'templatePrice.xlsx';
		force_download($name, $data);
	}
}

/* End of file project_price.php */
/* Location: ./application/controllers/project_price.php */