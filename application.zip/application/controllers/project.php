<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['permission'] = $this->get_user_permission();
		$data['list_project'] = $this->fetch_all_active_project();
    $data['menuLeft'] = 'off';

		$this->LoadView('Project/project',$data);
	}
	public function adding()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['permission'] = $this->get_user_permission();
    $data['menuLeft'] = 'off';
		$this->LoadView('Project/project_adding',$data);
	}
	public function record()
	{
		$this->load->model('tb_project');
        $pjid = $this->tb_project->get_next_id();
		$pjname = $this->input->post('pjname');
  		$databasenamenew = $this->input->post('Database');	
 		$Detail = $this->input->post('Detail');
 		$data_add = array(
            'pj_id' => $pjid,
            'pj_name' => $pjname,
            'pj_detail' => $Detail,
            'pj_datebase_name' => $databasenamenew
		);
		$this->tb_project->record($data_add);
        
 		if(!$this->isEmptyFile('Image'))
 		{
 			$obj_pj = $this->tb_project->get_detail_project_by_dbName($databasenamenew);
 			$result = $this->upload_image('Image','project/'.$obj_pj->pj_id,time());
 			$data_update = array('pj_image' => $result['image_url']);
 			$this->updateProject($data_update,$obj_pj->pj_id);
 		}
 		
		$this->create_new_database_project($databasenamenew,$pjname,$pjid);

		alert_redirect('Add Project Success','/home');
	}
	public function editing($pj_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['pjid'] = $pj_id;
		$data['project'] = $this->get_detail_project($pj_id);
		$data['permission'] = $this->get_user_permission();
    $data['menuLeft'] = 'off';
		$this->LoadView('Project/project_editing',$data);
	}
	public function update($pj_id)
	{
		$this->load->model('log_project');

		$userEdit = $this->user_id;	
 		$pjname  = $this->input->post('pjname');
 		$pj_detail = $this->input->post('Detail');
		
		if($this->isEmptyFile('Image')){
				///////// NOT HAVE IMAGE ////////
				/////////////////////////////////
				$data = array(
					'pj_name' => $pjname,
					'pj_detail' => $pj_detail
				);
				$this->updateProject($data,$pj_id);
				////// KEEP LOG //////
				//////////////////////
				$obj_pj = $this->get_detail_project($pj_id);
				$data_log_not_image = array(
					'pj_id' => $obj_pj->pj_id,
					'pj_name' => $obj_pj->pj_name,
					'pj_detail' => $obj_pj->pj_detail,
					'pj_datebase_name' => $obj_pj->pj_datebase_name,
					'pj_active' => $obj_pj->pj_active,
					'pj_update_by' => $this->user_id
				);
				
				$this->log_project->record($data_log_not_image);
		}else{
				$result = $this->upload_image('Image','project/'.$pj_id,time());
				if($result['error_status'] == FALSE){
					///////// HAVE IMAGE ////////////
					/////////////////////////////////
					$data = array(
						'pj_name' => $pjname,
						'pj_detail' => $pj_detail,
						'pj_image' => $result['image_url']
					);
					$this->updateProject($data,$pj_id);
					////// KEEP LOG //////
					//////////////////////
					$obj_pj = $this->get_detail_project($pj_id);
					$data_log_have_image = array(
						'pj_id' => $obj_pj->pj_id,
						'pj_name' => $obj_pj->pj_name,
						'pj_detail' => $obj_pj->pj_detail,
						'pj_datebase_name' => $obj_pj->pj_datebase_name,
						'pj_active' => $obj_pj->pj_active,
						'pj_update_by' => $this->user_id,
						'pj_image' => $result['image_url']
					);
					$this->log_project->record($data_log_have_image);
				}
		}

		alert_redirect('Edit project Success','/project/view');
	}
	public function deleting($pj_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project_add,'4') === FALSE) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}else{
			$data = array(
				'pj_active' => 'off'
			);
			$this->updateProject($data,$pj_id);
			alert_redirect('Delete Project Success','/project/view');
		}
	}
	public function select($pj_id){
		$detail_pj = $this->get_detail_project($pj_id);

		$this->session->set_userdata('project_id_sel', $detail_pj->pj_id);
		$this->session->set_userdata('project_name_sel', $detail_pj->pj_name);
		$this->session->set_userdata('project_database_sel',  $detail_pj->pj_datebase_name);
    $this->session->set_userdata('project_image_sel',  $detail_pj->pj_image);
		$this->refreshSession();
    
		//redirect('/dashboard');
    echo '<script>window.location.href = "'.BASE_DOMAIN.'dashboard"</script>';
	}
	/**
	* -------------------------------------
	* [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function updateProject($data,$pjid){
		$this->load->model('tb_project');
		$this->tb_project->update($data,$pjid);
	}
	private function get_detail_project($pjid){
		$this->load->model('tb_project');
		return $this->tb_project->get_detail_project($pjid);
	}
	private  function fetch_all_active_project(){
		$this->load->model('tb_project');
		return $this->tb_project->fetch_all_active_project();
	}

	/**
	* --------------------------------------
	* [CREATE DATABASE PROJECT]
	* --------------------------------------
	*/
	private function create_new_database_project($dbname,$pjname,$pjid)
	{
        $this->load->database();
        $hostnameorservername = $this->db->hostname;
        $serverusername = $this->db->username;
        $serverpassword = $this->db->password;

		$conn = mysql_connect($hostnameorservername, $serverusername, $serverpassword);
		 
		$str = "CREATE DATABASE ".$dbname."";
		mysql_query($str);
		 
		mysql_connect($hostnameorservername, $serverusername, $serverpassword);
		mysql_select_db($dbname);
        
        $str = "CREATE TABLE `log_building` (
                  `building_id` int(11) DEFAULT NULL,
                  `building_name` varchar(50) DEFAULT NULL,
                  `building_info` text,
                  `building_image` varchar(250) DEFAULT NULL,
                  `building_sts_active` varchar(5) DEFAULT 'on',
                  `building_update_by` int(11) DEFAULT NULL,
                  `building_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_floor` (
                  `fl_id` int(11) DEFAULT NULL,
                  `fl_build_id` int(11) DEFAULT NULL,
                  `fl_name` varchar(10) DEFAULT NULL,
                  `fl_info` text,
                  `fl_image` varchar(250) DEFAULT NULL,
                  `fl_sts_active` varchar(3) DEFAULT 'on',
                  `fl_update_by` int(11) DEFAULT NULL,
                  `fl_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_payment_terms` (
                  `pt_id` int(11) DEFAULT NULL,
                  `pt_name` varchar(100) DEFAULT NULL,
                  `pt_room_type_id` int(11) DEFAULT NULL,
                  `pt_total_down_percent` varchar(100) DEFAULT NULL,
                  `pt_booking` int(100) DEFAULT NULL,
                  `pt_contract` int(100) DEFAULT NULL,
                  `pt_down_payment_month` int(100) DEFAULT NULL,
                  `pt_ballon_payment` varchar(3) DEFAULT 'no',
                  `pt_installment1` int(20) DEFAULT NULL,
                  `pt_months_installment1` varchar(50) DEFAULT NULL,
                  `pt_installment2` int(20) DEFAULT NULL,
                  `pt_months_installment2` varchar(50) DEFAULT NULL,
                  `pt_installment3` int(20) DEFAULT NULL,
                  `pt_months_installment3` varchar(50) DEFAULT NULL,
                  `pt_installment4` int(20) DEFAULT NULL,
                  `pt_months_installment4` varchar(50) DEFAULT NULL,
                  `pt_installment5` int(20) DEFAULT NULL,
                  `pt_months_installment5` varchar(50) DEFAULT NULL,
                  `pt_installment6` int(20) DEFAULT NULL,
                  `pt_months_installment6` varchar(50) DEFAULT NULL,
                  `pt_installment7` int(20) DEFAULT NULL,
                  `pt_months_installment7` varchar(50) DEFAULT NULL,
                  `pt_installment8` int(20) DEFAULT NULL,
                  `pt_months_installment8` varchar(50) DEFAULT NULL,
                  `pt_installment9` int(20) DEFAULT NULL,
                  `pt_months_installment9` varchar(50) DEFAULT NULL,
                  `pt_installment10` int(20) DEFAULT NULL,
                  `pt_months_installment10` varchar(50) DEFAULT NULL,
                  `pt_installment11` int(20) DEFAULT NULL,
                  `pt_months_installment11` varchar(50) DEFAULT NULL,
                  `pt_installment12` int(20) DEFAULT NULL,
                  `pt_months_installment12` varchar(50) DEFAULT NULL,
                  `pt_installment13` int(20) DEFAULT NULL,
                  `pt_months_installment13` varchar(50) DEFAULT NULL,
                  `pt_installment14` int(20) DEFAULT NULL,
                  `pt_months_installment14` varchar(50) DEFAULT NULL,
                  `pt_installment15` int(20) DEFAULT NULL,
                  `pt_months_installment15` varchar(50) DEFAULT NULL,
                  `pt_installment16` int(20) DEFAULT NULL,
                  `pt_months_installment16` varchar(50) DEFAULT NULL,
                  `pt_installment17` int(20) DEFAULT NULL,
                  `pt_months_installment17` varchar(50) DEFAULT NULL,
                  `pt_installment18` int(20) DEFAULT NULL,
                  `pt_months_installment18` varchar(50) DEFAULT NULL,
                  `pt_installment19` int(20) DEFAULT NULL,
                  `pt_months_installment19` varchar(50) DEFAULT NULL,
                  `pt_date_expired` date DEFAULT NULL,
                  `pt_sts_active` varchar(3) DEFAULT 'on',
                  `pt_update_by` int(11) DEFAULT NULL,
                  `pt_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE IF NOT EXISTS `log_price` (
                  `pr_id` int(11) DEFAULT NULL,
                  `pr_unit_number_id` int(11) DEFAULT NULL,
                  `pr_building_id` int(11) DEFAULT NULL,
                  `pr_base_price_sqm` varchar(20) DEFAULT NULL,
                  `pr_base_price_sqft` varchar(20) DEFAULT NULL,
                  `pr_base_price` varchar(20) DEFAULT NULL,
                  `pr_floor` varchar(20) DEFAULT NULL,
                  `pr_cornor` varchar(20) DEFAULT NULL,
                  `pr_garden` varchar(20) DEFAULT NULL,
                  `pr_swimming_pool` varchar(20) DEFAULT NULL,
                  `pr_city` varchar(20) DEFAULT NULL,
                  `pr_facillity_floor` varchar(20) DEFAULT NULL,
                  `pr_t_junction` varchar(20) DEFAULT NULL,
                  `pr_blocked_view` varchar(20) DEFAULT NULL,
                  `pr_unattractive_view` varchar(20) DEFAULT NULL,
                  `pr_garbage_room` varchar(20) DEFAULT NULL,
                  `pr_bottom_line_price_sqm` float DEFAULT NULL,
                  `pr_bottom_line_price_sqft` float DEFAULT NULL,
                  `pr_bottom_line_for_internal` varchar(20) DEFAULT NULL,
                  `pr_mark_up` varchar(20) DEFAULT NULL,
                  `pr_asking_sqm` varchar(20) DEFAULT NULL,
                  `pr_asking_sqft` varchar(20) DEFAULT NULL,
                  `pr_asking_price` varchar(20) DEFAULT NULL,
                  `pr_update_by` int(11) DEFAULT NULL,
                  `pr_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_project` (
                  `pj_id` int(11) DEFAULT NULL,
                  `pj_name` text,
                  `pj_name_th` varchar(500) DEFAULT NULL,
                  `pj_type` text,
                  `pj_owners` varchar(500) DEFAULT NULL,
                  `pj_owners_en` varchar(500) DEFAULT NULL,
                  `pj_location` text,
                  `pj_location_th` varchar(500) DEFAULT NULL,
                  `pj_decoration` text,
                  `pj_facilities` text,
                  `pj_security` text,
                  `pj_area` text,
                  `pj_area_en` text,
                  `pj_owner` text,
                  `pj_owner_en` text,
                  `pj_commencement` text,
                  `pj_expected` text,
                  `pj_common` text,
                  `pj_sinking` text,
                  `pj_active` varchar(3) DEFAULT 'on',
                  `pj_start_downpayment` date DEFAULT NULL,
                  `pj_end_downpayment` date DEFAULT NULL,
                  `pj_date_project` date DEFAULT NULL,
                  `pj_date_promotion` int(11) DEFAULT NULL,
                  `pj_owner_address` varchar(500) DEFAULT NULL,
                  `pj_owner_address_en` varchar(500) DEFAULT NULL,
                  `pj_ownership_date` date DEFAULT NULL,
                  `pj_address` varchar(500) DEFAULT NULL,
                  `pj_address_en` varchar(500) DEFAULT NULL,
                  `pj_cannot_transfer_date` date DEFAULT NULL,
                  `pj_land` varchar(500) DEFAULT NULL,
                  `pj_land_en` varchar(500) DEFAULT NULL,
                  `pj_coffers_fee` int(5) DEFAULT NULL,
                  `pj_amenities_fee` int(5) DEFAULT NULL,
                  `pj_quotation_tel` varchar(15) DEFAULT NULL,
                  `pj_update_by` int(11) DEFAULT NULL,
                  `pj_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_promotion` (
                  `pm_id` int(11) DEFAULT NULL,
                  `pm_name` varchar(100) DEFAULT NULL,
                  `pm_name_en` varchar(100) DEFAULT NULL,
                  `pm_type` varchar(10) DEFAULT NULL,
                  `pm_value` varchar(100) DEFAULT NULL,
                  `pm_detail` text,
                  `pm_detail_en` text,
                  `pm_date_expire` date DEFAULT NULL,
                  `pm_sts_active` varchar(3) DEFAULT 'on',
                  `pm_update_by` int(11) DEFAULT NULL,
                  `pm_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_terms_and_condition` (
                  `ct_id` int(11) DEFAULT NULL,
                  `ct_detail` text,
                  `ct_update_by` int(11) DEFAULT NULL,
                  `ct_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_unit_number` (
                  `un_id` int(11) DEFAULT NULL,
                  `un_build_id` int(11) DEFAULT NULL,
                  `un_floor_id` int(11) DEFAULT NULL,
                  `un_unit_type_id` int(11) DEFAULT NULL,
                  `un_name` varchar(10) DEFAULT NULL,
                  `un_number` varchar(5) DEFAULT NULL,
                  `un_direction` text,
                  `un_view` text,
                  `un_status_room` varchar(10) DEFAULT 'Available',
                  `un_sts_active` varchar(3) DEFAULT 'on',
                  `un_update_by` int(11) DEFAULT NULL,
                  `un_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `log_unit_type` (
                  `unit_type_id` int(11) DEFAULT NULL,
                  `unit_type_name` varchar(100) DEFAULT NULL,
                  `unit_type_info` text,
                  `unit_type_area_sqm` varchar(10) DEFAULT NULL,
                  `unit_type_area_sqft` varchar(10) DEFAULT NULL,
                  `unit_type_image` varchar(250) DEFAULT NULL,
                  `unit_type_room_type_id` int(11) DEFAULT NULL,
                  `unit_type_sts_active` varchar(5) DEFAULT 'on',
                  `unit_type_update_by` int(11) DEFAULT NULL,
                  `unit_type_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_booking` (
                  `bk_booking_id` int(11) NOT NULL AUTO_INCREMENT,
                  `bk_booking_code` varchar(20) NOT NULL,
                  `bk_quotation_code` varchar(20) NOT NULL,
                  `bk_leads_id` int(11) NOT NULL,
                  `bk_project_id` int(11) NOT NULL,
                  `bk_money_amount` double NOT NULL,
                  `bk_date_booking` datetime NOT NULL,
                  `bk_contract_date` date NOT NULL,
                  `bk_pay_day` int(2) NOT NULL DEFAULT '15',
                  `bk_letter_warning` varchar(4) DEFAULT NULL,
                  `bk_staff_id` int(11) NOT NULL,
                  `bk_time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `bk_status` varchar(11) DEFAULT 'on',
                  `bk_remark` text,
                  `bk_call_remark` varchar(3) NOT NULL DEFAULT 'no',
                  `bk_transfer_letter` varchar(20) DEFAULT NULL,
                  `bk_transfer_to` varchar(30) DEFAULT NULL,
                  PRIMARY KEY (`bk_booking_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_building` (
                  `building_id` int(11) NOT NULL,
                  `building_name` varchar(50) NOT NULL,
                  `building_info` text,
                  `building_image` varchar(250) DEFAULT NULL,
                  `building_sts_active` varchar(5) DEFAULT 'on'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE IF NOT EXISTS `tb_calendar` (
                `cd_id` int(11) NOT NULL,
                  `cd_title` text NOT NULL,
                  `cd_start` DATE NOT NULL,
                  `cd_end` DATE DEFAULT NULL,
                  `cd_url` text,
                  `cd_user_id` int(11) NOT NULL,
                  `cd_status` VARCHAR(10) NOT NULL DEFAULT 'on',
                  `cd_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_cancelation` (
                  `cc_id` int(11) unsigned NOT NULL,
                  `cc_booking_code` varchar(30) NOT NULL DEFAULT '',
                  `cc_contract_code` varchar(30) DEFAULT NULL,
                  `cc_refund` varchar(3) NOT NULL DEFAULT 'no',
                  `cc_remark` text,
                  `cc_staff` int(11) NOT NULL,
                  `cc_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE IF NOT EXISTS `tb_cancelled_receipt` (
                  `cr_id` int(11) NOT NULL,
                  `cr_offical_code` varchar(20) NOT NULL,
                  `cr_temp_code` varchar(20) NOT NULL,
                  `cr_payfor` varchar(20) NOT NULL,
                  `cr_reason` text NOT NULL,
                  `cr_staff` int(11) NOT NULL,
                  `cr_unit_id` INT(11) NOT NULL,
                  `cr_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE IF NOT EXISTS `tb_changed_receipt` (
                  `cr_id` int(11) NOT NULL,
                  `cr_temporary_receipt` varchar(20) NOT NULL,
                  `cr_offical_receipt` varchar(20) NOT NULL,
                  `cr_new_temporary_receipt` VARCHAR(20) NOT NULL,
                  `cr_for` varchar(20) NOT NULL,
                  `cr_reason` text NOT NULL,
                  `cr_unit` int(11) NOT NULL,
                  `cr_staff` int(11) NOT NULL,
                  `cr_status` varchar(10) NOT NULL DEFAULT 'on',
                  `cr_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_contract` (
                  `ct_id` int(11) NOT NULL AUTO_INCREMENT,
                  `ct_code` varchar(20) NOT NULL,
                  `ct_booking_code` varchar(20) NOT NULL,
                  `ct_cus_id` varchar(20) NOT NULL,
                  `ct_type` varchar(10) NOT NULL,
                  `ct_project_id` int(11) DEFAULT NULL,
                  `ct_date` datetime NOT NULL,
                  `ct_temp_receipt_date` datetime DEFAULT NULL,
                  `ct_pay_day` int(2) NOT NULL DEFAULT '15',
                  `ct_paid` varchar(3) NOT NULL DEFAULT 'no',
                  `ct_active` varchar(11) NOT NULL DEFAULT 'on',
                  `ct_letter_warning` text,
                  `ct_time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `ct_transfer_letter` varchar(20) DEFAULT NULL,
                  `ct_transfer_to` varchar(30) DEFAULT NULL,
                  `ct_staff_id` int(11) NOT NULL,
                  `ct_remark` varchar(250) DEFAULT NULL,
                  `ct_pdf` varchar(250) DEFAULT NULL,
                  PRIMARY KEY (`ct_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_contract_mapping` (
                  `cm_id` int(11) unsigned NOT NULL,
                  `cm_crm_code` varchar(30) NOT NULL DEFAULT '',
                  `cm_rama9_code` varchar(30) NOT NULL DEFAULT ''
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_contract_promotion` (
                  `cp_id` int(11) NOT NULL,
                  `cp_contract_code` varchar(20) DEFAULT NULL,
                  `cp_booking_code` varchar(20) NOT NULL,
                  `cp_promotion_id` int(11) NOT NULL,
                  `cp_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `cp_status` varchar(11) NOT NULL DEFAULT 'on'
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_credit_auto` (
                  `ca_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                  `ca_cus_id` int(11) NOT NULL,
                  `ca_unit_id` int(11) NOT NULL,
                  `ca_credit_type` int(11) NOT NULL,
                  `ca_bank` int(11) NOT NULL,
                  `ca_owner` varchar(250) NOT NULL DEFAULT '',
                  `ca_phone` varchar(20) NOT NULL DEFAULT '',
                  `ca_credit_number` int(20) NOT NULL,
                  `ca_credit_expiry` varchar(10) NOT NULL DEFAULT '',
                  `ca_total_month` int(11) NOT NULL,
                  `ca_installment_fee` int(20) NOT NULL,
                  `ca_pay_amount` int(40) NOT NULL,
                  `ca_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`ca_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_email` (
                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                  `email_cus_id` int(11) NOT NULL,
                  `email_msg_type` varchar(20) DEFAULT NULL,
                  `email_message` varchar(200) DEFAULT NULL,
                  `email_sent_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
                  `email_staff_id` int(11) DEFAULT NULL,
                  `email_booking_code` varchar(20) DEFAULT NULL,
                  `email_installment_code` varchar(20) DEFAULT NULL,
                  `email_ct_code` varchar(20) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_fgf` (
                  `fgf_id` int(11) NOT NULL,
                  `fgf_contract_code1` varchar(30) DEFAULT NULL,
                  `fgf_contract_code2` varchar(30) DEFAULT NULL,
                  `fgf_cus_id1` int(11) NOT NULL,
                  `fgf_cus_id2` int(11) NOT NULL,
                  `fgf_date` date DEFAULT NULL,
                  `fgf_last_date` date DEFAULT NULL,
                  `fgf_sale` int(4) DEFAULT NULL,
                  `fgf_approver` int(4) DEFAULT NULL,
                  `fgf_date_approver` date DEFAULT NULL,
                  `fgf_permission` int(1) NOT NULL COMMENT '0,1,2 0=getcus1 1=getcus2 2=gettwo',
                  `fgf_project_id` int(11) NOT NULL,
                  `fgf_status` varchar(50) DEFAULT NULL,
                  `fgf_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_floor` (
                  `fl_id` int(11) NOT NULL,
                  `fl_build_id` int(11) NOT NULL,
                  `fl_name` varchar(10) NOT NULL,
                  `fl_info` text,
                  `fl_image` varchar(250) DEFAULT NULL,
                  `fl_sts_active` varchar(3) NOT NULL DEFAULT 'on'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_installment` (
                  `im_id` int(11) NOT NULL,
                  `im_code` varchar(20) NOT NULL DEFAULT 'Waiting',
                  `im_contract_code` varchar(20) DEFAULT NULL,
                  `im_installment_time` int(2) unsigned zerofill DEFAULT NULL,
                  `im_duedate` date DEFAULT NULL,
                  `im_status` varchar(11) DEFAULT 'on',
                  `im_paid` varchar(3) NOT NULL DEFAULT 'no',
                  `im_remark` varchar(200) DEFAULT NULL,
                  `im_call_remark` varchar(3) NOT NULL DEFAULT 'no',
                  `im_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `im_cus_id` int(11) DEFAULT NULL,
                  `im_confirm` char(3) DEFAULT NULL,
                  `im_received_date` date DEFAULT NULL,
                  `im_fee_define` varchar(20) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_letter_booking_warning` (
                  `lt_id` int(6) NOT NULL,
                  `lt_code` varchar(20) DEFAULT NULL,
                  `lt_cus_id` int(11) NOT NULL,
                  `lt_autorized_user` int(11) DEFAULT NULL,
                  `lt_project_id` varchar(20) DEFAULT NULL,
                  `lt_booking_id` varchar(20) NOT NULL,
                  `lt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_letter_contract_warning` (
                  `lt_id` int(6) NOT NULL,
                  `lt_code` varchar(20) DEFAULT NULL,
                  `lt_cus_id` int(11) NOT NULL,
                  `lt_project_id` varchar(20) DEFAULT NULL,
                  `lt_contract_id` varchar(20) NOT NULL,
                  `lt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `lt_autorized_user` int(11) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_letter_referred` (
                  `lt_letter_id` int(6) NOT NULL,
                  `lt_referredfee_id` varchar(20) DEFAULT NULL,
                  `lt_ct_code` varchar(20) DEFAULT NULL,
                  `lt_contract_referfrom` int(11) DEFAULT NULL,
                  `lt_new_customer` int(11) NOT NULL,
                  `lt_letter_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `lt_deadline` int(11) DEFAULT NULL,
                  `lt_staffid` int(11) DEFAULT NULL,
                  `lt_project_id` varchar(20) DEFAULT NULL,
                  `lt_approve_by` int(11) DEFAULT NULL,
                  `lt_approve_date` date DEFAULT NULL,
                  `lt_status` varchar(20) DEFAULT 'Waitting',
                  `lt_autorized_user` int(11) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_message_type` (
                  `id` int(11) NOT NULL,
                  `msg_type_name` varchar(90) DEFAULT NULL
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_overdue_remark` (
                  `or_id` int(11) unsigned NOT NULL,
                  `or_booking_code` varchar(30) DEFAULT NULL,
                  `or_contract_code` varchar(30) DEFAULT NULL,
                  `or_installment_code` varchar(30) DEFAULT NULL,
                  `or_remark` varchar(500) DEFAULT '',
                  `or_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_payment` (
                  `pm_id` int(11) NOT NULL,
                  `pm_temp_code` varchar(30) DEFAULT NULL,
                  `pm_receipt_code` varchar(30) DEFAULT NULL,
                  `pm_date` datetime NOT NULL,
                  `pm_type` varchar(10) NOT NULL COMMENT 'Cash, Credit, Transfer, Check, Other',
                  `pm_amount` double NOT NULL,
                  `pm_cr_bank` int(4) DEFAULT NULL,
                  `pm_cr_type` int(2) DEFAULT NULL,
                  `pm_cr_holder` varchar(50) DEFAULT NULL,
                  `pm_cr_number` varchar(200) DEFAULT NULL,
                  `pm_cr_approve_code` varchar(25) DEFAULT NULL,
                  `pm_cr_expire` varchar(10) DEFAULT NULL,
                  `pm_cr_fee` double DEFAULT NULL,
                  `pm_check_number` varchar(50) DEFAULT NULL,
                  `pm_check_date` date DEFAULT NULL,
                  `pm_check_bank` varchar(50) DEFAULT NULL,
                  `pm_confirm` varchar(3) NOT NULL DEFAULT 'no',
                  `pm_status` int(1) NOT NULL DEFAULT '1' COMMENT '1,0    1=Active 0=No  default=1',
                  `pm_account` int(11) DEFAULT NULL,
                  `pm_remark` text,
                  `pm_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_payment_terms` (
                  `pt_id` int(11) NOT NULL,
                  `pt_name` varchar(100) NOT NULL,
                  `pt_room_type_id` int(11) NOT NULL DEFAULT '0',
                  `pt_total_down_percent` varchar(100) NOT NULL,
                  `pt_booking` int(100) DEFAULT NULL,
                  `pt_contract` int(100) DEFAULT NULL,
                  `pt_down_payment_month` int(100) DEFAULT NULL,
                  `pt_ballon_payment` varchar(3) DEFAULT 'no',
                  `pt_installment1` int(20) DEFAULT NULL,
                  `pt_months_installment1` varchar(50) DEFAULT NULL,
                  `pt_installment2` int(20) DEFAULT NULL,
                  `pt_months_installment2` varchar(50) DEFAULT NULL,
                  `pt_installment3` int(20) DEFAULT NULL,
                  `pt_months_installment3` varchar(50) DEFAULT NULL,
                  `pt_installment4` int(20) DEFAULT NULL,
                  `pt_months_installment4` varchar(50) DEFAULT NULL,
                  `pt_installment5` int(20) DEFAULT NULL,
                  `pt_months_installment5` varchar(50) DEFAULT NULL,
                  `pt_installment6` int(20) DEFAULT NULL,
                  `pt_months_installment6` varchar(50) DEFAULT NULL,
                  `pt_installment7` int(20) DEFAULT NULL,
                  `pt_months_installment7` varchar(50) DEFAULT NULL,
                  `pt_installment8` int(20) DEFAULT NULL,
                  `pt_months_installment8` varchar(50) DEFAULT NULL,
                  `pt_installment9` int(20) DEFAULT NULL,
                  `pt_months_installment9` varchar(50) DEFAULT NULL,
                  `pt_installment10` int(20) DEFAULT NULL,
                  `pt_months_installment10` varchar(50) DEFAULT NULL,
                  `pt_installment11` int(20) DEFAULT NULL,
                  `pt_months_installment11` varchar(50) DEFAULT NULL,
                  `pt_installment12` int(20) DEFAULT NULL,
                  `pt_months_installment12` varchar(50) DEFAULT NULL,
                  `pt_installment13` int(20) DEFAULT NULL,
                  `pt_months_installment13` varchar(50) DEFAULT NULL,
                  `pt_installment14` int(20) DEFAULT NULL,
                  `pt_months_installment14` varchar(50) DEFAULT NULL,
                  `pt_installment15` int(20) DEFAULT NULL,
                  `pt_months_installment15` varchar(50) DEFAULT NULL,
                  `pt_installment16` int(20) DEFAULT NULL,
                  `pt_months_installment16` varchar(50) DEFAULT NULL,
                  `pt_installment17` int(20) DEFAULT NULL,
                  `pt_months_installment17` varchar(50) DEFAULT NULL,
                  `pt_installment18` int(20) DEFAULT NULL,
                  `pt_months_installment18` varchar(50) DEFAULT NULL,
                  `pt_installment19` int(20) DEFAULT NULL,
                  `pt_months_installment19` varchar(50) DEFAULT NULL,
                  `pt_date_expired` date NOT NULL,
                  `pt_sts_active` varchar(3) NOT NULL DEFAULT 'on'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE IF NOT EXISTS `tb_price` (
                  `pr_id` int(11) NOT NULL,
                  `pr_unit_number_id` int(11) NOT NULL,
                  `pr_building_id` int(11) NOT NULL,
                  `pr_base_price_sqm` varchar(20) DEFAULT NULL,
                  `pr_base_price_sqft` varchar(20) DEFAULT NULL,
                  `pr_base_price` varchar(20) DEFAULT NULL,
                  `pr_floor` varchar(20) DEFAULT NULL,
                  `pr_cornor` varchar(20) DEFAULT NULL,
                  `pr_garden` varchar(20) DEFAULT NULL,
                  `pr_swimming_pool` varchar(20) DEFAULT NULL,
                  `pr_city` varchar(20) DEFAULT NULL,
                  `pr_facillity_floor` varchar(20) DEFAULT NULL,
                  `pr_t_junction` varchar(20) DEFAULT NULL,
                  `pr_blocked_view` varchar(20) DEFAULT NULL,
                  `pr_unattractive_view` varchar(20) DEFAULT NULL,
                  `pr_garbage_room` varchar(20) DEFAULT NULL,
                  `pr_bottom_line_price_sqm` float DEFAULT NULL,
                  `pr_bottom_line_price_sqft` float DEFAULT NULL,
                  `pr_bottom_line_for_internal` varchar(20) DEFAULT NULL,
                  `pr_mark_up` varchar(20) DEFAULT NULL,
                  `pr_asking_sqm` varchar(20) DEFAULT NULL,
                  `pr_asking_sqft` varchar(20) DEFAULT NULL,
                  `pr_asking_price` varchar(20) DEFAULT NULL,
                  `pr_by_user` int(11) NOT NULL,
                  `pr_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_project` (
                  `pj_id` int(11) NOT NULL AUTO_INCREMENT,
                  `pj_name` text,
                  `pj_name_th` varchar(500) DEFAULT NULL,
                  `pj_type` text,
                  `pj_owners` varchar(500) DEFAULT NULL,
                  `pj_owners_en` varchar(500) DEFAULT NULL,
                  `pj_location` text,
                  `pj_location_th` varchar(500) DEFAULT NULL,
                  `pj_decoration` text,
                  `pj_facilities` text,
                  `pj_security` text,
                  `pj_area` text,
                  `pj_area_en` text,
                  `pj_owner` text,
                  `pj_owner_en` text,
                  `pj_commencement` text,
                  `pj_expected` text,
                  `pj_common` text,
                  `pj_sinking` text,
                  `pj_active` varchar(3) DEFAULT 'on',
                  `pj_start_downpayment` date DEFAULT NULL,
                  `pj_end_downpayment` date DEFAULT NULL,
                  `pj_date_project` date DEFAULT NULL,
                  `pj_date_promotion` int(11) DEFAULT NULL,
                  `pj_owner_address` varchar(500) DEFAULT NULL,
                  `pj_owner_address_en` varchar(500) DEFAULT NULL,
                  `pj_ownership_date` date DEFAULT NULL,
                  `pj_address` varchar(500) DEFAULT NULL,
                  `pj_address_en` varchar(500) DEFAULT NULL,
                  `pj_cannot_transfer_date` date DEFAULT NULL,
                  `pj_land` varchar(500) DEFAULT NULL,
                  `pj_land_en` varchar(500) DEFAULT NULL,
                  `pj_coffers_fee` int(5) DEFAULT NULL,
                  `pj_amenities_fee` int(5) DEFAULT NULL,
                  `pj_quotation_tel` varchar(15) DEFAULT NULL,
                  PRIMARY KEY (`pj_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "INSERT INTO `tb_project` (`pj_id`,`pj_name`) VALUES ('$pjid','$pjname');";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_promotion` (
                  `pm_id` int(11) NOT NULL,
                  `pm_name` varchar(100) NOT NULL,
                  `pm_name_en` varchar(100) NOT NULL,
                  `pm_type` varchar(10) NOT NULL,
                  `pm_value` varchar(100) DEFAULT NULL,
                  `pm_detail` text,
                  `pm_detail_en` text,
                  `pm_date_expire` date NOT NULL,
                  `pm_sts_active` varchar(3) NOT NULL DEFAULT 'on',
                  `pm_room_type_id` varchar(10) NOT NULL,
                  `pm_unit_type` varchar(10) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_quotation` (
                  `qt_id` int(11) NOT NULL,
                  `qt_code` varchar(20) NOT NULL,
                  `qt_leads_id` int(11) NOT NULL,
                  `qt_project_id` int(11) NOT NULL,
                  `qt_buliding_id` int(11) NOT NULL,
                  `qt_floor_id` int(11) NOT NULL,
                  `qt_unit_number_id` int(11) NOT NULL,
                  `qt_sale_id` int(11) NOT NULL,
                  `qt_promotion` varchar(100) DEFAULT NULL,
                  `qt_payment_terms` int(11) NOT NULL,
                  `qt_date` datetime NOT NULL,
                  `qt_status` varchar(3) NOT NULL DEFAULT 'on',
                  `qt_remark` text,
                  `qt_unit_price` int(20) NOT NULL,
                  `qt_total_down_payment` int(20) DEFAULT NULL,
                  `qt_total_down_percent` double DEFAULT NULL,
                  `qt_booking_fee` int(20) DEFAULT NULL,
                  `qt_contract_fee` int(20) DEFAULT NULL,
                  `qt_avg_installment` int(20) DEFAULT NULL,
                  `qt_total_months` int(3) NOT NULL,
                  `qt_installment1` int(20) DEFAULT NULL,
                  `qt_months_installment1` varchar(50) DEFAULT NULL,
                  `qt_installment2` int(20) DEFAULT NULL,
                  `qt_months_installment2` varchar(50) DEFAULT NULL,
                  `qt_installment3` int(20) DEFAULT NULL,
                  `qt_months_installment3` varchar(50) DEFAULT NULL,
                  `qt_installment4` int(20) DEFAULT NULL,
                  `qt_months_installment4` varchar(50) DEFAULT NULL,
                  `qt_installment5` int(20) DEFAULT NULL,
                  `qt_months_installment5` varchar(50) DEFAULT NULL,
                  `qt_installment6` int(20) DEFAULT NULL,
                  `qt_months_installment6` varchar(50) DEFAULT NULL,
                  `qt_installment7` int(20) DEFAULT NULL,
                  `qt_months_installment7` varchar(50) DEFAULT NULL,
                  `qt_installment8` int(20) DEFAULT NULL,
                  `qt_months_installment8` varchar(50) DEFAULT NULL,
                  `qt_installment9` int(20) DEFAULT NULL,
                  `qt_months_installment9` varchar(50) DEFAULT NULL,
                  `qt_installment10` int(20) DEFAULT NULL,
                  `qt_months_installment10` varchar(50) DEFAULT NULL,
                  `qt_installment11` int(20) DEFAULT NULL,
                  `qt_months_installment11` varchar(50) DEFAULT NULL,
                  `qt_installment12` int(20) DEFAULT NULL,
                  `qt_months_installment12` varchar(50) DEFAULT NULL,
                  `qt_installment13` int(20) DEFAULT NULL,
                  `qt_months_installment13` varchar(50) DEFAULT NULL,
                  `qt_installment14` int(20) DEFAULT NULL,
                  `qt_months_installment14` varchar(50) DEFAULT NULL,
                  `qt_installment15` int(20) DEFAULT NULL,
                  `qt_months_installment15` varchar(50) DEFAULT NULL,
                  `qt_installment16` int(20) DEFAULT NULL,
                  `qt_months_installment16` varchar(50) DEFAULT NULL,
                  `qt_installment17` int(20) DEFAULT NULL,
                  `qt_months_installment17` varchar(50) DEFAULT NULL,
                  `qt_installment18` int(20) DEFAULT NULL,
                  `qt_months_installment18` varchar(50) DEFAULT NULL,
                  `qt_installment19` int(20) DEFAULT NULL,
                  `qt_months_installment19` varchar(50) DEFAULT NULL,
                  `qt_installment20` int(20) DEFAULT NULL,
                  `qt_months_installment20` varchar(50) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_receipt_offical` (
                  `rc_id` int(11) NOT NULL,
                  `rc_code` varchar(40) NOT NULL DEFAULT '',
                  `rc_temp_code` varchar(30) DEFAULT NULL,
                  `rc_refer_form` varchar(30) DEFAULT NULL,
                  `rc_payfor` varchar(20) NOT NULL DEFAULT '',
                  `rc_booking_code` varchar(20) DEFAULT NULL,
                  `rc_contract_code` varchar(20) DEFAULT NULL,
                  `rc_transfer_code` varchar(20) DEFAULT NULL,
                  `rc_installment_code` varchar(10) DEFAULT NULL,
                  `rc_installment_time` varchar(2) DEFAULT NULL,
                  `rc_total_amount` double DEFAULT NULL,
                  `rc_official_date` datetime DEFAULT NULL,
                  `rc_staff_official` int(11) NOT NULL,
                  `rc_confirm` char(3) NOT NULL DEFAULT 'no',
                  `rc_status` varchar(11) NOT NULL DEFAULT 'on',
                  `rc_remark` text,
                  `rc_time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `rc_customer_id` int(11) NOT NULL,
                  `rc_un_name` varchar(5) NOT NULL DEFAULT ''
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_receipt_temporary` (
                  `rc_id` int(11) NOT NULL,
                  `rc_code` varchar(40) NOT NULL DEFAULT '',
                  `rc_refer_form` varchar(30) DEFAULT NULL,
                  `rc_payfor` varchar(20) NOT NULL DEFAULT '',
                  `rc_booking_code` varchar(20) DEFAULT NULL,
                  `rc_contract_code` varchar(20) DEFAULT NULL,
                  `rc_transfer_code` varchar(20) DEFAULT NULL,
                  `rc_installment_code` varchar(10) DEFAULT NULL,
                  `rc_installment_time` varchar(2) DEFAULT NULL,
                  `rc_total_amount` double DEFAULT NULL,
                  `rc_temporary_date` datetime DEFAULT NULL,
                  `rc_staff_temporary` int(11) DEFAULT NULL,
                  `rc_confirm` char(3) NOT NULL DEFAULT 'no',
                  `rc_status` varchar(11) NOT NULL DEFAULT 'on',
                  `rc_remark` text,
                  `rc_time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `rc_customer_id` int(11) NOT NULL,
                  `rc_un_name` varchar(5) NOT NULL DEFAULT '',
                  `rc_edited` varchar(3) NOT NULL DEFAULT 'no'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_report` (
                  `rp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                  `rp_name_th` varchar(50) DEFAULT NULL,
                  `rp_name_en` varchar(50) DEFAULT NULL,
                  `rp_select` text,
                  `rp_from` text,
                  `rp_where` text,
                  `rp_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`rp_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_room_status` (
                    `rs_id` int(11) NOT NULL,
                    `rs_unit_number` int(11) NOT NULL,
                    `rs_cus_id` int(11) NOT NULL,
                    `rs_status` text COLLATE utf8_unicode_ci NOT NULL,
                    `rs_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    `rs_staff_id` text COLLATE utf8_unicode_ci
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_room_status` (
                  `rs_id` int(11) NOT NULL,
                  `rs_unit_number` int(11) NOT NULL,
                  `rs_cus_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
                  `rs_status` text COLLATE utf8_unicode_ci NOT NULL,
                  `rs_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `rs_staff_id` text COLLATE utf8_unicode_ci
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_sms` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `sms_cus_id` int(11) NOT NULL,
                  `sms_msg_type` varchar(30) DEFAULT NULL,
                  `sms_message` varchar(200) DEFAULT NULL,
                  `sms_sent_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
                  `sms_staff_id` int(11) DEFAULT NULL,
                  `sms_booking_code` varchar(30) DEFAULT NULL,
                  `sms_installment_code` varchar(30) DEFAULT NULL,
                  `sms_ct_code` varchar(30) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_survey_answer` (
                  `sa_id` int(11) unsigned NOT NULL,
                  `sa_cus_id` int(11) NOT NULL,
                  `sa_group` int(11) NOT NULL,
                  `sa_answer` text NOT NULL,
                  `sa_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_survey_choice` (
                  `sc_id` int(11) unsigned NOT NULL,
                  `sc_name` text NOT NULL,
                  `sc_question` int(11) DEFAULT NULL,
                  `sc_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_survey_group` (
                  `sg_id` int(11) unsigned NOT NULL,
                  `sg_name` text NOT NULL,
                  `sg_question` text,
                  `sg_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_survey_question` (
                  `sq_id` int(11) unsigned NOT NULL,
                  `sq_name` text NOT NULL,
                  `sq_group` int(11) DEFAULT NULL,
                  `sq_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_terms_and_condition` (
                  `ct_id` int(11) NOT NULL,
                  `ct_detail` text NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
		$str = "INSERT  INTO `tb_terms_and_condition`(`ct_id`,`ct_detail`) VALUES (1,'ค่าธรมเนียม/ค่าใช้จ่ายการติดตั้ง และเงินประกันมิเตอร์ไฟฟ้า<br>จัดเก็บครั้งเดียว/ชำระให้กับการไฟฟ้า แจ้งค่าใช้จ่ายให้ทราบเมื่อก่อสร้างอาคารเสร็จ<br>ค่าจดทะเบียนโอนกรรมสิทธิ์ 1% ของราคาประเมินหรือตามอัตราที่กฏหมายกำหนด<br>ค่าจดทะเบียนจำนอง 1% ของวงเงินสินเชื่อ หรืออัตราที่กฏหมายกำหนด (เฉพาะกรณีที่กู้เงินกับสถาบันารเงิน)');";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_transferred` (
                  `tf_id` int(11) unsigned NOT NULL,
                  `tf_old_booking` varchar(30) NOT NULL DEFAULT '',
                  `tf_old_contract` varchar(30) DEFAULT NULL,
                  `tf_new_booking` varchar(30) NOT NULL DEFAULT '',
                  `tf_new_contract` varchar(30) DEFAULT NULL,
                  `tf_old_customer` varchar(30) NOT NULL DEFAULT '',
                  `tf_new_customer` varchar(30) NOT NULL DEFAULT '',
                  `tf_unit_id` int(11) NOT NULL,
                  `tf_staff_id` int(11) NOT NULL,
                  `tf_remark` text NOT NULL,
                  `tf_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_transfer_booking` (
                  `tf_id` int(6) NOT NULL,
                  `tf_code` varchar(20) DEFAULT NULL,
                  `tf_from_cus` int(11) DEFAULT NULL,
                  `tf_project_id` varchar(20) DEFAULT NULL,
                  `tf_to_cus` int(11) DEFAULT NULL,
                  `tf_room` int(11) DEFAULT NULL,
                  `tf_booking_id` varchar(20) DEFAULT NULL,
                  `tf_autorized_user` int(11) DEFAULT NULL,
                  `tf_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_transfer_contract` (
                  `tf_id` int(6) NOT NULL,
                  `tf_code` varchar(20) DEFAULT NULL,
                  `tf_project_id` varchar(20) DEFAULT NULL,
                  `tf_from_cus` int(11) DEFAULT NULL,
                  `tf_to_cus` int(11) DEFAULT NULL,
                  `tf_room` int(11) DEFAULT NULL,
                  `tf_contract_id_old` varchar(20) DEFAULT NULL,
                  `tf_contract_id_new` varchar(20) DEFAULT NULL,
                  `tf_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `tf_autorized_user` int(11) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE IF NOT EXISTS `tb_transfer_ownership` (
                  `tr_id` int(11) NOT NULL,
                  `tr_code` varchar(20) NOT NULL,
                  `tr_contract_code` varchar(20) NOT NULL,
                  `tr_customer_id` int(11) NOT NULL,
                  `tr_unit_number_id` int(11) NOT NULL,
                  `tr_amount` double NOT NULL,
                  `tr_paid` varchar(3) NOT NULL DEFAULT 'no',
                  `tr_status` varchar(12) NOT NULL DEFAULT 'on',
                  `tr_time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_unit_number` (
                  `un_id` int(11) NOT NULL,
                  `un_build_id` int(11) NOT NULL,
                  `un_floor_id` int(11) NOT NULL,
                  `un_unit_type_id` int(11) NOT NULL,
                  `un_name` varchar(10) NOT NULL,
                  `un_number` varchar(5) NOT NULL,
                  `un_direction` text NOT NULL,
                  `un_view` text NOT NULL,
                  `un_status_room` varchar(10) NOT NULL DEFAULT 'Available',
                  `un_sts_active` varchar(3) NOT NULL DEFAULT 'on'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_unit_type` (
                  `unit_type_id` int(11) NOT NULL,
                  `unit_type_name` varchar(100) NOT NULL,
                  `unit_type_info` text NOT NULL,
                  `unit_type_area_sqm` varchar(10) NOT NULL,
                  `unit_type_area_sqft` varchar(10) DEFAULT NULL,
                  `unit_type_image` varchar(250) DEFAULT NULL,
                  `unit_type_room_type_id` int(11) DEFAULT NULL,
                  `unit_type_sts_active` varchar(5) NOT NULL DEFAULT 'on'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "CREATE TABLE `tb_update_promotion` (
                  `up_id` int(11) unsigned NOT NULL,
                  `up_booking_code` varchar(30) NOT NULL DEFAULT '',
                  `up_contract_code` varchar(30) DEFAULT NULL,
                  `up_old_promotion` varchar(100) DEFAULT '',
                  `up_new_promotion` varchar(100) DEFAULT '',
                  `up_remark` text,
                  `up_staff_id` int(11) NOT NULL,
                  `up_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_booking`
                  ADD PRIMARY KEY (`bk_booking_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_building`
                  ADD PRIMARY KEY (`building_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_calendar`
                    ADD PRIMARY KEY (`cd_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_cancelation`
                  ADD PRIMARY KEY (`cc_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_cancelled_receipt`
                 ADD PRIMARY KEY (`cr_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_changed_receipt`
                  ADD PRIMARY KEY (`cr_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_contract`
                  ADD PRIMARY KEY (`ct_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_contract_mapping`
                  ADD PRIMARY KEY (`cm_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_contract_promotion`
                  ADD PRIMARY KEY (`cp_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_fgf`
                  ADD PRIMARY KEY (`fgf_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_floor`
                  ADD PRIMARY KEY (`fl_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_installment`
                  ADD PRIMARY KEY (`im_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_booking_warning`
                  ADD PRIMARY KEY (`lt_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_contract_warning`
                  ADD PRIMARY KEY (`lt_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_referred`
                  ADD PRIMARY KEY (`lt_letter_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_message_type`
                  ADD PRIMARY KEY (`id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_overdue_remark`
                  ADD PRIMARY KEY (`or_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_payment`
                  ADD PRIMARY KEY (`pm_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_payment_terms`
                  ADD PRIMARY KEY (`pt_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_price`
                  ADD PRIMARY KEY (`pr_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_project`
                  ADD PRIMARY KEY (`pj_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_promotion`
                  ADD PRIMARY KEY (`pm_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_quotation`
                  ADD PRIMARY KEY (`qt_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_receipt_offical`
                  ADD PRIMARY KEY (`rc_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_receipt_temporary`
                  ADD PRIMARY KEY (`rc_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_room_status`
                  ADD PRIMARY KEY (`rs_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_sms`
                  ADD PRIMARY KEY (`id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_answer`
                  ADD PRIMARY KEY (`sa_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_choice`
                  ADD PRIMARY KEY (`sc_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_group`
                  ADD PRIMARY KEY (`sg_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_question`
                  ADD PRIMARY KEY (`sq_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_terms_and_condition`
                  ADD PRIMARY KEY (`ct_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transferred`
                  ADD PRIMARY KEY (`tf_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transfer_booking`
                  ADD PRIMARY KEY (`tf_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transfer_contract`
                  ADD PRIMARY KEY (`tf_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transfer_ownership`
                  ADD PRIMARY KEY (`tr_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_unit_number`
                  ADD PRIMARY KEY (`un_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_unit_type`
                  ADD PRIMARY KEY (`unit_type_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_update_promotion`
                  ADD PRIMARY KEY (`up_id`);";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_booking`
                  MODIFY `bk_booking_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_building`
                  MODIFY `building_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_calendar`
                    MODIFY `cd_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_cancelation`
                  MODIFY `cc_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_cancelled_receipt`
                    MODIFY `cr_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_changed_receipt`
                  MODIFY `cr_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_contract`
                  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_contract_mapping`
                  MODIFY `cm_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_contract_promotion`
                  MODIFY `cp_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_fgf`
                  MODIFY `fgf_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_floor`
                  MODIFY `fl_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_installment`
                  MODIFY `im_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_booking_warning`
                  MODIFY `lt_id` int(6) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_contract_warning`
                  MODIFY `lt_id` int(6) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_referred`
                  MODIFY `lt_letter_id` int(6) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_letter_contract_warning`
                  MODIFY `lt_id` int(6) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_message_type`
                  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_overdue_remark`
                  MODIFY `or_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_payment`
                  MODIFY `pm_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_payment_terms`
                  MODIFY `pt_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_price`
                  MODIFY `pr_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_project`
                  MODIFY `pj_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_promotion`
                  MODIFY `pm_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_quotation`
                  MODIFY `qt_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_receipt_offical`
                  MODIFY `rc_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_receipt_temporary`
                  MODIFY `rc_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_room_status`
              MODIFY `rs_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_sms`
                  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_answer`
                  MODIFY `sa_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_choice`
                  MODIFY `sc_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_survey_question`
                  MODIFY `sq_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_terms_and_condition`
                  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transferred`
                  MODIFY `tf_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transfer_booking`
                  MODIFY `tf_id` int(6) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transfer_contract`
                  MODIFY `tf_id` int(6) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_transfer_ownership`
                  MODIFY `tr_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_unit_number`
                  MODIFY `un_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_unit_type`
                  MODIFY `unit_type_id` int(11) NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
        
        $str = "ALTER TABLE `tb_update_promotion`
                  MODIFY `up_id` int(11) unsigned NOT NULL AUTO_INCREMENT;";
        mysql_query($str);
    }
}

/* End of file project.php */
/* Location: ./application/controllers/project.php */