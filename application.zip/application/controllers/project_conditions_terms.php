<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_conditions_terms extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'condition';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_terms_and_condition');
		$data['condition'] = $this->tb_terms_and_condition->get_detail_by_id('1');
		$this->LoadView('Project_detail/Project_conditions_terms/project_conditions_terms_view',$data);
	}
	public function record(){
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();

		$userEdit = $this->user_id;
		$ct_detail = $this->input->post('textDescription');
		$data_update = array(
			'ct_detail' => $ct_detail
		);
		$this->load->model('tb_terms_and_condition');
		$this->tb_terms_and_condition->update($data_update,'1');

		////// KEEP LOG /////
		/////////////////////
		$data_log = array(
			'ct_id' => '1',
			'ct_detail' => $ct_detail,
			'ct_update_by' => $userEdit
		);
		$this->load->model('log_terms_and_condition');
		$this->log_terms_and_condition->record($data_log);
		//$this->pdb->trans_complete();
		
		if ($this->pdb->trans_status() === FALSE){
	       $this->pdb->trans_rollback();
	       alert_redirect('Update Terms and Conditions Fail','/project_conditions_terms/view');
		}
		else{
		   $this->pdb->trans_commit();
		   alert_redirect('Update Terms and Conditions Success','/project_conditions_terms/view');
		}
		
	}
}

/* End of file project_conditions_terms.php */
/* Location: ./application/controllers/project_conditions_terms.php */