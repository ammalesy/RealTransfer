<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Changereceipt extends NZ_Controller {
	var $title_page = 'Admin System';
    var $page_var   = 'changeReceipt';
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->change();
	}
    
    public function change()
    {
        $this->load->model('tb_building');
        $this->load->model('tb_changed_receipt');
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['buildinglist']   = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        
        $data['history'] = $this->tb_changed_receipt->getAllDetail();
        $this->LoadView('ChangeReceipt/change_receipt_view',$data);
    }
    
    public function cancel()
    {
        $this->load->model('tb_building');
        $this->load->model('tb_cancelled_receipt');
        $data['title'] = $this->title_page;
        $data['page'] = 'cancelReceipt';
        $data['buildinglist']   = $this->tb_building->fetch_all_building();
        $data['project_database_sel'] = $this->project_database_sel;
        
        $data['history'] = $this->tb_cancelled_receipt->getAllDetail();
        $this->LoadView('ChangeReceipt/cancel_receipt_view',$data);
    }
    
    public function payment($rcCode)
    {
        $unit = $this->input->post('unit');
        $reason = $this->input->post('reason');
        
        if(empty($rcCode) || empty($unit) || empty($reason)) {
            echo "<script>alert('Change receipt fail!');";
            echo "window.location.href = '".BASE_DOMAIN."changereceipt/change';</script>";
            exit;
        }
        
        $this->load->model('tb_receipt_offical');
        $reDetail  = $this->tb_receipt_offical->get_full_detail($rcCode);
        $definefee = $reDetail->rc_total_amount;
        $bkCode    = $reDetail->rc_booking_code;
        $ctCode    = $reDetail->rc_contract_code;
        $imCode    = $reDetail->rc_installment_code;
        $payFor    = $reDetail->rc_payfor;
        $this->load->model('tb_customer');
        $fullName = $this->tb_customer->get_fullname_of_receiptCustomerID($reDetail->rc_customer_id);
        
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['bkCode'] = $bkCode;
        $data['ctCode'] = $ctCode;
        $data['imCode'] = $imCode;
        $data['rcCode'] = $rcCode;
        $data['fullName'] = $fullName;
        $data['payFor'] = $payFor;
        $data['unit'] = $unit;
        $data['reason'] = $reason;
        
        $data['definefee'] =  $definefee;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $this->load->model('tb_receipt_offical');
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled();
        }
        
        $this->LoadView("ChangeReceipt/change_receipt_adding", $data);
    }

    public function changing()
    {

        $this->load->database();
        $this->pdb->trans_begin();
        $rcCode = $this->input->post('rcCode');
        $update = array('rc_status' => 'cancelled');
        $where  = array('rc_code'   => $rcCode);
        $this->load->model('tb_receipt_offical');
        $this->tb_receipt_offical->update_where($update, $where);
        $rcDetail = $this->tb_receipt_offical->get_one_by($where);

        $today = date('Y-m-d H:i:s');
        $sale = $this->user_id;
        $projectid = $this->project_id_sel;
        $this->load->model('tb_receipt_temporary');
        $newid = $this->tb_receipt_temporary->get_next_id();
        $tmpID = '';
        for ($i=strlen($newid); $i < 5 ; $i++) {
            $tmpID .= '0';
        }
        $tmpIDP = '';
        for ($i=strlen($projectid);$i<2;$i++)
            $tmpIDP .= '0';
        $newrcv = 'T'.$tmpIDP.$projectid.'-'.date('ymd').'-'.$tmpID.$newid;

        $receiptID = implode(',', $this->input->post('receiptID'));
        if(!empty($receiptID)) {
            $update = array('rc_status'=>'off');
            foreach(explode(',', $receiptID) as $receipt) {
                $this->tb_receipt_offical->update($update, $receipt);
            }
        }

        $remark = $this->input->post('Remark');
        $data_receipt = array(
            'rc_code'               => $newrcv,
            'rc_refer_form'         => $receiptID,
            'rc_customer_id'        => $rcDetail->rc_customer_id,
            'rc_payfor'             => $rcDetail->rc_payfor,
            'rc_booking_code'       => $rcDetail->rc_booking_code,
            'rc_contract_code'      => $rcDetail->rc_contract_code,
            'rc_installment_code'   => $rcDetail->rc_installment_code,
            'rc_installment_time'   => $rcDetail->rc_installment_time,
            'rc_total_amount'       => $rcDetail->rc_total_amount,
            'rc_staff_temporary'    => $sale,
            'rc_temporary_date'     => date('Y-m-d H:i:s'),
            'rc_remark'             => $remark,
            'rc_un_name'            => $rcDetail->rc_un_name
        );
        $this->tb_receipt_temporary->record($data_receipt);

        $this->load->model('tb_payment');
        $Type  = $this->input->post('Type');
        $type_payment = '';
        $pay_crcard = '';
        $pay_other = '';
        if(!empty($Type))
        {
            foreach($Type as $checkbox):
                if ( trim($checkbox) == 'Cash' )   $type_payment = 'yes';
                if ( trim($checkbox) == 'CrCard' ) $pay_crcard = 'yes';
                if ( trim($checkbox) == 'Other' )  $pay_other  = 'yes';              
             endforeach;
        }
        $cash_amount = $this->input->post('Cashamount');
        if($type_payment == 'yes') {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $cash_amount
            );
            $this->tb_payment->record($data_payment);
        }


        $crcard_bank            = $this->input->post('CardBank');
        $BankName               = $this->input->post('BankName');
        $credit_type_credit  = $this->input->post('CardType');
        $credit_approve_code = $this->input->post('ApproveCode');
        $crcard_no           = $this->input->post('Cardno');
        $expiremonth_ = $this->input->post('expiremonth');
        $expireyear_ = $this->input->post('expireyear');
        $crcard_amount  =    $this->input->post('Cardamount');
        $crcard_fname   =    $this->input->post('CardHolder');

        if($pay_crcard == 'yes') {
            $this->load->model('tb_bank');
            $this->load->library('encrypt');
            $bankCount = 0;
            for($i=0;$i<count($crcard_amount);$i++) {
                $crcard_date = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";                
                if($crcard_bank[$i] == 0) {
                    $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
                    if(empty($b_id)) {
                        $b_id = $this->tb_bank->get_next_id();
                        $data = array(
                            'b_id' => $b_id,
                            'bank_name_th' => $BankName[$bankCount]
                        );
                        $this->tb_bank->record($data);
                    }
                    $bankCount++;
                }else $b_id = $crcard_bank[$i];
                
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Credit',
                    'pm_amount' => $crcard_amount[$i],
                    'pm_cr_bank' => $b_id,
                    'pm_cr_type' => $credit_type_credit[$i],
                    'pm_cr_holder' => $crcard_fname[$i],
                    'pm_cr_number' => $this->encrypt->encode($crcard_no[$i]),
                    'pm_cr_approve_code' => $credit_approve_code[$i],
                    'pm_cr_expire' => $crcard_date
                );
               $this->tb_payment->record($data_payment);
            }
        }

        $other_by       =    $this->input->post('OtherBy');
        $other_amount   =    $this->input->post('Otheramount');
        $pm_check_number   =    $this->input->post('CheckNo');
        $pm_check_date     =    $this->input->post('CheckDate');
        $pm_check_bank     =    $this->input->post('CheckBank');
        if($pay_other == 'yes') {
            if($other_by == 'Check'){
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Check',
                    'pm_amount' => $other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank
                );
            }else
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $other_by,
                    'pm_amount' => $other_amount
                );
           $this->tb_payment->record($data_payment);
        }

        $unit   = $this->input->post('unit');
        $reason = $this->input->post('reason');
        $this->load->model('tb_changed_receipt');
        $data = array(
            'cr_offical_receipt' => $rcDetail->rc_code,
            'cr_temporary_receipt' => $rcDetail->rc_temp_code,
            'cr_new_temporary_receipt' => $newrcv,
            'cr_for' => $rcDetail->rc_payfor,
            'cr_reason' => $reason,
            'cr_unit' => $unit,
            'cr_staff' => $this->user_id
        );
        $this->tb_changed_receipt->record($data);

        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            echo "<script>alert('Change receipt fail!');";
            echo "window.location.href = '".BASE_DOMAIN."changereceipt/change';</script>";
        }else{
            $this->pdb->trans_commit();
            echo "<script>window.open('".BASE_DOMAIN."receipt/report/th/$newrcv','_blank');";
            echo "window.location.href = '".BASE_DOMAIN."changereceipt/change';</script>";
        }
    }
    
    public function cancelling($rcCode)
    {
        
        $this->load->database();
        $this->pdb->trans_begin();
        
        $this->load->model('tb_receipt_offical');
        $this->load->model('tb_cancelled_receipt');
        
        $rcDetail = $this->tb_receipt_offical->get_one_by(array('rc_code' => $rcCode));
        if($rcDetail->rc_payfor == 'Installment Fee') {
            $this->cancelInstallment($rcDetail);
        }else {
            echo "<script>alert('Cancel receipt $rcCode fail!');";
            echo "window.location.href = '".BASE_DOMAIN."changereceipt/cancel';</script>";
            exit;
        }
        
        $update = array('rc_status' => 'cancelled');
        $this->tb_receipt_offical->update_where($update, array('rc_code' => $rcCode));
        
        $sale = $this->user_id;
        $unit = $this->input->post('unit-number');
        $reason = $this->input->post('reason');
        
        $data = array(
            'cr_offical_code' => $rcDetail->rc_code,
            'cr_temp_code' => $rcDetail->rc_temp_code,
            'cr_payfor' => $rcDetail->rc_payfor,
            'cr_reason' => $reason,
            'cr_staff' => $sale,
            'cr_unit_id' => $unit
        );
        $this->tb_cancelled_receipt->record($data);
        
        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            echo "<script>alert('Cancel receipt $rcCode fail!');";
            echo "window.location.href = '".BASE_DOMAIN."changereceipt/cancel';</script>";
        }else{
            $this->pdb->trans_commit();
//            echo "<script>alert('Cancel receipt $rcCode Success.');";
            echo "<script>window.location.href = '".BASE_DOMAIN."changereceipt/cancel';</script>";
        }
    }
    
    function cancelInstallment($rcDetail)
    {
        $this->load->model('tb_installment');
        $imDetail = $this->tb_installment->get_by_code($rcDetail->rc_installment_code, $rcDetail->rc_contract_code);
        $update = array(
            'im_paid' => 'no',
            'im_confirm' => NULL,
            'im_received_date' => NULL
        );
        $this->tb_installment->update_where($update, array('im_id' => $imDetail->im_id));
    }
}
?>