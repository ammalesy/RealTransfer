<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Upload extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'upload';
	/**
	*
	*/
	function __construct() 
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->helper('download');
    }
    
	public function index()
	{
		$this->contract();
	}
	public function contract(){
//		$this->checkSessionTimeout();
        
        if ($this->get_user_permission()->pm_contract<1) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        } else {
            $data['title'] = $this->title_page;
            $data['page'] = $this->page_var.'Contract';
//    		$data['permission'] = $this->get_user_permission();
            $data['list_booking'] = $this->fetch_booking($this->project_id_sel);
            $this->LoadView('Upload/contract',$data);
        }
	}
	public function upload_pdf() {
		$ctcode = $this->input->post('ctcode');

		$folderName = 'pdf/project/'.$this->project_id_sel.'/contract';
//		echo "<script>console.log('$folderName')</script>";
		if(!is_dir($folderName))
        {
           mkdir($folderName,0777,TRUE);
        }

		$config['upload_path']     = $folderName.'/';
		$config['allowed_types']   = 'pdf';
        $config['file_name']       = $ctcode;
        $config['max_size']        = '10240';

		$this->load->library('upload', $config);
        $this->upload->initialize($config);
        if (!$this->upload->do_upload('pdf'))
        {
//            alert_redirect('Upload fail. please check file format.', '/upload/contract');
            echo "<script>alert('Upload fail. please check file format.'); window.location.href='".BASE_DOMAIN."upload/contract';</script>";
        }else{
            $file_details = $this->upload->data();
        	$data = array(
	    		'ct_pdf' => $folderName."/".$file_details['file_name']
	    	);
	    	$this->load->model('tb_contract');
	    	$this->tb_contract->update_where_equal_ct_code($data, $ctcode);
//	    	alert_redirect('Upload pdf success.', '/upload/contract');
            echo "<script>alert('Upload pdf success.'); window.location.href='".BASE_DOMAIN."upload/contract';</script>";
        }
	}
    private function fetch_booking($pj_id){

		$this->load->model('tb_booking');
		$list_booking = $this->tb_booking->fetch_all_BookingInfoContract_byProjectID($pj_id);
		foreach($list_booking as $aBooking):
			$aBooking->transferdate =  !empty($aBooking->tf_timestamp)?date('d/m/Y',strtotime($aBooking->tf_timestamp)):'';
//			$this->load->model('tb_customer_personal_info');
//			$aBooking->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($aBooking->tf_to_cus);

			$qcode = $aBooking->bk_quotation_code;
			$this->load->model('tb_quotation');
			$quotation = $this->tb_quotation->getDetail_by_id_withProjectTable($qcode);
			$aBooking->pj_name = $quotation->pj_name;

			$this->load->model('tb_building');
			$building = $this->tb_building->get_detail_building_by_building_id($quotation->qt_buliding_id);
			$aBooking->building_name = $building->building_name;

			$this->load->model('tb_unit_number');
			$unit_number = $this->tb_unit_number->get_detail_unit_by_un_id($quotation->qt_unit_number_id);
			$aBooking->un_name = $unit_number->un_name;
            $this->load->model('tb_contract_mapping');
            $aBooking->mapping = $this->tb_contract_mapping->getMapping($aBooking->ct_code);
            //echo "<script>console.log('$aBooking->mapping')</script>";
		endforeach;
		return $list_booking;
	}
}
?>