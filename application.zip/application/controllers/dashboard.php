<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$data = $this->load_dashboard_all();
		if(empty($title_page))
			$title_page = "Admin System";
		$data['title'] = $title_page;
//		$this->load->view('Dashboard/new_dashboard',$data);
		$this->LoadView('Dashboard/new_dashboard',$data);
	}
	public function all()
	{
		$data = $this->load_dashboard_all();
		$this->LoadView('Dashboard/all',$data);
	}
	private function load_new_dashboard(){

	}
	private function load_dashboard_all()
	{
		$this->load->model('tb_customer');
		$countidcus2 = $this->tb_customer->count_cus_id_with_flag('cus');
		$fullnamelastcus = $this->tb_customer->get_lastCustomer()->fullname;
		$countidleads = $this->tb_customer->count_cus_id_where("cus_flag != 'cus'");
		$lastLead = $this->tb_customer->get_lastLead();
		if($lastLead != NULL){
			$fullnamelastleads = $lastLead->fullname;
		}else{
			$fullnamelastleads = "";
		}
		
		$this->load->model('tb_customer_personal_info');
		$countidcus = $this->tb_customer_personal_info->count_pers_id_cus();

		$this->load->model('tb_booking');
		$bookingWaiting = $this->tb_booking->count_booking_code();
		$lastBookingContract = $this->tb_booking->get_last_bookingContract();
		$bookingcodelast= $lastBookingContract->bk_booking_code;
		$bookingcontractdatelast= $lastBookingContract->bk_contract_date;

		$this->load->model('tb_booking');
		$sumpricebooking = $this->tb_booking->get_sum_price_booking();
        $pricebooking = $sumpricebooking->Total_amount;
		
		$this->load->model('tb_quotation');
		$lastQuotationLeads = $this->tb_quotation->get_last_quotation_lead();
		$Quolast= $lastQuotationLeads->qt_code;
		$Quolastleadsid= $lastQuotationLeads->qt_leads_id;
		$fullnamelasteQuocus = $this->tb_customer->get_fullname_of_quotationID($Quolastleadsid);
		$QuoWaiting= $this->tb_quotation->count_qt_code();
        $buildingID = $lastQuotationLeads->qt_buliding_id;
	
		$this->load->model('tb_contract');
		$contractLastCusObj = $this->tb_contract->get_lastContract_customer();
		$Conlast= $contractLastCusObj->ct_code;
		$Conlastcusid= $contractLastCusObj->ct_cus_id;
		$fullnamelastConcus = $this->tb_customer->get_fullname_of_contractID($Conlastcusid);
		$ConWaiting= $this->tb_contract->count_ct_code();

		$this->load->model('tb_contract');
		$sumpricecontract = $this->tb_contract->get_sum_price_contract();
        $pricecontract = $sumpricecontract->Total_amount;

		$this->load->model('tb_unit_number');
		$totalavailable = $this->tb_unit_number->get_count_avai();


         $this->load->model('tb_user_personal_info');
 		 $user = $this->tb_user_personal_info->get_detail_personal($this->user_id);
 		 $userprofile = $user->user_pers_fname."  ".$user->user_pers_lname;
		
		$this->load->model('tb_contract');
		$countdatecon = $this->tb_contract->get_count_con();
		
		$this->load->model('tb_booking');
		$maxdatebook = $this->tb_booking->get_max_book_date();
		
		$this->load->model('tb_quotation');
		$maxdatequo = $this->tb_quotation->get_max_quo_date();

        $formatChart = 'line';
			$dateStart = date("Y-m-d");

			$timeShow = array(
				date("d/m",strtotime("-6 days",strtotime($dateStart))),
				date("d/m",strtotime("-5 days",strtotime($dateStart))),
				date("d/m",strtotime("-4 days",strtotime($dateStart))),
				date("d/m",strtotime("-3 days",strtotime($dateStart))),
				date("d/m",strtotime("-2 days",strtotime($dateStart))),
				date("d/m",strtotime("-1 days",strtotime($dateStart))),
				date("d/m",strtotime($dateStart)));

			$timesStart = array(
				date("Y-m-d",strtotime("-6 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-5 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-4 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-3 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-2 days",strtotime($dateStart))),
				date("Y-m-d",strtotime("-1 days",strtotime($dateStart))),
				date("Y-m-d",strtotime($dateStart)));

			$i = 0;
			foreach ($timesStart as $time) {
				$timeStart = $time; 
				$timeEnd = $time;

				$start = $timeStart.' 00:00:00';
				$end = $timeEnd. ' 23:59:59';

				$this->load->model('tb_chart');
				
					$getCount_cus = $this->tb_chart->get_count_quotation_by_date_report($start, $end);
					
				if($getCount_cus->count_cus != null)
					$count = $getCount_cus->count_cus;
				else
					$count = 0;
				if($time == date("Y-m-d",strtotime($dateStart)))
				{
					$count_cus .= $count;
					$xAxis .= '"'.$timeShow[$i].'"'; 
				}
				else
				{
					$count_cus .= $count.',';
					$xAxis .= '"'.$timeShow[$i].'"'.',';
				}
				++$i;
			}
				if($dateStart == $dateEnd)
					$date_show = date("d/m/Y",strtotime($dateStart));
				else
					$date_show = date("d/m/Y",strtotime("-6 days",strtotime($dateStart))).' - '.date("d/m/Y",strtotime($dateStart));


		$walkin = 0;
		$this->load->model('tb_customer');
		$getDetail_cus = $this->tb_customer->get_customer_lead();
        foreach($getDetail_cus as $detail_cus){
            //Media
            $cus_madia_type = $detail_cus->cus_media_type;
            $media_type = split(",", $cus_madia_type);
            
            for($numM=0;$numM<=sizeof($media_type);$numM++){
                if($media_type[$numM] == '1')    
                    $website += 1;
                else if($media_type[$numM] == '2')
                    $sms += 1;
                else if($media_type[$numM] == '3')
                    $online += 1;
                else if($media_type[$numM] == '4')
                    $poster += 1;
                else if($media_type[$numM] == '5')
                    $billboard += 1;
                else if($media_type[$numM] == '6')
                    $booth += 1;
                else if($media_type[$numM] == '7')
                    $friends += 1;
                else if($media_type[$numM] == '8')
                    $news += 1;
                else if($media_type[$numM] == '9')
                    $leaflet += 1;
                else if($media_type[$numM] == '10')
                    $others += 1;
            }
            //End 
            
            //Visit
            $cus_visit_type = $detail_cus->cus_visit_type;
            $visit_type = split(",", $cus_visit_type);
            
            for($numV=0;$numV<=sizeof($visit_type);$numV++){
                if($visit_type[$numV] == '1')    
                    $walkin += 1;
                else if($visit_type[$numV] == '2')
                    $callin += 1;
            }
            //End Visit
        }
	
		$this->load->model('tb_receipt_temporary');
		$lastReciptCusObj = $this->tb_receipt_temporary->get_last();
		$receiptWaiting = $this->tb_receipt_temporary->count_waiting_code();
		// print_r($lastReciptCusObj);
		if($lastReciptCusObj != NULL){
			$Recwaitlast= $lastReciptCusObj->rc_code;
			$Recwaitlastcusid= $lastReciptCusObj->bk_leads_id;
			
		}else{
			$Recwaitlast= "";
			$Recwaitlastcusid= "";
		}
		
        $typeOfMatrix = array('Sold','Available','Booked');
		$this->load->model('tb_unit_number');
        
        foreach($typeOfMatrix as $type){
            if($type == 'Sold'){
                $numOfType = $this->tb_unit_number->get_count_type_by_build_id_and_type($buildingID,$type);
                $countSold = $numOfType->num_status;
            }else if($type == 'Available'){
                $numOfType = $this->tb_unit_number->get_count_type_by_build_id_and_type($buildingID,$type);
                $countAvai = $numOfType->num_status;
//                 echo('<script>alert("'.$buildingID.'")</script>');  
            }else if($type == 'Booked'){
                $numOfType = $this->tb_unit_number->get_count_type_by_build_id_and_type($buildingID,$type);
                $countBook = $numOfType->num_status;
            }
           
        }

        $persofavai = ($countAvai/$totalavailable) * 100;
        
		$fullnamelastRecwaitcus = $this->tb_customer->get_fullname_of_receiptCustomerID($Recwaitlastcusid);
		$RecwaitWaiting= $this->tb_receipt_temporary->count_waiting_code();

		$data = array(
			'title' => $this->title_page,
			'countidcus' => $countidcus,
			'fullnamelastcus' => $fullnamelastcus,
			'countidleads' => $countidleads ,
			'fullnamelastleads' => $fullnamelastleads,
			'bookingWaiting' => $bookingWaiting,
			'lastBookingContract' => $lastBookingContract,
			'bookingcodelast' => $bookingcodelast,
			'bookingcontractdatelast' => $bookingcontractdatelast,
			'lastQuotationLeads' => $lastQuotationLeads,
			'Quolast' => $Quolast,
			'Quolastleadsid' => $Quolastleadsid,
			'fullnamelasteQuocus' => $fullnamelasteQuocus,
			'QuoWaiting' => $QuoWaiting,
			'Conlast' => $Conlast,
			'Conlastcusid' => $Conlastcusid,
			'fullnamelastConcus' => $fullnamelastConcus,
			'ConWaiting' => $ConWaiting,
			'Recwaitlast' => $Recwaitlast,
			'Recwaitlastcusid' => $Recwaitlastcusid,
			'fullnamelastRecwaitcus' => $fullnamelastRecwaitcus,
			'RecwaitWaiting' => $RecwaitWaiting,
			'page' => 'Dashboard',
			'receiptWaiting' => $receiptWaiting,
            'countSold' => $countSold,
            'countAvai' => $countAvai,
            'countBook' => $countBook,
            'pricebooking' => $pricebooking,
            'pricecontract' => $pricecontract,
			'website' => $website,
			'callin' => $callin,
			'walkin' => $walkin,
			'sms' => $sms,
			'online' => $online,
			'poster' => $poster,
			'billboard' => $billboard,
			'ebooth' => $booth,
			'friends' => $friends,
			'news' => $news,
			'leaflet' => $leaflet,
			'others' => $others,
			'format_chart' => $formatChart,
			'count_cus' => $count_cus,
			'xAxis' => $xAxis,
			'date_show' => $date_show,
			'rotation' => $rotation,
			'type' => $type,
			'sumavai' => $totalavailable,
			'userprofile' => $userprofile,
			'countdatecon' => $countdatecon,
			'maxdatebook' => $maxdatebook,
			'maxdatequo' => $maxdatequo,
			'persofavai' => $persofavai
		);

 		return $data;
		
	}
	
}

/* End of file dashboard.php */
/* Location: ./application/controllers/dashboard.php */