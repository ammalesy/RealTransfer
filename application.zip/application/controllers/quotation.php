<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Quotation extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Quotation';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{

		$this->view();

		// $data['script'] = "javascript: window.open('".BASE_URL."/quotation/view');";
		// $this->load->view('Quotation/redirect',$data);
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['list_quotation'] = $this->fetch_all_quotation();
		$this->LoadView('Quotation/quotation',$data);
	}
	public function adding($cusid)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->model('tb_customer_personal_info');
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo();
		$data['project_name_sel'] = $this->project_name_sel;
		$data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
        $data['cus_id'] = $cusid;
		$this->LoadView('Quotation/quotation_adding',$data);
	}
	public function checkprice($param)
    {
		if ($param =='report' && $this->input->post('leadsid') != 0) {

			$leads  =	$this->input->post('leadsid');
			$Project = 	$this->project_id_sel;
			$Building = $this->input->post('Building');
			$Floor = $this->input->post('Floor');
			$Number = $this->input->post('Number');
			$PaymentTerms = $this->input->post('PaymentTerms');
			$dateQuo = date("ymd"); 
			if($this->input->post('pro') != NULL){
				$promotiomQuo =implode(',', $this->input->post('pro'));
			}else{
				$promotiomQuo =0;
			}
			
			$qremark = $this->input->post('qremark');
			$pj_name = $this->project_name_sel;
			
			$this->load->model('tb_price');
			$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
			$pr_selling_sqm = $getPrice->pr_selling_sqm;
			$pr_asking_price = $getPrice->pr_asking_price;
		
			$pr_bottom_line	= floatval(str_replace(',', '', $getPrice->pr_bottom_line_for_internal));		
			$valueAllGift = 0;

	
			$today = $dateQuo;   
			$this->load->model('tb_promotion');
//			$getPromotion = $this->tb_promotion->fetchDiscountBySearchQuotation($promotiomQuo);
//            foreach ($getPromotion as $promotion) {
//                $valueAllGift += $promotion->pm_value;
//            }

			//$valueAllGift += $pm_value;
			//$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value;
			
			//$htmlDiscount = '';
            
//            $queryGift = $this->tb_promotion->fetchGiftBySearchQuotation($promotiomQuo);
//		 	foreach($queryGift as $aGift):
//		 		$valueAllGift += $aGift->pm_value;
//		 	endforeach;
            
            $getPromotion = $this->tb_promotion->fetchBySearchQuotation($promotiomQuo);
            foreach ($getPromotion as $promotion) {
                $valueAllGift += $promotion->pm_value;
            }
            
            $pr_asking_price1 = str_replace( ',', '', $pr_asking_price);
			$pricedisc = (float)intval($pr_asking_price1) -(float)$valueAllGift;
//            echo "pr_asking_price1 : ".(float)intval($pr_asking_price1);
//            echo "+++valueAllGift : ".(float)$valueAllGift;
//            echo "+++pr_bottom_line : ".$pr_bottom_line;
//            echo "+++pricedisc : ".$pricedisc;
//            echo "+++yoyo : ".$this->get_user_permission()->pm_quotation;
            //exit();
			// echo ($pricedisc.' And '.$valueAllGift.' And '.$pr_asking_price1);
			if (strpos($this->get_user_permission()->pm_quotation,'3') == false && $pricedisc < $pr_bottom_line) {
			 	echo "<script> alert('Can not create quotation, please remove some promotion');  history.back(); </script>";
                exit;
			}else{
				date_default_timezone_set('Asia/Bangkok');
				$today = date("Y-m-d H:i:s"); 
				$this->load->model('tb_quotation');
				$newid = $this->tb_quotation->get_new_id($Project);
				$tmp = strlen($newid);
				$tmpProjectid = strlen($Project);
				$tmpID = '';
				for ($i=$tmp; $i < 5 ; $i++) { 
					$tmpID .= '0';
				}
				$tmptmp = strlen($newid);
				$tmpIDP = '';
				for ($i=$tmpProjectid; $i < 2 ; $i++) { 
					$tmpIDP .= '0';
				}
				$dateQuo = date("ymd"); 
				$newid ='Q'.$tmpIDP.$Project.'-'.$dateQuo.'-'.$tmpID.''.$newid; 
		
				$sale = $this->user_id;

				////////////////////////////////////
				$this->load->model('tb_payment_terms');
				$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($PaymentTerms);
                $booking = $getPaymentTerms->pt_booking;
                $contract = $getPaymentTerms->pt_contract;
                $percent = $getPaymentTerms->pt_total_down_percent;
				
				$Arr_ask = explode(",", $getPrice->pr_asking_price);
				$ask_price = '';
				foreach ($Arr_ask as $value) {
					$ask_price .= $value;
				}

				$total = $percent*$ask_price/100 ;

				/*================================*/
				/*======= Transaction start ======*/
			 	/*================================*/
			 	$this->load->database();
			 	$this->pdb->trans_begin();
                
                $this->load->model('tb_project');
//                testestestsetsetsetsetsetsetsetsetsetsetsetsetset
                $getTotalmonth_temp = $this->tb_project->get_detail_project_selected($Project);

                $endYear = date('Y', strtotime($getTotalmonth_temp->pj_start_downpayment ));
                $curYear = date('Y');
                
                $endMonth = date('m', strtotime($getTotalmonth_temp->pj_start_downpayment ));
                $curMonth = date('m');
                
                if ((($endYear - $curYear) * 12) + ($endMonth - $curMonth) > 0) {
                    $curDate = date('Y-m-d', strtotime($getTotalmonth_temp->pj_start_downpayment."-1 month"));
                    
                } else {
                    $curDate = date('Y-m-d');
                }
                
                $endDate = strtotime($getTotalmonth_temp->pj_end_downpayment);
                
                $endYear = date('Y', $endDate);
                $curYear = date('Y', strtotime($curDate));
                
                $endMonth = date('m', $endDate);
                $curMonth = date('m', strtotime($curDate));
                
                $totalmonth_temp = (($endYear - $curYear) * 12) + ($endMonth - $curMonth);
//                testestestsetsetsetsetsetsetsetsetsetsetsetsetset
                
                $totalmonth = $getPaymentTerms->pt_down_payment_month;
                if($totalmonth == 0)
                {
                    $totalmonth = $totalmonth_temp;
                    
                }else if($totalmonth > $totalmonth_temp) {
                    echo "<script>
                        alert('Cannot use Payment term because total month incorrect');
                        history.back();
                    </script>";
                    exit;
                }
                // print_r('test'.$getTotalmonth_temp->pj_date_project);
				 if($getPaymentTerms->pt_ballon_payment == 'no') {
					$avg = ($total-$booking-$contract) / $totalmonth;
					$avg = ceil($avg/100)*100;
                    $totalDownPayment = ($avg * $totalmonth) + $booking + $contract;
					$data_quotation = array(
						'qt_code' => $newid,
						'qt_leads_id' => $leads,
						'qt_project_id' => $Project,
						'qt_buliding_id' => $Building,
						'qt_floor_id' => $Floor,
						'qt_unit_number_id' => $Number,
						'qt_sale_id' => $sale,
						'qt_payment_terms' => $PaymentTerms,
						'qt_date' => $today,
						'qt_promotion' => $promotiomQuo,
						'qt_remark' => $qremark,
						'qt_end_downpayment' => $getTotalmonth_temp->pj_end_downpayment,
						'qt_end_project' => $getTotalmonth_temp->pj_date_project,
						'qt_unit_price' => $ask_price,
                        'qt_total_down_payment' => $totalDownPayment,
                        'qt_total_down_percent' => $percent,
                        'qt_booking_fee' => $booking,
                        'qt_contract_fee' => $contract,
						'qt_avg_installment' => $avg,
						'qt_total_months' => $totalmonth
					);
				}else {      
                     $maxLoop = 20;
                     foreach($getPaymentTerms as $index=>$value) $Arr[$index] = $value;
                     for($i=1;$i<$maxLoop;$i++) {
                         $installment[$i]        = $Arr['pt_installment'.$i];
                         $months_installment[$i] = $Arr['pt_months_installment'.$i];
                     }
                     
                     $totalInstallment = 0;
                     $totalInstallmentMonth = 0;
                     $index = 0;
                     $lastMonth = 0;
                     foreach($installment as $key=>$value) {
                         if(empty($value)){
                             break;
                         }
                         $index = $key;
                         $month = explode('-', $months_installment[$key]);
                         $totalInstallment += ($month[1] - $month[0]+1)*$value;
                         $totalInstallmentMonth += $month[1] - $month[0]+1;
                         $lastMonth = $month[1];
                     }
                     
                     if($totalmonth - $totalInstallmentMonth > 0) {
                         $installment[$index+1] = ($total - $totalInstallment - $booking - $contract)/($totalmonth - $totalInstallmentMonth);
                         $lastMonth+=1;
                         $months_installment[$index+1] = $lastMonth.'-'.$totalmonth;
                         $installment[$index+1] = ceil($installment[$index+1]/100)*100;
                         $totalDownPayment = $installment[$index+1]*($totalmonth - $totalInstallmentMonth);
                     }else {
                         $totalDownPayment = 0;
                     }
                     
                     $totalDownPayment += $totalInstallment + $booking + $contract;
                     
                     if($installment[$index+1] < 0) {
                         echo "<script>
                            alert('Cannot use Payment term because system cannot calculate last fee');
                            history.back();
                         </script>";
                         exit;
                     }

                     $data_quotation = array(
						'qt_code' => $newid,
						'qt_leads_id' => $leads,
						'qt_project_id' => $Project,
						'qt_buliding_id' => $Building,
						'qt_floor_id' => $Floor,
						'qt_unit_number_id' => $Number,
						'qt_sale_id' => $sale,
						'qt_payment_terms' => $PaymentTerms,
						'qt_date' => $today,
						'qt_promotion' => $promotiomQuo,
						'qt_remark' => $qremark,
						'qt_end_downpayment' => $getTotalmonth_temp->pj_end_downpayment,
						'qt_end_project' => $getTotalmonth_temp->pj_date_project,
						'qt_unit_price' => $ask_price,
                        'qt_total_down_payment' => $totalDownPayment,
                        'qt_total_down_percent' => $percent,
                        'qt_booking_fee' => $booking,
                        'qt_contract_fee' => $contract,
						'qt_total_months' => $totalmonth
                     );
                     for($i=1;$i<=$maxLoop;$i++):
                        $data_quotation['qt_installment'.$i] = $installment[$i];
                        $data_quotation['qt_months_installment'.$i] = $months_installment[$i];
                     endfor;
				}
				$this->tb_quotation->record($data_quotation);

				$data_room_sts = array(
					'rs_unit_number' => $Number,
					'rs_cus_id' => $leads,
					'rs_status' => 'Quotation',
					'rs_staff_id' => $sale
				);
				$this->load->model('tb_room_status');
				$this->tb_room_status->record($data_room_sts);
				/*=======================================*/
			 	/*======= check status transaction ======*/
				/*=======================================*/
				if ($this->pdb->trans_status() === FALSE){
		     		$this->pdb->trans_rollback();
				}
				else{
				  	$this->pdb->trans_commit();
                    echo "<script>  window.open('".BASE_DOMAIN."quotation/report/$newid','_blank'); </script>";
				}
			}
           alert_redirect('add quotation success.','/quotation/view');
            // echo "<script>  window.location.href = '".BASE_DOMAIN."quotation/view' </script>";
		}else{
	 		echo "<script> alert('Can not create quotation, Please check customer');   history.back(); </script>";	
		}
	}
//	public function report($quotation_id){
//		$qid = $quotation_id;
//		$this->load->library('currency');
//		$this->load->library('dateformat');
//		////////////////////
//		$this->load->model('tb_quotation');
//		$getQuo = $this->tb_quotation->getDetail_by_id($qid);
//        $Project = $getQuo->qt_project_id;
//        $dateQuo = $getQuo->qt_date;
//		$leads  = $getQuo->qt_leads_id;
//        $PaymentTerms = $getQuo->qt_payment_terms;
//        $qt_booking_fee = $getQuo->qt_booking_fee;
//        $qt_contract_fee = $getQuo->qt_contract_fee;
//        $qt_total_months = $getQuo->qt_total_months;
//        $qt_avg_installment = $getQuo->qt_avg_installment;
//        $qt_total_down_payment = $getQuo->qt_total_down_payment;
//        $qt_unit_price = $getQuo->qt_unit_price;
//        $TotalInstallmentFee = $qt_total_down_payment - ($qt_booking_fee + $qt_contract_fee);
//        $balloonDownMonth = $getQuo->qt_total_months;
//        foreach($getQuo as $key=>$value) $Arr[$key] = $value;
//        for($i=1;$i<21;$i++) $balloon[$i] = $Arr['qt_months_installment'.$i];
//        for($i=1;$i<21;$i++) $balloonTemp[$i] = split("-", $balloon[$i]);
//        for($i=1;$i<21;$i++) $balloon[$i] = ($balloonTemp[$i][0]==$balloonTemp[$i][1])?$balloonTemp[$i][0]:$balloonTemp[$i][0]." - ".$balloonTemp[$i][1];
//        for($i=1;$i<21;$i++) $balloonAmount[$i] = $Arr['qt_installment'.$i];
//        for($i=1;$i<21;$i++) $num[$i] = $balloonTemp[$i][1] - $balloonTemp[$i][0] + 1;
//        for($i=1;$i<21;$i++) $installmentBall[$i] = $balloonAmount[$i] * $num[$i];
//        for($i=1;$i<21;$i++) $lastBalloon[$i] = $balloonTemp[$i];
//        $totalInstallmentBall = 0;
//        for($i=1;$i<21;$i++) $totalInstallmentBall += $installmentBall[$i];
//        $rem = $getQuo->qt_remark;
//        if($rem != null)
//            $htmlRemark = '<td><pre class="tab"><li> '.$rem.'</li></pre></td>';
//		$Number = $getQuo->qt_unit_number_id;
//        $Building = $getQuo->qt_buliding_id;
//        $floorID = $getQuo->qt_floor_id;
//		$promotiomQuo =$getQuo->qt_promotion;
//        
//        $this->load->model('tb_user_personal_info');
//        $getSale = $this->tb_user_personal_info->get_detail_by_user_pers_id($getQuo->qt_sale_id);
//        $nameSale = $getSale->user_pers_fname.' '.$getSale->user_pers_lname;
//
//		$this->load->model('tb_project');
//		$getProject = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($Project);
//        $get = $this->tb_project->get_detail_project_ignoreStatusActive($Project);
//        $pj_name = $get->pj_name;
//		$pj_img = $get->pj_image;
//        $companyName = $getProject->pj_company_name;
//
//		$this->load->model('tb_customer');
//		$getLeads = $this->tb_customer->get_detail_leads_withOut_oppotunityStage($leads);
//        $pers_prefix = $getLeads->pers_prefix;
//		$ld_fnames = $getLeads->pers_fname;
//		$ld_lname = $getLeads->pers_lname;
//        $ld_mobile	= $getLeads->pers_mobile;
//        $ld_tel = $getLeads->pers_tel;
//		$ld_mail = $getLeads->pers_email;
//		
//		$this->load->model('tb_building');
//		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
//		$building_name 	= $getBuilding->building_name;
//
//		$this->load->model('tb_unit_number');
//		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
//        $un_name = $getRoom->un_name;
//		$unit_type_name = $getRoom->unit_type_name;
//		$unit_type_area_sqm = $getRoom->unit_type_area_sqm;
//        $room_type_name		= $getRoom->room_type_name;
//		$un_direction		= $getRoom->un_direction;
//        
//        $this->load->model('tb_floor');
//        $getFloor = $this->tb_floor->get_detail_by_id($floorID);
//        $floorName = $getFloor->fl_name;
//		
//		$this->load->model('tb_price');
//		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
//		$pr_selling_sqm = $getPrice->pr_selling_sqm;
//		$pr_asking_price = $getPrice->pr_asking_price;
//        
//		$this->load->model('tb_terms_and_condition');
//		$getConditionTerms = $this->tb_terms_and_condition->get_detail_by_id('1');
//		$ConditionTerms	= $getConditionTerms->ct_detail;
//        
//        $this->load->model('tb_payment_terms');
//        $getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($PaymentTerms);
//        $Balloon = $getPaymentTerms->pt_ballon_payment;
//        
//        $TotalInstallmentFee = $qt_total_down_payment - ($qt_booking_fee + $qt_contract_fee);
//			
//        for($i=1;$i<21;$i++){
//            if(!empty($balloonAmount[$i]))
//                $balloonDetail .= '
//                <tr>
//                    <td width="50px">&nbsp;</td>
//                    <td width="500px" valign="top">Installment (งวดที่) '.$balloon[$i] .'</td>
//                    <td width="150px" align="right" valign="top">'.number_format($balloonAmount[$i] ,2).'</td>
//                    <td width="107px" valign="top">Baht/Month</td>
//                </tr>
//                ';
//        }
//        
//        if ($Balloon=='no'){
//            $InstallmentDetail = '
//            <tr>
//                <td width="50px" valign="top">&nbsp;</td>
//                <td width="450px" valign="top">Installment Fee : Down Payment '.$qt_total_months.' months (ผ่อนดาวน์  '.$qt_total_months .' เดือน)</td>
//                <td width="150px" align="right" valign="top">'.number_format($qt_avg_installment ,2).'</td>
//                <td width="107px" valign="top">Baht/Month</td>
//            </tr>
//            <tr>
//                <td width="50px" valign="top">&nbsp;</td>
//                <td width="450px" valign="top">Total Installment Fee  </td>
//                <td width="150px" align="right" valign="top">'.number_format($TotalInstallmentFee ,2).'</td>
//                <td width="107px" valign="top">Baht </td>
//            </tr>
//            <tr>
//                <td colspan="4"></td>
//            </tr>
//            <tr>
//                <td width="50px" valign="top">&nbsp;</td>
//                <td width="450px" valign="top">Total Down Payment </td>
//                <td width="150px" align="right" valign="top">'.number_format($qt_total_down_payment,2).'</td>
//                <td width="107px" valign="top">Baht</td>
//            </tr>
//            ';
//        }
//        else{
//            $InstallmentDetail = '
//            <tr>
//                <td colspan="4"><b>Total Down Payment : '.$balloonDownMonth.' Installments</b></td>
//            </tr>
//            '.$balloonDetail.'
//            <tr>
//                <td width="50px">&nbsp;</td>
//                <td width="450px">Total Installment Fee  </td>
//                <td width="150px" align="right">'.number_format($TotalInstallmentFee ,2).'</td>
//                <td width="107px">Baht </td>
//            </tr>
//            <tr>
//                <td colspan="4"><br></td>
//            </tr>
//            <tr>
//                <td width="50px">&nbsp;</td>
//                <td width="450px">Total Down Payment </td>
//                <td width="150px" align="right">'.number_format($qt_total_down_payment,2).'</td>
//                <td width="107px">Baht</td>
//            </tr>
//            ';
//        }
//        
//        //list installment
//        if ($Balloon == 'no' )
//        {
//            $halfTotalDownMonth=ceil($qt_total_months/2);
//            for($i=1;$i<=$qt_total_months;$i++){
//                if($i<=$halfTotalDownMonth)
//                    $htmlTotalDownMonth .= ' 
//                                <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ '.number_format($qt_avg_installment,2).' บาท </b><br></pre>
//                    ';
//                else if(($i>$halfTotalDownMonth))
//                    $htmlTotalDownMonth2 .= '
//                                <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ '.number_format($qt_avg_installment,2).' บาท </b><br></pre>
//                    ';
//            }
//        }
//        else
//        {
//            $halfTotalDownMonth=ceil($qt_total_months/2);
//            for($i=1;$i<=$qt_total_months;$i++) {
//                if($balloonTemp[$i][1] != null && $i<=$balloonTemp[$i][1]) {
//                    if($i<=$halfTotalDownMonth)
//                        $htmlTotalDownMonth .= ' 
//                                    <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ '.number_format($balloonAmount[0],2).' บาท </b><br></pre>
//                        ';
//                    else if(($i>$halfTotalDownMonth))
//                        $htmlTotalDownMonth2 .= '
//                                    <pre class="tab"><b>งวดที่ '.$i.' ชำระงวดละ '.number_format($balloonAmount[0],2).' บาท </b><br></pre>
//                        ';
//                }
//            }
//        }
//        
//        $name = $pers_prefix.' '.$ld_fnames.' '.$ld_lname;
//		////////////////////
//        $data['pj_name'] = $pj_name;
//        $data['qid'] = $qid;
//  		$data['html'] = $html;
//        $data['name'] = $name;
//        $data['dateQuo'] = $dateQuo;
//        $data['dateformat'] = $this->dateformat;
//        $data['Currency'] = $this->currency;
//        $data['ld_mobile'] = $ld_mobile;
//        $data['ld_tel'] = $ld_tel;
//        $data['ld_mail'] = $ld_mail;
//        $data['un_name'] = $un_name;
//        $data['unit_type_name'] = $unit_type_name;
//        $data['floorName'] = $floorName;
//        $data['building_name'] = $building_name;
//        $data['unit_type_area_sqm'] = $unit_type_area_sqm;
//        $data['pr_selling_sqm'] = $pr_selling_sqm;
//        $data['qt_unit_price'] = $qt_unit_price;
//        $data['qt_booking_fee'] = $qt_booking_fee;
//        $data['qt_contract_fee'] = $qt_contract_fee;
//        $data['qt_total_months'] = $qt_total_months;
//        $data['qt_avg_installment'] = $qt_avg_installment;
//        $data['TotalInstallmentFee'] = $TotalInstallmentFee;
//        $data['qt_total_down_payment'] = $qt_total_down_payment;
//        $data['htmlTotalDownMonth'] = $htmlTotalDownMonth;
//        $data['htmlTotalDownMonth2'] = $htmlTotalDownMonth2;
//        $data['room_type_name'] = $room_type_name;
//        $data['un_direction'] = $un_direction;
//        $data['InstallmentDetail'] = $InstallmentDetail;
//        $data['ld_fnames'] = $ld_fnames;
//        $data['ld_lname'] = $ld_lname;
//        $data['companyName'] = $companyName;
//        $data['nameSale'] = $nameSale;
//        $data['htmlRemark'] = $htmlRemark;
//
//
//
//
//        
//         
//  		$data['permission'] = $this->get_user_permission();
//		$this->load->view('Quotation/quotation_report',$data);
//	}
	public function booking($qid){

		$this->load->model('tb_quotation');
		$objResult = $this->tb_quotation->getDetail_by_id_withStatus_ON($qid);
		if($objResult != NULL){
			$projectid 	= $objResult->qt_project_id;
			$bulidingid = $objResult->qt_buliding_id;
			$numberid 	= $objResult->qt_unit_number_id;
			$qt_leads_id = $objResult->qt_leads_id;
				

			$this->load->model('tb_project');
			$get1 = $this->tb_project->get_detail_project_ignoreStatusActive($projectid);

			$this->load->model('tb_unit_number');
			$objResultRoom = $this->tb_unit_number->get_room_NotAvailable($numberid,$bulidingid);
			if($objResultRoom != NULL){
				alert_redirect('unit number unavailable','/quotation/view');
			}else{
				$this->load->model('tb_customer');
				$cusflag = $this->tb_customer->getCustomerFlag_by_id($qt_leads_id);		
			
				if ($cusflag =='cus') {
					//redirect("/booking/adding/".$qid."");
                    echo "<script>window.location.href = '".BASE_DOMAIN."booking/adding/$qid';</script>";
				} else {
                    echo "<script>
                                if (confirm(\"Please Add Customer Information First\") == true) {
                                    window.location.href = '".BASE_DOMAIN."customer/editingFormBooking/".$qt_leads_id."/".$qid."';
                                }else {
                                    window.location.href = '".BASE_DOMAIN."quotation/view';
                                }
                            </script>";
//					alert_redirect("Please Add Customer Information First","/customer/editingFormBooking/".$qt_leads_id."/".$qid."");						
				}
			}
		}else{
			alert_redirect('unit number unavailable','/quotation/view');	
		}
	}
    public function bookingcontract($qid){

		$this->load->model('tb_quotation');
		$objResult = $this->tb_quotation->getDetail_by_id_withStatus_ON($qid);
		if($objResult != NULL){
			$projectid 	= $objResult->qt_project_id;
			$bulidingid = $objResult->qt_buliding_id;
			$numberid 	= $objResult->qt_unit_number_id;
			$qt_leads_id = $objResult->qt_leads_id;
				

			$this->load->model('tb_project');
			$get1 = $this->tb_project->get_detail_project_ignoreStatusActive($projectid);

			$this->load->model('tb_unit_number');
			$objResultRoom = $this->tb_unit_number->get_room_NotAvailable($numberid,$bulidingid);
			if($objResultRoom != NULL){
				alert_redirect('unit number unavailable','/quotation/view');
			}else{
				$this->load->model('tb_customer');
				$cusflag = $this->tb_customer->getCustomerFlag_by_id($qt_leads_id);		
			
				if ($cusflag =='cus') {
					//redirect("/booking/adding/".$qid."");
                    echo "<script>window.location.href = '".BASE_DOMAIN."bookingcontract/adding/$qid';</script>";
				} else {
                    echo "<script>
                                if (confirm(\"Please Add Customer Information First\") == true) {
                                    window.location.href = '".BASE_DOMAIN."customer/editingFormBooking/".$qt_leads_id."/".$qid."';
                                }else {
                                    window.location.href = '".BASE_DOMAIN."quotation/view';
                                }
                            </script>";
//					alert_redirect("Please Add Customer Information First","/customer/editingFormBooking/".$qt_leads_id."/".$qid."");						
				}
			}
		}else{
			alert_redirect('unit number unavailable','/quotation/view');	
		}
	}
	/**
	* -------------------------------------
	* Scope [PRIVATE METHOD]
	* -------------------------------------
	*/
	//////// QUOTATION ////////////
	///////////////////////////////
	private function fetch_all_quotation(){
		$this->load->model('tb_quotation');
		$this->load->model('tb_user_personal_info');
		$list_quotation = $this->tb_quotation->fetch_all_quotation($this->project_id_sel);
		foreach($list_quotation as $aQuotation):
			$Number	=	$aQuotation->qt_unit_number_id;	
			$Building =	$aQuotation->qt_buliding_id;
			$databasenameQuo = $aQuotation->pj_datebase_name;

			$building = $this->get_detail_building_by_building_id($Building);
			$aQuotation->building_name = $building->building_name;

			$unitNumber = $this->get_detail_unit_by_un_id($Number);
			$aQuotation->un_name = $unitNumber->un_name;
			$aQuotation->un_status_room = $unitNumber->un_status_room;

			$issued = $this->tb_user_personal_info->get_detail_personal($aQuotation->qt_sale_id);

			if($issued == NULL){
				$aQuotation->issued = NULL;
			}else{
				$aQuotation->issued = $issued->user_pers_fname." ".$issued->user_pers_lname;	
			}

			$booking = $this->get_detail_by_bk_quotation_code($aQuotation->qt_code);
			if($booking == NULL){
				$aQuotation->booking = NULL;
			}else{
				$aQuotation->booking = $booking;
			}
		endforeach;
		return $list_quotation;
	}
	private function get_detail_building_by_building_id($building_id){
		$this->load->model('tb_building');
		return $this->tb_building->get_detail_building_by_building_id($building_id);
	}
	private function get_detail_unit_by_un_id($un_id){
		$this->load->model('tb_unit_number');
		return $this->tb_unit_number->get_detail_unit_by_un_id($un_id);
	}
	private function get_detail_by_bk_quotation_code($bk_quotation_code){
		$this->load->model('tb_booking');
		return $this->tb_booking->get_detail_by_bk_quotation_code($bk_quotation_code);
	}

	public function report($qid){
        $this->load->library('dateformat');
        $this->load->library('currency');
        
        $this->load->model('tb_quotation');
        $this->load->model('tb_customer');
        $this->load->model('tb_project');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_terms_and_condition');
        $this->load->model('tb_user_personal_info');
        $this->load->model('tb_price');
        
        ////////////// QUOTATION ///////////////////
        $getQuotation = $this->tb_quotation->getDetail_by_id($qid);
        /////////////// PROJECT ////////////////////
        $getProject   = $this->tb_project->get_detail_project_ignoreStatusActive($getQuotation->qt_project_id);
        $projectImage = $getProject->pj_image;
        $getProject   = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($getQuotation->qt_project_id);
        ////////// TERMS AND CONDITION /////////////
        $terms_and_condition = $this->tb_terms_and_condition->get_detail();
        $customer = $this->tb_customer->get_detail_by_id_joinInfo_AddressInfo($getQuotation->qt_leads_id)[0];
        ///////////////// UNIT /////////////////////
        $unit = $this->tb_unit_number->get_detail_unit($getQuotation->qt_unit_number_id);
        /////////////// SELLER /////////////////////
        $user = $this->tb_user_personal_info->get_detail_by_user_pers_id($getQuotation->qt_sale_id);
        $seller = $user->user_pers_fname.'&nbsp;&nbsp;'.$user->user_pers_lname;
        /////////////// PRICE //////////////////////
        $getPrice = $this->tb_price->get_detail_by_buildingID_UnitNumberID($getQuotation->qt_buliding_id,$getQuotation->qt_unit_number_id);
        /////////////// INSTALLMENT /////////////////////
        if(!empty($getQuotation->qt_avg_installment))
            $installment = $getQuotation->qt_avg_installment;
        else {
            $installment = $getQuotation->qt_installment1;
            $balloonMonth = '';
            $balloonFee = 0;
            $quotationArr = (array)$getQuotation;
            for($i=2;$i<21;$i++) {
                if(!empty($quotationArr['qt_installment'.$i]) && $installment != $quotationArr['qt_installment'.$i]) {
                    $arr = explode('-',$quotationArr['qt_months_installment'.$i]);
                    for($j=$arr[0];$j<=$arr[1];$j++)
                        $balloonMonth .= empty($balloonMonth)?$j:','.$j;
                    $balloonFee = $quotationArr['qt_installment'.$i];
                }
            }
        }
            
        /////////////////////////////////////////////////
        
        $data['permission'] = $this->get_user_permission();
        $data['quotation'] = $getQuotation;
        $data['customer'] = $customer;
        $data['unit'] = $unit;
        $data['getProject'] = $getProject;
        $data['projectImage'] = $projectImage;
        $data['seller'] = $seller;
        $data['installment'] = $installment;
        $data['balloonMonth'] = $balloonMonth;
        $data['balloonFee'] = $balloonFee;
        $data['terms_and_condition'] = $terms_and_condition;
        $data['getPrice'] = $getPrice;
        
		$this->load->view('Quotation/quotation_report',$data);
    }
    
    function edit($qtCode)
    {
        $this->load->model("tb_customer");
        $this->load->model("tb_quotation");
        $qtDetail = $this->tb_quotation->getDetail_by_id_withStatus_ON($qtCode);
        $leadName = $this->tb_customer->get_fullname_of_quotationID($qtDetail->qt_leads_id);
        
        $data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['qtCode'] = $qtCode;
		$data['leadName'] = $leadName;
		$data['qtDetail'] = $qtDetail;
		$this->LoadView('Quotation/quotation_edit',$data);
    }
    
    function update()
    {
        $this->load->database();
        $this->pdb->trans_begin();
        $data = array(
            'qt_unit_price'         => $this->input->post("qt_unit_price"),
            'qt_total_down_payment' => $this->input->post("qt_total_down_payment"),
            'qt_booking_fee'        => $this->input->post("qt_booking_fee"),
            'qt_contract_fee'       => $this->input->post("qt_contract_fee"),
            'qt_total_months'       => $this->input->post("qt_total_months")
        );
        if(!empty($this->input->post("qt_avg_installment"))) {
            $data['qt_avg_installment'] = $this->input->post("qt_avg_installment");
        }else {
            $data['qt_months_installment'] = $this->input->post("qt_months_installment");
            $data['qt_installment']        = $this->input->post("qt_installment");
        }
        
        $qtCode = $this->input->post("qtCode");
        $this->load->model("tb_quotation");
        $this->tb_quotation->update($data, $qtCode);
        
        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            echo "<script> alert('Edited Fail!'); window.location.href = '".BASE_DOMAIN."quotation/view' </script>";
        }
        else{
            $this->pdb->trans_commit();
            echo "<script> alert('Edited Success!'); window.open('".BASE_DOMAIN."quotation/report/$qtCode','_blank'); window.location.href = '".BASE_DOMAIN."quotation/view' </script>";
        }
    }
}

/* End of file customer.php */
/* Location: ./application/controllers/customer.php */