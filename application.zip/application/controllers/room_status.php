<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Room_status extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Roomstatus';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view_building(); 
	}
	public function view_building(){
//		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        if (strpos($this->get_user_permission()->pm_room_sts,'2') != false) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
		$this->load->model('tb_building');
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
//		$data['permission'] = $this->get_user_permission();
		$data['list_building'] = $this->tb_building->fetch_all_building();
//		$this->load->view('Room_status/room_status_building',$data);
		$this->LoadView('Room_status/room_status_building',$data);
	}
	public function view($bid)
	{
        if (strpos($this->get_user_permission()->pm_room_sts,'2') === false) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');		
        }
		$data['title'] = $this->title_page;
		$data['bid'] = $bid;
		$data['page'] = $this->page_var;
//		$data['permission'] = $this->get_user_permission();
		$this->load->model('tb_unit_number');
		$data['list_unit_number'] = $this->tb_unit_number->fetch_FullUnitDetail_by_un_build_id($bid);

//		$this->load->view('Room_status/room_status_view',$data);	
		$this->LoadView('Room_status/room_status_view',$data);	
	}
	public function matrix($bid) {
        if (strpos($this->get_user_permission()->pm_room_sts,'2') != false) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
		$data['title'] = "Matrix View";
		$data['bid'] = $bid;
		$data['page'] = $this->page_var;
//		$data['permission'] = $this->get_user_permission();
        $typeOfMatrix = array('Sold','Available','Booked');
		$this->load->model('tb_unit_number');
        
        foreach($typeOfMatrix as $type){
            if($type == 'Sold'){
                $numOfType = $this->tb_unit_number->get_count_type_by_build_id_and_type($bid,$type);
                $countSold = $numOfType->num_status;
            }else if($type == 'Available'){
                $numOfType = $this->tb_unit_number->get_count_type_by_build_id_and_type($bid,$type);
                $countAvai = $numOfType->num_status;
//                 echo('<script>alert("'.$countAvai.'")</script>');  
            }else if($type == 'Booked'){
                $numOfType = $this->tb_unit_number->get_count_type_by_build_id_and_type($bid,$type);
                $countBook = $numOfType->num_status;
            }
           
        }
        $data['countSold'] = $countSold;
        $data['countAvai'] = $countAvai;
        $data['countBook'] = $countBook;
		$data['floor_max_room'] = $this->tb_unit_number->get_max_room_by_un_build_id($bid);
		$data['list_unit'] = $this->tb_unit_number->fetch_FullUnitDetail_by_un_build_id($bid);

//		$this->load->view('Room_status/room_status_matrix',$data);
		$this->LoadView('Room_status/room_status_matrix',$data);
	}
	public function matrixView($rid,$bid,$fl,$typ,$area){
		$data['title'] = "Matrix View";
		$data['rid'] = $rid;
		$data['bid'] = $bid;
		$data['fl'] = $fl;
		$data['typ'] = $typ;
		$data['area'] = $area;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();

		$this->load->model('tb_room_status');
		$this->load->model('tb_unit_number');
		$this->load->model('tb_customer_personal_info');
		$list_room = $this->tb_room_status->fetch_fullDetailroom_by_rs_unit_number($rid);
		foreach($list_room as $get):
			$get->unit_number = $this->tb_unit_number->get_detail_unit_by_un_id($get->rs_unit_number);
			$get->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerArr($get->rs_cus_id);
		endforeach;
		
		$data['list_room'] = $list_room;

		$this->load->view('Room_status/room_status_matrix_view',$data);
	}
	public function detail($rid,$bid,$fl,$typ,$area)
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['bid'] = $bid;
		$data['fl'] = $fl;
		$data['typ'] = $typ;
		$data['area'] = $area;
		$this->load->model('tb_room_status');
		$this->load->model('tb_unit_number');
		$this->load->model('tb_customer_personal_info');
		$list_room = $this->tb_room_status->fetch_fullDetailroom_by_rs_unit_number($rid);
		//print_r($list_room);
		foreach($list_room as $room):
			$room->unit_number = $this->tb_unit_number->get_detail_unit_by_un_id($room->rs_unit_number);
			$room->customer = $this->tb_customer_personal_info->get_detail_by_pers_id_withCustomerTable($room->rs_cus_id);
		endforeach;

		$data['list_room'] = $list_room;
	
		$this->load->model('tb_building');
		$data['building'] = $this->tb_building->get_detail_building_by_building_id($bid);
		$this->load->view('Room_status/room_status_detail',$data);	
	}
}

/* End of file room_status.php */
/* Location: ./application/controllers/room_status.php */