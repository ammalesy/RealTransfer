<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_floor extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Floor';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_floor');
		$data['list_floor'] = $this->tb_floor->fetch_all_floor_withBuildingTable();
		$this->LoadView('Project_detail/Project_floor/project_floor_view',$data);
	}
	public function editing($fl_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_building');
		$this->load->model('tb_floor');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$data['floor'] = $this->tb_floor->get_detail_by_id_withBuildingTable($fl_id);
		$this->LoadView('Project_detail/Project_floor/project_floor_editing',$data);
	}
	public function update($fl_id)
	{
		$this->load->model('tb_floor');
		$this->load->model('log_floor');
		$floor = $this->input->post('floor');
		$Building = $this->input->post('Building');
		$Name = $this->input->post('Name');
		$Info = $this->input->post('Info');
		$userEdit = $this->user_id;
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		/*============================*/
		/*====== SELECTED IMAGE ======*/
		/*============================*/
		if(!$this->isEmptyFile('Image'))
		{
			$result_upload = $this->upload_image('Image',"project/".$this->project_id_sel."/floor/".$fl_id,time());
			if($result_upload['error_status'] == FALSE){
				$data_update = array(
				'fl_name' => $Name,
				'fl_info' => $Info,
				'fl_build_id' => $Building,
				'fl_image' => $result_upload['image_url']
				);
				$this->tb_floor->update($data_update,$fl_id);

				$flObj = $this->tb_floor->get_detail_by_id($fl_id);
				$data_log = array(
					'fl_id' => $flObj->fl_id,
					'fl_build_id' => $flObj->fl_build_id,
					'fl_name' => $flObj->fl_name,
					'fl_info' => $flObj->fl_info,
					'fl_sts_active' => $flObj->fl_sts_active,
					'fl_update_by' => $userEdit,
					'fl_image' => $result_upload['image_url']
				);		
				$this->log_floor->record($data_log);
			}
		/*============================*/
		/*==== DON'T SELECT IMAGE ====*/
		/*============================*/
		}else{
			$data_update = array(
				'fl_name' => $Name,
				'fl_info' => $Info,
				'fl_build_id' => $Building
			);
			$this->tb_floor->update($data_update,$fl_id);

			$flObj = $this->tb_floor->get_detail_by_id($fl_id);
			$data_log = array(
				'fl_id' => $flObj->fl_id,
				'fl_build_id' => $flObj->fl_build_id,
				'fl_name' => $flObj->fl_name,
				'fl_info' => $flObj->fl_info,
				'fl_sts_active' => $flObj->fl_sts_active,
				'fl_update_by' => $userEdit
			);		
			$this->log_floor->record($data_log);
		}
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Edit Floor Fail','/project_floor/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Edit Floor Success','/project_floor/view');
		}
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_building');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$this->LoadView('Project_detail/Project_floor/project_floor_adding',$data);
	}
	public function record(){
		$this->load->model('tb_floor');
		$Name = $this->input->post('Name');
		$Info = $this->input->post('Info');
		
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		foreach($Name  as $index => $position ):
			
			$Building = $this->input->post('Building');
			$name_add = $Name[$index] ;
			$info_add = $Info[$index] ;

			
			$data = array(
				'fl_id' => '0',
				'fl_build_id' => $Building,
				'fl_name' => $name_add,
				'fl_info' => $info_add
			);
			
			$new_id = $this->tb_floor->record($data);
			$path_upload = "project/".$this->project_id_sel."/floor/".$new_id;
			$name_file = time();
			$result_upload = $this->upload_multiple_image('Image',$index,$path_upload,$name_file);	
			if($result_upload['error_status'] == FALSE){
				$data_update = array('fl_image' => $result_upload['image_url']);
				$this->tb_floor->update($data_update,$new_id);

			}
			
		endforeach;
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Add Floor Fail','/project_floor/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Add Floor Success','/project_floor/view');
		}
	}
	public function deleting($fl_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'fl_sts_active' => 'off'
		);
		$this->load->model('tb_floor');
		$this->tb_floor->update($data_delete,$fl_id);
		
		alert_redirect('Delete Floor Success','/project_floor/view');
	}
}

/* End of file project_building.php */
/* Location: ./application/controllers/project_building.php */