<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_payment_terms extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Payment Terms';
    var $page_new = 'New Payment Terms';
    var $page_edit = 'Edit Payment Terms';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
        $data['head_title'] = $this->page_new;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_payment_terms');
		$data['list_payment'] = $this->tb_payment_terms->fetch_all();
		$this->LoadView('Project_detail/Project_payment_terms/project_payment_terms_view',$data);
	}
	public function editing($pt_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
        $data['heading'] = 'Edit';
		$data['page'] = $this->page_var;
        $data['head_title'] = $this->page_edit;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
		$data['ptid'] = $pt_id;

        $this->load->model('tb_room_type');
        $data['list_room_type'] = $this->tb_room_type->fetch_all();
		$this->load->model('tb_payment_terms');
		$data['payment'] = $this->tb_payment_terms->get_detail_active_by_id($pt_id);
        $data['action'] = 'update';
		$this->LoadView('Project_detail/Project_payment_terms/project_payment_terms_form',$data);
	}
	public function update($pt_id)
	{
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
	 	
		$this->load->model('tb_payment_terms');
		$this->load->model('log_payment_terms');
		$ptName				= $this->input->post('ptName');
        $roomType			= $this->input->post('roomType');
		$Down 				= $this->input->post('Down');
		$Booking 			= $this->input->post('Booking');
		$Contract 			= $this->input->post('Contract');
		$DownPaymentMonth 	= $this->input->post('DownPaymentMonth');
        $Ballon 			= ($this->input->post('Ballon')=='yes')?'yes':'no';
		$maxLoop = 19;
        for($i=1;$i<=$maxLoop;$i++):
            $Market[$i]		= $this->input->post('Market'.$i);
            $BallonMonth[$i]= $this->input->post('BallonMonth'.$i);
        endfor;
		$expired 			= $this->input->post('yyyy').'-'.$this->input->post('mm').'-'.$this->input->post('dd');
		$userEdit 			= $this->user_id;

		$temp = '';
		$checkMonth = TRUE;
        if($Ballon == 'yes') {
            foreach ($BallonMonth as $key=>$Month){
                if(!empty($Month)) {
                    $index = explode('-', $Month);
                    if(count($index) < 2 || count($index) > 2 || $index[1] < $index[0]) {
                        $checkMonth = FALSE;
                        break;
                    }
                    for($i=$index[0];$i<=$index[1];$i++){
                        if(empty($temp[$i]))
                            $temp[$i] = $Market[$key];
                        else {
                            $checkMonth = FALSE;
                            break;
                        }
                    }
                }else {
                    $Market[$key]       = NULL;
                    $BallonMonth[$key]  = NULL;
                }
                if(!$testMonth)
                    break;
            }
        }
		if ($checkMonth) {
            //// KEEP LOG ////
			/////////////////
			$pObj = $this->tb_payment_terms->get_detail_by_id($pt_id);
			$data_log = array(
				'pt_id'                 => $pObj->pt_id,
				'pt_name'               => $pObj->pt_name,
                'pt_room_type_id'       => $pObj->pt_room_type_id,
				'pt_total_down_percent' => $pObj->pt_total_down_percent,
				'pt_booking'            => $pObj->pt_booking,
				'pt_contract'           => $pObj->pt_contract,
				'pt_down_payment_month' => $pObj->pt_down_payment_month,
				'pt_installment1'       => $pObj->pt_installment1,
                'pt_months_installment1'=> $pObj->pt_months_installment1,
                'pt_installment2'       => $pObj->pt_installment2,
                'pt_months_installment2'=> $pObj->pt_months_installment2,
                'pt_installment3'       => $pObj->pt_installment3,
                'pt_months_installment3'=> $pObj->pt_months_installment3,
                'pt_installment4'       => $pObj->pt_installment4,
                'pt_months_installment4'=> $pObj->pt_months_installment4,
				'pt_installment5'       => $pObj->pt_installment5,
                'pt_months_installment5'=> $pObj->pt_months_installment5,
                'pt_installment6'       => $pObj->pt_installment6,
                'pt_months_installment6'=> $pObj->pt_months_installment6,
                'pt_installment7'       => $pObj->pt_installment7,
                'pt_months_installment7'=> $pObj->pt_months_installment7,
                'pt_installment8'       => $pObj->pt_installment8,
                'pt_months_installment8'=> $pObj->pt_months_installment8,
				'pt_installment9'       => $pObj->pt_installment9,
                'pt_months_installment9'=> $pObj->pt_months_installment9,
                'pt_installment10'       => $pObj->pt_installment10,
                'pt_months_installment10'=> $pObj->pt_months_installment10,
				'pt_installment11'       => $pObj->pt_installment11,
                'pt_months_installment11'=> $pObj->pt_months_installment11,
                'pt_installment12'       => $pObj->pt_installment12,
                'pt_months_installment12'=> $pObj->pt_months_installment12,
                'pt_installment13'       => $pObj->pt_installment13,
                'pt_months_installment13'=> $pObj->pt_months_installment13,
                'pt_installment14'       => $pObj->pt_installment14,
                'pt_months_installment14'=> $pObj->pt_months_installment14,
				'pt_installment15'       => $pObj->pt_installment15,
                'pt_months_installment15'=> $pObj->pt_months_installment15,
                'pt_installment16'       => $pObj->pt_installment16,
                'pt_months_installment16'=> $pObj->pt_months_installment16,
                'pt_installment17'       => $pObj->pt_installment17,
                'pt_months_installment17'=> $pObj->pt_months_installment17,
                'pt_installment18'       => $pObj->pt_installment18,
                'pt_months_installment18'=> $pObj->pt_months_installment18,
				'pt_installment19'       => $pObj->pt_installment19,
                'pt_months_installment19'=> $pObj->pt_months_installment19,
				'pt_date_expired'       => $pObj->pt_date_expired,
				'pt_sts_active'         => $pObj->pt_sts_active,
				'pt_update_by'          => $userEdit
			);
			$this->log_payment_terms->record($data_log);
            
			if($Ballon == 'yes') {
                $data_update = array(
                    'pt_name' => $ptName,
                    'pt_room_type_id' => $roomType,
                    'pt_total_down_percent' => $Down,
                    'pt_booking' => $Booking,
                    'pt_contract' => $Contract,
                    'pt_down_payment_month' => $DownPaymentMonth,
                    'pt_ballon_payment' => $Ballon,
                    'pt_date_expired' => $expired
                );
                for($i=1;$i<=$maxLoop;$i++):
                    $data_adding['pt_installment'.$i] = $Market[$i];
                    $data_adding['pt_months_installment'.$i] = $BallonMonth[$i];
                endfor;
            }else {
                $data_update = array(
                    'pt_name' => $ptName,
                    'pt_room_type_id' => $roomType,
                    'pt_total_down_percent' => $Down,
                    'pt_booking' => $Booking,
                    'pt_contract' => $Contract,
                    'pt_down_payment_month' => $DownPaymentMonth,
                    'pt_ballon_payment' => $Ballon,
                    'pt_date_expired' => $expired
                );
            }
			$this->tb_payment_terms->update($data_update,$pt_id);

			if ($this->pdb->trans_status() === FALSE){
		       	$this->pdb->trans_rollback();
		   		alert_redirect('Edit Payment Terms Fail','/project_payment_terms/view');
			}
			else{
			   	$this->pdb->trans_commit();
			   	alert_redirect('Edit Payment Terms Success','/project_payment_terms/view');
			}
			
		}else alert_redirect('Edit Ballon Month is Fail','/project_payment_terms/view');
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
        $data['heading'] = 'Add';
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;
        $this->load->model('tb_room_type');
        $data['list_room_type'] = $this->tb_room_type->fetch_all();
        $data['action'] = 'record';
		$this->LoadView('Project_detail/Project_payment_terms/project_payment_terms_form',$data);
	}
	public function record(){
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();

		$ptName				= $this->input->post('ptName');
        $roomType       	= $this->input->post('roomType');
		$Down 				= $this->input->post('Down');
		$Booking 			= $this->input->post('Booking');
		$Contract 			= $this->input->post('Contract');
		$DownPaymentMonth 	= $this->input->post('DownPaymentMonth');
		$Ballon 			= ($this->input->post('Ballon')=='yes')?'yes':'no';
        $maxLoop = 19;
        for($i=1;$i<=$maxLoop;$i++):
            $Market[$i]		= $this->input->post('Market'.$i);
            $BallonMonth[$i]= $this->input->post('BallonMonth'.$i);
        endfor;
		$expired 			= $this->input->post('yyyy').'-'.$this->input->post('mm').'-'.$this->input->post('dd');

        $temp = '';
		$checkMonth = TRUE;
        if($Ballon == 'yes') {
            foreach ($BallonMonth as $key=>$Month){
                if(!empty($Month)) {
                    $index = explode('-', $Month);
                    if(count($index) < 2 || count($index) > 2 || $index[1] < $index[0]) {
                        $checkMonth = FALSE;
                        break;
                    }
                    for($i=$index[0];$i<=$index[1];$i++){
                        if(empty($temp[$i]))
                            $temp[$i] = $Market[$key];
                        else {
                            $checkMonth = FALSE;
                            break;
                        }
                    }
                }else {
                    $Market[$key]       = NULL;
                    $BallonMonth[$key]  = NULL;
                }
                if(!$testMonth)
                    break;
            }
        }
		if ($checkMonth) {
            if($Ballon == 'yes') {
                $data_adding = array(
                    'pt_name' => $ptName,
                    'pt_room_type_id' => $roomType,
                    'pt_total_down_percent' => $Down,
                    'pt_booking' => $Booking,
                    'pt_contract' => $Contract,
                    'pt_down_payment_month' => $DownPaymentMonth,
                    'pt_ballon_payment' => $Ballon,
                    'pt_date_expired' => $expired
                );
                for($i=1;$i<=$maxLoop;$i++):
                    $data_adding['pt_installment'.$i] = $Market[$i];
                    $data_adding['pt_months_installment'.$i] = $BallonMonth[$i];
                endfor;
            }else {
                $data_adding = array(
                    'pt_name' => $ptName,
                    'pt_room_type_id' => $roomType,
                    'pt_total_down_percent' => $Down,
                    'pt_booking' => $Booking,
                    'pt_contract' => $Contract,
                    'pt_down_payment_month' => $DownPaymentMonth,
                    'pt_ballon_payment' => $Ballon,
                    'pt_date_expired' => $expired
                );
            }
			$this->load->model('tb_payment_terms');
			$this->tb_payment_terms->record($data_adding);

			if ($this->pdb->trans_status() === FALSE){
		       	$this->pdb->trans_rollback();
		   		alert_redirect('Add Payment Terms Fail','/project_payment_terms/view');
			}
			else{
			   	$this->pdb->trans_commit();
			   	alert_redirect('Add Payment Terms Success','/project_payment_terms/view');
			}

			
		}else{
			alert_redirect('Ballon Month is not complete','/project_payment_terms/adding');
		}

	}
	public function deleting($pt_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'pt_sts_active' => 'off'
		);
		$this->load->model('tb_payment_terms');
		$this->tb_payment_terms->update($data_delete,$pt_id);
		
		alert_redirect('Delete Payment terms Success','/project_payment_terms/view');
	}
}

/* End of file project_payment_terms.php */
/* Location: ./application/controllers/project_payment_terms.php */