<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_unit_number extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'number';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_unit_number');
		$data['list_unit_number'] = $this->tb_unit_number->fetch_full_unit_number();
		$this->LoadView('Project_detail/Project_unit_number/project_unit_number_view',$data);
	}
	public function editing($fl_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_building');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$this->LoadView('Project_detail/Project_unit_number/project_unit_number_editing',$data);
	}
	public function update(){
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		$this->load->model('tb_unit_type');
		$this->load->model('tb_floor');
		$this->load->model('tb_unit_number');
		$this->load->model('log_unit_number');
		$csv_mimetypes = array(
		    'text/csv',
		    'text/plain',
		    'application/csv',
		    'text/comma-separated-values',
		    'application/excel',
		    'application/vnd.ms-excel',
		    'application/vnd.msexcel',
		    'text/anytext',
		    'application/octet-stream',
		    'application/txt',
		);
		if (!in_array($_FILES['projectFile']['type'], $csv_mimetypes)) {
			alert_redirect('Format File Invalid','/project_unit_number/editing');
		}
		$flagInsert = TRUE;
		$strCSV[] = "";
		$tmpdate = date("Y_m_d_H_i_s");
		$Str_file = explode(".",$_FILES['projectFile']['name']);  
		$new_name="unit_number_".$tmpdate.".".$Str_file['1'];
		if(move_uploaded_file($_FILES["projectFile"]["tmp_name"],"csv/".$new_name)){
		
			$objCSV = fopen("csv/".$new_name, "r");

			$count = 0;
			$Building = $this->input->post('Building');
			$arr=array();
		 	while (($objArr = fgetcsv($objCSV, 500000, ",")) !== FALSE) {
		
			 	if ($count>0) {
					$row1 = 0;
					$row2 = 0;
					$row3 = 0;
					$typename = $objArr[3];
					$unit_type = $this->tb_unit_type->get_detail_with_unit_type_name($typename);
					if($unit_type != NULL){
						$row1 = 1;
					}
					
					$floorname = $objArr[2];
					$floor = $this->tb_floor->get_detail_by_idAndName($Building,$floorname);
					if($floor != NULL){
						$row2 = 1;
					}

					if($objArr[0] !='' ){
													
						if (isset($arr[$objArr[0]])){
							$flagInsert = FALSE;
							break ;
						}else{
							$flagInsert = TRUE;
							$arr[$objArr[0]] = $objArr[0];
						}						
						
						if($row2>0 && $row1>0  ){
							$flagInsert = TRUE;
						}else{
						
							$flagInsert = FALSE;
							break ;
						}
						$unitname =	$objArr[0];
						$unit_number = $this->tb_unit_number->get_detail_by_idAndName($Building,$unitname);
						if($unit_number != NULL){						
							$row3 = 1;
						}
					
						if($row3>0){

							$flagInsert = TRUE;
							
						}else{
							$flagInsert = FALSE;
							break ;
						}

						$list_value_update[] = array(
							'un_build_id' => $Building,
							'un_floor_id' => $floor->fl_id,
							'un_unit_type_id' => $unit_type->unit_type_id, 
							'un_name' => $objArr[0], 
							'un_number' => $objArr[1], 
							'un_direction' => $objArr[4], 
							'un_view' => $objArr[5]
						);
						$list_where[] = "un_id = '".$unit_number->un_id."'";

						$objUnit = $this->tb_unit_number->get_detail_unit_by_un_id($unit_number->un_id);
						$list_log[] = array(
							'un_id' => $objUnit->un_id,
							'un_build_id' => $Building,
							'un_floor_id' => $floor->fl_id,
							'un_unit_type_id' => $unit_type->unit_type_id,
							'un_name' => $objArr[0],
							'un_number' => $objArr[1],
							'un_direction' => $objArr[4],
							'un_view' => $objArr[5],
							'un_status_room' => $objUnit->un_status_room,
							'un_sts_active' => $objUnit->un_sts_active,
							'un_update_by' => $this->user_id
						);
					}
				}
				$count++;
		 	} /////// END While loop /////
		 	fclose($objCSV);
		} /////// END If Upload csv /////
		if ($flagInsert) {
			$i = 0;
			foreach ($list_value_update as  $value):
				$this->tb_unit_number->update_where($value,$list_where[$i]);	
				$i++;
			endforeach;

			foreach ($list_log as  $log_value):

				$this->log_unit_number->record($log_value);	
			endforeach;
			/*=======================================*/
		 	/*======= check status transaction ======*/
			/*=======================================*/
			if ($this->pdb->trans_status() === FALSE){
	     		$this->pdb->trans_rollback();
	 			alert_redirect('Update Unit Number Fail','/project_unit_number/view');
			}
			else{
			  	$this->pdb->trans_commit();
			   	alert_redirect('Update Unit Number Success','/project_unit_number/view');
			}
			
		}else{
			alert_redirect('Cannot update this file. Please check the validity.','/project_unit_number/editing');	
		}
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_building');
		$data['list_building'] = $this->tb_building->fetch_all_building();
		$this->LoadView('Project_detail/Project_unit_number/project_unit_number_adding',$data);
	}
	public function record(){
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		$this->load->model('tb_unit_type');
		$this->load->model('tb_floor');
		$this->load->model('tb_unit_number');
		$csv_mimetypes = array(
		    'text/csv',
		    'text/plain',
		    'application/csv',
		    'text/comma-separated-values',
		    'application/excel',
		    'application/vnd.ms-excel',
		    'application/vnd.msexcel',
		    'text/anytext',
		    'application/octet-stream',
		    'application/txt',
		);
		if (!in_array($_FILES['projectFile']['type'], $csv_mimetypes)) {
			alert_redirect('Format File Invalid','/project_unit_number/adding');
		}
		$flagInsert = TRUE;
		$strCSV[] = "";
		$tmpdate = date("Y_m_d_H_i_s");
		$Str_file = explode(".",$_FILES['projectFile']['name']);  
		$new_name="unit_number_".$tmpdate.".".$Str_file['1'];
		if(move_uploaded_file($_FILES["projectFile"]["tmp_name"],"csv/".$new_name)){
		
			$objCSV = fopen("csv/".$new_name, "r");

			$count = 0;
			$Building = $this->input->post('Building');
            print_r( $building);
			$arr=array();
		 	while (($objArr = fgetcsv($objCSV, 1000, ",")) !== FALSE) {
		
			 	if ($count>0) {
					$row1 = 0;
					$row2 = 0;
					$row3 = 0;
					$typename = $objArr[3];
					$unit_type = $this->tb_unit_type->get_detail_with_unit_type_name($typename);
					if($unit_type != NULL){
						$row1 = 1;
					}
					
					$floorname = $objArr[2];
					$floor = $this->tb_floor->get_detail_by_idAndName($Building,$floorname);
					if($floor != NULL){
						$row2 = 1;
					}

					if($objArr[0] !='' ){
													
						if (isset($arr[$objArr[0]])){
							$flagInsert = FALSE;
							break ;
						}else{
							$flagInsert = TRUE;
							$arr[$objArr[0]] = $objArr[0];
						}						
						
						if($row2>0 && $row1>0  ){
							$flagInsert = TRUE;
						}else{
						
							$flagInsert = FALSE;
							break ;
						}
						$unitname =	$objArr[0];
						$unit_number = $this->tb_unit_number->get_detail_by_idAndName($Building,$unitname);
						if($unit_number != NULL){						
							$row3 = 1;
						}
					
						if($row3>0){
						
							$flagInsert = FALSE;
							break ;
							
						}else{
							$flagInsert = TRUE;
						}

						$list_value_insert[] = array(
							'un_build_id' => $Building,
							'un_name' => $objArr[0],
							'un_number' => $objArr[1], 
							'un_floor_id' => $floor->fl_id, 
							'un_unit_type_id' => $unit_type->unit_type_id, 
							'un_direction' => $objArr[4], 
							'un_view' => $objArr[5]
						);
					}
				}
				$count++;
		 	} /////// END While loop /////
		 	fclose($objCSV);
		} /////// END If Upload csv /////
		if ($flagInsert) {
			foreach ($list_value_insert as  $value):
				$this->tb_unit_number->record($value);	
			endforeach;
			/*=======================================*/
		 	/*======= check status transaction ======*/
			/*=======================================*/
			if ($this->pdb->trans_status() === FALSE){
	     		$this->pdb->trans_rollback();
	 			alert_redirect('Add Unit Number Fail','/project_unit_number/view');
			}
			else{
			  	$this->pdb->trans_commit();
			   	alert_redirect('Add Unit Number Success'.$building.'test','/project_unit_number/view');
			}
			
		}else{
			alert_redirect('Cannot add this file. Please check the validity.','/project_unit_number/adding');	
		}
	}
	public function deleting($un_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'un_sts_active' => 'off'
		);
		$this->load->model('tb_unit_number');
		$this->tb_unit_number->update_where($data_delete,"un_id = '".$un_id."'");
		
		alert_redirect('Delete Unit Number Success','/project_unit_number/view');
	}
	public function download_csv(){
		$this->load->helper('download');
		$data = file_get_contents("csvTemplate/templateUnitNumber.xlsx"); 
		$name = 'templateUnitNumber.xlsx';
		force_download($name, $data);
	}
}

/* End of file project_unit_number.php */
/* Location: ./application/controllers/project_unit_number.php */