<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Calendar extends NZ_Controller {
	
	var $title_page = 'Admin System';
	var $page_var = 'Calendar';
	
	function __construct() {
        parent::__construct();
    }
    
	public function index() {
		$this->view();
	}
    
	public function view() {
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
        
		$this->load->view('Calendar/calendar_view',$data);
	}
    
    function record($title, $start, $end, $url) {
        $data = array(
            "cd_title" => urldecode($title),
            "cd_start" => $start,
            "cd_user_id" => $this->user_id
        );
        $data["cd_end"] = empty($end)?NULL:$end;
        $data["cd_url"] = empty($url)?NULL:$url;
        
        $this->load->model('tb_calendar');
        $id = $this->tb_calendar->record($data);
        
        $data = array("id" => $id);
        echo json_encode($data);
    }
    
    function update($id, $title, $start, $end, $url) {
        $data = array(
            "cd_title" => urldecode($title),
            "cd_start" => $start,
            "cd_user_id" => $this->user_id
        );
        $data["cd_end"] = empty($end)?NULL:$end;
        $data["cd_url"] = empty($url)?NULL:$url;
        
        $this->load->model('tb_calendar');
        $id = $this->tb_calendar->update($id, $data);
        
        $data = array("id" => $id);
        echo json_encode($data);
    }
    
    function remove($id) {
        $this->load->model('tb_calendar');
        $this->tb_calendar->update($id, array('cd_status'=>'remove'));   
    }
    
    function json() {
        $this->load->model('tb_calendar');
        $data = (array)$this->tb_calendar->jsonEvent();
        
        echo json_encode($data);
    }
    
    /*
    CREATE TABLE IF NOT EXISTS `tb_calendar` (
    `cd_id` int(11) NOT NULL,
      `cd_title` text NOT NULL,
      `cd_start` DATE NOT NULL,
      `cd_end` DATE DEFAULT NULL,
      `cd_url` text,
      `cd_user_id` int(11) NOT NULL,
      `cd_status` VARCHAR(10) NOT NULL DEFAULT 'on',
      `cd_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
    
    ALTER TABLE `tb_calendar`
     ADD PRIMARY KEY (`cd_id`);
    
    ALTER TABLE `tb_calendar`
    MODIFY `cd_id` int(11) NOT NULL AUTO_INCREMENT;
    */
}
?>