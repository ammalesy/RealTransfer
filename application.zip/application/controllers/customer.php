<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Customer';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_customer'] = $this->fetch_customer();
        $data['userid'] = $this->user_id;
//		$data['list_remark_cus'] = $this->fetch_remark_cus();
		$this->LoadView('Customer/customer',$data);
	}
	public function adding()
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_nationality'] = $this->fetch_all_nationality();
		$list_countries = $this->fetch_all_countries();
		$list_provinces = $this->FetchAllProvince('return');
		$list_districts = $this->FetchAllDistrict('return');
		$list_sub_districts = $this->FetchAllSubDistrict('return');
		$list_postcodes = $this->FetchAllPostCode();

		$countries = array();
		$provinces = array();
		$districts = array();
		$subDistricts = array();
		$postcodes = array();

		foreach($list_countries as $aCountries) {
	        $country = array(
	        	'label' => $aCountries->country_name,
	        	'val' => $aCountries->country_id);
	        $countries[] = $country;
	    }
	    $countries = json_encode($countries);

	    foreach ($list_provinces as $_list_provinces) {
	        $province = $_list_provinces->pv_name_th;
	        $provinces[] = $province;
	    }
	    $provinces = json_encode($provinces);

	    foreach ($list_districts as $_list_districts) {
	        $district = $_list_districts->d_name_th;
	        $districts[] = $district;
	    }
	    $districts = json_encode($districts);

	    foreach ($list_sub_districts as $_list_sub_districts) {
	        $subDistrict = $_list_sub_districts->sd_name_th;
	        $subDistricts[] = $subDistrict;
	    }
	    $subDistricts = json_encode($subDistricts);

	    foreach ($list_postcodes as $_list_postcodes) {
	        $postcode = $_list_postcodes->pc_code;
	        $postcodes[] = $postcode;
	    }
    	$postcodes = json_encode($postcodes);

	    $data['countries'] = $countries;
	    $data['provinces'] = $provinces;
	    $data['districts'] = $districts;
	    $data['subDistricts'] = $subDistricts;
	    $data['postcodes'] = $postcodes;

		$this->LoadView('Customer/customer_form',$data);
	}
	public function editing($cid)
	{
        $cusDetail = $this->get_detail_customer($cid);
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['customer'] = $cusDetail;
		$data['list_nationality'] = $this->fetch_all_nationality();
		$data['list_countries'] = $this->fetch_all_countries();
		$data['cid'] = $cid;
		$data['qid'] = null;
		$comma = '';
		$this->load->model('tb_province');
		$provinces = $this->tb_province->fetch_all_province();
		foreach($provinces as $row):
			$province .= $comma.'{value: "'.$row->pv_id.'",label: "'.$row->pv_name_th.'"}';
			if($comma==='') $comma = ',';
		endforeach;
		$data['province'] = '['. $province. ']';
        $province = '<option value="">------- Select ------</option>';
        foreach($provinces as $row):
			$province .= '<option>'.$row->pv_name_th.'</option>';
		endforeach;
		$data['optionProvince'] = $province;
        $dobArr = explode('-', $cusDetail->pers_dob);
        // print_r($cusDetail);exit;
        // $dobArr[0] += 543;
        $dob = implode('-', $dobArr);
        $data['dob'] = $dob;


		$list_countries = $this->fetch_all_countries();
		$list_provinces = $this->FetchAllProvince('return');
		$list_districts = $this->FetchAllDistrict('return');
		$list_sub_districts = $this->FetchAllSubDistrict('return');
		$list_postcodes = $this->FetchAllPostCode();

		$countries = array();
		$provinces = array();
		$districts = array();
		$subDistricts = array();
		$postcodes = array();

		foreach($list_countries as $aCountries) {
	        $country = (object)array(
	        	'label' => $aCountries->country_name,
	        	'val' => $aCountries->country_id);
	        $countries[] = $country;
	    }
	    $countries = json_encode($countries);

	    foreach ($list_provinces as $_list_provinces) {
	        $province = $_list_provinces->pv_name_th;
	        $provinces[] = $province;
	    }
	    $provinces = json_encode($provinces);

	    foreach ($list_districts as $_list_districts) {
	        $district = $_list_districts->d_name_th;
	        $districts[] = $district;
	    }
	    $districts = json_encode($districts);

	    foreach ($list_sub_districts as $_list_sub_districts) {
	        $subDistrict = $_list_sub_districts->sd_name_th;
	        $subDistricts[] = $subDistrict;
	    }
	    $subDistricts = json_encode($subDistricts);

	    foreach ($list_postcodes as $_list_postcodes) {
	        $postcode = $_list_postcodes->pc_code;
	        $postcodes[] = $postcode;
	    }
    	$postcodes = json_encode($postcodes);

	    $data['countries'] = $countries;
	    $data['provinces'] = $provinces;
	    $data['districts'] = $districts;
	    $data['subDistricts'] = $subDistricts;
	    $data['postcodes'] = $postcodes;
		$this->LoadView('Customer/customer_form',$data);
	}
	public function editingFormBooking($cid,$qid)
	{
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['customer'] = $this->get_detail_customer($cid);
		$data['list_nationality'] = $this->fetch_all_nationality();
		$data['list_countries'] = $this->fetch_all_countries();
		$data['cid'] = $cid;
		$data['qid'] = $qid;
		$comma = '';
		$this->load->model('tb_province');
		$provinces = $this->tb_province->fetch_all_province();
		foreach($provinces as $row):
			$province .= $comma.'{value: "'.$row->pv_id.'",label: "'.$row->pv_name_th.'"}';
			if($comma==='') $comma = ',';
		endforeach;
		$data['province'] = '['. $province. ']';
        $province = '<option value="">------- Select ------</option>';
        foreach($provinces as $row):
            $selected = (trim($row->pv_name_th) == 'กรุงเทพมหานคร')?'selected':'';
			$province .= '<option '.$selected.'>'.$row->pv_name_th.'</option>';
		endforeach;
		$data['optionProvince'] = $province;


		$list_countries = $this->fetch_all_countries();
		$list_provinces = $this->FetchAllProvince('return');
		$list_districts = $this->FetchAllDistrict('return');
		$list_sub_districts = $this->FetchAllSubDistrict('return');
		$list_postcodes = $this->FetchAllPostCode();

		$countries = array();
		$provinces = array();
		$districts = array();
		$subDistricts = array();
		$postcodes = array();

		foreach($list_countries as $aCountries) {
	        $country = array(
	        	'label' => $aCountries->country_name,
	        	'val' => $aCountries->country_id);
	        $countries[] = $country;
	    }
	    $countries = json_encode($countries);

	    foreach ($list_provinces as $_list_provinces) {
	        $province = $_list_provinces->pv_name_th;
	        $provinces[] = $province;
	    }
	    $provinces = json_encode($provinces);

	    foreach ($list_districts as $_list_districts) {
	        $district = $_list_districts->d_name_th;
	        $districts[] = $district;
	    }
	    $districts = json_encode($districts);

	    foreach ($list_sub_districts as $_list_sub_districts) {
	        $subDistrict = $_list_sub_districts->sd_name_th;
	        $subDistricts[] = $subDistrict;
	    }
	    $subDistricts = json_encode($subDistricts);

	    foreach ($list_postcodes as $_list_postcodes) {
	        $postcode = $_list_postcodes->pc_code;
	        $postcodes[] = $postcode;
	    }
    	$postcodes = json_encode($postcodes);

	    $data['countries'] = $countries;
	    $data['provinces'] = $provinces;
	    $data['districts'] = $districts;
	    $data['subDistricts'] = $subDistricts;
	    $data['postcodes'] = $postcodes;
		$this->LoadView('Customer/customer_form',$data);
	}
	public function record()
	{
		$pers_fname = $this->input->post('firstname');
    	$pers_lname = $this->input->post('lastname');
        $pers_card_id = $this->input->post('idcard');
    	$this->load->model('tb_customer_personal_info');
    	echo "country".$this->input->post('country')."<br>";
    	// echo "country_cur".$this->input->post('lastest_country')."<br>";
    	// echo "country_lastest".$this->input->post('cur_country')."<br>";
    	// echo "country_work".$this->input->post('workingcountry')."<br>";
    	// exit();
    	$number	= $this->tb_customer_personal_info->duplicateFnameLname($pers_fname,$pers_lname);


		$pers_dob = date("Y-m-d",strtotime($this->input->post('dob')));
        


        if($this->tb_customer_personal_info->check_cus_name($pers_fname,$pers_lname)) {
            echo '<script>alert("Customer name already.");history.back();</script>';
            exit;
        }
        if(!empty($pers_card_id)) {
            if($this->tb_customer_personal_info->check_id_card($pers_card_id)) {
                echo '<script>alert("ID Card already.");history.back();</script>';
                exit;
            }
        }

        // if(!checkdate($this->input->post('mm'),$this->input->post('dd'),$this->input->post('yyyy')))
        // {
        //     echo "<script>
        //             alert('Date of birth is not current.');
        //             history.back();
        //         </script>";
        //     exit;
        // }

	 	$cus_id = $this->get_new_customer_id();
 		$pers_id=$cus_id;
 		$addr_id=$cus_id;
 		$addr_cur_id=$cus_id;
 		$work_id=$cus_id;
 		$con_id=$cus_id;
		$addr_lastest_id = $cus_id;
        // $pers_dob = $this->input->post('dd').'-'.$this->input->post('mm').'-'.$this->input->post('yyyy');
        
 		$c = date('Y');
 		$y = date('Y',strtotime($pers_dob));
 		$age =  $c-$y;

			if ($age>10) {

				if ( empty($number)  )
                {
                    $prefix = $this->input->post('Prefix');
 					$pers_sex = $this->input->post('sex');
 					$pers_Nationality = $this->input->post('Nationality');
 					$pers_identification = $this->input->post('identification');
 					$pers_Passport = empty($this->input->post('Passport'))?NULL:$this->input->post('Passport');
					$pers_mobile = $this->input->post('mobile');
					$pers_tel = $this->input->post('tel');
					$pers_email = $this->input->post('email');
					$tempBookingAddr1 = $this->input->post('bookingaddr1');
					$tempBookingAddr2 = $this->input->post('bookingaddr2');
					$tempBookingAddr3 = $this->input->post('bookingaddr3');
					if ($tempBookingAddr1 != NULL)  $cus_booking = 1;
                    else if ($tempBookingAddr2 != NULL)  $cus_booking = 2;
                    else if ($tempBookingAddr3 != NULL)  $cus_booking = 3;
					$pers_id_cus = $cus_id;

					if ($pers_Nationality == 171) {
			            if ($prefix == 'Mr.') {
			                $prefix = 'นาย';
			            } else if ($prefix == 'Miss') {
			                $prefix = 'นางสาว';
			            } else if ($prefix == 'Mrs.') {
			                $prefix = 'นาง';
			            }
			            $identificationFlag = "IDCard";
			        } else {
			        	$identificationFlag = "passport";
			        }

					$data_pers = array(
						'pers_id' => $pers_id,
                        'pers_prefix' => $prefix,
						'pers_fname' => $pers_fname,
						'pers_lname' => $pers_lname,
						'pers_card_id' => $pers_card_id,
						'pers_nationality' => $pers_Nationality,
						'pers_identification_flag' => $identificationFlag,
						'pers_passport' => $pers_Passport,
						'pers_dob' => $pers_dob,
						'pers_mobile' => $pers_mobile,
						'pers_tel' => $pers_tel,
						'pers_email' => $pers_email,
						'pers_id_cus' => $pers_id_cus,
						'pers_sex' => $pers_sex
					);
					$this->load->model('tb_customer_personal_info');
					$this->tb_customer_personal_info->record($data_pers);


					$addr_address 	= $this->input->post('address');
					$addr_sub_district = $this->input->post('sub_district');
					$addr_district = $this->input->post('district');
					$addr_province = $this->input->post('province');
					$addr_post_code  = $this->input->post('post');
					$addr_country = $this->input->post('country');
					$addr_id_cus  = $cus_id;
					$data_addr = array(
						'addr_id' => $addr_id,
						'addr_address' => $addr_address,
						'addr_sub_district' => $addr_sub_district,
						'addr_district' => $addr_district,
						'addr_province' => $addr_province,
						'addr_post_code' => $addr_post_code,
						'addr_country' => $addr_country,
						'addr_id_cus' => $addr_id_cus
					);
					$this->load->model('tb_customer_address_info');
					$this->tb_customer_address_info->record($data_addr);


					$addr_lastest_address = $this->input->post('lastest_address');
					$addr_lastest_sub_district = $this->input->post('lastest_sub_district');
					$addr_lastest_district   = $this->input->post('lastest_district');
					$addr_lastest_province   = $this->input->post('lastest_province');
					$addr_lastest_post_code  = $this->input->post('lastest_post');
					$addr_lastest_country    = $this->input->post('lastest_country');
					$addr_lastest_id_cus     = $cus_id;
					$this->load->model('tb_customer_address_lastest');
					$data_addr_lastest = array(
						'addr_lastest_id' => $addr_lastest_id,
						'addr_lastest_address' => $addr_lastest_address,
						'addr_lastest_sub_district' => $addr_lastest_sub_district,
						'addr_lastest_district' => $addr_lastest_district,
						'addr_lastest_province' => $addr_lastest_province,
						'addr_lastest_post_code' => $addr_lastest_post_code,
						'addr_lastest_country' => $addr_lastest_country,
						'addr_lastest_id_cus' => $addr_lastest_id_cus);
					$this->tb_customer_address_lastest->record($data_addr_lastest);


					$addr_cur_address = $this->input->post('cur_address');
					$addr_cur_sub_district = $this->input->post('cur_sub_district');
					$addr_cur_district = $this->input->post('cur_district');
					$addr_cur_province = $this->input->post('cur_province');
					$addr_cur_post_code  = $this->input->post('cur_post');
					$addr_cur_country = $this->input->post('cur_country');
					$addr_cur_id_cus  = $cus_id;
					$data_addr_cur = array(
						'addr_cur_id' => $addr_cur_id,
						'addr_cur_address' => $addr_cur_address,
						'addr_cur_sub_district' => $addr_cur_sub_district,
						'addr_cur_district' => $addr_cur_district,
						'addr_cur_province' => $addr_cur_province,
						'addr_cur_post_code' => $addr_cur_post_code,
						'addr_cur_country' => $addr_cur_country,
						'addr_cur_id_cus' => $addr_cur_id_cus
					);
					$this->load->model('tb_customer_address_current_info');
					$this->tb_customer_address_current_info->record($data_addr_cur);

					$work_position = $this->input->post('position');
					$work_company = $this->input->post('company');
					$work_house_no = $this->input->post('workinghouseno');
					$work_road = $this->input->post('workingroad');
					$work_sub_district = $this->input->post('working_sub_district');
					$work_district = $this->input->post('working_district');
					$work_province = $this->input->post('working_province');
					$work_post_code  = $this->input->post('working_post');
					$work_country = $this->input->post('workingcountry');
					$work_cus_id = $cus_id;
					$data_work = array(
						'work_id' => $work_id,
						'work_position' => $work_position,
						'work_company' => $work_company,
						'work_house_no' => $work_house_no,
						'work_road' => $work_road,
						'work_sub' => $work_sub_district,
						'work_district' => $work_district,
						'work_province' => $work_province,
						'work_post_code' => $work_post_code,
						'work_country' => $work_country,
						'work_cus_id' => $work_cus_id
					);
					$this->load->model('tb_customer_working_info');
					$this->tb_customer_working_info->record($data_work);

					$conFname = $this->input->post('ConFname');
					$conLname = $this->input->post('ConLname');
					$contel = $this->input->post('contel');
					$conMail= $this->input->post('conMail');
					$data_contact = array(
						'con_id' => $con_id,
						'con_fname' => $conFname,
						'con_lname' => $conLname,
						'con_email' => $conMail,
						'con_tel' => $contel,
						'con_id_cus' => $cus_id
					);
					$this->load->model('tb_customer_contact_info');
					$this->tb_customer_contact_info->record($data_contact);

					$sale = $this->user_id;
					$data_customer = array(
						'cus_id' => $cus_id,
						'cus_pers_id' => $pers_id,
						'cus_addr_id' => $addr_id,
						'cus_addr_cur_id' => $addr_cur_id,
						'cus_con_id' => $con_id,
						'cus_work_id' => $work_id,
						'cus_flag' => 'cus',
						'cus_created_by' => $sale,
                        'cus_customer_date' => date("Y-m-d H:i:s"),
						'cus_addr_lastest_id' => $addr_lastest_id,
						'cus_sts_active' => 'on',
                        'cus_addr_default' => $cus_booking
					);
					$this->recordCustomer($data_customer);
					echo "<script>
                            alert('Add Customer Success.');
                            window.location.href = '".BASE_DOMAIN."customer/view';
                        </script>";
                    exit;
                }
                else {
                    echo "<script>
                            window.location.href = '".BASE_DOMAIN."customer/view';
                        </script>";
                }
 			} else {
                echo "<script>
                    alert('Don not allow anyone under the age of 10 years.');
                    history.back();
                </script>";
 			}
	}

	public function update($cid)
	{
		$pers_dob = date("Y-m-d",strtotime($this->input->post('dob')));
		// $pers_dob = $this->input->post('dd').'-'.$this->input->post('mm').'-'.$this->input->post('yyyy');
	  	$c = date('Y');
		$y = date('Y', strtotime($pers_dob));
		$age =  $c-$y;

        // if(!checkdate($this->input->post('mm'),$this->input->post('dd'),$this->input->post('yyyy')))
        // {
        //     echo "<script>
        //             alert('Date of birth is not current.');
        //             history.back();
        //         </script>";
        //     exit;
        // }

		 if ($age>10) {

				$cus_id=$cid;
				$pers_id=$cus_id;
				$addr_id=$cus_id;
				$addr_cur_id=$cus_id;
				$work_id=$cus_id;
				$con_id=$cus_id;

				$qid=$this->input->post('qid');

				$customer = $this->get_detail_customer($cid);

	            $prefix = $this->input->post('Prefix');
				$pers_fname = $this->input->post('firstname');
				$pers_lname = $this->input->post('lastname');
				$pers_sex = $this->input->post('sex');
				$pers_Nationality = $this->input->post('Nationality');
				$pers_identification = $this->input->post('identification');
				$pers_Passport = empty($this->input->post('Passport'))?NULL:$this->input->post('Passport');
				$pers_card_id = $this->input->post('idcard');
				$pers_mobile = $this->input->post('mobile');
				$pers_tel = $this->input->post('tel');
				$pers_email = $this->input->post('email');

				$addr_address = $this->input->post('address');
				$addr_sub_district = $this->input->post('sub_district');
				$addr_district = $this->input->post('district');
				$addr_province = $this->input->post('province');
				$addr_post_code  = $this->input->post('post');
				$addr_country = $this->input->post('country');

				$addr_lastest_address = $this->input->post('lastest_address');
				$addr_lastest_sub_district = $this->input->post('lastest_sub_district');
				$addr_lastest_district = $this->input->post('lastest_district');
				$addr_lastest_province = $this->input->post('lastest_province');
				$addr_lastest_post_code  = $this->input->post('lastest_post');
				$addr_lastest_country = $this->input->post('lastest_country');

			    $tempBookingAddr1 = $this->input->post('bookingaddr1');
				$tempBookingAddr2 = $this->input->post('bookingaddr2');
				$tempBookingAddr3 = $this->input->post('bookingaddr3');
				if ($tempBookingAddr1 != NULL)  $cus_booking = 1;
                else if ($tempBookingAddr2 != NULL)  $cus_booking = 2;
                else if ($tempBookingAddr3 != NULL)  $cus_booking = 3;

				$addr_cur_address = $this->input->post('cur_address');
				$addr_cur_sub_district = $this->input->post('cur_sub_district');
				$addr_cur_district = $this->input->post('cur_district');
				$addr_cur_province = $this->input->post('cur_province');
				$addr_cur_post_code  = $this->input->post('cur_post');
				$addr_cur_country = $this->input->post('cur_country');

				$work_position = $this->input->post('position');
				$work_company = $this->input->post('company');
				$work_house_no = $this->input->post('workinghouseno');
				$work_road = $this->input->post('workingroad');
				$work_sub = $this->input->post('working_sub_district');
				$work_district = $this->input->post('working_district');
				$work_province = $this->input->post('working_province');
				$work_post_code  = $this->input->post('working_post');
				$work_country = $this->input->post('workingcountry');
				$work_cus_id = $cus_id;

				$conFname =$this->input->post('ConFname');
				$conLname = $this->input->post('ConLname');
				$contel = $this->input->post('contel');
				$conMail= $this->input->post('conMail');
				$data_cus = array(
					'cus_flag' => 'cus',
                    'cus_customer_date' => date("Y-m-d H:i:s"),
                    'cus_addr_default' => $cus_booking
				);
				$this->updateCustomer($data_cus,$cid);


			 	$userEdit = $this->user_id;

			 	if ($pers_Nationality == 171) {
		            if ($prefix == 'Mr.') {
		                $prefix = 'นาย';
		            } else if ($prefix == 'Miss') {
		                $prefix = 'นางสาว';
		            } else if ($prefix == 'Mrs.') {
		                $prefix = 'นาง';
		            }
		            $identificationFlag = "IDCard";
		        } else {
		        	$identificationFlag = "passport";
		        }

				if (
					$pers_Nationality	!= $customer->pers_nationality ||
					$pers_identification != $customer->pers_identification_flag ||
					$pers_Passport 	!= $customer->pers_passport ||
					$pers_fname 	!= $customer->pers_fname ||
					$pers_lname 	!= $customer->pers_lname ||
					$prefix			!= $customer->pers_prefix ||
					$pers_sex		!= $customer->pers_sex ||
					$pers_card_id 	!= $customer->pers_card_id ||
					$pers_mobile 	!= $customer->pers_mobile ||
					$pers_tel 		!= $customer->pers_tel ||
					$pers_email 	!= $customer->pers_email ||
					$pers_dob 		!= $customer->pers_dob)
				{
					$data_pers = array(
                        'pers_prefix' => $prefix,
						'pers_fname' => $pers_fname,
						'pers_lname' => $pers_lname,
						'pers_sex' => $pers_sex,
						'pers_nationality' => $pers_Nationality,
						'pers_identification_flag' => $identificationFlag,
						'pers_passport' => $pers_Passport,
						'pers_card_id' => $pers_card_id,
						'pers_dob' => $pers_dob,
						'pers_mobile' => $pers_mobile,
						'pers_tel' => $pers_tel,
						'pers_email' => $pers_email,
						'pers_id_cus' => $cus_id
					);
					$this->load->model('tb_customer_personal_info');
					$this->tb_customer_personal_info->update($data_pers,$cus_id);

					$obj_pers = $this->tb_customer_personal_info->get_detail_by_pers_id_cus($cus_id);
					$data_log_pers = array(
						'pers_id' => $obj_pers->pers_id,
                        'pers_prefix' => $obj_pers->pers_prefix,
						'pers_fname' => $obj_pers->pers_fname,
						'pers_lname' => $obj_pers->pers_lname,
						'pers_sex' => $obj_pers->pers_sex,
						'pers_nationality' => $obj_pers->pers_nationality,
						'pers_identification_flag' => $obj_pers->pers_identification_flag,
						'pers_passport' => $obj_pers->pers_passport,
						'pers_card_id' => $obj_pers->pers_card_id,
						'pers_dob' => $obj_pers->pers_dob,
						'pers_mobile' => $obj_pers->pers_mobile,
						'pers_tel' => $obj_pers->pers_tel,
						'pers_email' => $obj_pers->pers_email,
						'pers_id_cus' => $obj_pers->pers_id_cus,
						'pers_update_by' => $this->user_id
					);
					$this->record_log_customer_personal_info($data_log_pers);

				} else {
					$this->load->model('tb_customer_personal_info');
					$obj_pers = $this->tb_customer_personal_info->get_detail_by_pers_id_cus($cus_id);
					$data_log_pers = array(
						'pers_id' => $obj_pers->pers_id,
                        'pers_prefix' => $obj_pers->pers_prefix,
						'pers_fname' => $obj_pers->pers_fname,
						'pers_lname' => $obj_pers->pers_lname,
						'pers_sex' => $obj_pers->pers_sex,
						'pers_nationality' => $obj_pers->pers_nationality,
						'pers_identification_flag' => $obj_pers->pers_identification_flag,
						'pers_passport' => $obj_pers->pers_passport,
						'pers_card_id' => $obj_pers->pers_card_id,
						'pers_dob' => $obj_pers->pers_dob,
						'pers_mobile' => $obj_pers->pers_mobile,
						'pers_tel' => $obj_pers->pers_tel,
						'pers_email' => $obj_pers->pers_email,
						'pers_id_cus' => $obj_pers->pers_id_cus,
						'pers_update_by' => $this->user_id
					);
					$this->record_log_customer_personal_info($data_log_pers);
                }

				if ($addr_address 		!= $customer->addr_address ||
					$addr_sub_district 	!= $customer->addr_sub_district ||
					$addr_district 		!= $customer->addr_district ||
					$addr_province 		!= $customer->addr_province ||
					$addr_post_code 	!= $customer->addr_post_code ||
					$addr_country  		!= $customer->addr_country)
				{
					$data_addr_info = array(
						'addr_address' => $addr_address,
						'addr_sub_district' => $addr_sub_district,
					  	'addr_district' => $addr_district,
						'addr_province' => $addr_province,
						'addr_post_code' => $addr_post_code,
						'addr_country' => $addr_country,
						'addr_id_cus' => $cus_id
					);
					$this->load->model('tb_customer_address_info');
					$this->tb_customer_address_info->update($data_addr_info,$cus_id);

					$obj_addr = $this->tb_customer_address_info->get_detail_by_addr_id_cus($cus_id);
					$data_log_addr_info = array(
						'addr_id' => $obj_addr->addr_id,
						'addr_address' => $obj_addr->addr_address,
						'addr_sub_district' => $obj_addr->addr_sub_district,
						'addr_district' => $obj_addr->addr_district,
						'addr_province' => $obj_addr->addr_province,
						'addr_post_code' => $obj_addr->addr_post_code,
						'addr_country' => $obj_addr->addr_country,
						'addr_id_cus' => $obj_addr->addr_id_cus,
						'addr_update_by' => $this->user_id
					);
					$this->record_log_customer_address_info($data_log_addr_info);
				} else {
					$this->load->model('tb_customer_address_info');
					$obj_addr = $this->tb_customer_address_info->get_detail_by_addr_id_cus($cus_id);
					$data_log_addr_info = array(
						'addr_id' => $obj_addr->addr_id,
						'addr_address' => $obj_addr->addr_address,
						'addr_sub_district' => $obj_addr->addr_sub_district,
						'addr_district' => $obj_addr->addr_district,
						'addr_province' => $obj_addr->addr_province,
						'addr_post_code' => $obj_addr->addr_post_code,
						'addr_country' => $obj_addr->addr_country,
						'addr_id_cus' => $obj_addr->addr_id_cus,
						'addr_update_by' => $this->user_id
					);
					$this->record_log_customer_address_info($data_log_addr_info);
                }

				if ($addr_cur_address		!= $customer->addr_cur_address ||
					$addr_cur_sub_district 	!= $customer->addr_cur_sub_district ||
					$addr_cur_district 		!= $customer->addr_cur_district ||
					$addr_cur_province 		!= $customer->addr_cur_province ||
					$addr_cur_post_code 	!= $customer->addr_cur_post_code ||
					$addr_cur_country  		!= $customer->addr_cur_country)
				{
					$data_addr_cur = array(
						'addr_cur_address' => $addr_cur_address,
					  	'addr_cur_sub_district' => $addr_cur_sub_district,
					  	'addr_cur_district' => $addr_cur_district,
					  	'addr_cur_province' => $addr_cur_province,
					  	'addr_cur_post_code' => $addr_cur_post_code,
					  	'addr_cur_country' => $addr_cur_country,
					  	'addr_cur_id_cus' => $cus_id
					);
					$this->load->model('tb_customer_address_current_info');
					$this->tb_customer_address_current_info->update($data_addr_cur,$cus_id);

					$obj_addr_cur = $this->tb_customer_address_current_info->get_detail_by_addr_cur_id_cus($cus_id);
					$data_log_addr_cur = array(
						'addr_cur_id' => $obj_addr_cur->addr_cur_id,
						'addr_cur_address' => $obj_addr_cur->addr_cur_address,
						'addr_cur_sub_district' => $obj_addr_cur->addr_cur_sub_district,
						'addr_cur_district' => $obj_addr_cur->addr_cur_district,
						'addr_cur_province' => $obj_addr_cur->addr_cur_province,
						'addr_cur_post_code' => $obj_addr_cur->addr_cur_post_code,
						'addr_cur_country' => $obj_addr_cur->addr_cur_country,
						'addr_cur_id_cus' => $obj_addr_cur->addr_cur_id_cus,
						'addr_cur_update_by' => $this->user_id
					);
					$this->record_log_customer_address_current_info($data_log_addr_cur);
				} else {
					$this->load->model('tb_customer_address_current_info');
					$obj_addr_cur = $this->tb_customer_address_current_info->get_detail_by_addr_cur_id_cus($cus_id);
					$data_log_addr_cur = array(
						'addr_cur_id' => $obj_addr_cur->addr_cur_id,
						'addr_cur_address' => $obj_addr_cur->addr_cur_address,
						'addr_cur_sub_district' => $obj_addr_cur->addr_cur_sub_district,
						'addr_cur_district' => $obj_addr_cur->addr_cur_district,
						'addr_cur_province' => $obj_addr_cur->addr_cur_province,
						'addr_cur_post_code' => $obj_addr_cur->addr_cur_post_code,
						'addr_cur_country' => $obj_addr_cur->addr_cur_country,
						'addr_cur_id_cus' => $obj_addr_cur->addr_cur_id_cus,
						'addr_cur_update_by' => $this->user_id
					);
					$this->record_log_customer_address_current_info($data_log_addr_cur);
                }

				if ($work_position 	!= $customer->work_position ||
					$work_company  	!= $customer->work_company ||
					$work_house_no 	!= $customer->work_house_no ||
					$work_road 		!= $customer->work_road ||
					$work_sub 		!= $customer->work_sub ||
					$work_district 	!= $customer->work_district ||
					$work_province 	!= $customer->work_province ||
					$work_post_code != $customer->work_post_code ||
					$work_country 	!= $customer->work_country)
				{
					$data_working = array(
						  'work_position' => $work_position,
						  'work_company' => $work_company,
						  'work_house_no' => $work_house_no,
						  'work_road' => $work_road,
						  'work_sub' => $work_sub,
						  'work_district' => $work_district,
						  'work_province' => $work_province,
						  'work_post_code' => $work_post_code,
						  'work_country' => $work_country,
						  'work_cus_id' => $cus_id
					);
					$this->load->model('tb_customer_working_info');
					$this->tb_customer_working_info->update($data_working,$cus_id);

					$obj_working = $this->tb_customer_working_info->get_detail_by_work_cus_id($cus_id);
					$data_log_working = array(
						'work_id' => $obj_working->work_id,
						'work_position' => $obj_working->work_position,
						'work_company' => $obj_working->work_company,
						'work_house_no' => $obj_working->work_house_no,
						'work_road' => $obj_working->work_road,
						'work_sub' => $obj_working->work_sub,
						'work_district' => $obj_working->work_district,
						'work_province' => $obj_working->work_province,
						'work_post_code' => $obj_working->work_post_code,
						'work_country' => $obj_working->work_country,
						'work_cus_id' => $obj_working->work_cus_id,
						'work_update_by' => $this->user_id
					);
					$this->record_log_customer_working_info($data_log_working);
				} else {
					$this->load->model('tb_customer_working_info');
					$obj_working = $this->tb_customer_working_info->get_detail_by_work_cus_id($cus_id);
					$data_log_working = array(
						'work_id' => $obj_working->work_id,
						'work_position' => $obj_working->work_position,
						'work_company' => $obj_working->work_company,
						'work_house_no' => $obj_working->work_house_no,
						'work_road' => $obj_working->work_road,
						'work_sub' => $obj_working->work_sub,
						'work_district' => $obj_working->work_district,
						'work_province' => $obj_working->work_province,
						'work_post_code' => $obj_working->work_post_code,
						'work_country' => $obj_working->work_country,
						'work_cus_id' => $obj_working->work_cus_id,
						'work_update_by' => $this->user_id
					);
					$this->record_log_customer_working_info($data_log_working);
                }

				if ($conFname 	!= $customer->con_fname ||
					$conLname  	!= $customer->con_lname ||
					$contel  	!= $customer->con_tel ||
					$conMail 	!= $customer->con_email)
				{
					$data_contact = array(
							'con_fname' => $conFname,
							'con_lname' => $conLname,
						 	'con_email' => $conMail,
							'con_tel' => $contel,
							'con_id_cus' => $cus_id
					);
					$this->load->model('tb_customer_contact_info');
					$this->tb_customer_contact_info->update($data_contact,$cus_id);

					$obj_contact = $this->tb_customer_contact_info->get_detail_by_con_id_cus($cus_id);
					$data_log_contact = array(
						'con_id' => $obj_contact->con_id,
						'con_fname' => $obj_contact->con_fname,
						'con_lname' => $obj_contact->con_lname,
						'con_email' => $obj_contact->con_email,
						'con_tel' => $obj_contact->con_tel,
						'con_id_cus' => $obj_contact->con_id_cus,
						'con_update_by' => $this->user_id
					);
					$this->record_log_customer_contact_info($data_log_contact);

				} else {
					$this->load->model('tb_customer_contact_info');
					$obj_contact = $this->tb_customer_contact_info->get_detail_by_con_id_cus($cus_id);
					$data_log_contact = array(
						'con_id' => $obj_contact->con_id,
						'con_fname' => $obj_contact->con_fname,
						'con_lname' => $obj_contact->con_lname,
						'con_email' => $obj_contact->con_email,
						'con_tel' => $obj_contact->con_tel,
						'con_id_cus' => $obj_contact->con_id_cus,
						'con_update_by' => $this->user_id
					);
					$this->record_log_customer_contact_info($data_log_contact);
                }
             
				if ($addr_lastest_address		!= $customer->addr_lastest_address ||
						$addr_lastest_sub_district 	!= $customer->addr_lastest_sub_district ||
						$addr_lastest_district 		!= $customer->addr_lastest_district ||
						$addr_lastest_province 		!= $customer->addr_lastest_province ||
						$addr_lastest_post_code 	!= $customer->addr_lastest_post_code ||
						$addr_lastest_country  		!= $customer->addr_lastest_country)
					{

					$data_cus_addr_lastest = array(
						'addr_lastest_address' => $addr_lastest_address,
						'addr_lastest_sub_district' => $addr_lastest_sub_district,
						'addr_lastest_district' => $addr_lastest_district,
						'addr_lastest_province' => $addr_lastest_province,
						'addr_lastest_post_code' => $addr_lastest_post_code,
						'addr_lastest_country' => $addr_lastest_country,
						'addr_lastest_id_cus' => $cus_id
					);
					$this->load->model('tb_customer_address_lastest');
					$this->tb_customer_address_lastest->update($data_cus_addr_lastest,$cus_id);

					$obj_cus_addr_lastest = $this->tb_customer_address_lastest->get_detail_by_addr_lastest_id_cus($cus_id);
					$data_log_addr_lastest = array(
						 'addr_lastest_id' => $obj_cus_addr_lastest->addr_lastest_id,
			             'addr_lastest_address' => $obj_cus_addr_lastest->addr_lastest_address,
			             'addr_lastest_sub_district' => $obj_cus_addr_lastest->addr_lastest_sub_district,
			             'addr_lastest_district' => $obj_cus_addr_lastest->addr_lastest_district,
			             'addr_lastest_province' => $obj_cus_addr_lastest->addr_lastest_province,
			             'addr_lastest_post_code' => $obj_cus_addr_lastest->addr_lastest_post_code,
			             'addr_lastest_country' => $obj_cus_addr_lastest->addr_lastest_country,
			             'addr_lastest_id_cus' => $obj_cus_addr_lastest->addr_lastest_id_cus,
			             'addr_cur_update_by' => $this->user_id
					);
					$this->record_log_customer_address_lastest($data_log_addr_lastest);
					} else {
                        $this->load->model('tb_customer_address_lastest');
                        $obj_cus_addr_lastest = $this->tb_customer_address_lastest->get_detail_by_addr_lastest_id_cus($cus_id);
                        $data_log_addr_lastest = array(
                             'addr_lastest_id' => $obj_cus_addr_lastest->addr_lastest_id,
                             'addr_lastest_address' => $obj_cus_addr_lastest->addr_lastest_address,
                             'addr_lastest_sub_district' => $obj_cus_addr_lastest->addr_lastest_sub_district,
                             'addr_lastest_district' => $obj_cus_addr_lastest->addr_lastest_district,
                             'addr_lastest_province' => $obj_cus_addr_lastest->addr_lastest_province,
                             'addr_lastest_post_code' => $obj_cus_addr_lastest->addr_lastest_post_code,
                             'addr_lastest_country' => $obj_cus_addr_lastest->addr_lastest_country,
                             'addr_lastest_id_cus' => $obj_cus_addr_lastest->addr_lastest_id_cus,
                             'addr_cur_update_by' => $this->user_id
                        );
					$this->record_log_customer_address_lastest($data_log_addr_lastest);
                    }
             
				if ($qid!=null) {
					echo ("<script> window.location.href = '".BASE_DOMAIN."booking/adding/".$qid."'</script>");
                    exit;
				} else {
//                    $this->updateLog_customer($data_cus,$cid);
//                    echo "updateLog_customer_address_current_info : ";
//                    print_r($data_log_addr_cur);
//                    echo "<br/><br/>updateLog_customer_address_info : ";
//                    print_r($data_log_addr_info);
//                    echo "<br/><br/>updateLog_customer_address_lastest : ";
//                    print_r($data_log_addr_lastest);
//                    echo "<br/><br/>updateLog_customer_contact_info : ";
//                    print_r($data_log_contact);
//                    echo "<br/><br/>updateLog_customer_personal_info : ";
//                    print_r($data_log_pers);
//                    echo "<br/><br/>updateLog_customer_working_info : ";
//                    print_r($data_log_working);
//                    echo "<br/><br/>updateLog_customer : ";
//                    print_r($data_cus);
//                    echo "<br/><br/>cid : ".$cid;
//                    exit();
//                    $this->updateLog_customer_address_current_info($data_log_addr_cur,$cid);
//                    $this->updateLog_customer_address_info($data_log_addr_info,$cid);
//                    $this->updateLog_customer_address_lastest($data_log_addr_lastest,$cid);
//                    $this->updateLog_customer_contact_info($data_log_contact,$cid);
//                    $this->updateLog_customer_personal_info($data_log_pers,$cid);
//                    $this->updateLog_customer_working_info($data_log_working,$cid);
                    echo "<script>
                            alert('Edit Customer Success.');
                            window.location.href = '".BASE_DOMAIN."customer/view';
                        </script>";
				}

			} else {
			   	echo "<script> alert('Do not allow anyone under age of 10'); history.back(); </script>";
			}
	}
	public function deleting($cid){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_customer,'4') === FALSE) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data = array(
			'cus_sts_active' => 'off'
		);
        $this->updateCustomer($data,$cid);
        alert_redirect('Delete Customer Success','/customer/view');
	}

	private function fetch_customer(){
		$this->load->model('tb_customer');
		$this->load->model('tb_customer_project');
		$this->load->model('log_lead_remark');
        $customers = $this->tb_customer->fetch_customer();
        foreach($customers as $key=>$cus) {
            $cus->pid = $this->tb_customer_project->get_string_pro($cus->cus_id);
			$lastLead = $this->log_lead_remark->Lastest($cus->cus_id);
            $cus->lr_timestamp = $lastLead->lr_timestamp;
            $cus->lr_remark = $lastLead->lr_remark;
        }
		return $customers;
	}

//	private function fetch_remark_cus(){
//		$this->load->model('tb_customer');
//		$this->load->model('tb_visit_type');
//		$this->load->model('log_lead_remark');
//        $leadList = $this->tb_customer->fetch_leads_ignorActive();
//        foreach ($leadList as $key=>$lead) {
//            $lead->type = $this->tb_visit_type->get_name_by_id($lead->cus_visit_type);
//			
//			$lastLead = $this->log_lead_remark->Lastest($lead->cus_id);
//            $lead->lr_timestamp = $lastLead->lr_timestamp;
//            $lead->lr_remark = $lastLead->lr_remark;
//			
//        }
//		return $leadList;
//	}
	private function get_new_customer_id(){
		$this->load->model('tb_customer');
		return $this->tb_customer->get_new_customer_id();
	}
	private function fetch_all_nationality(){
		$this->load->model('tb_nationality');
		return $this->tb_nationality->fetch_all_nationality();
	}
	private function fetch_all_countries(){
		$this->load->model('tb_countries');
		return $this->tb_countries->fetch_all_countries();
	}
	function FetchAllProvince($get) {
		$this->load->model('tb_province');
		if ($get === 'return') {
			return $this->tb_province->fetch_all_province();
		} else if ($get === 'json') {
			echo json_encode($this->tb_province->fetch_all_province());
		}
	}
	function FetchAllDistrict($get) {
		$this->load->model('tb_district');
		if ($get === 'return') {
			return $this->tb_district->fetch_all_district();
		} else if ($get === 'json') {
			echo json_encode($this->tb_district->fetch_all_district());
		}
	}
	function FetchAllSubDistrict($get) {
		$this->load->model('tb_sub_district');
		if ($get === 'return') {
			return $this->tb_sub_district->fetch_all_sub_district();
		} else if ($get === 'json') {
			echo json_encode($this->tb_sub_district->fetch_all_sub_district());
		}
	}
	function FetchAllPostCode($get) {
		$this->load->model('tb_postcode');
		if ($get === 'return') {
			return $this->tb_postcode->fetch_all_postcode();
		} else if ($get === 'json') {
			echo json_encode($this->tb_postcode->fetch_all_postcode());
		}
	}
	private function get_detail_customer($cid){
		$this->load->model('tb_customer');
		return $this->tb_customer->get_detail_customer($cid);
	}

	//////// RECORD //////////
	//////////////////////////
	private function recordCustomer($data)
	{
		$this->load->model('tb_customer');
		$this->tb_customer->record($data);
	}

	////// UPDATE //////////
	////////////////////////
	private function updateCustomer($data,$cid)
	{
		$this->load->model('tb_customer');
		$this->tb_customer->update($data,$cid);
	}
	private function updateLog_customer($data,$cid)
	{
		$this->load->model('log_customer');
		$this->log_customer->update($data,$cid);
	}
	private function updateLog_customer_address_current_info($data,$cid)
	{
		$this->load->model('log_customer_address_current_info');
		$this->log_customer_address_current_info->update($data,$cid);
	}
	private function updateLog_customer_address_info($data,$cid)
	{
		$this->load->model('log_customer_address_info');
		$this->log_customer_address_info->update($data,$cid);
	}
	private function updateLog_customer_address_lastest($data,$cid)
	{
		$this->load->model('log_customer_address_lastest');
		$this->log_customer_address_lastest->update($data,$cid);
	}
	private function updateLog_customer_conract_info($data,$cid)
	{
		$this->load->model('log_customer_conract_info');
		$this->log_customer_conract_info->update($data,$cid);
	}
	private function updateLog_customer_personal_info($data,$cid)
	{
		$this->load->model('log_customer_personal_info');
		$this->log_customer_personal_info->update($data,$cid);
	}
	private function updateLog_customer_working_info($data,$cid)
	{
		$this->load->model('log_customer_working_info');
		$this->log_customer_working_info->update($data,$cid);
	}

	/**
	* -------------------------------------
	* Log Management [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function record_log_customer_personal_info($data)
	{
		$this->load->model('log_customer_personal_info');
		$this->log_customer_personal_info->record($data);
	}
	private function record_log_customer_contact_info($data)
	{
		$this->load->model('log_customer_contact_info');
		$this->log_customer_contact_info->record($data);
	}
	private function record_log_customer_address_info($data)
	{
		$this->load->model('log_customer_address_info');
		$this->log_customer_address_info->record($data);
	}
	private function record_log_customer_address_current_info($data)
	{
		$this->load->model('log_customer_address_current_info');
		$this->log_customer_address_current_info->record($data);
	}
	private function record_log_customer_working_info($data)
	{
		$this->load->model('log_customer_working_info');
		$this->log_customer_working_info->record($data);
	}
	private function record_log_customer_address_lastest($data)
	{
		$this->load->model('log_customer_address_lastest');
		$this->log_customer_address_lastest->record($data);
	}

}

/* End of file customer.php */
/* Location: ./application/controllers/customer.php */
