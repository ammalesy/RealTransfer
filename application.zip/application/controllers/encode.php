<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Encode extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin Back Office';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
        
    }

    public function encryptCode($val) {
        $this->load->library('encrypt');
    	$arr = array('code' => $this->encrypt->encode($val));
    	echo json_encode($arr);
    }
    
    public function encrypt($val) {
        $this->load->library('encrypt');
    	echo $this->encrypt->encode($val);
    }
}
?>