<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Faq extends NZ_Controller {
    
	var $page_var = 'FAQ';
	
    function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
    
    function view()
    {
        $this->load->model('tb_faq');
        $data['title'] = 'FAQ';
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
        $data['list'] = $this->tb_faq->all();
		$this->load->view('FAQ/faq_view',$data);
    }
    
    function update()
    {
        $this->load->model('tb_faq');
        $data['title'] = 'FAQ Update';
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
        $data['list'] = $this->tb_faq->all();
		$this->load->view('FAQ/faq_form',$data);
    }
    
    function record()
    {
        $this->load->model('tb_faq');
        $this->tb_faq->TRUNCATE();
        $question = $this->input->post('question');
        $answer   = $this->input->post('answer');
        $userID   = $this->user_id;
        foreach($question as $index=>$q) {
            $data = array(
                'fq_question' => $q,
                'fq_answer'   => $answer[$index],
                'fq_user_id'  => $userID
            );
            $this->tb_faq->record($data);
        }
        
        echo '<script>
            window.location.href = "'.BASE_DOMAIN.'FAQ/view";
        </script>';
    }
    
}
?>