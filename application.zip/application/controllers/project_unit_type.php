<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_unit_type extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Unit';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_unit_type');
		$data['list_unit_type'] = $this->tb_unit_type->fetch_all_with_TbRoomType();
		$this->LoadView('Project_detail/Project_unit_type/project_unit_type_view',$data);
	}
	public function editing($unit_type_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_room_type');
		$this->load->model('tb_unit_type');
		$data['list_room'] = $this->tb_room_type->fetch_active_room();
		$data['unit_type'] = $this->tb_unit_type->get_detail_withTbRoomType_by_unit_type_id($unit_type_id);
		$this->LoadView('Project_detail/Project_unit_type/project_unit_type_editing',$data);
	}
	public function update($unit_type_id)
	{
		$this->load->model('log_unit_type');
		$this->load->model('tb_unit_type');

		$unit = $this->input->post('unit');
		$Name = $this->input->post('Name');
		$Info = $this->input->post('Info');
		$Room = $this->input->post('Room');
		$Areasqm = $this->input->post('Areasqm');
		$Areasqft = $this->input->post('Areasqft');
		$userEdit = $this->user_id;

		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();
		/*============================*/
		/*====== SELECTED IMAGE ======*/
		/*============================*/
		if(!$this->isEmptyFile('Image'))
		{
			$result_upload = $this->upload_image('Image',"project/".$this->project_id_sel."/unit_type/".$unit_type_id,time());
			if($result_upload['error_status'] == FALSE){
				$data_update = array(
					'unit_type_name' => $Name,
					'unit_type_info' => $Info,
					'unit_type_area_sqm' => $Areasqm,
					'unit_type_area_sqft' => $Areasqft,
					'unit_type_room_type_id' => $Room,
					'unit_type_image' => $result_upload['image_url']
				);
				$this->tb_unit_type->update($data_update,$unit_type_id);
				
				$unitObj = $this->tb_unit_type->get_detail_by_unit_type_id($unit_type_id);
				$data_log = array(
						'unit_type_id' => $unitObj->unit_type_id,
						'unit_type_name' => $unitObj->unit_type_name,
						'unit_type_info' => $unitObj->unit_type_info,
						'unit_type_area_sqm' => $unitObj->unit_type_area_sqm,
						'unit_type_area_sqft' => $unitObj->unit_type_area_sqft,
						'unit_type_room_type_id' => $unitObj->unit_type_room_type_id,
						'unit_type_sts_active' => $unitObj->unit_type_sts_active,
						'unit_type_update_by' => $userEdit,
						'unit_type_image' => $result_upload['image_url']
				);
				$this->log_unit_type->record($data_log);
			}
		/*============================*/
		/*==== DON'T SELECT IMAGE ====*/
		/*============================*/
		}else{
			$data_update = array(
				'unit_type_name' => $Name,
				'unit_type_info' => $Info,
				'unit_type_area_sqm' => $Areasqm,
				'unit_type_area_sqft' => $Areasqft,
				'unit_type_room_type_id' => $Room
			);
			$this->tb_unit_type->update($data_update,$unit_type_id);
			
			$unitObj = $this->tb_unit_type->get_detail_by_unit_type_id($unit_type_id);
			$data_log = array(
					'unit_type_id' => $unitObj->unit_type_id,
					'unit_type_name' => $unitObj->unit_type_name,
					'unit_type_info' => $unitObj->unit_type_info,
					'unit_type_area_sqm' => $unitObj->unit_type_area_sqm,
					'unit_type_area_sqft' => $unitObj->unit_type_area_sqft,
					'unit_type_room_type_id' => $unitObj->unit_type_room_type_id,
					'unit_type_sts_active' => $unitObj->unit_type_sts_active,
					'unit_type_update_by' => $userEdit
			);
			$this->log_unit_type->record($data_log);
		}
//                echo ("data_update1 : ");
//                print_r ($data_update);
//                echo ("+++data_update2 : ");
//                print_r ($data_log);
//                exit();
		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Edit Unit Type Fail','/project_unit_type/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Edit Unit Type Success','/project_unit_type/view');
		}
		
	}
	public function adding(){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['pjname'] = $this->project_name_sel;

		$this->load->model('tb_room_type');
		$data['list_room'] = $this->tb_room_type->fetch_active_room();

		$this->LoadView('Project_detail/Project_unit_type/project_unit_type_adding',$data);
	}
	public function record(){
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->pdb->trans_begin();

		$this->load->model('tb_unit_type');
		$Project = $this->input->post('Project');
		$Name = $this->input->post('Name');
		$Info = $this->input->post('Info');
		$Room = $this->input->post('Room');
		$Areasqm = $this->input->post('Areasqm');
		$Areasqft = $this->input->post('Areasqft');
	
		foreach($Name  as $index => $position ):
			$name_add = $Name[$index] ;
			$info_add = $Info[$index] ;
			$Room_add = $Room[$index] ;
			$Areasqm_add = $Areasqm[$index] ;
			$Areasqft_add = $Areasqft[$index] ;

			$data_r = array(
				'unit_type_id' => '0',
				'unit_type_name' => $name_add,
				'unit_type_info' => $info_add,
				'unit_type_area_sqm' => $Areasqm_add,
				'unit_type_area_sqft' => $Areasqft_add,
				'unit_type_room_type_id' => $Room_add
			);
			$new_id = $this->tb_unit_type->record($data_r);
			$path_upload = "project/".$this->project_id_sel."/unit_type/".$new_id;
			$name_file = time();
			$result_upload = $this->upload_multiple_image('Image',$index,$path_upload,$name_file);	
			if($result_upload['error_status'] == FALSE){
				$data_update = array('unit_type_image' => $result_upload['image_url']);
				$this->tb_unit_type->update($data_update,$new_id);

			}

		endforeach;

		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->pdb->trans_status() === FALSE){
     		$this->pdb->trans_rollback();
 			alert_redirect('Add Unit Type Fail','/project_unit_type/view');
		}
		else{
		  	$this->pdb->trans_commit();
		   	alert_redirect('Add Unit Type Success','/project_unit_type/view');
		}
		
	}
	public function deleting($unit_type_id){
		$permission = $this->get_user_permission();
		if (strpos($permission->pm_project,'4') !== false) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
		}
		$data_delete = array(
			'unit_type_sts_active' => 'off'
		);
		$this->load->model('tb_unit_type');
		$this->tb_unit_type->update($data_delete,$unit_type_id);
		
		alert_redirect('Delete Unit Type Success','/project_unit_type/view');
	}
}

/* End of file project_unit_type.php */
/* Location: ./application/controllers/project_unit_type.php */
?>