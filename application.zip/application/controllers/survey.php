<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Survey extends NZ_Controller
{
    /**
     * $title_page         :: text on your browser tabbar.
     */
    var $title_page = 'Admin System';
    var $page_var = 'Survey';

    /**
     *
     */
    function __construct()
    {
        parent::__construct();
        $this->checkSessionTimeout();
    }

    public function index()
    {
        $this->view();
    }

    function surveyStandAlone () {
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_answer');
        $this->load->model('tb_customer_personal_info');
        $data['title'] = $this->title_page;
        $data['page'] = 'Make' . $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['groups'] = $this->tb_survey_group->get_all_active();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['survey'] = $this->tb_survey_answer->get_all();
        $data['list_nationality'] = $this->fetch_all_nationality();

        $data['project_database_sel'] = $this->project_database_sel;
        $this->load->view('header',$data);
        $this->load->view ('SurveyStandAlone/SurveyFormCBRE', $data);
        $this->load->view('footer', $data);
    }

    public function group($type, $option)
    {
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        if ($type === 'adding') {
            $this->load->model('tb_survey_question');
            $data['questions'] = $this->tb_survey_question->get_all_in_group($option);

            $this->LoadView('Survey/ManageSurvey/survey_group_form', $data);
        } else if ($type === 'editing') {
            $this->load->model('tb_survey_group');
            $this->load->model('tb_survey_question');
            $data['groupDetail'] = $this->tb_survey_group->get_by_id($option);
            $data['questions'] = $this->tb_survey_question->get_all_in_group($option);

            $this->LoadView('Survey/ManageSurvey/survey_group_form', $data);
        } else {
            $this->load->model('tb_survey_group');
            $survey = $this->tb_survey_group->get_all();

            $data['survey'] = $this->tb_survey_group->get_all();
            $this->LoadView('Survey/ManageSurvey/survey_group', $data);
        }
    }

    public function question($type, $option)
    {
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        if ($type === 'adding') {
            $this->load->model ('tb_survey_group');
            $this->load->model ('tb_survey_question');
            $data['groups'] = $this->tb_survey_group->get_all();
            $data['mainQuestion'] = $this->tb_survey_question->get_all_main_question();
            $this->LoadView('Survey/ManageSurvey/survey_question_form', $data);
        } else if ($type === 'editing') {
            $this->load->model('tb_survey_question');
            $this->load->model('tb_survey_choice');
            $this->load->model('tb_survey_group');
            $data['groups'] = $this->tb_survey_group->get_all();
            $data['questionDetail'] = $this->tb_survey_question->get_by_id($option);
            $data['choices'] = $this->tb_survey_choice->get_by_question($option);

            $this->LoadView('Survey/ManageSurvey/survey_question_form', $data);
        } else {
            $this->load->model('tb_survey_question');
            $data['survey'] = $this->tb_survey_question->get_all();

            $this->LoadView('Survey/ManageSurvey/survey_question', $data);
        }
    }

    public function record($type, $link)
    {
        if ($type === 'group') {
            $tableName = 'survey';
            $name = $this->input->post('groupName');
            $question = '';
            $questionArr = $this->processQuestion ($this->input->post('question'));
            foreach ($this->input->post('question') as $value) {
                $question .= !empty($value) ? (!empty($question) ? ',' . $value : $value) : '';
            }
            $data = array(
                'sg_name' => $name,
                'sg_question' => $question,
                'sg_active' => 'Y'
            );
            $this->load->model('tb_survey_group');
            $sgID = $this->tb_survey_group->record($data);
            $this->tb_survey_group->update(array('sg_table_code' => $tableName.$sgID),$sgID);
            $this->tb_survey_group->create_table_survey ($tableName.$sgID, $questionArr);
            echo '<script>window.location.href = "' . BASE_DOMAIN . 'survey/group";</script>';
        } else if ($type === 'question') {
            $name = $this->input->post('questionName');
            $nameEn = $this->input->post('questionNameEn');
            
            $group = $this->input->post('group');
            $group = !empty($group) ? $group : 0;
            $this->load->model('tb_survey_question');
            $id = $this->tb_survey_question->next_id();
            if ($this->input->post('select-main-ques')) {
                $data = array(
                    'sq_id' => $id,
                    'sq_name' => $name,
                    'sq_name_en' => $nameEn,
                    'sq_main_sub' => 'S',
                    'sq_main_question' => $this->input->post('select-main-ques'),
                    'sq_group' => $group,
                    'sq_active' => 'Y'
                );
            } else {
                $data = array(
                    'sq_id' => $id,
                    'sq_name' => $name,
                    'sq_name_en' => $nameEn,
                    'sq_group' => $group,
                    'sq_active' => 'Y'
                );
            }
            $this->tb_survey_question->record($data);
            /////////////////////////////////////////
            $choice = $this->input->post('choiceName');
            $choiceEn = $this->input->post('choiceNameEn');
            $style = $this->input->post('ansStyle');
            $status = $this->input->post('ansStatus');
            $this->load->model('tb_survey_choice');
            $num = 0;
            foreach ($choice as $value):
                if ($status[$num] == 1) {
                    $statusAns = 'Y';
                } else {
                    $statusAns = 'N';
                }
                
                if (!empty($value)) {
                    $data = array(
                        'sc_name' => $value,
                        'sc_name_en' => $choiceEn[$num],
                        'sc_question' => $id,
                        'sc_type' => $style[$num],
                        'sc_active' => $statusAns
                    );
                    $this->tb_survey_choice->record($data);
                }
                $num++;
            endforeach;
            echo '<script>window.location.href = "' . BASE_DOMAIN . 'survey/question";</script>';
        } else if ($type === 'make') {
            $this->load->model('tb_survey_answer');
            $this->load->model('tb_survey_choice');
            $this->load->model('tb_survey_group');
            $this->load->model('tb_survey_ans_text');
            $this->load->model('tb_survey_question');
            $this->load->model('tb_customer_personal_info');
            $filterQues = $this->tb_survey_group->get_question_survey($this->input->post('gid'));
            $allQues = array();
            foreach ($filterQues as $_filterQues) {
                if ($_filterQues->checkMain == 'M') {
                    $getSubQues = $this->tb_survey_question->get_sub_ques_by_main_ques ($_filterQues->sq_id);
                    foreach ($getSubQues as $_getSubQues) {
                        array_push($allQues,$_getSubQues->id);
                    }
                } else {
                    array_push($allQues,$_filterQues->sq_id);
                }
            }
            $num=0;
            $newLead = $this->input->post('newlead');

            if ($newLead == 'true') {
                $prefix = $this->input->post('Prefix');
                $fname = $this->input->post('firstname');
                $lname = $this->input->post('lastname');
                $nationality = $this->input->post('Nationality');
                $mobile = $this->input->post('mobile');
                $tel = $this->input->post('tel');
                $mail = $this->input->post('mail');

                if($this->tb_customer_personal_info->check_cus_name($fname,$lname)) {
                  echo '<script>
                        alert("Sorry: This first and last name are already in the database. Please check again!!");
                        window.history.back(-2);
                    </script>';
                    exit;
                }
                $cus_id = $this->get_new_customer_id();
                $pers_id = $this->get_new_customer_personal_id();
                $addr_id = $this->get_new_customer_address_info_id();
                $addr_cur_id = $this->get_new_customer_address_current_info_id();
                $work_id = $this->get_new_customer_working_info_id();
                $con_id = $this->get_new_customer_contact_info_id();
                $addr_lastest_id = $this->get_new_customer_address_lastest_id();

                

                if ($prefix == "นาย" || $prefix == "Mr.") {
                    $sex = 'Male';
                } else {
                    $sex = 'Female';
                }
                if ($nationality == 'ไทย') {
                    $nationality = 171;
                } else {
                    $nationality = 0;
                }
                // echo "prefix : $prefix... fname : $fname... lname : $lname... sex : $sex... nation : $nationality... mobile : $mobile... tel : $tel... mail : $mail... curAddr : ".$this->input->post('curAddr').$this->input->post('subdistrict').$this->input->post('district').$this->input->post('province').$this->input->post('postcode')."";exit();
                if ($nationality == 171) {
                    if ($prefix == 'Mr.' || $prefix == 'นาย') {
                        $prefix = 'นาย';
                    } else if ($prefix == 'Miss' || $prefix == 'นางสาว') {
                        $prefix = 'นางสาว';
                    } else if ($prefix == 'Mrs.' || $prefix == 'นาง') {
                        $prefix = 'นาง';
                    } else {
                        $prefix = 'คุณ';
                    }
                    $identificationFlag = "IDCard";
                } else {
                    $identificationFlag = "passport";
                }
                
                $data_pers = array(
                    'pers_id' => $pers_id,
                    'pers_prefix' => $prefix,
                    'pers_fname' => $fname,
                    'pers_lname' => $lname,
                    'pers_card_id' => '',
                    'pers_dob' => '',
                    'pers_mobile' => $mobile,
                    'pers_tel' => $tel,
                    'pers_email' => $mail,
                    'pers_id_cus' => $cus_id,
                    'pers_nationality' => $nationality,
                    'pers_identification_flag' => $identificationFlag,
                    'pers_sex' => $sex
                );
                $this->tb_customer_personal_info->record($data_pers);

                $data_addr_info = array(
                    'addr_id' => $addr_id,
                    'addr_country' => '213',
                    'addr_id_cus' => $cus_id,
                );//Thailand = 213
                $this->load->model('tb_customer_address_info');
                $this->tb_customer_address_info->record($data_addr_info);   
                
                $data_addr_cur_info = array(
                    'addr_cur_id' => $addr_cur_id,
                    'addr_cur_address' => $this->input->post('curAddr'),
                    'addr_cur_sub_district' => $this->input->post('subdistrict'),
                    'addr_cur_district' => $this->input->post('district'),
                    'addr_cur_province' => $this->input->post('province'),
                    'addr_cur_post_code' => $this->input->post('postcode'),
                    'addr_cur_id_cus' => $cus_id,
                    'addr_cur_country' => '213'
                );
                $this->load->model('tb_customer_address_current_info');
                $this->tb_customer_address_current_info->record($data_addr_cur_info);
            
                $data_working = array(
                    'work_id' => $work_id,
                    'work_cus_id' => $cus_id,
                    'work_country' => '213'
                );  
                $this->load->model('tb_customer_working_info');
                $this->tb_customer_working_info->record($data_working);
                
                $data_con = array(
                    'con_id' => $con_id,
                    'con_id_cus' => $cus_id
                );
                $this->load->model('tb_customer_contact_info');
                $this->tb_customer_contact_info->record($data_con);

                $data_addr_last = array(
                    'addr_lastest_id' => $addr_lastest_id,
                    'addr_lastest_id_cus' => $cus_id,
                    'addr_lastest_country' => '213'
                );
                $this->load->model('tb_customer_address_lastest');
                $this->tb_customer_address_lastest->record($data_addr_last);

                $sale = $this->user_id;
                $data_leads = array(
                    'cus_id' => $cus_id,
                    'cus_pers_id' => $pers_id,
                    'cus_addr_id' => $addr_id,
                    'cus_addr_cur_id' => $addr_cur_id,
                    'cus_con_id' => $con_id,
                    'cus_work_id' => $work_id,
                    'cus_stages_id' => 1,
                    'cus_created_by' => $sale,
                    'cus_sts_active' => 'on',
                    'cus_addr_lastest_id' => $addr_lastest_id,
                    'cus_remark' => 'สร้างจาก survey'
                );
                $this->recordLeads($data_leads);
                $tempCus = $cus_id;
            } else {
                $tempCus = $this->input->post('cusid');
            }

            $cus = $tempCus;
            $group = $this->input->post('gid');
            $mediaQuesID = 1;//fix
            $budgetQuesID = 5;//fix

            foreach ($allQues as $_allQues) {
                $ques = $_allQues;
                $style = $this->input->post("ansStyle".($_allQues)."");
                $ans = $this->input->post("ch".($_allQues)."");
                $ansArr[$_allQues] = array();
                $lastQuery = count($ans);
                $numAns = 0;
                foreach ($ans as $_ans) {
                    // $style = $this->tb_survey_choice->get_detail_by_id ($_ans);
                    if ($style[$numAns] == 'textbox') {
                        if(($numAns+1) == $lastQuery){
                            $ansAll[$num] .= $_ans;
                        } else {
                            $ansAll[$num] .= $_ans.',';
                        }
                    } else {
                        $checkQues = $this->tb_survey_choice->get_detail_by_id($_ans);  
                        // if ($checkQues->sc_question == $_allQues->sq_id) {
                        if ( $checkQues->sc_type == 'checkboxtextbox' || $checkQues->sc_type == 'radiotextbox') {
                            if(($numAns+1) == $lastQuery){
                                $ansAll[$num] .= $_ans;
                            } else {
                                $ansAll[$num] .= $_ans.',';
                            }
                            $verify = $this->tb_survey_ans_text->check_cus_survey ($_ans, $cus, $group);
                            if ($verify !== null) {
                                $data_text_up = array(
                                    'sat_sg_id' => $group,
                                    'sat_sc_id' => $_ans,
                                    'sat_text' => $this->input->post("chtx$_ans")
                                );
                                // echo "update : $_ans ... $cus ... $group ... ".$this->input->post("chtx$_ans")." ... $verify->sat_id";
                                $this->tb_survey_ans_text->update ($data_text_up, $verify->sat_id);
                            } else {
                                $data_text_rec = array(
                                    'sat_sg_id' => $group,
                                    'sat_cus_id' => $cus,
                                    'sat_sc_id' => $_ans,
                                    'sat_text' => $this->input->post("chtx$_ans")
                                );
                                // echo "record : $_ans ... $cus ... $group ... ".$this->input->post("chtx$_ans")."";
                                $this->tb_survey_ans_text->record ($data_text_rec);
                            }
                            
                            // echo $this->input->post("chtx$_ans");exit();
                        } else if ($checkQues == null) {
                            if(($numAns+1) == $lastQuery){
                                $ansAll[$num] .= '0';
                            } else {
                                $ansAll[$num] .= '0,';
                            }
                        } else {
                            if(($numAns+1) == $lastQuery){
                                $ansAll[$num] .= $_ans;
                                if ($checkQues->sc_question == $mediaQuesID) {
                                    $media .= $checkQues->sc_mapping;
                                } else if ($checkQues->sc_question == $budgetQuesID) {
                                    $this->load->model('tb_budget');
                                    $tempBudget = $this->tb_budget->get_budget_by_id($checkQues->sc_mapping);
                                    $budget .= $tempBudget->budget_name;
                                }
                            } else {
                                $ansAll[$num] .= $_ans.',';
                                if ($checkQues->sc_question == $mediaQuesID) {
                                    $media .= $checkQues->sc_mapping.',';
                                } else if ($checkQues->sc_question == $budgetQuesID) {
                                    $this->load->model('tb_budget');
                                    $tempBudget = $this->tb_budget->get_budget_by_id($checkQues->sc_mapping);
                                    $budget .= $tempBudget->budget_name.',';
                                }
                            }
                        }
                        // } 
                    }
                    $numAns++;
                }
                $data["$ques"] = $ansAll[$num];
                $num++;
            }

            $data_leads = array(
                'cus_budget' => $budget,
                'cus_media_type' => $media
            );
            $this->updateLeads($data_leads,$cus);

            ////// KEEP LOG ////
            $this->load->model('tb_customer_personal_info');
            $obj_pers = $this->tb_customer_personal_info->get_detail_by_id($cus);
            
            $data_log_pers = array(
                'pers_id' => $obj_pers->pers_id,
                'pers_prefix' => $obj_pers->pers_prefix,
                'pers_fname' => $obj_pers->pers_fname,
                'pers_lname' => $obj_pers->pers_lname,
                'pers_sex' => $obj_pers->pers_sex,
                'pers_nationality' => $obj_pers->pers_nationality,
                'pers_identification_flag' => $obj_pers->pers_identification_flag,
                'pers_passport' => $obj_pers->pers_passport,
                'pers_card_id' => $obj_pers->pers_card_id,
                'pers_dob' => $obj_pers->pers_dob,
                'pers_mobile' => $obj_pers->pers_mobile,
                'pers_tel' => $obj_pers->pers_tel,
                'pers_email' => $obj_pers->pers_email,
                'pers_id_cus' => $obj_pers->pers_id_cus,
                'pers_update_by' => $this->user_id
            );
            $this->record_log_customer_personal_info($data_log_pers);

            ////// KEEP LOG ////
            $this->load->model('tb_customer');
            $obj_leads = $this->tb_customer->get_detail_by_id($cus);
            $data_log_leads = array(
                'cus_id' => $obj_leads->cus_id,
                'cus_pers_id' => $obj_leads->cus_pers_id,
                'cus_addr_id' => $obj_leads->cus_addr_id,
                'cus_addr_cur_id' => $obj_leads->cus_addr_cur_id,
                'cus_con_id' => $obj_leads->cus_con_id,
                'cus_work_id' => $obj_leads->cus_work_id,
                'cus_stages_id' => $obj_leads->cus_stages_id,
                'cus_budget' => $obj_leads->cus_budget,
                'cus_visit_type' => $obj_leads->cus_visit_type,
                'cus_media_type' => $obj_leads->cus_media_type,
                'cus_flag' => $obj_leads->cus_flag,
                'cus_created_by' => $obj_leads->cus_created_by,
                'cus_created_date' => $obj_leads->cus_created_date,
                //'cus_sts_active' => $obj_leads->cus_sts_active,
                'cus_update_by' => $this->user_id
            );
            $this->record_log_leads($data_log_leads);
            
            $this->load->model('tb_customer_address_info');
            $obj_addr = $this->tb_customer_address_info->get_detail_by_addr_id_cus($cus);
            $data_log_addr_info = array(
                'addr_id' => $obj_addr->addr_id,
                'addr_sub_district' => $obj_addr->addr_sub_district,
                'addr_district' => $obj_addr->addr_district,
                'addr_province' => $obj_addr->addr_province,
                'addr_post_code' => $obj_addr->addr_post_code,
                'addr_country' => $obj_addr->addr_country,
                'addr_id_cus' => $obj_addr->addr_id_cus,
                'addr_update_by' => $this->user_id
            );
            $this->record_log_customer_address_info($data_log_addr_info);
            
            $this->load->model('tb_customer_address_current_info');
            $obj_addr_cur = $this->tb_customer_address_current_info->get_detail_by_addr_cur_id_cus($cus);
            $data_log_addr_cur = array(
                'addr_cur_id' => $obj_addr_cur->addr_cur_id,
                'addr_cur_sub_district' => $obj_addr_cur->addr_cur_sub_district,
                'addr_cur_district' => $obj_addr_cur->addr_cur_district,
                'addr_cur_province' => $obj_addr_cur->addr_cur_province,
                'addr_cur_post_code' => $obj_addr_cur->addr_cur_post_code,
                'addr_cur_country' => $obj_addr_cur->addr_cur_country,
                'addr_cur_id_cus' => $obj_addr_cur->addr_cur_id_cus,
                'addr_cur_update_by' => $this->user_id
            );
            $this->record_log_customer_address_current_info($data_log_addr_cur);
            
            $this->load->model('tb_customer_working_info');
            $obj_working = $this->tb_customer_working_info->get_detail_by_work_cus_id($cus);
            $data_log_working = array(
                'work_id' => $obj_working->work_id,
                'work_position' => $obj_working->work_position,
                'work_company' => $obj_working->work_company,
                'work_house_no' => $obj_working->work_house_no,
                'work_road' => $obj_working->work_road,
                'work_sub' => $obj_working->work_sub,
                'work_district' => $obj_working->work_district,
                'work_province' => $obj_working->work_province,
                'work_post_code' => $obj_working->work_post_code,
                'work_country' => $obj_working->work_country,
                'work_cus_id' => $obj_working->work_cus_id,
                'work_update_by' => $this->user_id
            );
            $this->record_log_customer_working_info($data_log_working);
            
            $this->load->model('tb_customer_contact_info');
            $obj_contact = $this->tb_customer_contact_info->get_detail_by_con_id_cus($cus);
            $data_log_contact = array(
                'con_id' => $obj_contact->con_id,
                'con_fname' => $obj_contact->con_fname,
                'con_lname' => $obj_contact->con_lname,
                'con_email' => $obj_contact->con_email,
                'con_tel' => $obj_contact->con_tel,
                'con_id_cus' => $obj_contact->con_id_cus,
                'con_update_by' => $this->user_id
            );
            $this->record_log_customer_contact_info($data_log_contact);
            
            $this->load->model('tb_customer_address_lastest');
            $obj_cus_addr_lastest = $this->tb_customer_address_lastest->get_detail_by_addr_lastest_id_cus($cus);
            $data_log_addr_lastest = array(
                 'addr_lastest_id' => $obj_cus_addr_lastest->addr_lastest_id,
                 'addr_lastest_address' => $obj_cus_addr_lastest->addr_lastest_address,
                 'addr_lastest_sub_district' => $obj_cus_addr_lastest->addr_lastest_sub_district,
                 'addr_lastest_district' => $obj_cus_addr_lastest->addr_lastest_district,
                 'addr_lastest_province' => $obj_cus_addr_lastest->addr_lastest_province,
                 'addr_lastest_post_code' => $obj_cus_addr_lastest->addr_lastest_post_code,
                 'addr_lastest_country' => $obj_cus_addr_lastest->addr_lastest_country,
                 'addr_lastest_id_cus' => $obj_cus_addr_lastest->addr_lastest_id_cus,
                 'addr_cur_update_by' => $this->user_id
            );
            $this->record_log_customer_address_lastest($data_log_addr_lastest);
            
            if ($this->tb_survey_answer->check_cus($cus, "survey$group")) {
                $this->tb_survey_answer->update($data, "survey$group", $cus);
            } else {
                $data["cus_id"] = $cus;
                $data["sg_id"] = $this->input->post('gid');
                $this->tb_survey_answer->record($data, "survey$group");
            }
            if ($link === "standAlone") {
                alert_redirect('Thank you','/survey/SurveyStandAlone');
                echo '<script>window.location.href = "' . BASE_DOMAIN . 'survey/SurveyStandAlone";</script>';    
            } else {
                echo '<script>window.location.href = "' . BASE_DOMAIN . 'survey/view";</script>';    
            }   
        } else if ($type === 'mainQuestion') {
            $this->load->model('tb_survey_question');
            $id = $this->tb_survey_question->next_id();
            $data = array(
                'sq_id' => $id,
                'sq_name' => $this->input->post('nameTh'),
                'sq_name_en' => $this->input->post('nameEn'),
                'sq_main_sub' => 'M',
                'sq_active' => 'Y'
            );
            $this->tb_survey_question->record($data);
            echo 'Successful';
        }
    }
    function processQuestion ($idArr) {
        $this->load->model ('tb_survey_question');
        $result = array();
        foreach ($idArr as $value) {
            $getQuestion = $this->tb_survey_question->get_detail_by_id ($value);
            if ($getQuestion->mainSub == 'M') {
                $getSubQuestion = $this->tb_survey_question->get_sub_ques_by_main_ques ($getQuestion->id);
                foreach ($getSubQuestion as $getSubQuestion) {
                    array_push($result, $getSubQuestion->id);
                }
            } else {
                array_push($result, $getQuestion->id);
            }
        }
        return $result;
    }

    public function update($type)
    {
        if ($type === 'group') {
            $id = $this->input->post('gid');
            $name = $this->input->post('groupName');
            $question = '';
            foreach ($this->input->post('question') as $value) $question .= !empty($value) ? (!empty($question) ? ',' . $value : $value) : '';
            $data = array(
                'sg_name' => $name,
                'sg_question' => $question
            );
            $this->load->model('tb_survey_group');
            $this->tb_survey_group->update($data, $id);
            echo '<script>window.location.href = "' . BASE_DOMAIN . 'survey/group";</script>';
        } else if ($type === 'question') {
            $qid = $this->input->post('qid');
            $name = $this->input->post('questionName');
            $group = $this->input->post('group');
            $group = !empty($group) ? $group : 0;
            $data = array(
                'sq_name' => $name,
                'sq_group' => $group
            );
            $this->load->model('tb_survey_question');
            $this->tb_survey_question->update($data, $qid);
            //////////////////////////////////////////////
            $cid = $this->input->post('cid');
            $choice = $this->input->post('choiceName');
            $this->load->model('tb_survey_choice');
            $i = 0;
            foreach ($choice as $value):
                if ($i < count($cid)) {
                    if (!empty($value)) {
                        $data = array(
                            'sc_name' => $value,
                        );
                        $this->tb_survey_choice->update($data, $cid[$i]);
                    }
                } else if (!empty($value)) {
                    $data = array(
                        'sc_name' => $value,
                        'sc_question' => $qid
                    );
                    $this->tb_survey_choice->record($data);
                }
                $i++;
            endforeach;
            echo '<script>window.location.href = "' . BASE_DOMAIN . 'survey/question";</script>';
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////
    function view()
    {
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_answer');
        $this->load->model('tb_customer_personal_info');

        $data['title'] = $this->title_page;
        $data['page'] = 'Make' . $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['groups'] = $this->tb_survey_group->get_all();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo();
        $data['survey'] = $this->tb_survey_answer->get_all();

        $this->LoadView('Survey/MakeSurvey/survey_view', $data);
    }

    function report($type, $id ,$cusID)
    {
        if ($type === 'answer') {
            $this->load->model('tb_survey_group');
            $this->load->model('tb_survey_choice');
            $this->load->model('tb_customer_personal_info');
            $this->load->model('tb_survey_ans_text');
            $this->load->model('tb_survey_question');
            $filterQues = $this->tb_survey_group->get_question_survey($id);
            $getQuestion = array();

            $num = 0;
            $quesNo = array();
            foreach ($filterQues as $_filterQues) {
                if ($_filterQues->checkMain == 'M') {
                    $getSubQues = $this->tb_survey_question->get_sub_ques_by_main_ques ($_filterQues->sq_id);
                    $num++;

                    $numSec = 0;
                    foreach ($getSubQues as $_getSubQues) {
                        array_push($getQuestion,$_getSubQues->id);
                        $numSec++;
                        array_push($quesNo, "$num.$numSec");
                    }
                } else {
                    array_push($getQuestion,$_filterQues->sq_id);
                    $num++;
                    array_push($quesNo, "$num");
                }
                
            }

            $group = $this->tb_survey_group->get_by_id($id);

            $num=0;
            foreach ($getQuestion as $_getQuestion) {
                $getQuesDetail = $this->tb_survey_question->get_detail_by_id ($_getQuestion);
                $question = ($this->language === 'TH')?$getQuesDetail->nameTh:$getQuesDetail->nameEn;
                $answer = $this->tb_survey_choice->get_answer_by_question_id ($id, $_getQuestion, $cusID);
                $html .= "
                <div class='survey-block'>
                  <div class='survey-title'>".$quesNo[$num]." / ".count($getQuestion)."</div>
                  <div class='survey-content'>
                    <h2>$question</h2>
                    <div class='survey-ans'>$answer</div>
                  </div>
                </div>
                ";
                $num++;
            }
            // $answerDetail = $this->tb_survey_answer->get_by_id($id);
            $getCustomer = $this->tb_customer_personal_info->get_detail_by_pers_id_cus($cusID);
            $data['cusName'] = $getCustomer->pers_fname . ' ' . $getCustomer->pers_lname;
            $data['group'] = $group->sg_name;
        }
        $data['html'] = $html;
        $this->LoadView('Survey/MakeSurvey/survey_report', $data);
    }
    
    function report_print($type, $id)
    {
        if ($type === 'answer') {
            $this->load->model('tb_survey_answer');
            $this->load->model('tb_customer_personal_info');

            $answerDetail = $this->tb_survey_answer->get_by_id($id);
            $per = $this->tb_customer_personal_info->get_detail_by_pers_id_cus($answerDetail->sa_cus_id);
            $data['cusName'] = $per->pers_fname . ' ' . $per->pers_lname;
        }
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_question');
        $this->load->model('tb_survey_choice');
        $groupDetail = $this->tb_survey_group->get_by_id(($type === 'answer') ? $answerDetail->sa_group : $id);
        $questionDetail = $this->tb_survey_question->get_all_in_group($groupDetail->sg_question);
        $groupName = $groupDetail->sg_name;
        $answer = ($type === 'answer') ? explode(',', $answerDetail->sa_answer) : array();
        foreach ($questionDetail as $question):
            $questionList[$question->sq_name] = $this->tb_survey_choice->get_by_question($question->sq_id);
        endforeach;
        $data['groupName'] = $groupName;
        $data['questionList'] = $questionList;
        $data['answer'] = $answer;

        $this->LoadView('Survey/MakeSurvey/survey_report_print', $data);
    }

    function form()
    {
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_answer');
        $this->load->model('tb_customer_personal_info');
        $data['title'] = $this->title_page;
        $data['page'] = 'Make' . $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['groups'] = $this->tb_survey_group->get_all_active();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();
        $data['survey'] = $this->tb_survey_answer->get_all();
        $data['list_nationality'] = $this->fetch_all_nationality();

        $data['project_database_sel'] = $this->project_database_sel;
        $this->LoadView('Survey/MakeSurvey/survey_form', $data);
    }

    function dashboard()
    {
        $this->load->model ('tb_survey_group');
        $data['chartDefault'] = 1;
        $data['title'] = $this->title_page;
        $data['permission'] = $this->get_user_permission();
        $data['allGroup'] = $this->tb_survey_group->get_all_active ();
        $this->LoadView('Survey/MakeSurvey/SurveyDashboard', $data);
    }

    // private function
    function surveyChart ($chart, $group) {
        $this->load->model ('tb_survey_group');
        $this->load->model ('tb_survey_answer');
        $this->load->model ('tb_survey_choice');
        $this->load->model ('tb_survey_question');

        $quesNo = $this->getQuestionNO ($group);

        $getQuestion = $this->tb_survey_group->get_question_survey_dashboard ($group);

        $num=0;
        foreach ($getQuestion as $_getQuestion) {
            $getDetail = $this->tb_survey_answer->get_count_answer_survey ("survey$group", $_getQuestion->id);
            $lastQuery = count($getDetail);
            $num2=0;
            foreach ($getDetail as $_getDetail) {
                if ($chart == '3') { 
                    if ($lastQuery == ($num2+1)) {
                        $pieData[$num] .= "['".$_getDetail->sc_name."', $_getDetail->count]";
                    } else {
                        $pieData[$num] .= "['".$_getDetail->sc_name."', $_getDetail->count],";
                    }
                } else {
                    if ($lastQuery == ($num2+1)) {
                        $listChoice[$num] .= "'$_getDetail->sc_name'";
                        $count[$num] .= "$_getDetail->count";
                    } else {
                        $listChoice[$num] .= "'$_getDetail->sc_name',";
                        $count[$num] .= "$_getDetail->count,";
                    }
                }
                $num2++;
            }

            if ($chart == '1') {
                $html[$num] .= "
                <div class='lineChart$num'>
                </div>
                <script>
                $(function () {
                    $('.lineChart$num').highcharts({
                        title: {
                            text: 'ข้อ ".($quesNo[$num]).". $_getQuestion->nameTh',
                            x: -20 //center
                        },
                        subtitle: {
                            text: '',
                            x: -20
                        },
                        xAxis: {
                            categories: [$listChoice[$num]]
                        },
                        yAxis: {
                            title: {
                                text: 'จำนวนข้อที่ตอบ (ครั้ง)'
                            },
                            plotLines: [{
                                value: 0,
                                width: 1,
                                color: '#808080'
                            }]
                        },
                        tooltip: {
                            valueSuffix: ' ครั้ง'
                        },
                        legend: {
                            layout: 'vertical',
                            align: 'right',
                            verticalAlign: 'middle',
                            borderWidth: 0
                        },
                        series: [{
                            name: 'เลือกตัวเลือกนี้',
                            data: [$count[$num]]
                        }]
                    });  
                }); 
                </script>
                ";
            } else if ($chart == '2') {
                $html[$num] .= "
                <div class='columnChart$num'>
                </div>
                <script>
                $(function () {
                    $('.columnChart$num').highcharts({
                        chart: {
                            type: 'column'
                        },
                        title: {
                            text: 'ข้อ ".($quesNo[$num]).". $_getQuestion->nameTh'
                        },
                        subtitle: {
                            text: ''
                        },
                        xAxis: {
                            categories: [$listChoice[$num]],
                            crosshair: true
                        },
                        yAxis: {
                            min: 0,
                            title: {
                                text: 'จำนวนข้อที่ตอบ (ครั้ง)'
                            }
                        },
                        tooltip: {
                            headerFormat: '<p> {point.key}</p><table>',
                            pointFormat: '{series.name}: ' +
                                '<b>{point.y:.0f} ครั้ง</b>',
                            footerFormat: '</table>',
                            shared: true,
                            useHTML: true
                        },
                        plotOptions: {
                            column: {
                                pointPadding: 0.2,
                                borderWidth: 0
                            }
                        },
                        series: [{
                            name: 'เลือกตัวเลือกนี้',
                            data: [$count[$num]]
                        }]
                    });
                });
                </script>
                ";
            } else if ($chart == '3') {
                $html[$num] = "
                <div class='pieChart$num'>
                </div>
                <script>
                $(function () {
                    $('.pieChart$num').highcharts({
                        chart: {
                            type: 'pie',
                        },
                        title: {
                            text: 'ข้อ ".($quesNo[$num]).". $_getQuestion->nameTh'
                        },
                        subtitle: {
                            text: ''
                        },
                        plotOptions: {
                            pie: {
                                innerSize: 100,
                            }
                        },

                        series: [{
                            name: 'จำนวนข้อที่ตอบ ',
                            data: [
                               $pieData[$num]
                            ].filter(function(d) {return d[1] > 0})
                        }]
                    });
                });
                </script>
                ";
            }
            $num++;
        }
        echo json_encode($html);
    }

    public function getSurvey ($group, $need) {
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_choice');
        $this->load->model('tb_survey_question');
        $question = $this->tb_survey_group->get_question_survey ($group);
        $choiceID = array();
        $num = 0;
        foreach ($question as $_question) {
            $num++;
            $choice = $this->tb_survey_choice->get_choice_survey ($_question->sq_id);
            $numCh = 0;
            foreach ($choice as $_choice) { 
                if ($_choice->type == 'checkbox') {
                    $choices[$num] .= 
                    "    <div class='col s12 m6 l6'>
                            <span>
                                <input type='hidden' name='ch$_question->sq_id[$numCh]' value='0' />
                                <input class='ch$_question->sq_id' type='checkbox' id='ch$_question->sq_id$numCh' name='ch$_question->sq_id[$numCh]' value='$_choice->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                <label for='ch$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                                <input type='hidden' name='ansStyle$_question->sq_id[]' value='$_choice->type' />
                            </span>
                        </div>";  
                } else if ($_choice->type == 'radio') {
                    $choices[$num] .= 
                    "    <div class='col s12 m6 l6'>
                            <span>
                                <input class='ch$_question->sq_id' name='ch$_question->sq_id[]' type='radio' id='ch$_question->sq_id$numCh' value='$_choice->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                <label for='ch$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                                <input type='hidden' name='ansStyle$_question->sq_id[$numCh]' value='$_choice->type' />
                            </span>
                        </div>";
                } else if ($_choice->type == 'textbox') {
                    $choices[$num] .= 
                    "    <div>
                            <div class='input-field'>
                                <input class='ch$_question->sq_id' id='ch$_question->sq_id$numCh' type='text' class='validate' name='ch$_question->sq_id[]' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'>
                                <label for='ch$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                                <input type='hidden' name='ansStyle$_question->sq_id[]' value='$_choice->type' />
                            </div>
                        </div>";
                } else if ($_choice->type == 'checkboxtextbox') {
                    $choices[$num] .= 
                    "    <div class='col s12 m6 l6'>
                            <span>
                                <input  type='hidden' name='ch$_question->sq_id[$numCh]' value='0' />
                                <input class='ch$_question->sq_id' type='checkbox' id='ch$_question->sq_id$numCh' name='ch$_question->sq_id[$numCh]' value='$_choice->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                <label for='ch$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                                <input type='hidden' name='ansStyle$_question->sq_id[]' value='$_choice->type' />
                            </span>
                            <div class='input-field chtx$_question->sq_id$numCh'>
                                <input id='chtx$_question->sq_id$numCh' type='text' class='validate' name='chtx$_choice->id'>
                                <label for='chtx$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                            </div>
                        </div>
                        <script>
                        $(document).ready(function(){
                            $('.chtx$_question->sq_id$numCh').hide();
                            $('#ch$_question->sq_id$numCh').click(function(){
                                $('.chtx$_question->sq_id$numCh').toggle(300);
                                $('#chtx$_question->sq_id$numCh').focus();
                            });
                        });
                        </script>
                        ";
                } else if ($_choice->type == 'radiotextbox') {
                    $choices[$num] .= 
                    "    <div class='col s12 m6 l6'>
                            <span>
                                <input class='ch$_question->sq_id' name='ch$_question->sq_id[]' type='radio' id='ch$_question->sq_id$numCh' value='$_choice->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                <label for='ch$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                                <input type='hidden' name='ansStyle$_question->sq_id[$numCh]' value='$_choice->type' />
                            </span>
                            <div class='input-field chtx$_question->sq_id$numCh'>
                                <input id='chtx$_question->sq_id$numCh' type='text' class='validate' name='chtx$_choice->id'>
                                <label for='chtx$_question->sq_id$numCh'>".(($this->language === 'TH')?$_choice->nameTh:$_choice->nameEn)."</label>
                            </div>
                        </div>
                        <script>
                        $(document).ready(function(){
                            $('.chtx$_question->sq_id$numCh').hide();
                            $('#ch$_question->sq_id$numCh').click(function(){
                                $('.chtx$_question->sq_id$numCh').toggle(300);
                                $('#chtx$_question->sq_id$numCh').focus();
                            });
                        });
                        </script>
                        ";

                }
                $numCh++;
            }
            if ($_question->checkMain == 'M') {
                $subQuestion = $this->tb_survey_question->get_sub_ques_by_main_ques ($_question->sq_id);
                $numSub = 0;
                foreach ($subQuestion as $_subQuestion) {
                    $numSub++;
                    $choiceSub = $this->tb_survey_choice->get_choice_survey ($_subQuestion->id);
                    $numChSub = 0;
                    foreach ($choiceSub as $_choiceSub) {
                        if ($_choiceSub->type == 'checkbox') {
                            $choicesSub[$numSub] .= 
                            "    <div class='col s12 m6 l6'>
                                    <span>
                                        <input type='hidden' name='ch$_subQuestion->id[$numChSub]' value='0' />
                                        <input class='ch$_subQuestion->id' type='checkbox' id='ch$_subQuestion->id$numChSub' name='ch$_subQuestion->id[$numChSub]' value='$_choiceSub->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                        <label for='ch$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                        <input type='hidden' name='ansStyle$_subQuestion->id[]' value='$_choiceSub->type' />
                                    </span>
                                </div>";  
                        } else if ($_choiceSub->type == 'radio') {
                            $choicesSub[$numSub] .= 
                            "    <div class='col s12 m6 l6'>
                                    <span>
                                        <input class='ch$_subQuestion->id' name='ch$_subQuestion->id[]' type='radio' id='ch$_subQuestion->id$numChSub' value='$_choiceSub->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                        <label for='ch$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                        <input type='hidden' name='ansStyle$_subQuestion->id[$numChSub]' value='$_choiceSub->type' />
                                    </span>
                                </div>";
                        } else if ($_choiceSub->type == 'textbox') {
                            $choicesSub[$numSub] .= 
                            "    <div>
                                    <div class='input-field'>
                                        <input class='ch$_subQuestion->id' id='ch$_subQuestion->id$numChSub' type='text' class='validate' name='ch$_subQuestion->id[]' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'>
                                        <label for='ch$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                        <input type='hidden' name='ansStyle$_subQuestion->id[]' value='$_choiceSub->type' />
                                    </div>
                                </div>";
                        } else if ($_choiceSub->type == 'checkboxtextbox') {
                            $choicesSub[$numSub] .= 
                            "    <div class='col s12 m6 l6'>
                                    <span>
                                        <input type='hidden' name='ch$_subQuestion->id[$numChSub]' value='0' />
                                        <input class='ch$_subQuestion->id' type='checkbox' id='ch$_subQuestion->id$numChSub' name='ch$_subQuestion->id[$numChSub]' value='$_choiceSub->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                        <label for='ch$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                        <input type='hidden' name='ansStyle$_subQuestion->id[]' value='$_choiceSub->type' />
                                    </span>
                                    <div class='input-field chtx$_subQuestion->id$numChSub'>
                                        <input id='chtx$_subQuestion->id$numChSub' type='text' class='validate' name='chtx$_choiceSub->id'>
                                        <label for='chtx$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                    </div>
                                </div>
                                <script>
                                $(document).ready(function(){
                                    $('.chtx$_subQuestion->id$numChSub').hide();
                                    $('#ch$_subQuestion->id$numChSub').click(function(){
                                        $('.chtx$_subQuestion->id$numChSub').toggle(300);
                                        $('#chtx$_subQuestion->id$numChSub').focus();
                                    });
                                });
                                </script>
                                ";
                        } else if ($_choiceSub->type == 'radiotextbox') {
                            $choicesSub[$numSub] .= 
                            "    <div class='col s12 m6 l6'>
                                    <span>
                                        <input class='ch$_subQuestion->id' name='ch$_subQuestion->id[]' type='radio' id='ch$_subQuestion->id$numChSub' value='$_choiceSub->id' onclick='checkAnswer("."\""."ch$_question->sq_id"."\"".")'/>
                                        <label for='ch$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                        <input type='hidden' name='ansStyle$_subQuestion->id[$numChSub]' value='$_choiceSub->type' />
                                    </span>
                                    <div class='input-field chtx$_question->id$numChSub'>
                                        <input id='chtx$_subQuestion->id$numChSub' type='text' class='validate' name='chtx$_choiceSub->id'>
                                        <label for='chtx$_subQuestion->id$numChSub'>".(($this->language === 'TH')?$_choiceSub->nameTh:$_choiceSub->nameEn)."</label>
                                    </div>
                                </div>
                                <script>
                                $(document).ready(function(){
                                    $('.chtx$_subQuestion->id$numChSub').hide();
                                    $('#ch$_subQuestion->id$numChSub').click(function(){
                                        $('.chtx$_subQuestion->id$numChSub').toggle(300);
                                        $('#chtx$_subQuestion->id$numChSub').focus();
                                    });
                                });
                                </script>
                                ";
                        }
                        $numChSub++;
                    }
                    $allSubQues[($num-1)] .= 
                    "
                    <div class='survey-block'>
                        <div class='survey-title'>$num.$numSub</div>
                        <div class='survey-content'>
                            <h2>".(($this->language === 'TH')?$_subQuestion->nameTh:$_subQuestion->nameEn)."</h2>
                            <div class='row ch$_question->sq_id'>
                                $choicesSub[$numSub]
                            </div>
                        </div>
                    <div class='survey-block'>
                    ";
                    // $choiceID[($num-1)] = "$_question->sq_id";
                    // array_push($choiceID, "ch$_subQuestion->id");

                }
                $html[($num-1)] = 
                "<div class='survey-block'>
                    <div class='survey-title'>$num/".(count($question))."</div>
                    <div class='survey-content'>
                        <h2>".(($this->language === 'TH')?$_question->sq_name:$_question->nameEng)."</h2>
                        <div class='row survey-form'>
                            ".$allSubQues[($num-1)]."
                        </div>
                    </div>
                </div>";
                array_push($choiceID, "ch$_question->sq_id");
            } else {
                $html[($num-1)] = 
                "<div class='survey-block ch$_question->sq_id'>
                    <div class='survey-title'>$num/".(count($question))."</div>
                    <div class='survey-content'>
                        <h2>".(($this->language === 'TH')?$_question->sq_name:$_question->nameEng)."</h2>
                        <div class='row'>
                            $choices[$num]
                        </div>
                    </div>
                </div>";
                // $choiceID[($num-1)] = "$_question->sq_id";
                array_push($choiceID, "ch$_question->sq_id");
            }
        }
        // echo("survey$question");
        if ($need == "choice") {
            echo json_encode($choiceID);
        } else {
            echo json_encode($html);
        }
    }
    private function fetch_all_nationality(){
        $this->load->model('tb_nationality');
        return $this->tb_nationality->fetch_all_nationality();
    }
    private function get_new_customer_id(){
        $this->load->model('tb_customer');
        return $this->tb_customer->get_new_customer_id();
    }
    private function get_new_customer_personal_id(){
        $this->load->model('tb_customer_personal_info');
        return $this->tb_customer_personal_info->get_new_customer_personal_id();
    }
    private function get_new_customer_address_info_id(){
        $this->load->model('tb_customer_address_info');
        return $this->tb_customer_address_info->get_new_customer_address_info_id();
    }
    private function get_new_customer_address_current_info_id(){
        $this->load->model('tb_customer_address_current_info');
        return $this->tb_customer_address_current_info->get_new_customer_address_current_info_id();
    }
    private function get_new_customer_working_info_id(){
        $this->load->model('tb_customer_working_info');
        return $this->tb_customer_working_info->get_new_customer_working_info_id(); 
    }
    private function get_new_customer_contact_info_id(){
        $this->load->model('tb_customer_contact_info');
        return $this->tb_customer_contact_info->get_new_customer_contact_info_id();
    }
    private function get_new_customer_address_lastest_id(){
        $this->load->model('tb_customer_address_lastest');
        return $this->tb_customer_address_lastest->get_new_customer_address_lastest_id();
    }
    private function recordLeads($data)
    {
        $this->load->model('tb_customer');
        $this->tb_customer->record($data);
        
    }
    private function updateLeads($data,$cid)
    {
        $this->load->model('tb_customer');
        $this->tb_customer->update($data,$cid);
    }
    private function record_log_customer_personal_info($data)
    {
        $this->load->model('log_customer_personal_info');
        $this->log_customer_personal_info->record($data);
    }
    private function record_log_leads($data)
    {
        $this->load->model('log_customer');
        $this->log_customer->record($data);
    }
    private function record_log_customer_contact_info($data)
    {
        $this->load->model('log_customer_contact_info');
        $this->log_customer_contact_info->record($data);
    }
    private function record_log_customer_address_info($data)
    {
        $this->load->model('log_customer_address_info');
        $this->log_customer_address_info->record($data);
    }
    private function record_log_customer_address_current_info($data)
    {
        $this->load->model('log_customer_address_current_info');
        $this->log_customer_address_current_info->record($data);
    }
    private function record_log_customer_working_info($data)
    {
        $this->load->model('log_customer_working_info');
        $this->log_customer_working_info->record($data);
    }
    private function record_log_customer_address_lastest($data)
    {
        $this->load->model('log_customer_address_lastest');
        $this->log_customer_address_lastest->record($data);
    }

    function getMainQuestion () {
        $this->load->model ('tb_survey_question');
        echo json_encode ($this->tb_survey_question->get_all_main_question ());
    }

    function getQuestionNO ($id) {
        $this->load->model('tb_survey_group');
        $this->load->model('tb_survey_question');

        $filterQues = $this->tb_survey_group->get_question_survey($id);

        $num = 0;
        $quesNo = array();
        foreach ($filterQues as $_filterQues) {
            if ($_filterQues->checkMain == 'M') {
                $getSubQues = $this->tb_survey_question->get_sub_ques_by_main_ques ($_filterQues->sq_id);
                $num++;
                $numSec = 0;
                foreach ($getSubQues as $_getSubQues) {
                    $numSec++;
                    array_push($quesNo, "$num.$numSec");
                }
            } else {
                $num++;
                array_push($quesNo, "$num");
            } 
        }
        return $quesNo;
    }
}

?>
