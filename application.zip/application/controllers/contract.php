<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contract extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Contract';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
	public function view(){
		
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['list_booking'] = $this->fetch_booking($this->project_id_sel);
        $this->load->model('tb_receipt_temporary');
		
		$this->LoadView('Contract/contract',$data);
	}
	public function adding($bookCode,$cus_id) {
		
		$this->load->model('tb_customer_personal_info');
		$detailCustomer = $this->tb_customer_personal_info->get_detail_by_pers_id_cus($cus_id);
		$data['cus_name'] = $detailCustomer->pers_fname." ".$detailCustomer->pers_lname;
		$data['cus_id'] = $cus_id;
		$data['bookby'] = $data['cus_name'];
		$data['bookCust'] = $cus_id;
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['bookCode'] = $bookCode;
		$data['permission'] = $this->get_user_permission();
		if($bookCode == NULL){
			redirect('/booking/view');
		}
		$this->load->model('tb_contract');
		$querybookCode = $this->tb_contract->get_detail_by_ct_booking_code($bookCode);
		if($querybookCode != NULL) {
			alert_redirect('Can not create contract , Please check Booking No.','/booking/view');
            exit;
		}

		$this->load->model('tb_booking');
		$getQuocode = $this->tb_booking->get_detail_by_bk_booking_code($bookCode);
		$quoCode = $getQuocode->bk_quotation_code;
		$bookingDeposit = $getQuocode->bk_money_amount;
		$bookingCusid = $getQuocode->bk_leads_id;
		
		$this->load->model('tb_customer');
		$getBookingName= $this->tb_customer->get_detail_leads_withOut_oppotunityStageAndActive($bookingCusid);
		$BookingName = $getBookingName->pers_prefix.$getBookingName->pers_fname.' '.$getBookingName->pers_lname;
				
		$this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$Project = 	$getQuo->qt_project_id;
		$Building =$getQuo->qt_buliding_id;
		$Floor =$getQuo->qt_floor_id;
		$Number =$getQuo->qt_unit_number_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$dateQuo =$getQuo->qt_date;
		$promotiomQuo =$getQuo->qt_promotion;
	
		$this->load->model('tb_project');
		$get = $this->tb_project->get_detail_project_ignoreStatusActive($Project);
		$databasenameQuo = $get->pj_datebase_name;
		$pj_name = $get->pj_name;

		$this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;

		$this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
		$unit_type_name 	= $getRoom->unit_type_name;
		$un_name 			= $getRoom->un_name;
		$unit_type_area_sqm 	= $getRoom->unit_type_area_sqm;
		$un_direction		= $getRoom->un_direction;
		$room_type_name		= $getRoom->room_type_name;
		$room_type_id		= $getRoom->room_type_id;
        
//        $unitDetail = $this->tb_unit_number->get_detail_unit_by_un_id($Number);
//        if($getRoom->un_status_room != 'Booked') {
//            alert_redirect('This room is unavailable.','/contract/view');
//            exit;
//        }

		$this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_selling_sqm 	= $getPrice->pr_asking_sqm;
		$pr_asking_price	= $getPrice->pr_asking_price;
		
	
		$today = $dateQuo;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_contract_promotion');
        $proList = $this->tb_contract_promotion->get_detail_by_bk_code($bookCode);
        $proID = array();
        foreach($proList as $pro) {
            $proID[] = $pro->cp_promotion_id;
        }
        $promotionid = implode(',', $proID);
        /////////////////////////////////////////////////////////////
		$this->load->model('tb_promotion');
		$pm_value = 0;
		$pm_value = $this->tb_promotion->getPromotionBySearchQuotation_Discount($promotionid);
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value - (float)$getQuo->qt_total_down_payment;
        $getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotionid);
        /////////////////////////////////////////////////////////////
        
        $TransferPayment = $specialPrice;

		$CondoPrice = $pr_asking_price1;
		$BookingFee 	= $getQuo->qt_booking_fee;
		$ContractFee 	= $getQuo->qt_contract_fee;
	  	
	  	$TotalDownMonth = $getQuo->qt_total_months;

		$todayQuo = $dateQuo;
        
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        
		$data['quoCode'] = $quoCode;
		$data['bookCode'] = $bookCode;
		$data['TotalDownMonth'] = $TotalDownMonth;
		$data['pj_name'] = $pj_name;
		$data['todayQuo'] = $todayQuo;
		$data['BookingName'] = $BookingName;
		$data['un_name'] = $un_name;
		$data['building_name'] = $building_name;
		$data['unit_type_name'] = $unit_type_name;
		$data['unit_type_area_sqm'] = $unit_type_area_sqm;
		$data['room_type_name'] = $room_type_name;
		$data['pr_selling_sqm'] = $pr_asking_sqm;
		$data['un_direction'] = $un_direction;
		$data['pr_asking_price'] = $pr_asking_price;
		$data['CondoPrice'] = $CondoPrice;
		$data['pm_value'] = $pm_value;
		$data['list_promotion'] = $getPromotion;
		$data['BookingFee'] = $BookingFee;
		$data['ContractFee'] = $ContractFee;
		$data['TransferPayment'] = $TransferPayment;
		$data['InstallmentDetail'] = $InstallmentDetail;
		$data['Project'] = $Project;
		$data['Building'] = $Building;
		$data['Number'] = $Number;
		$data['Balloon'] = $Balloon;
		$data['BalloonFee'] = $BalloonFee;
		$data['InstallmentFee'] = $InstallmentFee;
		$data['BalloonMonthText'] = $BalloonMonthText;
		$data['getBookingName'] = $getBookingName;
		$data['room_type_id'] = $room_type_id;
        $data['project_database_sel'] = $this->project_database_sel;
        $data['qtDetail'] = $getQuo;
		if  ( !empty($room_type_id) )
        {
           $getrefers = $this->tb_promotion->fetch_detailTypeCash_by_pm_room_type_id($room_type_id);
           $data['getrefers'] = $getrefers;
 		}
        /////////

		$this->load->model('tb_customer_personal_info');
		$data['list_customer'] = $this->tb_customer_personal_info->fetch_all_customer_smallInfo_NotLeads();

		$this->load->model('tb_authorize_user');
		$data['signature'] = $this->tb_authorize_user->get_info_by_documentContract();
		
		$this->LoadView('Contract/contract_adding',$data);
	}
    
	public function record($bookCode){
        date_default_timezone_set('Asia/Bangkok');
        $this->load->database();
        $this->pdb->trans_begin();
        
		$sale = $this->user_id;
		$cus = '';
		$count =0;
		$pt_contract = $this->input->post('cusid');
		
		$flagCusId1 = TRUE;
		$flagCusId2 = TRUE;
		$flagCusId3 = TRUE;
		$flagCusId4 = TRUE;
		$usersignature	= $this->input->post('authorize');
		$cus1 = $this->input->post('user_fullname1');
		$cus2 = $this->input->post('user_fullname2');
		$cus3 = $this->input->post('user_fullname3');
		$cus4 = $this->input->post('user_fullname4');

        $this->load->model('tb_project');
		$get1 = $this->tb_project->get_detail_project_ignoreStatusActive($projectid);

		$databasename =	$get1->pj_datebase_name;
		$unitnumberid = $this->input->post('unitnumberid'); 
		$buildingid = $this->input->post('buildingid');  
		$unitnumber = $this->input->post('unitnumber'); 

        $this->load->model('tb_unit_number');
        $unitDetail = $this->tb_unit_number->get_detail_unit_by_un_id($unitnumberid);
        if($unitDetail->un_status_room != 'Booked') {
            alert_redirect('This room is unavailable.','/contract/view');
            exit;
        }
        $this->load->model('tb_contract');
        $querybookCode = $this->tb_contract->get_detail_by_ct_booking_code($bookCode);
		if($querybookCode != NULL) {
			alert_redirect('Can not create contract , Please check Booking No.','/booking/view');
            exit;
		}
		
		if ($cus1!=NULL) {
			if ($pt_contract[0]==0) {
				$flagCusId1 = FALSE;
			}
		}
		if ($cus2!=NULL) {
			if ($pt_contract[1]==0) {
				$flagCusId2 = FALSE;
			}
		}
		if ($cus3!=NULL) {
			if ($pt_contract[2]==0) {
				$flagCusId3 = FALSE;
			}
		}
		if ($cus4!=NULL) {
			if ($pt_contract[3]==0) {
				$flagCusId4 = FALSE;
			}
		}
		if ($flagCusId1==FALSE||$flagCusId2==FALSE||$flagCusId3==FALSE||$flagCusId4==FALSE) {
				echo "<script> alert('Can not create contract , Please check customer');  history.back();</script>";
				exit;
		}
        
		foreach($pt_contract as $index => $val ){
            if ($pt_contract[$index]!= null) {
                if ($count>0) {
                    $cus .=',';
                }
                $cus .= $pt_contract[$index];
                $count++;
            }
		}
	
		$projectid =	$this->input->post('projectid');
		$typeCon =	$this->input->post('TypeCon');        
		$Paymentmonth =	$this->input->post('Paymentmonth');           
	    $MoneyAmount  =	$this->input->post('unitreserv');
        
        date_default_timezone_set('Asia/Bangkok');
		$today = date("Y-m-d H:i:s"); 
		
		$newid = $this->tb_contract->get_new_contract_id($this->project_id_sel);
		$tmp   = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
		$tmptmp = strlen($projectid);
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) {
			$tmpIDP .= '0';
		}
        
        $this->load->model('tb_booking');
        $booking = $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bookCode);
//        $contractDate = date_format(date_create($booking->bk_contract_date), 'ymd');
        
		$dateQuo = date("ymd"); 
		$newid ='C'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid;
        $ctCode = $newid;
        $newrid ='R'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid;
		
		$data_contract = array(
			'ct_code' => $newid,
			'ct_booking_code' => $bookCode,
			'ct_cus_id' => $cus,
			'ct_type' => $typeCon,
			'ct_date' => $booking->bk_contract_date,
			'ct_pay_day' => $booking->bk_pay_day,
			'ct_staff_id' => $this->user_id,
			'ct_project_id' => $this->project_id_sel,
			'ct_paid' => 'no'
		);
		$this->tb_contract->record($data_contract);

        $this->load->model('tb_booking');
        if($this->tb_booking->get_detail_by_bk_booking_code($bookCode)->bk_status === 'on') {
            $data_booking = array('bk_status' => 'off');
            $this->tb_booking->update($data_booking,$bookCode);
        }
        $data_room_sts = array(
			'rs_unit_number' => $unitnumberid,
			'rs_cus_id' => $cus,
			'rs_status' => 'Make Contract',
			'rs_staff_id' => $this->user_id
		);
		$this->load->model('tb_room_status');
		$this->tb_room_status->record($data_room_sts);
        
        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            alert_redirect('Contract Fail','/contract/view');
        }
        else{
            $this->pdb->trans_commit();
            echo "<script>window.open('".BASE_DOMAIN."contract/report/th/$newid','_blank');";
            echo "window.location.href = '".BASE_DOMAIN."contract/view';</script>";
//            redirect('/contract/view');
        }
	}
    
    public function maketempreceipt($ctCode) {
        $this->checkSessionTimeout();
		/////////////////////////////////////////////////////////////
        $this->load->model('tb_contract');
        $ctDetail = $this->tb_contract->get_detail_by_ct_code($ctCode);
        $bkCode = $ctDetail->ct_booking_code;
        if($ctDetail->ct_paid !== 'no' || $ctDetail->ct_active === 'cancelled') {
            alert_redirect('Can not create temp receipt.','/contract/view');
            exit;
        }
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_booking');
        $bkDetail = $this->tb_booking->get_detail_by_bk_booking_code($bkCode);
        $qtCode = $bkDetail->bk_quotation_code;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_quotation');
        $qtDetail = $this->tb_quotation->getDetail_by_id($qtCode);
        $Number =$qtDetail->qt_unit_number_id;
        $Building =$qtDetail->qt_buliding_id;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_customer_personal_info');
        $cusList = $this->tb_customer_personal_info->list_customer($ctDetail->ct_cus_id);
        $cusFullName = array();
        foreach($cusList as $cus)
            $cusFullName[] = $cus->pers_fname.' '.$cus->pers_lname;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
        $room_type_id = $getRoom->room_type_id;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_payment_terms');
		$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($qtDetail->qt_payment_terms);
        $BookingFee 	= $getPaymentTerms->pt_booking;
        $ContractFee 	= $getPaymentTerms->pt_contract;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_bank');
        $banklist = $this->tb_bank->get_all_bank();
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_credit_type');
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_selling_sqm 	= $getPrice->pr_asking_sqm;
		$pr_asking_price	= $getPrice->pr_asking_price;
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_contract_promotion');
        $proList = $this->tb_contract_promotion->get_detail_by_bk_code($bkCode);
        $proID = array();
        foreach($proList as $pro) {
            $proID[] = $pro->cp_promotion_id;
        }
        $promotionid = implode(',', $proID);
        /////////////////////////////////////////////////////////////
        $this->load->model('tb_promotion');
        $pm_value = 0;
		$pm_value = $this->tb_promotion->getPromotionBySearchQuotation_Discount($promotionid);
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value - (float)$qtDetail->qt_total_down_payment;
        $getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotionid);
		
		$allCredit = $this->tb_promotion->fetchAllCredit();
        /////////////////////////////////////////////////////////////
        
        $TransferPayment = $specialPrice;
        
        
        $this->load->model('log_customer_credit');
        $this->load->library('encrypt');
        $data['credit'] = $this->log_customer_credit->on(explode(',',$ctDetail->ct_cus_id)[0]);
        
        $data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
        if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $this->load->model('tb_receipt_offical');
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled();
        }
        $data['ctCode'] = $ctCode;
        $data['bkCode'] = $bkCode; 
        $data['qtCode'] = $qtCode;
        $data['type']   = $ctDetail->ct_type;
        $data['cusList']= $cusFullName;
        $data['todayQuo'] = $qtDetail->qt_date;
        $data['unName'] = $getRoom->un_name;
        $data['building'] = $getBuilding->building_name;
        $data['unType'] = $getRoom->unit_type_name;
        $data['unit_type_area_sqm'] = $getRoom->unit_type_area_sqm;
        $data['un_direction'] = $getRoom->un_direction;
        $data['room_type_name'] = $getRoom->room_type_name;
        $data['pr_selling_sqm'] = $getPrice->pr_selling_sqm;
        $data['pr_asking_price'] = $getPrice->pr_asking_price;
        $data['project_database_sel'] = $this->project_database_sel;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        $data['allCredit'] = $allCredit;
        $data['room_type_id'] = $room_type_id;
        $data['TransferPayment'] = $TransferPayment;
        $data['qtDetail'] = $qtDetail;
        $data['list_promotion'] = $getPromotion;
        $data['promotionid'] = $promotionid;
        $data['Number'] = $Number;
        
		$this->LoadView('Contract/contract_maketempreceipt',$data);
    }
    
    public function update() {
        date_default_timezone_set('Asia/Bangkok');
        
        $unitnumber     = $this->input->post('unitnumber');
        $installmentMonth   = $this->input->post('installmentMonth');
        $ctCode         = $this->input->post('ctCode');
        $unitnumberid   = $this->input->post('unitnumberid');
        $contractfee    = $this->input->post('contractfee');
        $ctCode         = $this->input->post('ctCode');
        $bkCode         = $this->input->post('bkCode');
        $remark         = $this->input->post('Remark');
        
        $Project = 	$this->project_id_sel;
        $today = date('Y-m-d H:i:s');
        
        $this->load->database();
        $this->pdb->trans_begin();
        $this->load->model('tb_contract');
		$ctDetail = $this->tb_contract->get_detail_by_ct_code($ctCode);
        if($ctDetail->ct_paid !== 'no' || $ctDetail->ct_active === 'cancelled') {
            alert_redirect('Can not create temp receipt.','/contract/view');
            exit;
        }
        $this->load->model('tb_unit_number');
        try {
            $data_unit_number = array(
                'un_status_room' => 'Sold'
            );
            $this->tb_unit_number->update_where($data_unit_number,"un_id = '".$unitnumberid."' AND un_name = '".$unitnumber."' AND un_status_room = 'Booked'");         
        } catch (Exception $e) {
            alert_redirect('This room is unavailable.','/contract/view');
            exit;
        }
        $data = array(
            'ct_remark' => $remark,
            'ct_active' => 'off',
            'ct_paid' => 'yes',
            'ct_temp_receipt_date' => $today
        );
        $this->tb_contract->update_where_equal_ct_code($data, $ctCode);
        
        $this->load->model('tb_customer_project');
        foreach(explode(',', $ctDetail->ct_cus_id) as $val) {
            if( empty( $this->tb_customer_project->get_id_by_cus($val) ) ) {
                $data = array(
                    'cp_cus_id' => $val,
                    'cp_project_id' => $this->project_id_sel
                );
                $this->tb_customer_project->record($data);
            }
        }
        
        $unit_name = '';
        for($i = strlen($unitnumber);$i<4;$i++){
            $unit_name .= '0';
        }
        $unit_name .= $unitnumber;
        $imcode = 'IM-'.$unit_name.'-';
        $this->load->library('payment');
        $this->load->model('tb_installment');
        $this->load->model('tb_project');
        $projectDetail = $this->tb_project->get_detail_project_selected($Project);
        if(!empty($projectDetail->pj_end_downpayment)) {
            $startDate = strtotime("-$installmentMonth month", strtotime($projectDetail->pj_end_downpayment));
//            echo '<script>console.log("'.$projectDetail->pj_end_downpayment.';'.$installmentMonth.';'.$startDate.'")</script>';
        }else {
            $startDate = date("Y-m-".$ctDetail->ct_pay_day);
        }
        
        $this->load->model('tb_booking');
        $bkDetail = $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bkCode);

        foreach($bkDetail as $index=>$value) $Arr[$index] = $value;
		for ($i=1; $i <= $installmentMonth; $i++) {
//			$time = strtotime($today);
			$final = date("Y-m-".$ctDetail->ct_pay_day, strtotime("+$i month", $startDate));	
            
            $temp = '';
            for($j = strlen($i);$j<2;$j++){
                $temp .= '0';
            }
            
            $installmantfee_paymant = $this->payment->getDefinefee($temp.$i, $Arr);
            
			$data_installment = array(
                'im_code' => $imcode.$temp.$i,
				'im_contract_code' => $ctCode,
				'im_cus_id' => $ctDetail->ct_cus_id,
				'im_installment_time' => $temp.$i,
				'im_duedate' => $final,
				'im_fee_define' => $installmantfee_paymant,
				'im_amount' => $installmantfee_paymant,
			);
			$this->tb_installment->record($data_installment);
		}
		
		$data_room_sts = array(
			'rs_unit_number' => $unitnumberid,
			'rs_cus_id' => $ctDetail->ct_cus_id,
			'rs_status' => 'Temp receipt for contract',
			'rs_staff_id' => $this->user_id
		);
		$this->load->model('tb_room_status');
		$this->tb_room_status->record($data_room_sts);
        
        $this->load->model('tb_contract_promotion');
        $oldProID = array();
		foreach ($this->tb_contract_promotion->get_detail_by_bk_code($bkCode) as $key => $value) {
            $oldProID[] = $value->cp_promotion_id;
			$data_promotion = array(
				'cp_contract_code' => $ctCode
			);
			$this->tb_contract_promotion->update($data_promotion,$value->cp_id);
		}
        foreach ($this->input->post('pro') as $key => $value) {
            if(!in_array($value, $oldProID)) {
				$data_promotion = array(
                    'cp_contract_code' => $ctCode,
					'cp_booking_code'  => $bkCode,
					'cp_promotion_id'  => $value
				);
				$this->tb_contract_promotion->record($data_promotion);
            }
        }
        
        //////////////////////////////////////////////////////////
        $this->load->model('tb_receipt_temporary');
        $newid = $this->tb_receipt_temporary->get_next_id();
		$tmp   = strlen($newid);
		$tmpID = '';
		for ($i=$tmp; $i < 5 ; $i++) { 
			$tmpID .= '0';
		}
        $projectid = $this->project_id_sel;
		$tmptmp = strlen($projectid);
		$tmpIDP = '';
		for ($i=$tmptmp; $i < 2 ; $i++) {
			$tmpIDP .= '0';
		}
        
		$dateQuo = date("ymd"); 
        $newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid; 
        $receiptID = implode(',', $this->input->post('receiptID'));
		$data_receipt = array(
			'rc_code' => $newrcv,
            'rc_refer_form' => $receiptID,
			'rc_customer_id' => $ctDetail->ct_cus_id,
			'rc_payfor' => 'Contract Fee',
			'rc_booking_code' => $bkCode,
			'rc_contract_code' => $ctCode,
			'rc_total_amount' => $contractfee,
            'rc_temporary_date' => $today,
			'rc_staff_temporary' => $this->user_id,
            'rc_un_name' => $unitnumber
		);
		$this->load->model('tb_receipt_temporary');
		$this->tb_receipt_temporary->record($data_receipt);
        
        if(!empty($receiptID)) {
            $this->load->model('tb_receipt_offical');
            $update = array('rc_status'=>'off');
            foreach(explode(',', $receiptID) as $receipt) {
                $this->tb_receipt_offical->update($update, $receipt);
            }
        }
        //////////////////////////////////////////////////////////////
        $ct_type_payment = '';
        $ct_pay_crcard   = '';
        $ct_pay_other    = '';
        $Type = $this->input->post('Type');              
        if(!empty($Type))
        {      
          foreach($Type as $checkbox):
             if ( trim($checkbox) == 'Cash' )   $ct_type_payment = 'yes';
             if ( trim($checkbox) == 'CrCard' ) $ct_pay_crcard = 'yes';
             if ( trim($checkbox) == 'Other' )  $ct_pay_other  = 'yes';              
          endforeach;
        }
        $ct_amount          = $this->input->post('Cashamount');
        $ct_cr_bank         = $this->input->post('CardBank');
        $BankName           = $this->input->post('BankName');
        $ct_cr_type     	= $this->input->post('CardType');
        $ct_cr_approve_code	= $this->input->post('ApproveCode');
        $ct_cr_number       = $this->input->post('Cardno');
        $expiremonth_       = $this->input->post('expiremonth');
        $expireyear_        = $this->input->post('expireyear');
        $ct_cr_expire       = "";
        $ct_crcard_amount   = $this->input->post('Cardamount');
        $ct_cr_holder       = $this->input->post('CardHolder');
        $ct_other_by        = $this->input->post('OtherBy');
        $ct_other_amount    = $this->input->post('Otheramount');
        $pm_check_number    = $this->input->post('CheckNo');
        $pm_check_date      = $this->input->post('CheckDate');
        $pm_check_bank      = $this->input->post('CheckBank');
        $this->load->model('tb_payment');
        $this->load->model('tb_bank');
        if($ct_type_payment == "yes") {
            $data_payment = array(
                'pm_temp_code' => $newrcv,
                'pm_date' => $today,
                'pm_type' => 'Cash',
                'pm_amount' => $ct_amount,
            );
            $this->tb_payment->record($data_payment);
        }
        if($ct_pay_crcard == "yes") {
            $this->load->library('encrypt');
            $bankCount = 0;
            for($i=0;$i<count($ct_crcard_amount);$i++) {
                $ct_cr_expire = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";
                
                if($ct_cr_bank[$i] === 0) {
                    $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
                    echo $b_id;
                    if(empty($b_id)) {
                        $b_id = $this->tb_bank->get_next_id();
                        $data = array(
                            'b_id' => $b_id,
                            'bank_name_th' => $BankName[$bankCount]
                        );
                        $this->tb_bank->record($data);
                    }
                    $bankCount++;
                }else $b_id = $ct_cr_bank[$i];
                
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => 'Credit',
                    'pm_amount' => $ct_crcard_amount[$i],
                    'pm_cr_bank' => $b_id,
                    'pm_cr_type' => $ct_cr_type[$i],
                    'pm_cr_holder' => $ct_cr_holder[$i],
                    'pm_cr_number' => $this->encrypt->encode($ct_cr_number[$i]),
                    'pm_cr_approve_code' => $ct_cr_approve_code[$i],
                    'pm_cr_expire' => $ct_cr_expire
                );
                $this->tb_payment->record($data_payment);
                if($i == 0) {
                    $this->load->library('creditlog');
                    $this->creditlog->update($data_payment, explode(',', $ctDetail->ct_cus_id)[0]);
                }
            }
        }
        if($ct_pay_other == "yes") {
            if($ct_other_by == 'Check'){
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $ct_other_by,
                    'pm_amount' => $ct_other_amount,
                    'pm_check_number' => $pm_check_number,
                    'pm_check_date' => $pm_check_date,
                    'pm_check_bank' => $pm_check_bank                     
                );
            }else {
                $data_payment = array(
                    'pm_temp_code' => $newrcv,
                    'pm_date' => $today,
                    'pm_type' => $ct_other_by,
                    'pm_amount' => $ct_other_amount                   
                );
            }
            $this->tb_payment->record($data_payment);
        }
        
        
        if ($this->pdb->trans_status() === FALSE){
            $this->pdb->trans_rollback();
            alert_redirect('Make temp receipt Fail','/contract/view');
        }
        else{
//            $getTempReceipt = $this->tb_receipt_temporary->get_by_contract($ctCode);
            $this->pdb->trans_commit();
            echo "<script>window.open('".BASE_DOMAIN."receipt/report/th/$newrcv','_blank');";
            echo "window.location.href = '".BASE_DOMAIN."contract/view';</script>";
        }
    }
    
    public function test() {
        $this->load->model('tb_customer_personal_info');
        $getCustomer = $this->tb_customer_personal_info->get_detail_by_user_pers_id(1);
        $customerName = $getCustomer->pers_fname;
        
        $this->load->model('tb_floor');
        $getFloor = $this->tb_floor->fetch_all_floor_withBuildingTable();
        foreach($getFloor as $_getFloor){
            $_getFloor = (array)$_getFloor;
            $test .= $_getFloor['fl_name'];
        }
        
        $data['test'] = $test;
        $data['customerName'] = $customerName;
        $this->LoadView('Contract/test',$data);
    }

	public function report($language,$conid){
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$this->load->library('currency');
		$this->load->library('DateFormat');
		
		$loginname = $this->user_username;

		$this->load->model('tb_contract');
		$getbookine= $this->tb_contract->get_detail_by_ct_code($conid);
		$bookCode = $getbookine->ct_booking_code;
        $contractDate = $getbookine->ct_date;
        if($getbookine->ct_active != 'transferred')
            $Cusid = $getbookine->ct_cus_id;
        else {
            $this->load->model('tb_transferred');
            $Cusid = $this->tb_transferred->get_frist_cus_by_contract($conid);
        }
		
        $this->load->model('tb_contract_promotion');
        $getPromotion = $this->tb_contract_promotion->get_promotion_by_bk_code($bookCode);
      
        $detailTypeCash = $language=='th'?'บริษัทฯ จะนำไปหักออกจากจำนวนเงินที่ผู้ซื้อต้องชำระ ในงวดวันโอนกรรมสิทธิ์ในคราวเดียว':'';
        $detailTypeGift = $language=='th'?'ภายใน 45 วัน นับถัดจากวันโอนกรรมสิทธิ์':'';
        
        $checkGetPro = 0;
        foreach($getPromotion as $promotion){
            $checkGetPro++;
            if($promotion->pm_type == 'Cash'){
//                $detailOfPro = $detailTypeCash;
                $detailOfPro = $language=='th'?$promotion->pm_detail:$promotion->pm_detail_en;
                $htmlPromotion .= 
                '
                <tr>
                    <td align="center" valign="top">1</td>
                    <td valign="top">'.($language=='th'?$promotion->pm_name:$promotion->pm_name_en).'</td>
                    <td valign="top">'.$detailOfPro.'</td>
                </tr>
                ';
            }else if($promotion->pm_type == 'Gift'){
//                $detailOfPro = $detailTypeGift;
                $detailOfPro = $language=='th'?$promotion->pm_detail:$promotion->pm_detail_en;
                $htmlPromotion .= 
                '
                <tr>
                    <td align="center" valign="top">1</td>
                    <td valign="top">'.($language=='th'?$promotion->pm_name:$promotion->pm_name_en).'</td>
                    <td valign="top">'.$detailOfPro.'</td>
                </tr>
                ';
            } else if($promotion->pm_type == 'Referral'){
//                $detailOfPro = $detailTypeGift;
                $detailOfPro = $language=='th'?$promotion->pm_detail:$promotion->pm_detail_en;
                $htmlPromotion .= 
                '
                <tr>
                    <td align="center" valign="top">1</td>
                    <td valign="top">'.($language=='th'?$promotion->pm_name:$promotion->pm_name_en).'</td>
                    <td valign="top">'.$detailOfPro.'</td>
                </tr>
                ';
            }
        }
        
        $this->load->model('tb_contract_mapping');
        $getContractMapping = $this->tb_contract_mapping->getMappingByContractID($conid);
        $oldContractCode = $getContractMapping->cm_rama9_code;

		$this->load->model('tb_user_personal_info');
		$signature = $this->tb_user_personal_info->get_detail_by_user_pers_id($getbookine->ct_staff_id);
        $nameSale = $language=='th'?$signature->user_pers_fname.' '.$signature->user_pers_lname : $signature->user_pers_fname_en.' '.$signature->user_pers_lname_en;
		
		$this->load->model('tb_booking');
		$getQuocode= $this->tb_booking->get_fullDetail_innerJoinQuotaion_by_booking_code($bookCode);
		$quoCode = $getQuocode->bk_quotation_code;
		$bookingDeposit = $getQuocode->bk_money_amount;	
		$bookingDate = $getQuocode->bk_date_booking;	
		$lastContractDate =  $getQuocode->bk_contract_date;

		$flag = 0;
		$cusDetail = '';
		$nameCus = '';
 		
 		$this->load->model('tb_customer');
		$getBookingName_arr = $this->tb_customer->get_detail_by_id_joinInfo_AddressInfo($Cusid);
        $this->load->model('tb_nationality');
            
        $comma = '';
        if($language == 'en'){
            $cusNum = 0;
            foreach ($getBookingName_arr as $value) {
                $nameCusLicenses[$cusNum++] = $value->pers_prefix.' '.$value->pers_fname.' '.$value->pers_lname;
                $nationalityDetail = $this->tb_nationality->get_nationality_by_id($value->pers_nationality);
                $nationality = $nationalityDetail->nt_nationality;
                $country = $nationalityDetail->nt_nationality;
                $cusDetail .= $comma;
                $cusDetail .= '<span class="under">'.$value->pers_prefix.$value->pers_fname.' '.$value->pers_lname.'</span>, <span class="under">' .$nationality.'</span> nationality,Residing at No <span class="under">'.$value->addr_address.' '.$value->addr_sub_district.' '.$value->addr_district.' '.$value->addr_province.' '.$value->addr_post_code.'</span> Tel number <span class="under">'.(!empty($value->pers_mobile)?$value->pers_mobile:'&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;').'</span>';

                $nameCus .= $value->pers_prefix.$value->pers_fname.' '.$value->pers_lname;
                $comma = '<br/>and&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            }

        }else{
            $numOfBooking = 0;
            $cusNum = 0;
            foreach ($getBookingName_arr as $value) {
                $cusNum++;
                $dateOfBirth = $value->pers_dob;
        
                $yearOfBirth = intval(date('Y',strtotime($dateOfBirth)));
                $yearToday = intval(date('Y'));
                $age = $yearToday - $yearOfBirth;
                
                if($value->pers_nationality == 171){
                    $nationality = 'ไทย';
                    $countryCus = 'ไทย';
                }else {
                    $nationalityDetail = $this->tb_nationality->get_nationality_by_id($value->pers_nationality);
                    $nationality = $nationalityDetail->nt_nationality;
                    $countryCus = $nationalityDetail->nt_nationality;
                }
                
                $nameCusLicenses[$numOfBooking] = $value->pers_prefix.' '.$value->pers_fname.' '.$value->pers_lname;
                if($numOfBooking < 1)
                {
                    $nameCus .= $value->pers_prefix.' '.$value->pers_fname.' '.$value->pers_lname.' ';
                    $nameCusLicense = $value->pers_prefix.' '.$value->pers_fname.' '.$value->pers_lname.' ';
                }
                else
                    $nameCus .= 'และ '.$value->pers_prefix.' '.$value->pers_fname.' '.$value->pers_lname.' ';
                $nameCusDe = $value->pers_prefix.' '.$value->pers_fname.' '.$value->pers_lname;
                
                if($value->pers_identification_flag == 'IDCard')
                    $idCardCus = $value->pers_card_id;
                else
                    $idCardCus = $value->pers_passport;
                
                $mobileCus = $value->pers_mobile;
                $organTelCus = null;
                $telCus = $value->pers_tel;
                $emailCus = $value->pers_email;
                
                // get Address by qt_address
                $addr_booking = $value->cus_addr_default;

//                if ( $addr_booking == 2 )
//                {
                    $this->load->model('tb_customer_address_info');
                    $getaddrCur= $this->tb_customer_address_info->get_detail_by_cus_id($value->pers_id_cus);   

                    $doc_addr = $getaddrCur->addr_address;
                    $doc_sub_district = $getaddrCur->addr_sub_district;
                    $doc_district = $getaddrCur->addr_district;
                    $doc_province = $getaddrCur->addr_province;
                    $doc_zipcode = $getaddrCur->addr_post_code;
//                }
//                else if ( $addr_booking == 3 )    
//                {
//                    $this->load->model('tb_customer_address_lastest');
//                    $getaddrCur= $this->tb_customer_address_lastest->get_detail_by_cus_id($value->pers_id_cus); 
//
//                    $doc_addr = $getaddrCur->addr_lastest_address;
//                    $doc_sub_district = $getaddrCur->addr_lastest_sub_district;
//                    $doc_district = $getaddrCur->addr_lastest_district;
//                    $doc_province = $getaddrCur->addr_lastest_province;
//                    $doc_zipcode = $getaddrCur->addr_lastest_post_code;
//                }
//                else 
//                {
//                    $this->load->model('tb_customer_address_current_info');
//                    $getaddrCur= $this->tb_customer_address_current_info->get_detail_by_customerID($value->pers_id_cus);
//
//                    $doc_addr = $getaddrCur->addr_cur_address;
//                    $doc_sub_district = $getaddrCur->addr_cur_sub_district;
//                    $doc_district = $getaddrCur->addr_cur_district;
//                    $doc_province = $getaddrCur->addr_cur_province;
//                    $doc_zipcode = $getaddrCur->addr_cur_post_code;
//                }
                
                $cusDetail .=
                '
                <table width="752" border="0">
                  <tr>
                    <td width="55">'.(empty($cusDetail)?'':'และ').'</td>
                    <td width="308" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;"><p>'.$nameCusDe.'</p></td>
                    <td width="23">อายุ</td>
                    <td width="48" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.$age.'</p></td>
                    <td width="62">ปี สัญชาติ</td>
                    <td width="116" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.$nationality.'</p></td>
                    <td width="94">ถือบัตรประจำตัว</td>
                  </tr>
                </table>
                <table width="100%" border="0">
                  <tr>
                    <td width="25%">ประชาชน/หนังสือเดินทางเลขที่</td>
                    <td width="27%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.$idCardCus.'</p></td>
                    <td width="7%">ประเทศ</td>
                    <td width="21%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.$countryCus.'</p></td>
                    <td width="20%">ที่อยู่/ที่ตั้งสำนักงานเลขที่</td>
                  </tr>
                  <tr>
                    <td colspan="5" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;"><p>'.$doc_addr.' '.(empty($doc_sub_district)?$doc_sub_district:"ต.".$doc_sub_district).' '.(empty($doc_district)?$doc_district:"อ.".$doc_district).' '.(empty($doc_province)?$doc_province:"จ.".$doc_province).'</p></td>
                  </tr>
                </table>
                <table width="100%" border="0">
                  <tr>
                    <td width="7%">ประเทศ</td>
                    <td width="21%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.$countryCus.'</p></td>
                    <td width="12%">รหัสไปรษณีย์</td>
                    <td width="22%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.$doc_zipcode.'</p></td>
                    <td width="15%">โทรศัพท์ (มือถือ)</td>
                    <td width="23%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.(!empty($mobileCus)?$mobileCus:"-").'</p></td>
                  </tr>
                </table>
                <table width="100%" border="0">
                  <tr>
                    <td width="10%">(สำนักงาน)</td>
                    <td width="23%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.(!empty($organTelCus)?$organTelCus:"-").'</p></td>
                    <td width="6%">(บ้าน)</td>
                    <td width="25%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.(!empty($telCus)?$telCus:"-").'</p></td>
                    <td width="5%">อีเมล์</td>
                    <td width="31%" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;" align="center"><p>'.(!empty($emailCus)?$emailCus:"-").'</p></td>
                  </tr>
                </table>
                ';
                
                $numOfBooking++;
            }
            if($numOfBooking > 1)
                $nameCusLicense = '';
        }
		 	
			$flag++;
		
		$this->load->model('tb_quotation');
		$getQuo = $this->tb_quotation->getDetail_by_id($quoCode);
		$Project = 	$getQuo->qt_project_id;
		$Building =$getQuo->qt_buliding_id;
		$Floor =$getQuo->qt_floor_id;
		$Number =$getQuo->qt_unit_number_id;
		$PaymentTerms =$getQuo->qt_payment_terms;
		$dateQuo =$getQuo->qt_date;
        $qt_booking_fee = $getQuo->qt_booking_fee;
        $qt_contract_fee = $getQuo->qt_contract_fee;
        $qt_total_months = $getQuo->qt_total_months;
        $qt_avg_installment = $getQuo->qt_avg_installment;
        $qt_total_down_payment = $getQuo->qt_total_down_payment;
        $qt_unit_price = $getQuo->qt_unit_price;
        $balloonDownMonth = $getQuo->qt_total_months;
        $maxLoop = 20;
        foreach($getQuo as $index=>$value) $Arr[$index] = $value;
        for($i=1;$i<=$maxLoop;$i++) $balloon[$i] = $Arr['qt_months_installment'.$i];
        for($i=1;$i<=$maxLoop;$i++) $balloonTemp[$i] = split("-", $balloon[$i]);
        for($i=1;$i<=$maxLoop;$i++) $balloon[$i] = $balloonTemp[$i][0]." - ".$balloonTemp[$i][1];
        for($i=1;$i<=$maxLoop;$i++) $balloonAmount[$i] = $Arr['qt_installment'.$i];
        for($i=1;$i<=$maxLoop;$i++) $num[$i] = $balloonTemp[$i][1] - $balloonTemp[$i][0] + 1;
        for($i=1;$i<=$maxLoop;$i++) $installmentBall[$i] = $balloonAmount[$i] * $num[$i];
        for($i=1;$i<=$maxLoop;$i++) $lastBalloon[$i] = $balloonTemp[$i][0];
        $totalInstallmentBall = 0;
        for($i=1;$i<=$maxLoop;$i++) $totalInstallmentBall += $installmentBall[$i];

	
		$this->load->model('tb_project');
		$get = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($Project);
        $getProjectCom = $this->tb_project->get_detail_project_ignoreStatusActive($Project);
		$databasenameQuo = $get->pj_datebase_name;
		$pj_name = ($language=='th')?$get->pj_name_th.' '.$get->pj_location_th:$get->pj_name.' '.$get->pj_location.' '.$get->pj_type;
		$pj_location = $getProject->pj_location;
        $projectImage = $getProjectCom->pj_image;
        $projectDate = $get->pj_date_project;
        $companyName = ($language=='th')?$get->pj_owner:$get->pj_owner_en;
        $deadProDate = $get->pj_date_promotion;
        $ownerAddr = ($language=='th')?$get->pj_owner_address:$get->pj_owner_address_en;
        $ownerName = ($language=='th')?$get->pj_owners:$get->pj_owners_en;
        $ownerDate = $get->pj_ownership_date;
        $landLocation = ($language=='th')?$get->pj_land:$get->pj_land_en;
        $landArea = ($language=='th')?$get->pj_area:$get->pj_area_en;
        $projectAddr = ($language=='th')?$get->pj_address:$get->pj_address_en;
        $coffers = $get->pj_coffers_fee;
        $amenities = $get->pj_amenities_fee;

		
		$this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;
		
		$this->load->model('tb_floor');
		$getFloor = $this->tb_floor->get_detail_by_id($Floor);
		$Floorname 	= $getFloor->fl_name;

		$this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
		$unit_type_name 	= $getRoom->unit_type_name;
		$un_name 			= $getRoom->un_name;
		$unit_type_area_sqm 	= $getRoom->unit_type_area_sqm;
		$un_direction		= $getRoom->un_direction;
		$room_type_name		= $getRoom->room_type_name;
        
        
		$this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_selling_sqm 	= $getPrice->pr_asking_sqm;
		$pr_asking_price	= $getPrice->pr_asking_price;
		
		
		$pieces = explode(",",$pr_asking_price);
		$today = $dateQuo;   
		$this->load->model('tb_promotion');
		$getPromotion = $this->tb_promotion->getPromotionTypeCash_equalGreaterDateExpire($today);
		$promotionID = $getPromotion->pm_id;
//		$pm_name = $getPromotion->pm_name;
		$pm_value = $getPromotion->pm_value;
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
		
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value;
		
		$CondoPrice = $pr_asking_price;
		$this->load->model('tb_payment_terms');
		$getPaymentTerms = $this->tb_payment_terms->get_detail_by_id($PaymentTerms);
		$BookingFee 	= $getPaymentTerms->pt_booking;
		$ContractFee 	= $getPaymentTerms->pt_contract;
	  	
	  	$TotalDownMonth = $getQuo->qt_total_months;
		$Balloon 	= $getPaymentTerms->pt_ballon_payment;
		if ($Balloon == 'no' )
        {
			$InstallmentFee = $getQuo->qt_avg_installment;
			$TotalInstallmentFee = $InstallmentFee * $TotalDownMonth;
			$TotalDownPayment = $TotalInstallmentFee + $BookingFee + $ContractFee;
        }
        else ////////////////Balloon/////////////////////
        {
    		$BalloonMonth 	= count(explode(',', $getQuo->qt_balloon_month));
			$NormalMonth 	= $TotalDownMonth - $BalloonMonth;
			$InstallmentFee 	= $getQuo->qt_market_price;
			$BalloonFee 		= $getQuo->qt_balloon_price;
			$BalloonMonthText 	= $getQuo->qt_balloon_month;
            $TotalNormalFee 	= $NormalMonth * $InstallmentFee;
            $TotalBalloonFee 	= $BalloonFee * $BalloonMonth;
            $TotalInstallmentFee = $TotalNormalFee + $TotalBalloonFee;
            $TotalDownPayment 	= $TotalInstallmentFee + $BookingFee + $ContractFee;
        }
        $TransferPayment = $specialPrice - $TotalDownPayment;

        $htmlTotalDownMonth = '';
        
        $dateDownpay =date('Y-m-d', strtotime($get->pj_start_downpayment. '+'.(36-$TotalDownMonth).'month'));
        
        $transfer = $qt_unit_price - $qt_total_down_payment;
		if ($Balloon == 'no' )
        {
            if($language == 'th'){
                for($i=1;$i<=$TotalDownMonth;$i++){
                    $htmlTotalDownMonth .= '
                                <pre class="tab2 alignNormal">4.2.'.$i.' งวดที่ '.$i.' จำนวน '.number_format($InstallmentFee,2).' บาท ('.$this->currency->bahtThai($InstallmentFee).') ชำระภายในวันที่ '.$this->dateformat->thaiShortDate(date('Y-m-d', strtotime($dateDownpay. '+' .($i-1). 'month'))).'<br></pre>
                    ';
                    if($i == $TotalDownMonth){
                        $htmlTotalDownMonth .= '
                                <pre class="tab2 alignNormal">4.2.'.($i+1).' งวดสุดท้าย จำนวน '.number_format($transfer,2).' บาท ('.$this->currency->bahtThai($transfer).') ชำระภายในวันที่จดทะเบียนโอนกรรมสิทธิ์ห้องชุด ณ สำนักงานที่ดิน <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> ตามข้อ 4.4<br></pre>
                        ';
                    }
                }
            }
            else{
                for($i=1;$i<=$TotalDownMonth;$i++){
                    $htmlTotalDownMonth .= '
                        <pre class="tab2 alignNormal">4.2.'.$i.' The<span class="under"> '.$i.' </span>installment in the amount of<span class="under"> '.number_format($InstallmentFee,2).' </span>Baht (<span class="under">'.$this->currency->bahtEng($InstallmentFee).'</span>) due on<span class="under"> '.date('d F Y', strtotime($dateDownpay. '+' .($i-1). 'month')).' </span>.<br></pre>';
                }
                $htmlTotalDownMonth .= '
                <pre class="tab2 alignNormal" >4.2.'.($i).' The last installment in the amount of<span class="under"> '.number_format($transfer,2).' </span>Baht (<span class="under">'.$this->currency->bahtEng($transfer).'</span>) due on the date when the transfer of ownership is made at the land office under Section 4.4<br></pre>';
            }
        }
        else
        {
            $this->load->library('payment');
            if($language == 'th'){
                for($i=1;$i<=$TotalDownMonth;$i++){
                        $htmlTotalDownMonth .= '
                                    <pre class="tab2 alignNormal">4.2.'.$i.' งวดที่ '.$i.' จำนวน '.number_format($this->payment->getDefinefee($i,$Arr),2).' บาท ('.$this->currency->bahtThai($this->payment->getDefinefee($i,$Arr)).') ชำระภายในวันที่ '.$this->dateformat->thaiShortDate(date('Y-m-d', strtotime($dateDownpay. '+' .($i-1). 'month'))).'<br></pre>';
                }
                $htmlTotalDownMonth .= '
                    <pre class="tab2 alignNormal" >4.2.'.($i).' งวดสุดท้าย จำนวน '.number_format($transfer,2).' บาท ('.$this->currency->bahtThai($transfer).') ชำระภายในวันที่จดทะเบียนโอนกรรมสิทธิ์ห้องชุด ณ สำนักงานที่ดิน........................................... ตามข้อ 4.4<br></pre>';
            }
            else
            {
                for($i=1;$i<=$TotalDownMonth;$i++){
                    $htmlTotalDownMonth .= '
                    <pre class="tab2 alignNormal">4.2.'.$i.' The<span class="under"> '.$i.' </span>installment in the amount of<span class="under"> '.number_format($this->payment->getDefinefee($i,$Arr),2).' </span>Baht (<span class="under">'.$this->currency->bahtEng($this->payment->getDefinefee($i,$Arr)).'</span>) due on<span class="under"> '.date('d F Y', strtotime($dateDownpay. '+' .($i-1). 'month')).' </span>.<br></pre>';
                }
                $htmlTotalDownMonth .= '
                <pre class="tab2 alignNormal" >4.2.'.($i).' The last installment in the amount of<span class="under"> '.number_format($transfer,2).' </span>Baht (<span class="under">'.$this->currency->bahtEng($transfer).'</span>) due on the date when the transfer of ownership is made at the land office under Section 4.4<br></pre>';
            }
        }
		
		$moneyCash= '';
	    $moneyCrCard= '';
	    $moneyOther= '';
	    $flagCash= '';
	    $flagCrCard= '';
	    $flagOther= '';
        if ($getbookine->ct_cash_type == 'yes') {
			$moneyCash= number_format($ContractFee,2);		
			$flagCash ='checked="checked"';
	    } else if ($getbookine->ct_credit_type == 'yes') {
			$moneyCrCard= number_format($ContractFee,2);
			$flagCrCard ='checked="checked"';
	    } else if ($getbookine->ct_other_type == 'yes') {
			$moneyOther= number_format($ContractFee,2);
			$flagOther ='checked="checked"';
		}
		///////////////RECEIPT//////////////////
		$type_receipt = 'ใบเสร็จรับเงินชั่วคราว';
		$id = $conid;
		$prefix = $value->pers_prefix;
		$fname = $value->pers_fname;
		$lname = $value->pers_lname;
		$receiptText = 'Contract Fee';
		$total_price = $ContractFee;
		$cash_amount = $getbookine->ct_cash_amount;
		$other_amount = $getbookine->ct_other_amount;
		$credit_amount = $getbookine->ct_credit_amount;
		$credit_bank = $getbookine->ct_credit_bank;
		$credit_no = $getbookine->ct_credit_no;
		$credit_holder = $getbookine->ct_credit_holder;
		$other_by = $getbookine->ct_other_by;
		$payee = array('สำหรับลูกค้า / Customer Copy','สำหรับบัญชี / Accounting Department Copy','สำหรับฝ่ายขาย / Sales and Leasing Department Copy');
		$type_licence = '
            <br>
            <br>
            <br>
            <table width="700px" border="0" align="center"  class="tablefone">
                <tr>
                    <td align="center" width="500px" >&nbsp;</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;" width="100px">&nbsp;</td>
                </tr>
                <tr>
                    <td align="center" width="500px" >&nbsp;</td>
                    <td align="center" style="padding-top:5px">ผู้ซื้อ / Customer</td>
                </tr>
                <tr>
                    <td align="center" width="500px" >&nbsp;</td>
                    <td align="center" > '.$prefix.' '.$fname.' '.$lname.'</td>
                </tr>
            </table>
            <br>
            <br>
            <br>
            <table width="700px" border="0" align="center"  class="tablefone">
                <tr>
                    <td align="center" width="500px" >&nbsp;</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;" width="100px" align="center">
                    &nbsp;
                    </td>
                </tr>
                <tr>
                    <td align="center" width="500px" >&nbsp;</td>
                    <td align="center" style="padding-top:5px">ผู้รับเงิน / Payee</td>
                </tr>
                <tr>
                    <td align="center" width="500px" >&nbsp;</td>
                    <td align="center" >'.$loginname.'</td>
                </tr>
            </table>
		';
        $tablePromotion = '
                <table>
                    <tr>
                        <td>'.(($language == 'th')?'ผู้จะขายตกลงมอบสมนาคุณ และ/หรือ สิทธิพิเศษให้แก่ผู้จะซื้อตามรายการ ดังต่อไปนี้':'The Seller agrees to give you the following gifts and/or privileges.').'</td>
                    </tr>
                </table>
                <table border="1" width="100%" class="oneLine">
                    <tr>
                        <th align="center" width="5%">'.(($language == 'th')?'จำนวน':'Amount').'</th>
                        <th align="center" width="50%">'.(($language == 'th')?'รายการ':'Description').'</th>
                        <th align="center">'.(($language == 'th')?'กำหนดเวลาการส่งมอบ':'Delivering date').'</th>
                    </tr>'.$htmlPromotion;
        for($i=$checkGetPro;$i<3;$i++)
            $tablePromotion .= '
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>';
        $tablePromotion .= '</table>';

        if($oldContractCode != null)
            $id = $oldContractCode;
        else
            $id = $conid;

        if($language == 'th')
            $data['ctDate'] =   !empty($getbookine->ct_date)?$this->dateformat->thaiShortDate(date('Y-m-d', strtotime($getbookine->ct_date))):'';
		else
            $data['ctDate'] =   !empty($getbookine->ct_date)?date('d F Y', strtotime($getbookine->ct_date)):'';


		$data['loginname'] = $loginname;
		$data['getBookingName'] = $getBookingName;
		$data['doc_addr'] = $doc_addr;
		$data['doc_sub_district'] = $doc_sub_district;
		$data['doc_district'] = $doc_district;
		$data['doc_province'] = $doc_province;
		$data['doc_zipcode'] = $doc_zipcode;
        
		$data['building_name'] = $building_name;
        
		$data['flagCash'] = $flagCash;
		$data['moneyCash'] = $moneyCash;
		$data['flagCrCard'] = $flagCrCard;
		$data['getbookine'] = $getbookine;
		$data['moneyCrCard'] = $moneyCrCard;
		$data['flagOther'] = $flagOther;
		$data['moneyOther'] = $moneyOther;
		$data['getstaff'] = NULL;
        
		
		$data['cusDetail'] = $cusDetail;
		$data['cusNum'] = $cusNum;
		
		
		
		
		
		
		
		$data['TotalInstallmentFee'] = $TotalInstallmentFee;
		$data['TotalDownMonth'] = $TotalDownMonth;
		$data['TransferPayment'] = $TransferPayment;
		
		
		$data['datebooking'] = $datebooking;
		$data['installmentFeeDetail'] = $installmentFeeDetail;
		$data['doc_addr'] = $doc_addr;
		$data['doc_sub_district'] = $doc_sub_district;
		$data['doc_district'] = $doc_district;
		$data['doc_province'] = $doc_province;
		$data['doc_zipcode'] = $doc_zipcode;
		
		
		
		
		$data['title'] = $this->title_page;
		$data['Currency'] = $this->currency;
		/////////////////RECEIPT//////////////////////
		$data['type_receipt'] = $type_receipt;
		$data['conid'] = $conid;
		
		$data['prefix'] = $prefix;
		$data['fname'] = $fname;
		$data['lname'] = $lname;
		$data['receiptText'] = $receiptText;
		$data['total_price'] = $total_price;
		$data['cash_amount'] = $cash_amount;
		$data['other_amount'] = $other_amount;
		$data['credit_amount'] = $credit_amount;
		$data['credit_bank'] = $credit_bank;
		$data['credit_no'] = $credit_no;
		$data['credit_holder'] = $credit_holder;
		$data['other_by'] = $other_by;
		
		$data['type_licence'] = $type_licence;
		$data['DateFormat'] = $this->DateFormat;
        
       
        
        
        $data['deadProDate'] = $deadProDate;
        
        
        
        
        
        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        $data['id'] = $id;
        $data['projectImage'] = $projectImage;
        $data['pj_name'] = $pj_name;
        $data['coffers']   = $coffers;
        $data['amenities'] = $amenities;
        $data['un_name'] = $un_name;
        $data['Floorname'] = $Floorname;
        $data['room_type_name'] = $room_type_name;
        $data['unit_type_area_sqm'] = $unit_type_area_sqm;
        $data['nameSale'] = $nameSale;
        $data['contractDate'] = $contractDate;
        $data['nameCus'] = $nameCus;
        $data['ownerAddr'] = $ownerAddr;
        $data['lastContractDate'] = $lastContractDate;
        $data['companyName'] = $companyName;
        $data['ownerName'] = $ownerName;
        $data['ownerDate'] = $ownerDate;
        $data['ageCus'] = $age;
        $data['nationCus'] = $nationality;
        $data['idCardCus'] = $idCardCus;
        $data['countryCus'] = $countryCus;
        $data['addrCus'] = $doc_addr.' '.$doc_sub_district.' '.$doc_district;
        $data['zipCodeCus'] = $doc_zipcode;
        $data['mobileCus'] = !empty($mobileCus)?$mobileCus:'-';
        $data['organTelCus'] = !empty($organTelCus)?$organTelCus:'-';
        $data['telCus'] = !empty($telCus)?$telCus:'-';
        $data['emailCus'] = !empty($emailCus)?$emailCus:'-';
        $data['landLocation'] = $landLocation;
        $data['landArea'] = $landArea;
        $data['pr_selling_sqm'] = $pr_selling_sqm;
        $data['qt_unit_price'] = $qt_unit_price;
        $data['bookingDate'] = $bookingDate;
        $data['BookingFee'] = $BookingFee;
        $data['ContractFee'] = $ContractFee;
        $data['htmlTotalDownMonth'] = $htmlTotalDownMonth;
        $data['projectDate'] = $projectDate;
        $data['projectAddr'] = $projectAddr;
        $data['unit_type_name'] = $unit_type_name;
        $data['building_name'] = $building_name;
        $data['crdate'] =   !empty($getbookine->ct_credit_date)?$getbookine->ct_credit_date:'';
        $data['tablePromotion'] = $tablePromotion;
        $data['unitPlanImg'] = $getRoom->unit_type_image;
        $data['floorPlanImg'] = $getFloor->fl_image;
        $data['cusDetail'] = $cusDetail;
        $data['nameCusLicense'] = $nameCusLicense;
        $data['nameCusLicenses'] = $nameCusLicenses;
        
        

		if($language == 'th'){
			$this->load->view('Contract/contract_reportTH',$data);
		}else if($language == 'en'){
			$this->load->view('Contract/contract_reportEN',$data);
		}else{
			$this->load->view('Contract/contract_reportNiti',$data);
		}
	}
	
	private function fetch_booking($pj_id){

		$this->load->model('tb_booking');
		$list_booking = $this->tb_booking->fetch_all_BookingInfoContract_byProjectID($pj_id);
		foreach($list_booking as $aBooking):

			$qcode = $aBooking->bk_quotation_code;
			$this->load->model('tb_quotation');
			$quotation = $this->tb_quotation->getDetail_by_id_withProjectTable($qcode);
			$aBooking->pj_name = $quotation->pj_name;

			$this->load->model('tb_building');
			$building = $this->tb_building->get_detail_building_by_building_id($quotation->qt_buliding_id);
			$aBooking->building_name = $building->building_name;

			$this->load->model('tb_unit_number');
			$unit_number = $this->tb_unit_number->get_detail_unit_by_un_id($quotation->qt_unit_number_id);
			$aBooking->un_name = $unit_number->un_name;
            $this->load->model('tb_contract_mapping');
            $aBooking->mapping = $this->tb_contract_mapping->getMapping($aBooking->ct_code);
            //echo "<script>console.log('$aBooking->mapping')</script>";
		endforeach;
		return $list_booking;
	}
    
    function tranfer($language,$tid)
    {
        $this->load->library('dateformat');
        $this->load->model('tb_transferred');
        $this->load->model('tb_customer');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_project');
        $this->load->model('tb_nationality');
        $this->load->model('tb_receipt_temporary');
        
        $detail = $this->tb_transferred->get_by_contract($tid);
        $oldCus = $this->tb_customer->get_detail_customer($detail->tf_old_customer);
        $newCus = $this->tb_customer->get_detail_customer($detail->tf_new_customer);
        $unit   = $this->tb_unit_number->get_detail_unit_withUnitTypeRoomTypeAndPrice_by_un_id($detail->qt_unit_number_id);
        $project = $this->tb_project->get_detail_project_ignoreStatusActive_by_pdb($detail->qt_project_id);
        $newCus->nationality = $this->tb_nationality->get_nationality_by_id($newCus->pers_nationality)->nt_nationality;
        $lastReceipt = $this->tb_receipt_temporary->get_last_by_unit($unit->un_name);
        
        $data['detail'] = $detail;
        $data['oldCus'] = $oldCus;
        $data['newCus'] = $newCus;
        $data['unit'] = $unit;
        $data['project'] = $project;
        $data['lastReceipt'] = $lastReceipt;
        
        
        if($language == 'th'){
			$this->load->view('Contract/contract_tranferTH',$data);
		}else if($language == 'en'){
			$this->load->view('Contract/contract_tranferEN',$data);
		}
    }
}
?>