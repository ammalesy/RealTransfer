<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Report';
    var $page_var = 'report';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$this->view();
	}
    
    function view()
    {
        $id = $this->input->post('rpSelect');
        $id = empty($id)?1:$id;
        $this->load->model('tb_report');
        $getReport = $this->tb_report->get_by_id($id);
        if(!empty($getReport))
            $reportTable = $this->tb_report->query($getReport);
        $data['title'] = $this->title_page;
        $data['page'] = $this->page_var;
        $data['reportList'] = $this->tb_report->get_all();
        $data['reportTB'] = $reportTable;
        $this->load->view('Report/report_view',$data);
    }
}
?>