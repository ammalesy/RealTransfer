<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Assign extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	var $page_var = 'Assign';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['assign_project'] = $this->fetch_all_assign_project();
		$data['title'] = $this->title_page;
		$data['menuLeft'] = 'off';
		$this->LoadView('Assign/assign',$data);
	}
	public function adding()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$data['list_project'] = $this->fetch_all_projectActive();
		$data['list_personal'] = $this->fetch_all_personal();
		$data['menuLeft'] = 'off';
		$this->LoadView('Assign/assign_adding',$data);
	}
	public function record()
	{
		$User = $this->input->post('User');
		$Project = $this->input->post('Project');
		$data = array(
			'assign_id' => '0',
			'assign_project_id' => $Project,
			'assign_user_id' => $User
		);
		$this->recordAssign($data);
		alert_redirect('Assign User Success','/assign/view');
	}
	public function editing($aid)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['aid'] = $aid;
		$data['project'] = $this->get_detail_assign_project($aid);
		$data['list_project'] = $this->fetch_all_projectActive();
		$data['list_personal'] = $this->fetch_all_personal();
		$data['permission'] = $this->get_user_permission();
		$data['menuLeft'] = 'off';
		$this->LoadView('Assign/assign_editing',$data);
	}
	public function update($aid)
	{
		$userEdit = $this->user_id;
		$User = $this->input->post('User');
		$Project = $this->input->post('Project');
		$data = array(
			'assign_user_id' => $User,
			'assign_project_id' => $Project
		);
		$this->updateAssign($data,$aid);

		//////KEEP LOG /////
		////////////////////
		$object = $this->get_detail_assign_project($aid);
		$data_log = array(
			'assign_id' => $object->assign_id,
			'assign_user_id' => $object->assign_user_id,
			'assign_project_id' => $object->assign_project_id,
			'assign_sts_active' => $object->assign_sts_active,
			'assign_update_by' => $this->user_id
		);
		$this->record_log_assign_project($data_log);
		alert_redirect('Assign User Edit Success','/assign/view');
	}
	public function deleting($aid){
		$data = array(
			'assign_sts_active' => 'off'
		);
		$this->updateAssign($data,$aid);
		alert_redirect('Cancel Assign user to project Success','/assign/view');
	}

	/**
	* -------------------------------------
	* Scope [PRIVATE METHOD]
	* -------------------------------------
	*/
	//////// ASSIGN PROJECT //////
	//////////////////////////
	private function fetch_all_assign_project()
	{
		$this->load->model('tb_assign_project');
		return $this->tb_assign_project->fetch_all_assign_project();
	}
	private function fetch_all_projectActive()
	{
		$this->load->model('tb_project');
		return $this->tb_project->fetch_all_active_project();
	}
	private function fetch_all_personal()
	{
		$this->load->model('tb_user_personal_info');
		return $this->tb_user_personal_info->fetch_all_personal_without_permission();
	}
	private function get_detail_assign_project($aid)
	{
		$this->load->model('tb_assign_project');
		return $this->tb_assign_project->get_detail_assign_project($aid);
	}

	//////// RECORD //////////
	//////////////////////////
	private function recordAssign($data)
	{
		$this->load->model('tb_assign_project');
		$this->tb_assign_project->record($data);
	}

	//////// UPDATE //////////
	//////////////////////////
	private function updateAssign($data,$aid)
	{
		$this->load->model('tb_assign_project');
		$this->tb_assign_project->update($data,$aid);
	}

	/**
	* -------------------------------------
	* Log Management [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function record_log_assign_project($data)
	{
		$this->load->model('log_assign_project');
	 	$this->log_assign_project->record($data);
	}
}

/* End of file permission.php */
/* Location: ./application/controllers/permission.php */