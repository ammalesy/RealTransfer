<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CreditAuto extends NZ_Controller {
    
	var $title_page = 'Credit Auto';
	var $page_var = 'CreditAuto';
    
	function __construct()
    {
        parent::__construct();
    }
	public function index()
	{
        $this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
		$this->load->view('CreditAuto/CreditAuto_view',$data);
	}
    public function adding()
    {
        $this->checkSessionTimeout();
		/////////////////////////////
        $this->load->model('tb_credit_type');
        $this->load->model('tb_bank');
        $this->load->model('tb_customer_personal_info');
        $credit_type = $this->tb_credit_type->get_all_credit_type();
        $bank = $this->tb_bank->get_all_bank();
        $list_customer = $this->tb_customer_personal_info->fetch_all_customer_smallInfo();
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['page'] = $this->page_var;
		$data['permission'] = $this->get_user_permission();
        $data['credit_type'] = $credit_type;
        $data['bank'] = $bank;
        $data['list_customer'] = $list_customer;
        $data['project_database_sel'] = $this->project_database_sel;
        $data['common_database'] = $this->common_database;
		$this->load->view('CreditAuto/CreditAuto_form',$data);
    }
}
?>