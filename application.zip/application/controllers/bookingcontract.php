<?php if ( ! defined('BASEPATH') ) exit('No direct script access allowed');

class BookingContract extends NZ_Controller {
    var $title_page = 'Booking and Contract';
    var $page_var = 'BookingAndContract';
	function __construct()
    {
        parent::__construct();
    }
	public function index($qtCode)
	{
		$this->adding($qtCode);
	}
    public function adding($qtCode)
    {
        $this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
        $this->load->model('tb_quotation');
        $this->load->model('tb_customer');
        $this->load->model('tb_customer_personal_info');
        $this->load->model('tb_bank');
        $this->load->model('tb_credit_type');
        
        $qtDetail = $this->tb_quotation->getDetail_by_id($qtCode);
        $leads    =	$qtDetail->qt_leads_id;
        $definefee  = $qtDetail->qt_booking_fee + $qtDetail->qt_contract_fee;
        $promotiom  = $qtDetail->qt_promotion;
        $Number =$qtDetail->qt_unit_number_id;
        $Building =$qtDetail->qt_buliding_id;
        $Project = $qtDetail->qt_project_id;
        /////////////////////////////////////////////////////////
        $getLeads   = $this->tb_customer->get_detail_leads_withOut_oppotunityStage($leads);
		$leadsname 	= $getLeads->pers_fname.' '.$getLeads->pers_lname;
        $list_customer = $this->tb_customer_personal_info->fetch_all_customer_smallInfo();
        /////////////////////////////////////////////////////////
        $banklist = $this->tb_bank->get_all_bank();
        $credittypelist = $this->tb_credit_type->get_all_credit_type();
        
        $this->load->model('tb_promotion');
		$getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotiom);
		$promotionID = $getPromotion->pm_id;
		$pm_name = $getPromotion->pm_name;
		$pm_value = $getPromotion->pm_value;
        
        $this->load->model('tb_unit_number');
		$getRoom = $this->tb_unit_number->get_full_detail_unit_by_un_id($Number);
		$unit_type_name 	= $getRoom->unit_type_name;
		$un_name 			= $getRoom->un_name;
		$unit_type_area_sqm 	= $getRoom->unit_type_area_sqm;
		$un_direction		= $getRoom->un_direction;
		$room_type_name		= $getRoom->room_type_name;
        
        $this->load->model('tb_building');
		$getBuilding = $this->tb_building->get_detail_building_by_building_id($Building);
		$building_name 	= $getBuilding->building_name;
        
        $this->load->model('tb_price');
		$getPrice = $this->tb_price->get_detail_by_unit_id_and_building_id($Number,$Building);
		$pr_selling_sqm = $getPrice->pr_asking_sqm;
		$pr_asking_price = str_replace( ',', '', $getPrice->pr_asking_price);
        
        $this->load->model('tb_promotion');
        $pm_value = 0;
		$pm_value = $this->tb_promotion->getPromotionBySearchQuotation_Discount($promotionid);
		$pr_asking_price1 = str_replace( ',', '', $pr_asking_price );
		$specialPrice = (float)intval($pr_asking_price1) -(float)$pm_value - (float)$qtDetail->qt_total_down_payment;
        //$getPromotion = $this->tb_promotion->getPromotionBySearchQuotation($promotionid);
		
		$allCredit = $this->tb_promotion->fetchAllCredit();
        
        $data['un_name'] = $un_name;
		$data['building_name'] = $building_name;
		$data['unit_type_name'] = $unit_type_name;
		$data['unit_type_area_sqm'] = $unit_type_area_sqm;
		$data['room_type_name'] = $room_type_name;
		$data['pr_selling_sqm'] = $pr_selling_sqm;
		$data['un_direction'] = $un_direction;
		$data['pr_asking_price'] = $pr_asking_price;
		$data['CondoPrice'] = $CondoPrice;
        $data['getPromotion'] = $getPromotion;
        $data['title']      = $this->title_page;
		$data['page']       = $this->page_var;
        $data['permission'] = $this->get_user_permission();
        $data['project_database_sel'] = $this->project_database_sel;
        $data['leads']    = $leads;
        $data['leadsname'] = $leadsname;
		$data['list_customer'] = $list_customer;
        $data['promotiom'] = $promotiom;
        $data['definefee'] = $definefee;
        $data['banklist'] = $banklist;
        $data['credittypelist'] = $credittypelist;
        $data['qtCode'] = $qtCode;
        $data['allCredit'] = $allCredit;
        $data['Number'] = $Number;
        $data['Building'] = $Building;
        $data['Project'] = $Project;
        
		if(strpos($data['permission']->pm_receipt,'4') !== false) {
            $this->load->model('tb_receipt_offical');
            $data['receiptList'] = $this->tb_receipt_offical->get_cancelled();
        }
        
		$this->LoadView('BookingAndContract/booking_contract_adding',$data);
    }
    public function record()
    {
        date_default_timezone_set('Asia/Bangkok');
        $this->load->model('tb_quotation');
        $this->load->model('tb_price');
        $this->load->model('tb_promotion');
        $this->load->model('tb_customer_project');
        $this->load->model('tb_unit_number');
        $this->load->model('tb_booking');
        $this->load->model('tb_contract_promotion');
        $this->load->model('tb_receipt_temporary');
        $this->load->model('tb_contract');
        
        
        // $this->load->model('tb_room_status');
        
        // $this->load->model('tb_payment');
        // $this->load->model('tb_bank');
        
        // $this->load->model('tb_installment');
        // $this->load->model('tb_project');
        // $this->load->model('tb_transfer_ownership');
        // $this->load->library('payment');
        // $this->load->library('encrypt');
        
        $valueAllGift = 0;
        // $qtCode  = $this->input->post('qtCode');
        // $cusid   = $this->input->post('cusid');
        // $typeCon = $this->input->post('TypeCon');
        // $payDay  = $this->input->post('payDay');
        // $remark  = $this->input->post('Remark');
        // $bookCus = $cusid[0];
        // $ctCus   = '';

        $quoDetails = $this->tb_quotation->getDetail_by_id ($this->input->post('qtCode'));
        $priceDetails = $this->tb_price->get_detail_by_unit_id_and_building_id($quoDetails->qt_unit_number_id,$quoDetails->qt_buliding_id);
        $promotionDetails = $this->tb_promotion->fetchBySearchQuotation(implode(',', $this->input->post('pro')));
        $unitDetails = $this->tb_unit_number->get_detail_unit_by_un_id($this->input->post('unitnumberid'));
            
        $this->validatePromotion ($priceDetails, $promotionDetails); //check => allPromotion < bottomPrice ?
        
        echo "
        cusID : ".$this->conbineCustomer ('booking')."<br>
        cusID : ".$this->conbineCustomer ('contract')."<br>
        unID : ".$this->input->post('unitnumberid')."<br>
        unName : ".$this->input->post('unitnumber')."<br>
        buildID : ".$this->input->post('buildingid')."<br>
        statusRoom : $unitDetails->un_status_room<br>
        quotation : ".$this->input->post('qtCode')."<br>
        booking fee : $quoDetails->qt_booking_fee<br>
        contract date : ".date('Y-m-d', strtotime('+2week', strtotime(date('Y-m-d H:i:s'))))."<br>
        payday : ".$this->input->post('payDay')."<br>
        user : $this->user_id<br>
        booking code : ".$this->newCode ('booking')."<br>
        contract code : ".$this->newCode ('contract')."<br>
        temp code : ".$this->newCode ('tempreceipt')."<br>
        contract type : ".$this->input->post('TypeCon')."<br>
        ";
        exit();

        foreach(explode(',', $this->conbineCustomer ('contract')) as $val) {
            if( empty( $this->tb_customer_project->get_id_by_cus($val) ) ) {
                $dataCustomerProject = array(
                    'cp_cus_id' => $val,
                    'cp_project_id' => $this->project_id_sel
                );
                $this->tb_customer_project->record($dataCustomerProject);
            }
        } //record customer project

        if($unitDetails->un_status_room != 'Available') {
            alert_redirect('This room is unavailable.','/booking/view');
            exit;
        } //check status room
        
        try {
            $data_unit_number = array(
                'un_status_room' => 'Booked'
            );
            $this->tb_unit_number->update_where($data_unit_number,"un_id = '".$this->input->post('unitnumberid')."' AND un_name = '".$this->input->post('unitnumber')."' AND un_build_id = '".$this->input->post('buildingid')."' AND un_status_room = 'Available'");         
        } catch (Exception $e) {
            alert_redirect('This room is unavailable.','/booking/view');
            exit;
        }

        $newbid = $this->newCode ('booking');
        $dataBooking = array(
            'bk_booking_code' => $newbid,
            'bk_quotation_code' => $this->input->post('qtCode'),
            'bk_leads_id' => $this->conbineCustomer ('booking'),
            'bk_project_id' => $this->input->post('projectid'),
            'bk_money_amount' => $quoDetails->qt_booking_fee,
            'bk_date_booking' => date("Y-m-d H:i:s"),
            'bk_contract_date' => date('Y-m-d', strtotime('+2week', strtotime(date('Y-m-d H:i:s')))),
            'bk_pay_day' => $this->input->post('payDay'),
            'bk_remark' => 'booking & contract',
            'bk_staff_id' => $this->user_id,
            'bk_status' => 'off'
        );
        $this->tb_booking->record($dataBooking); //record booking

        $dataQuotation = array(
            'qt_status' => 'off'
        );
        $this->tb_quotation->update($dataQuotation,$this->input->post('qtCode')); //record quotation

        $newcid = $this->newCode ('contract');
        $data_contract = array(
            'ct_code' => $newcid,
            'ct_booking_code' => $newbid,
            'ct_cus_id' => $this->conbineCustomer ('contract'),
            'ct_type' => $this->input->post('TypeCon'),
            'ct_date' => date('Y-m-d', strtotime('+2week', strtotime(date('Y-m-d H:i:s')))),
            'ct_pay_day' => $this->input->post('payDay'),
            'ct_staff_id' => $this->user_id,
            'ct_project_id' => $this->input->post('projectid'),
            'ct_remark' => 'booking & contract',
            'ct_active' => 'off',
            'ct_paid' => 'yes',
            'ct_temp_receipt_date' => date("Y-m-d H:i:s")
        );
        $this->tb_contract->record($data_contract);
        
        foreach ($this->input->post('pro') as $key => $value) {
            $dataPromotion = array(
                'cp_booking_code' => $newbid,
                'cp_contract_code' => $newcid,
                'cp_promotion_id' => $value
            );
            $this->tb_contract_promotion->record($dataPromotion);
        } //record promotion

        // $newrcv = $this->newCode ('tempreceipt');
        // $data_receipt = array(
            // 'rc_code' => $newrcv,
            // 'rc_refer_form' => $receiptID,
            // 'rc_customer_id' => $cusid,
            // 'rc_payfor' => 'Booking Fee',
            // 'rc_booking_code' => $newbid,
            // 'rc_total_amount' => $MoneyAmount,
            // 'rc_staff_temporary' => $sale,
            // 'rc_temporary_date' => date('Y-m-d H:i:s'),
            // 'rc_un_name' => $unitnumber
        // );
        // $this->tb_receipt_temporary->record($data_receipt);

        $unit_name = '';
        for($i = strlen($unitDetails->un_name);$i<4;$i++){
            $unit_name .= '0';
        }
        $unit_name .= $unitDetails->un_name;
        $imcode = 'IM-'.$unit_name.'-';
        for ($i=1; $i <= $installmentMonth; $i++) {
            $final = date("Y-m-".$payDay, strtotime("+$i month", $startDate));   
            $temp = '';
            for($j = strlen($i);$j<2;$j++){
                $temp .= '0';
            }
            $installmantfee_paymant = $this->payment->getDefinefee($temp.$i, $qtArr);
        
            $data_installment = array(
                'im_code' => $imcode.$temp.$i,
                'im_contract_code' => $this->conbineCustomer ('contract'),
                'im_cus_id' => $ctDetail->ct_cus_id,
                'im_installment_time' => $temp.$i,
                'im_duedate' => $final,
                'im_fee_define' => $installmantfee_paymant,
                'im_amount' => $installmantfee_paymant,
            );
            $this->tb_installment->record($data_installment);
        }

        $data_room = array(
             'rs_unit_number' => $quoDetails->qt_unit_number_id;,
             'rs_cus_id' => $this->conbineCustomer ('booking'),
             'rs_status' => 'Booking',
             'rs_staff_id' => $this->user_id
         );
         $this->tb_room_status->record($data_room); //record room status booking

        $data_room_sts = array(
            'rs_unit_number' => $quoDetails->qt_unit_number_id;,
            'rs_cus_id' => $this->conbineCustomer ('contract'),
            'rs_status' => 'Make Contract',
            'rs_staff_id' => $this->user_id
        );
        $this->tb_room_status->record($data_room_sts); //record room status contract
        
        $data_room_sts = array(
            'rs_unit_number' => $quoDetails->qt_unit_number_id;,
            'rs_cus_id' => $this->conbineCustomer ('contract'),
            'rs_status' => 'Temp receipt for contract',
            'rs_staff_id' => $this->user_id
        );
        $this->tb_room_status->record($data_room_sts); //record room status temp contract

  //       foreach($cusid as $val) {
  //           if(!empty($val)) {
  //               $ctCus .= empty($ctCus)?$val:','.$val;
  //           }
  //       }
        
  //       $today = date("Y-m-d H:i:s"); 
  //       $sale = $this->user_id;
        
		// if( $bookCus!=0 && !empty($bookCus) ) {
  //           $this->load->database();
  //           $this->db->trans_begin();
  //           $this->pdb->trans_begin();
            
  //           $qtDetail = $this->tb_quotation->getDetail_by_id($qtCode);
  //           $unitID   = $qtDetail->qt_unit_number_id;
  //           $projectid = $qtDetail->qt_project_id;
  //           $bookingFee = $qtDetail->qt_booking_fee;
  //           $contractFee = $qtDetail->qt_contract_fee;
  //           $trAmount = $qtDetail->qt_unit_price - $qtDetail->qt_total_down_payment;
            
  //           $unitDetail = $this->tb_unit_number->get_detail_unit_by_un_id($unitID);
  //           $unitnumber = $unitDetail->un_name;
  //           $buildingid = $unitDetail->un_build_id;
            
  //           if($unitDetail->un_status_room != 'Available') {
  //               alert_redirect('This room is unavailable.','/booking/view');
  //               exit;
  //           }
			
  //           try {
  //               $data_unit_number = array(
		// 		    'un_status_room' => 'Sold'
  //               );
  //               $this->tb_unit_number->update_where($data_unit_number,"un_id = '".$unitID."' AND un_name = '".$unitnumber."' AND un_build_id = '".$buildingid."' AND un_status_room = 'Available'");         
  //           } catch (Exception $e) {
  //               alert_redirect('This room is unavailable.','/booking/view');
  //               exit;
  //           }
            
  //           $data_room = array(
		// 		'rs_unit_number' => $unitID,
		// 		'rs_cus_id' => $bookCus,
		// 		'rs_status' => 'Booking',
		// 		'rs_staff_id' => $sale
		// 	);
		// 	$this->tb_room_status->record($data_room);
  //           $data_room_sts = array(
  //               'rs_unit_number' => $unitID,
  //               'rs_cus_id' => $ctCus,
  //               'rs_status' => 'Make Contract',
  //               'rs_staff_id' => $sale
  //           );
  //           $this->tb_room_status->record($data_room_sts);
            
  //           $data_room_sts = array(
  //               'rs_unit_number' => $unitID,
  //               'rs_cus_id' => $ctCus,
  //               'rs_status' => 'Temp receipt for contract',
  //               'rs_staff_id' => $sale
  //           );
  //           $this->tb_room_status->record($data_room_sts);
            
  //           ///////////  Booking Code  ///////////
		// 	$newid= $this->tb_booking->get_new_booking_id($projectid);
		// 	$tmp = strlen($newid);
		// 	$tmpID = '';
		// 	for ($i=$tmp; $i < 5 ; $i++) $tmpID .= '0';
		// 	$tmptmp = strlen($projectid);
		// 	$tmpIDP = '';
		// 	for ($i=$tmptmp; $i < 2 ; $i++) $tmpIDP .= '0';
		// 	$dateQuo = date("ymd"); 
		// 	$newbid ='B'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid; 
		// 	//////////////////////////////////////
		
		// 	$time = strtotime($today);
		// 	$contract_date = date("Y-m-d", strtotime("+2week", $time));	

		// 	$data_booking = array(
		// 		'bk_booking_code' => $newbid,
		// 		'bk_quotation_code' => $qtCode,
		// 		'bk_leads_id' => $bookCus,
		// 		'bk_project_id' => $projectid,
		// 		'bk_money_amount' => $bookingFee,
		// 		'bk_date_booking' => $today,
		// 		'bk_contract_date' => $contract_date,
		// 		'bk_pay_day' => $payDay,
  //               'bk_remark' => $remark,
		// 		'bk_staff_id' => $sale,
  //               'bk_status' => 'off'
		// 	);
		// 	$this->tb_booking->record($data_booking);
            
  //           $data_quotation = array(
		// 		'qt_status' => 'off'
		// 	);
		// 	$this->tb_quotation->update($data_quotation,$qtCode);
            
  //           //////////////// CONTRACT CODE ////////////////
  //           $newid = $this->tb_contract->get_new_contract_id($projectid);
  //           $tmp   = strlen($newid);
  //           $tmpID = '';
  //           for ($i=$tmp; $i < 5 ; $i++) { 
  //               $tmpID .= '0';
  //           }
  //           $ctCode ='C'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$newid;

  //           $data_contract = array(
  //               'ct_code' => $ctCode,
  //               'ct_booking_code' => $newbid,
  //               'ct_cus_id' => $ctCus,
  //               'ct_type' => $typeCon,
  //               'ct_date' => $contract_date,
  //               'ct_pay_day' => $payDay,
  //               'ct_staff_id' => $sale,
  //               'ct_project_id' => $projectid,
  //               'ct_remark' => $remark,
  //               'ct_active' => 'off',
  //               'ct_paid' => 'yes',
  //               'ct_temp_receipt_date' => $today
  //           );
  //           $this->tb_contract->record($data_contract);
            
  //           foreach(explode(',', $ctCus) as $val) {
  //               if( empty( $this->tb_customer_project->get_id_by_cus($val) ) ) {
  //                   $data = array(
  //                       'cp_cus_id' => $val,
  //                       'cp_project_id' => $this->project_id_sel
  //                   );
  //                   $this->tb_customer_project->record($data);
  //               }
  //           }
  //           ////////////////////////////////////////////////
            
		// 	foreach ($this->input->post('pro') as $key => $value) {
		// 		$data_promotion = array(
		// 			'cp_booking_code' => $newbid,
		// 			'cp_contract_code' => $ctCode,
		// 			'cp_promotion_id' => $value
		// 		);
		// 		$this->tb_contract_promotion->record($data_promotion);
		// 	}
            
  //           //////////////  Installment  //////////////
  //           $unit_name = '';
  //           for($i = strlen($unitnumber);$i<4;$i++){
  //               $unit_name .= '0';
  //           }
  //           $unit_name .= $unitnumber;
  //           $imcode = 'IM-'.$unit_name.'-';
            
  //           $projectDetail = $this->tb_project->get_detail_project_selected($projectid);
  //           if(!empty($projectDetail->pj_end_downpayment)) {
  //               $startDate = strtotime("-$installmentMonth month", strtotime($projectDetail->pj_end_downpayment));
  //           }else {
  //               $startDate = date("Y-m-".$payDay);
  //           }
            
  //           $qtArr = (array)$qtDetail;
  //           for ($i=1; $i <= $installmentMonth; $i++) {
  //               $final = date("Y-m-".$payDay, strtotime("+$i month", $startDate));	
            
  //               $temp = '';
  //               for($j = strlen($i);$j<2;$j++){
  //                   $temp .= '0';
  //               }
            
  //               $installmantfee_paymant = $this->payment->getDefinefee($temp.$i, $qtArr);
            
  //               $data_installment = array(
  //                   'im_code' => $imcode.$temp.$i,
  //                   'im_contract_code' => $ctCode,
  //                   'im_cus_id' => $ctDetail->ct_cus_id,
  //                   'im_installment_time' => $temp.$i,
  //                   'im_duedate' => $final,
  //                   'im_fee_define' => $installmantfee_paymant,
  //                   'im_amount' => $installmantfee_paymant,
  //               );
  //               $this->tb_installment->record($data_installment);
  //           }
  //           //////////////////////////////////////////
            
  //           /////////////  Receipt Code  /////////////
  //           $newid = $this->tb_receipt_temporary->get_next_id();
		// 	$tmp = strlen($newid);
		// 	$tmpID = '';
		// 	for ($i=$tmp; $i < 5 ; $i++) {
		// 		$tmpID .= '0';
		// 	}
		// 	$newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid;
  //           $bkrc = $newrcv;
  //           /////////////////////////////////////////
  //           $receiptID = implode(',', $this->input->post('receiptID'));
  //           if(!empty($receiptID)) {
  //               $update = array('rc_status'=>'off');
  //               foreach(explode(',', $receiptID) as $receipt) {
  //                   $this->tb_receipt_offical->update($update, $receipt);
  //                   $rcDetail = $this->tb_receipt_offical->get_by_id($receipt);
  //                   if($bookingFee > 0 && $rcDetail->rc_total_amount <= $bookingFee)
  //                   {
  //                       $bkReceipt[] = $receipt;
  //                       $bookingFee -= $receipt;
  //                   }else
  //                       $ctReceipt[] = $receipt;
  //               }
  //               $bkReceipt = implode(',', $bkReceipt);
  //               $ctReceipt = implode(',', $ctReceipt);
  //           }
            
		// 	$data_receipt = array(
		// 		'rc_code' => $newrcv,
  //               'rc_refer_form' => $bkReceipt,
		// 		'rc_customer_id' => $bookCus,
		// 		'rc_payfor' => 'Booking Fee',
		// 		'rc_booking_code' => $newbid,
		// 		'rc_total_amount' => $bookingFee,
		// 		'rc_staff_temporary' => $sale,
  //               'rc_temporary_date' => $today,
  //               'rc_un_name' => $unitnumber
		// 	);
		// 	$this->tb_receipt_temporary->record($data_receipt);
  //           //////////////////////////////////////////////////////////
            
  //           $Type  = $this->input->post('Type');
  //           $cash_amount    =	$this->input->post('Cashamount');
  //           $crcard_amount  =	$this->input->post('Cardamount');
  //           $other_amount   =	$this->input->post('Otheramount');
  //           if($cash_amount == $bookingFee)
  //               $bkPayby = 'Cash';
  //           else if($crcard_amount[0] == $bookingFee)
  //               $bkPayby = 'CrCard';
  //           else if($other_amount == $bookingFee)
  //               $bkPayby = 'Other';
	 //       	if(!empty($Type))
	 //       	{
	 //         	foreach($Type as $checkbox):
		//           	if ( trim($checkbox) == 'Cash' )   $type_payment = 'yes';
		//           	if ( trim($checkbox) == 'CrCard' ) $pay_crcard = 'yes';
		//           	if ( trim($checkbox) == 'Other' )  $pay_other  = 'yes';              
	 //         	endforeach;
	 //       	}
            
  //           if( ($type_payment=='yes' && $bookingFee>0 && empty($bkPayby)) || $bkPayby=='Cash' )
  //           {
  //               if($cash_amount - $bookingFee > 0)
  //                   $amount = $bookingFee;
  //               else
  //                   $amount = $cash_amount;
	 //            $data_payment = array(
	 //                'pm_temp_code' => $newrcv,
	 //                'pm_date' => $today,
	 //                'pm_type' => 'Cash',
	 //                'pm_amount' => $amount
	 //            );
	 //            $this->tb_payment->record($data_payment);
  //               $cash_amount -= $amount;
  //               $bookingFee -= $amount;
  //               if($cash_amount < 1)
  //                   $type_payment = 'no';
	 //        }
            
  //           $other_by       =	$this->input->post('OtherBy');
  //           $pm_check_number   =    $this->input->post('CheckNo');
  //           $pm_check_date     =    $this->input->post('CheckDate');
  //           $pm_check_bank     =    $this->input->post('CheckBank');
  //           if( ($pay_other == 'yes' && $bookingFee > 0 && empty($bkPayby)) || $bkPayby=='Other') {
  //               if($other_amount - $bookingFee > 0)
  //                   $amount = $bookingFee;
  //               else
  //                   $amount = $other_amount;
  //               if($other_by == 'Check'){
  //                   $data_payment = array(
	 //                    'pm_temp_code' => $newrcv,
	 //                    'pm_date' => $today,
	 //                    'pm_type' => 'Check',
	 //                    'pm_amount' => $amount,
	 //                    'pm_check_number' => $pm_check_number,
  //                       'pm_check_date' => $pm_check_date,
  //                       'pm_check_bank' => $pm_check_bank
	 //                );
	 //        	}else
	 //                $data_payment = array(
	 //                    'pm_temp_code' => $newrcv,
	 //                    'pm_date' => $today,
	 //                    'pm_type' => $other_by,
	 //                    'pm_amount' => $amount
	 //                );
	 //           $this->tb_payment->record($data_payment);
  //               $other_amount -= $amount;
  //               $bookingFee -= $amount;
  //               if($other_amount < 1)
  //                   $pay_other = 'no';
	 //        }
            
  //           $expiremonth_ = $this->input->post('expiremonth');
  //           $expireyear_ = $this->input->post('expireyear');
  //           $crcard_bank    =	$this->input->post('CardBank');
  //           $BankName          =	$this->input->post('BankName');
	 //        $credit_type_credit    =	$this->input->post('CardType');
  //           $cardHolder   =	$this->input->post('CardHolder');
	 //        $crcard_no      =	$this->input->post('Cardno');
	 //        $credit_approve_code    =	$this->input->post('ApproveCode');
	 //        if(($pay_crcard == 'yes' && $bookingFee > 0 && empty($bkPayby)) || $bkPayby=='CrCard') {
  //               $bankCount = 0;
  //               for($i=0;$i<count($crcard_amount);$i++) {
  //                   $crcard_date = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";
                    
  //                   if($crcard_bank[$i] == 0) {
  //                       $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
  //                       if(empty($b_id)) {
  //                           $b_id = $this->tb_bank->get_next_id();
  //                           $data = array(
  //                               'b_id' => $b_id,
  //                               'bank_name_th' => $BankName[$bankCount]
  //                           );
  //                           $this->tb_bank->record($data);
  //                       }
  //                       $bankCount++;
  //                   }else $b_id = $crcard_bank[$i];
                    
  //                   if($crcard_amount[$i] - $bookingFee > 0)
  //                       $amount = $bookingFee;
  //                   else
  //                       $amount = $crcard_amount[$i];
                    
  //                   $data_payment = array(
	 //                    'pm_temp_code' => $newrcv,
  //                       'pm_date' => $today,
  //                       'pm_type' => 'Credit',
  //                       'pm_amount' => $amount,
  //                       'pm_cr_bank' => $b_id,
	 //                    'pm_cr_type' => $credit_type_credit[$i],
  //                       'pm_cr_holder' => $cardHolder[$i],
  //                       'pm_cr_number' => $this->encrypt->encode($crcard_no[$i]),
  //                       'pm_cr_approve_code' => $credit_approve_code[$i],
  //                       'pm_cr_expire' => $crcard_date
  //                   );
  //                   $this->tb_payment->record($data_payment);
                    
  //                   $crcard_amount[$i] -= $amount;
  //                   $bookingFee -= $amount;
  //                   if($bookingFee < 1)
  //                       break;
  //               }
	 //        }
            
  //           //////////////////  Receipt Contract  //////////////////
  //           $newid = $this->tb_receipt_temporary->get_next_id();
  //           $tmp   = strlen($newid);
  //           $tmpID = '';
  //           for ($i=$tmp; $i < 5 ; $i++) { 
  //               $tmpID .= '0';
  //           }
  //           $newrcv = 'T'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.$newid;
            
  //           $data_receipt = array(
  //               'rc_code' => $newrcv,
  //               'rc_refer_form' => $ctReceipt,
  //               'rc_customer_id' => $ctCus,
  //               'rc_payfor' => 'Contract Fee',
  //               'rc_booking_code' => $newbid,
  //               'rc_contract_code' => $ctCode,
  //               'rc_total_amount' => $contractFee,
  //               'rc_temporary_date' => $today,
  //               'rc_staff_temporary' => $sale,
  //               'rc_un_name' => $unitnumber
  //           );
  //           $this->tb_receipt_temporary->record($data_receipt);
            
  //           if($type_payment == "yes") {
  //               $data_payment = array(
  //                   'pm_temp_code' => $newrcv,
  //                   'pm_date' => $today,
  //                   'pm_type' => 'Cash',
  //                   'pm_amount' => $cash_amount,
  //               );
  //               $this->tb_payment->record($data_payment);
  //           }
            
  //           if($pay_crcard == "yes") {
  //               $bankCount = 0;
  //               for($i=0;$i<count($crcard_amount);$i++) {
  //                   $crcard_date = (!empty($expiremonth_[$i]) && !empty($expireyear_[$i]))?$expiremonth_[$i].'/'.$expireyear_[$i]:"";
                    
  //                   if($crcard_bank[$i] == 0) {
  //                       $b_id = $this->tb_bank->get_id_by_name_th($BankName[$bankCount]);
  //                       if(empty($b_id)) {
  //                           $b_id = $this->tb_bank->get_next_id();
  //                           $data = array(
  //                               'b_id' => $b_id,
  //                               'bank_name_th' => $BankName[$bankCount]
  //                           );
  //                           $this->tb_bank->record($data);
  //                       }
  //                       $bankCount++;
  //                   }else $b_id = $crcard_bank[$i];
                
  //                   if($crcard_amount[$i] > 0) {
  //                       $data_payment = array(
  //                           'pm_temp_code' => $newrcv,
  //                           'pm_date' => $today,
  //                           'pm_type' => 'Credit',
  //                           'pm_amount' => $crcard_amount[$i],
  //                           'pm_cr_bank' => $b_id,
  //                           'pm_cr_type' => $credit_type_credit[$i],
  //                           'pm_cr_holder' => $cardHolder[$i],
  //                           'pm_cr_number' => $this->encrypt->encode($crcard_no[$i]),
  //                           'pm_cr_approve_code' => $credit_approve_code[$i],
  //                           'pm_cr_expire' => $crcard_date
  //                       );
  //                       $this->tb_payment->record($data_payment);
  //                   }
  //               }
  //           }
  //           if($pay_other == "yes") {
  //               if($other_by == 'Check'){
  //                   $data_payment = array(
	 //                    'pm_temp_code' => $newrcv,
	 //                    'pm_date' => $today,
	 //                    'pm_type' => 'Check',
	 //                    'pm_amount' => $other_amount,
	 //                    'pm_check_number' => $pm_check_number,
  //                       'pm_check_date' => $pm_check_date,
  //                       'pm_check_bank' => $pm_check_bank
	 //                );
	 //        	}else {
  //                   $data_payment = array(
  //                       'pm_temp_code' => $newrcv,
  //                       'pm_date' => $today,
  //                       'pm_type' => $other_by,
  //                       'pm_amount' => $other_amount
  //                   );
  //               }
  //               $this->tb_payment->record($data_payment);
  //           }
        
  //           ///////////////// transfer ownership //////////////////
  //           $trNewID = $this->tb_transfer_ownership->get_next_id();
  //           $tmpID = '';
  //           for($i=strlen($trNewID);$i<5;$i++)
  //               $tmpID.= '0';
  //           $trCode = 'TR'.$tmpIDP.$projectid.'-'.$dateQuo.'-'.$tmpID.''.$trNewID;
        
  //           $dataTransferOwnership = array(
  //               'tr_code'           => $trCode,
  //               'tr_contract_code'  => $ctCode,
  //               'tr_customer_id'    => $ctCus,
  //               'tr_unit_number_id' => $unitID,
  //               'tr_amount'         => $trAmount
  //           );
  //           $this->tb_transfer_ownership->record($dataTransferOwnership);
            
  //           /////////////////////////////////////////////////////////////
            
  //           if ($this->pdb->trans_status() === FALSE || $this->db->trans_status() === FALSE){
  //               $this->db->trans_rollback();
  //               $this->pdb->trans_rollback();
  //               alert_redirect('Booking and Contract fail!','/quotation/view');
  //           }
  //           else{
  //               $this->db->trans_commit();
  //               $this->pdb->trans_commit();
  //               echo "<script>  window.open('".BASE_DOMAIN."booking/report/$newbid/TH','_blank');";
  //               echo "window.open('".BASE_DOMAIN."contract/report/th/$ctCode','_blank');";
  //               echo "window.open('".BASE_DOMAIN."receipt/report/th/$bkrc','_blank');";
  //               echo "window.open('".BASE_DOMAIN."receipt/report/th/$newrcv','_blank');";
  //               echo "window.location.href = '".BASE_DOMAIN."contract/view';</script>";
  //           }
		// }else{
  //           echo "<script>window.location.href = '".BASE_DOMAIN."bookingcontract/adding/".$qtCode."';</script>";
  //       }
    }

    function validatePromotion ($price, $promotion) {
        foreach ($promotion as $promotion) {
            $gift += $promotion->pm_value;
        }
        $askingPrice = str_replace( ',', '', $price->pr_asking_price);
        $bottomPrice = floatval(str_replace(',', '', $price->pr_bottom_line_for_internal));
        $priceDisc = (float)intval($askingPrice) -(float)$gift;

        if (strpos($this->get_user_permission()->pm_quotation,'3') === false && $priceDisc < $bottomPrice) {
            echo "<script> alert('Can not create booking, please remove some promotion');  history.back(); </script>";
            exit;
                    
        }
    }
    function conbineCustomer ($type) {
        foreach($this->input->post('cusid') as $index => $val) {
            if ($type == 'booking') {
                $cus = $this->input->post('cusid')[$index];
                break;
            } else if ($type == 'contract') {
                if(!empty($val)) {
                    $cus .= empty($cus)?$val:','.$val;
                }
            }
        }
        return $cus;
    }
    function newCode ($type) {
        if ($type == 'booking') {
            $this->load->model('tb_booking');
            $newid= $this->tb_booking->get_new_booking_id($this->input->post('projectid'));
            $head = 'B';
        } else if ($type == 'contract') {
            $this->load->model('tb_contract');
            $newid = $this->tb_contract->get_new_contract_id($this->input->post('projectid'));
            $head = 'C';
        } else if ($type == 'tempreceipt') {
            $this->load->model('tb_receipt_temporary');
            $newid = $this->tb_receipt_temporary->get_next_id();
            $head = 'T';
        }
        $tmptmp = strlen($this->input->post('projectid'));
        $tmpIDP = '';
        for ($i=$tmptmp; $i < 2 ; $i++) { 
            $tmpIDP .= '0';
        }
        $tmp = strlen($newid);
        $tmpID = '';
        for ($i=$tmp; $i < 5 ; $i++) {
            $tmpID .= '0';
        }
        $code = $head.$tmpIDP.$this->input->post('projectid').'-'.date("ymd").'-'.$tmpID.$newid;
        return $code;
    }
}
?>