<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Room extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	*/
	var $title_page = 'Admin System';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();

    }
	public function index()
	{
		$this->view();
	}
	public function view()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['permission'] = $this->get_user_permission();
		$data['title'] = $this->title_page;
		$data['list_room'] = $this->fetch_active_room();
		$data['menuLeft'] = 'off';
		$this->LoadView('Room/room',$data);
	}
	public function adding()
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['permission'] = $this->get_user_permission();
		$data['menuLeft'] = 'off';
		$this->LoadView('Room/room_adding',$data);
	}
	public function record()
	{
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();

 		$Name = $this->input->post('Name');
 		$Info = $this->input->post('Info');
	
		foreach($Name as $index => $position ){
		
			$name_add = $Name[$index] ;
			$info_add = $Info[$index] ;
			if (trim($name_add) != null) {
				
				$data = array(
					'room_type_id' => '0',
					'room_type_name' => $name_add,
					'room_type_info' => $info_add
				);
				$this->recordRoom($data);	
			}
		}

		/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->db->trans_status() === FALSE){
     		$this->db->trans_rollback();
 			alert_redirect('Add Room Type Fail','/room/view');
		}
		else{
		  	$this->db->trans_commit();
		   	alert_redirect('Add Room Type Success','/room/view');
		}
		
	}
	public function editing($room_type_id)
	{
		$this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['title'] = $this->title_page;
		$data['room_type_id'] = $room_type_id;
		$data['room'] = $this->get_detail_room($room_type_id);
		$data['permission'] = $this->get_user_permission();
		$data['menuLeft'] = 'off';
		$this->LoadView('Room/room_editing',$data);
	}
	public function update($room_type_id)
	{
		/*================================*/
		/*======= Transaction start ======*/
	 	/*================================*/
	 	$this->load->database();
	 	$this->db->trans_begin();

	 	$room = $this->input->post('room');
	 	$Name = $this->input->post('Name');
	 	$Info = $this->input->post('Info');
	 	$userEdit = $this->user_id;
	 	$data = array(
	 		'room_type_name' => $Name,
	 		'room_type_info' => $Info
	 	);
	 	$this->updateRoom($data,$room_type_id);

	 	///// KEEP LOG /////
	 	////////////////////
	 	$obj_room = $this->get_detail_room($room_type_id);
	 	$data_log = array(
	 		'room_type_id' => $obj_room->room_type_id,
	 		'room_type_name' => $obj_room->room_type_name,
	 		'room_type_info' => $obj_room->room_type_info,
	 		'room_type_sts_active' => $obj_room->room_type_sts_active,
	 		'room_type_update_by' => $userEdit
	 	);
	 	$this->record_log_room_type($data_log);

	 	/*=======================================*/
	 	/*======= check status transaction ======*/
		/*=======================================*/
		if ($this->db->trans_status() === FALSE){
     		$this->db->trans_rollback();
 			alert_redirect('Edit Room Type Fail','/room/view');
		}
		else{
		  	$this->db->trans_commit();
		   	alert_redirect('Edit Room Type Success','/room/view');
		}
	 	
	}
	public function deleting($room_type_id){
		$permission = $this->get_user_permission();

		if (strpos($permission->pm_room,'4') === FALSE) {
			alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
		}else{
			$data = array(
	 			'room_type_sts_active' => 'off'
	 		);
	 		$this->updateRoom($data,$room_type_id);
	 		alert_redirect('Delete Room Type Success','/room/view');	
		}
	}

	/**
	* -------------------------------------
	* Scope [PRIVATE METHOD]
	* -------------------------------------
	*/
	//////// ROOM ////////////
	//////////////////////////
	private function fetch_active_room(){
		$this->load->model('tb_room_type');
		return $this->tb_room_type->fetch_active_room();
	}
	private function get_detail_room($room_type_id){
		$this->load->model('tb_room_type');
		return $this->tb_room_type->get_detail_room($room_type_id);
	}

	//////// RECORD //////////
	//////////////////////////
	private function recordRoom($data)
	{
		$this->load->model('tb_room_type');
		$this->tb_room_type->record($data);
	}

	//////// UPDATE //////////
	//////////////////////////
	private function updateRoom($data,$room_type_id)
	{
		$this->load->model('tb_room_type');
		$this->tb_room_type->update($data,$room_type_id);
	}

	/**
	* -------------------------------------
	* Log Management [PRIVATE METHOD]
	* -------------------------------------
	*/
	private function record_log_room_type($data)
	{
		$this->load->model('log_room_type');
	 	$this->log_room_type->record($data);
	}
}

/* End of file room.php */
/* Location: ./application/controllers/room.php */