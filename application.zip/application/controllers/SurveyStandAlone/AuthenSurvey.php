<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class AuthenSurvey extends NZ_Controller {
	/**
	* $title_page 		 :: text on your browser tabbar.
	* $error_message_th  :: text on your error alert message.
	*/
	var $title_page = 'Admin System';
	var $error_message_th = 'โปรดตรวจสอบการเข้าระบบ';
	/**
	*
	*/
	function __construct()
    {
        parent::__construct();
    }
    
	public function index()
	{
		$data['title'] = $this->title_page;
		if($this->user_id == NULL){
			$this->load->view('Authen/AuthenSurvey',$data);
		}else{
            echo '<script>window.location.href = "'.BASE_DOMAIN.'SurveyStandAlone/HomeSurvey"</script>';
		}
	}
	public function login(){

		$this->load->model('tb_user');
		$username = trim($this->input->post('username'));
		$password = md5(trim($this->input->post('password')));
		$result = $this->tb_user->authentication($username,$password);

		$success = $result['success'];

		if($success){
			$this->generateSession($result['user_id'],$result['user_username'],$result['user_permission']);
			echo '<script>window.location.href = "'.BASE_DOMAIN.'SurveyStandAlone/HomeSurvey"</script>';
		}else{
			alert_redirect($this->error_message_th,'/SurveyStandAlone/AuthenSurvey');
		}
	}
	public function logout(){
		$this->session->sess_destroy();
        echo '<script>window.location.href = "'.BASE_DOMAIN.'SurveyStandAlone/AuthenSurvey"</script>';
	}
    function language($language) {
        $this->session->set_userdata('language', $language);
        echo '<script>window.location.href = "'.$_SERVER['HTTP_REFERER'].'"</script>';
    }
}

/* End of file authen.php */
/* Location: ./application/controllers/authen.php */