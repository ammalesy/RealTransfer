<?php
$name='THSarabunPSK-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 850,
  'Descent' => -250,
  'CapHeight' => 476,
  'Flags' => 262148,
  'FontBBox' => '[-466 -457 947 844]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 698,
);
$up=-35;
$ut=30;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/THSarabun-Bold.ttf';
$TTCfontID='0';
$originalsize=117744;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='thsarabunB';
$panose=' 8 5 2 b 5 0 4 2 0 2 0 3';
$haskerninfo=false;
$unAGlyphs=false;
?>