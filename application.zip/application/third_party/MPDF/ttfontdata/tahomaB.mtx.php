<?php
$name='Tahoma-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 1000,
  'Descent' => -207,
  'CapHeight' => 727,
  'Flags' => 262148,
  'FontBBox' => '[-698 -419 2196 1065]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 1000,
);
$up=-70;
$ut=98;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/tahomabd.ttf';
$TTCfontID='0';
$originalsize=692616;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='tahomaB';
$panose=' 8 0 2 b 8 4 3 5 4 4 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>