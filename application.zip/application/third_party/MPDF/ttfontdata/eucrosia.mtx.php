<?php
$name='EucrosiaUPC';
$type='TTF';
$desc=array (
  'Ascent' => 465,
  'Descent' => -153,
  'CapHeight' => 451,
  'Flags' => 4,
  'FontBBox' => '[-472 -385 791 839]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$up=-32;
$ut=5;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/upcel.ttf';
$TTCfontID='0';
$originalsize=74048;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='eucrosia';
$panose=' 0 0 2 2 6 3 5 4 5 2 3 4';
$haskerninfo=false;
$unAGlyphs=false;
?>