<?php
$name='AngsanaNew-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -206,
  'CapHeight' => 437,
  'Flags' => 262212,
  'FontBBox' => '[-458 -433 790 994]',
  'ItalicAngle' => -10,
  'StemV' => 165,
  'MissingWidth' => 500,
);
$up=-50;
$ut=25;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/angsaz.ttf';
$TTCfontID='0';
$originalsize=106124;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='angsaBI';
$panose=' 1 5 2 2 7 3 6 5 5 9 3 4';
$haskerninfo=false;
$unAGlyphs=false;
?>