<?php
$name='TFPimpakarn-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 895,
  'Descent' => -460,
  'CapHeight' => 473,
  'Flags' => 262212,
  'FontBBox' => '[-450 -420 779 894]',
  'ItalicAngle' => -12,
  'StemV' => 165,
  'MissingWidth' => 500,
);
$up=-35;
$ut=30;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/TF-Pimpakarn-Bol-Ita.ttf';
$TTCfontID='0';
$originalsize=160628;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='pimpakarnBI';
$panose=' 3 5 2 0 8 6 0 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>