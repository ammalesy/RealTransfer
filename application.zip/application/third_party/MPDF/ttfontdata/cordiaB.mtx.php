<?php
$name='CordiaNew-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 833,
  'Descent' => -261,
  'CapHeight' => 469,
  'Flags' => 262148,
  'FontBBox' => '[-547 -417 791 833]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 750,
);
$up=-50;
$ut=25;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/cordiab.ttf';
$TTCfontID='0';
$originalsize=90732;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='cordiaB';
$panose=' 8 5 2 b 6 4 2 2 2 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>