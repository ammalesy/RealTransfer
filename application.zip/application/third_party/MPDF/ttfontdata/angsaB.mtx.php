<?php
$name='AngsanaNew-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 888,
  'Descent' => -239,
  'CapHeight' => 437,
  'Flags' => 262148,
  'FontBBox' => '[-501 -433 783 995]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 750,
);
$up=-50;
$ut=25;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/angsab.ttf';
$TTCfontID='0';
$originalsize=106408;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='angsaB';
$panose=' 1 5 2 2 8 3 7 5 5 2 3 4';
$haskerninfo=false;
$unAGlyphs=false;
?>