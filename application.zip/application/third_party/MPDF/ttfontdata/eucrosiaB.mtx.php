<?php
$name='EucrosiaUPCBold';
$type='TTF';
$desc=array (
  'Ascent' => 449,
  'Descent' => -143,
  'CapHeight' => 451,
  'Flags' => 262148,
  'FontBBox' => '[-522 -402 777 849]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 750,
);
$up=-32;
$ut=5;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/upceb.ttf';
$TTCfontID='0';
$originalsize=75300;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='eucrosiaB';
$panose=' 0 0 2 2 8 3 7 5 5 2 3 4';
$haskerninfo=false;
$unAGlyphs=false;
?>