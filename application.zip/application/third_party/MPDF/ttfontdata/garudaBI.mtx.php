<?php
$name='Garuda-BoldOblique';
$type='TTF';
$desc=array (
  'Ascent' => 1284,
  'Descent' => -591,
  'CapHeight' => 1284,
  'Flags' => 262212,
  'FontBBox' => '[-606 -591 1161 1337]',
  'ItalicAngle' => -12,
  'StemV' => 165,
  'MissingWidth' => 766,
);
$up=-37;
$ut=20;
$ttffile='C:/AppServ/www/condo/admin/MPDF/ttfonts/Garuda-BoldOblique.ttf';
$TTCfontID='0';
$originalsize=57460;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='garudaBI';
$panose=' 0 0 2 b 7 4 2 2 2 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>