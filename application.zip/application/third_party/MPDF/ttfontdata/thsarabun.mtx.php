<?php
$name='THSarabunPSK';
$type='TTF';
$desc=array (
  'Ascent' => 850,
  'Descent' => -250,
  'CapHeight' => 476,
  'Flags' => 4,
  'FontBBox' => '[-427 -421 947 836]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 692,
);
$up=-35;
$ut=30;
$ttffile='C:/xampp/htdocs/crm/application/third_party/MPDF/ttfonts/THSarabun.ttf';
$TTCfontID='0';
$originalsize=98764;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='thsarabun';
$panose=' 8 5 2 b 5 0 4 2 0 2 0 3';
$haskerninfo=false;
$unAGlyphs=false;
?>