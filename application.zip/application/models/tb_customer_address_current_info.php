<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_customer_address_current_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_customer_address_current_info', $array);
    }
    function update($array,$cus_id)
    {
      $this->load->database();
      $this->db->where('addr_cur_id', $cus_id);
      $this->db->update('tb_customer_address_current_info', $array); 
    }
    function get_detail_by_addr_cur_id_cus($addr_cur_id_cus){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer_address_current_info 
                                 WHERE addr_cur_id_cus = '".$addr_cur_id_cus."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_customerID($customerID){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM  tb_customer_address_current_info , tb_customer
                                 WHERE cus_addr_cur_id = addr_cur_id
                                 AND cus_id ='".$customerID."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_new_customer_address_current_info_id()
    {

        $this->load->database();
        $query = $this->db->query("SELECT Max(addr_cur_id)+1 as MaxID from tb_customer_address_current_info");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    
}

/* End of file tb_customer_address_info.php */
/* Location: ./application/models/tb_customer_address_info.php */