<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_customer_address_lastest extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_customer_address_lastest', $array);
    }
    function update($array,$addr_lastest_id)
    {
      $this->load->database();
      $this->db->where('addr_lastest_id', $addr_lastest_id);
      $this->db->update('tb_customer_address_lastest', $array); 
    }
    function get_detail_by_addr_lastest_id_cus($addr_lastest_id_cus){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer_address_lastest 
                                 WHERE addr_lastest_id_cus = '".$addr_lastest_id_cus."'");
      $result = $query->result();

      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_cus_id($cus_id){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM  tb_customer_address_lastest, tb_customer
                                 WHERE cus_addr_lastest_id = addr_lastest_id_cus
                                 AND cus_id ='".$cus_id."'");
      $result = $query->result();

      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_new_customer_address_lastest_id()
    {
        $this->load->database();
        $query = $this->db->query("SELECT Max(addr_lastest_id)+1 as MaxID from tb_customer_address_lastest");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
}

/* End of file tb_customer_address_lastest.php */
/* Location: ./application/models/tb_customer_address_lastest.php */