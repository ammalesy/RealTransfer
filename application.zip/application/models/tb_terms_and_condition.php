<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_terms_and_condition extends NZ_Model {

    function __construct()
    {
      parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_terms_and_condition', $array);
    } 
    function update($array,$ct_id)
    {
      $this->pdb->where('ct_id', $ct_id);
      $this->pdb->update('tb_terms_and_condition', $array); 
    }
    function get_detail_by_id($ct_id){

      $query = $this->pdb->query("SELECT ct_detail  FROM tb_terms_and_condition WHERE ct_id = '".$ct_id."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail(){
        return $this->pdb->where('ct_id','1')->get("tb_terms_and_condition")->result()[0]->ct_detail;
    }
}

/* End of file tb_terms_and_condition.php */
/* Location: ./application/models/tb_terms_and_condition.php */