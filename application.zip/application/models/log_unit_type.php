<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_unit_type extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('log_unit_type', $array);
    }
}

/* End of file log_unit_type.php */
/* Location: ./application/models/log_unit_type.php */