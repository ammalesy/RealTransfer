<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_permission extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_permission', $array);
    }
    function update($array,$pm_id)
    {
      $this->load->database();
      $this->db->where('pm_id', $pm_id);
      $this->db->update('tb_permission', $array); 
    }
    function fetch_all_permission()
    {
    	$this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_permission 
                                   WHERE pm_sts_active ='on'");
  
        return $query->result();
    }
    function get_user_permission($user_id)
    { 
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_user ,tb_permission
                                   WHERE pm_id = user_permission 
                                   AND   user_id = '".$user_id."'");
        $row = $query->result();
        return $row[0];
    }
    function get_detail_permission($pm_id)
    { 
        $this->load->database();

        $query = $this->db->query("SELECT *
                                  FROM tb_permission 
                                  WHERE pm_sts_active = 'on' 
                                  AND pm_id = '".$pm_id."'");
        $row = $query->result();
        return $row[0];
    }
    function get_allDetail_permission($pm_id)
    { 
        $this->load->database();

        $query = $this->db->query("SELECT * 
                                  FROM tb_permission 
                                  WHERE pm_id = '".$pm_id."'");
        $row = $query->result();
        return $row[0];
    }
     
}

/* End of file tb_permission.php */
/* Location: ./application/models/tb_permission.php */