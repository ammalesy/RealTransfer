<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_user_authorize extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_user_authorize', $array);
    }
    function update($array,$user_id)
    {
      $this->load->database();
      $this->db->where('user_id', $user_id);
      $this->db->update('tb_user_authorize', $array); 
    }
    function get_info_by_user_id($user_id){
        $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_user_authorize
                                   WHERE user_id = '".$user_id."'");
        $row = $query->result();
        return $row[0];
    }
    function get_distinct_info_by_user_id($user_id){
        $this->load->database();
        $query = $this->db->query("SELECT distinct
                                   user_bookingfee,
                                   user_contactfee,
                                   user_installmentfee,
                                   user_remark
                                   FROM tb_user_authorize
                                   WHERE user_id = '".$user_id."'");
        $row = $query->result();
        return $row[0];
    }
}

/* End of file tb_user_authorize.php */
/* Location: ./application/models/tb_user_authorize.php */