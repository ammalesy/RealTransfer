<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_price extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
      parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_price', $array);
    }
    function update($array,$pr_id)
    {
      $this->pdb->where('pr_id', $pr_id);
      $this->pdb->update('tb_price', $array); 
    }
    function get_full_detail_by_pr_id($pr_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_price , tb_unit_number ,tb_building , tb_floor
                                 WHERE un_id = pr_unit_number_id 
                                 AND building_id = pr_building_id 
                                 AND pr_id  = '".$pr_id."'
                                 AND un_floor_id = fl_id");
                                 
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }

    function get_detail_withUnitNumberTable_by_un_name($un_name){

      $query = $this->pdb->query("SELECT *
                                  FROM tb_price 
                                  LEFT JOIN tb_unit_number ON (un_id=pr_unit_number_id) 
                                  WHERE TRIM(un_name) = '".trim($un_name)."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_buildingID_UnitNumberID($pr_building_id,$pr_unit_number_id){

      $query = $this->pdb->query("SELECT *
                               FROM tb_price 
                               WHERE pr_building_id = '".$pr_building_id."' 
                               AND pr_unit_number_id = '".$pr_unit_number_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_unit_id_and_building_id($pr_unit_number_id,$pr_building_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_price
                                 WHERE  pr_unit_number_id = '".$pr_unit_number_id."'
                                 AND pr_building_id = '".$pr_building_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_all_fullDetail(){
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_price , tb_building, tb_unit_number
                                 WHERE pr_building_id  = building_id 
                                 AND pr_unit_number_id = un_id 
                                 AND un_sts_active = 'on'");
      return $query->result();
    }
    
}

/* End of file tb_unit_number.php */
/* Location: ./application/models/tb_unit_number.php */