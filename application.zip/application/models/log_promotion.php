<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_promotion extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('log_promotion', $array);
    }
}

/* End of file log_promotion.php */
/* Location: ./application/models/log_promotion.php */