<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_survey_question extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
        $this->pdb->insert('tb_survey_question', $array);
    }
    function update($array, $id)
    {
        $this->pdb->where('sq_id', $id);
        $this->pdb->update('tb_survey_question', $array); 
    }
    function get_all()
    {
        return $this->pdb->get('tb_survey_question')->result();
    }
    function next_id()
    {
        return $this->pdb->select_max('sq_id')->get('tb_survey_question')->result()[0]->sq_id + 1;
    }
    function get_by_id($id)
    {
        return $this->pdb->where('sq_id',$id)->get('tb_survey_question')->result()[0];
    }
    function get_all_in_group($id)
    {
        return $this->pdb->where('sq_group',$id)->or_where('sq_group',0)->get('tb_survey_question')->result();
    }
    function get_detail_by_id($id)
    {
        $this->load->database();
      	$query = $this->pdb->query("	SELECT 
                                            sq_id AS id,
                                            sq_name AS nameTh,
                                            sq_name_en AS nameEn,
                                            sq_main_sub AS mainSub
                                        FROM tb_survey_question
                                        WHERE sq_id = '".$id."'");
      	$result = $query->result();
		if(count($result) > 0){
		return $result[0];
		}else{
		return NULL;
		}
    }
    function get_sub_ques_by_main_ques ($id) {
      $this->load->database();
      $query = $this->pdb->query("  SELECT 
                                        sq_id AS id,
                                        sq_name AS nameTh,
                                        sq_name_en AS nameEn
                                    FROM tb_survey_question
                                    WHERE sq_main_question = '$id'
                                    AND sq_active = 'Y'");
      $result = $query->result();
      return $result;
    }
    function get_all_main_question () {
      $this->load->database();
      $query = $this->pdb->query("  SELECT
                                    sq_id AS id,
                                    sq_name AS nameTh,
                                    sq_name_en AS nameEn 
                                    FROM tb_survey_question 
                                    WHERE sq_main_sub = 'M'
                                    AND sq_active = 'Y'");
      $result = $query->result();
      return $result;
    }
}
?>