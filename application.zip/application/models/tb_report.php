<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_report extends NZ_Model {
    function __construct()
    {
        parent::__construct();
    }
    function record($array)
    {
        $this->pdb->insert('tb_report', $array);
    }
    function update($array,$id)
    {
        $this->pdb->where('rp_id',$id)->update('tb_report', $array);
    }
    function get_all()
    {
        return $this->pdb->get('tb_report')->result();
    }
    function get_by_id($id)
    {
        return $this->pdb->where('rp_id',$id)->get('tb_report')->result()[0];
    }
    function query($obj)
    {
        $select = $obj->rp_select;
        $from   = $obj->rp_from;
        $where  = empty($obj->rp_where)?'':'WHERE '.$obj->rp_where;
        return $this->pdb->query("
            SELECT $select
            FROM $from
            $where
        ")->result();
    }
    function get_all_tables()
    {
        return $this->db->query("
            SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = '$this->project_database_sel'
        ")->result();
    }
}
?>