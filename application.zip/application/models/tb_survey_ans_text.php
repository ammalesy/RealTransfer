<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_survey_ans_text extends NZ_Model {

    function __construct ()
    {
        // Call the Model constructor
        parent::__construct ();
    }
    function record ($array)
    {
      $this->pdb->insert('tb_survey_ans_text', $array);
    }
    function update ($array, $id)
    {
        $this->pdb->where('sat_id', $id)->update('tb_survey_ans_text', $array); 
    }
    function check_cus_survey($ans, $cusID, $group) {
        $this->load->database();
        $query = $this->pdb->query("SELECT * FROM tb_survey_ans_text WHERE sat_cus_id = '$cusID'
                                    AND sat_sc_id = '$ans'
                                    AND sat_sg_id = '$group'");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }

}
?>