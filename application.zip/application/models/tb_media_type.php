<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_media_type extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_media_type', $array);
    }
    
    function fetch_all()
    {
    	  $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_media_type ORDER BY mt_id");
        return $query->result();
    }
    
    function get_media_type($mt_id)
    {
          $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_media_type where mt_id = '".$mt_id."'");
        return $query->result();
    }
}