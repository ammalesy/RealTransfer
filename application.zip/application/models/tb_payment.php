<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_payment  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_payment', $array);
    }
    function update($array, $pm_id)
    {
        $this->pdb->where('pm_id', $pm_id);
        $this->pdb->update('tb_payment', $array); 
    }
    function get_by_temp_code($code)
    {
        return $this->pdb->where('pm_temp_code',$code)->get('tb_payment')->result();
    }
    function get_payment_by_receipt_code($rcode)
    {
        $query = $this->pdb->query("SELECT *
                                  FROM  tb_payment
                                  LEFT JOIN ".$this->dbCommon.".tb_bank ON (b_id = pm_cr_bank)
                                  LEFT JOIN ".$this->dbCommon.".tb_credit_type ON (ct_id=pm_cr_type)
                                  WHERE pm_receipt_code = '$rcode'
                                  AND pm_status = 1");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_by_receipt_and_status($rcode,$status)
    {
        $query = $this->pdb->query("SELECT *
                                  FROM  tb_payment
                                  LEFT JOIN ".$this->dbCommon.".tb_bank ON (b_id = pm_cr_bank)
                                  LEFT JOIN ".$this->dbCommon.".tb_credit_type ON (ct_id=pm_cr_type)
                                  WHERE pm_receipt_code = '$rcode'
                                  AND pm_status = $status");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_by_temp_receipt($rcode)
    {
        $query = $this->pdb->query("SELECT *
                                  FROM  tb_payment
                                  LEFT JOIN ".$this->dbCommon.".tb_bank ON (b_id=pm_cr_bank)
                                  LEFT JOIN ".$this->dbCommon.".tb_credit_type ON (ct_id=pm_cr_type)
                                  WHERE pm_temp_code = '$rcode'
                                  AND pm_status = 1");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_by_temp_and_status($rcode,$status)
    {
        $query = $this->pdb->query("SELECT *
                                  FROM  tb_payment
                                  LEFT JOIN ".$this->dbCommon.".tb_bank ON (b_id=pm_cr_bank)
                                  LEFT JOIN ".$this->dbCommon.".tb_credit_type ON (ct_id=pm_cr_type)
                                  WHERE pm_temp_code = '$rcode'
                                  AND pm_status = $status");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_receipt_by_booking($bkcode) {
        $query = $this->pdb->query("
            SELECT * FROM tb_receipt_offical
            WHERE rc_booking_code = '$bkcode'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
}
?>