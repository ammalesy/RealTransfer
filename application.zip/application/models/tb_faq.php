<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_faq extends NZ_Model {
    function __construct()
    {
        parent::__construct();
    }
    
    function record($data)
    {
        $this->db->insert('tb_faq', $data);   
    }
    
    function all()
    {
        return $this->db->get('tb_faq')->result();   
    }
    
    function TRUNCATE()
    {
        $this->db->query('TRUNCATE tb_faq');   
    }
}
?>