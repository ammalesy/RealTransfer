<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_user_working_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('log_user_working_info', $array);
    }
}

/* End of file log_user_working_info.php */
/* Location: ./application/models/log_user_working_info.php */