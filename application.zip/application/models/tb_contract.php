<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_contract  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_contract', $array);
    }
    function update($array,$ct_booking_code)
    {
      $this->pdb->where('ct_booking_code', $ct_booking_code);
      $this->pdb->update('tb_contract', $array); 
    }
    function update_where_equal_ct_code($array,$ct_code)
    {
      $this->pdb->where('ct_code', $ct_code);
      $this->pdb->update('tb_contract', $array); 
    }
    /**/
    function fetch_all_by_bk_project_id($bk_project_id){
 
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_contract 
                                 INNER JOIN tb_booking 
                                 ON (ct_booking_code=bk_booking_code)
                                 WHERE ct_active = 'on'                         
                                 AND bk_project_id = '".$bk_project_id."' 
                                ORDER BY ct_code ASC");
      return $query->result();
    }
    /*
    * Provide For DashBoard Module
    */
    function get_detail_by_ct_booking_code($ct_booking_code){
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_contract 
                                 WHERE ct_booking_code = '".$ct_booking_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_ct_code($ct_code){

      $query = $this->pdb->query("SELECT * 
                                 FROM tb_contract 
                                 WHERE ct_code = '".$ct_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function fetch_all_notActive_by_ct_cus_id($ct_cus_id){

      $query = $this->pdb->query("SELECT * 
                                 FROM tb_contract 
                                 WHERE ct_cus_id = '".$ct_cus_id."' 
                                 AND  ct_active = 'cancelled'");
      return $query->result();
    }
    
    function fetch_all_by_ct_cus_idAndCt_project_id($ct_cus_id,$ct_project_id){

      $query = $this->pdb->query("SELECT *
                                  FROM tb_contract
                                  LEFT JOIN tb_letter_referred
                                  ON (ct_code=lt_ct_code)
                                  WHERE ct_cus_id ='{".$ct_cus_id."}'
                                  AND ct_active != 'cancel'
                                  AND ct_project_id ='".$ct_project_id."'");
       return $query->result();
    }
    function get_detail_by_ct_cus_id($ct_cus_id){

      $query = $this->pdb->query("SELECT distinct qt_code,un_name,ct_booking_code,ct_code 
                            FROM tb_contract 
                            INNER JOIN tb_booking ON (ct_booking_code=bk_booking_code)
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            LEFT JOIN tb_unit_number ON (un_id=  qt_unit_number_id)
                            WHERE ct_cus_id ='".$ct_cus_id."' 
                            AND ct_active='on'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_lastContract_customer(){

      $query = $this->pdb->query("SELECT ct_code,  ct_cus_id 
                                 FROM tb_contract , tb_booking  
                                 WHERE ct_booking_code = bk_booking_code  
                                 order by  ct_code desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function count_ct_code(){

       $query = $this->pdb->query("SELECT  COUNT(ct_code) as connumber 
                                  FROM tb_contract ");
       $result = $query->result();
       return $result[0]->connumber;
    }
    function get_new_contract_id($project_id_sel)
    {

        $query = $this->pdb->query("SELECT COUNT(ct_code) as newid
                                   FROM tb_contract 
                                   WHERE ct_project_id = '".$project_id_sel."'");
        $row = $query->result();
        $new_id = ($row[0]->newid + 1);
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    function getContractInfo_byContractCode($contractcode){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                FROM ".$this->project_database_sel.".tb_contract  , tb_customer , 
                                     tb_customer_personal_info, tb_project
                                WHERE pers_id = cus_pers_id 
                                AND ct_cus_id = cus_id
                                AND ct_booking_code ='".$contractcode."' 
                                AND  pj_id = ct_project_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_installment_detail_by_code($ct_code)
    {
        $query = $this->pdb->query("SELECT qt_unit_price, qt_avg_installment, qt_total_months, qt_total_down_payment,
                                    qt_installment1, qt_months_installment1,
                                    qt_installment2, qt_months_installment2,
                                    qt_installment3, qt_months_installment3,
                                    qt_installment4, qt_months_installment4,
                                    qt_installment5, qt_months_installment5,
                                    qt_buliding_id, qt_unit_number_id,
                                    ct_active
                                    FROM  tb_quotation  ,tb_booking, tb_contract
                                    WHERE ct_code = '$ct_code'
                                    AND bk_booking_code = ct_booking_code 
                                    AND qt_code = bk_quotation_code");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_unit_name_by_contract($ccode){

      $query = $this->pdb->query("SELECT distinct qt_code,un_name,ct_booking_code,ct_code, bk_booking_code, ct_cus_id, un_id
                            FROM tb_contract 
                            INNER JOIN tb_booking ON (ct_booking_code=bk_booking_code)
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            LEFT JOIN tb_unit_number ON (un_id=  qt_unit_number_id)
                            WHERE ct_code ='".$ccode."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_contract_by_unit_name($unit){
      $query = $this->pdb->query("SELECT *
                            FROM tb_contract 
                            INNER JOIN tb_booking ON (ct_booking_code=bk_booking_code)
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            LEFT JOIN tb_unit_number ON (un_id=  qt_unit_number_id)
                            WHERE un_name ='".$unit."'
                            AND ct_active != 'cancelled'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_contract_by_unit_id($unit){
      $query = $this->pdb->query("SELECT *
                            FROM tb_contract 
                            INNER JOIN tb_booking ON (ct_booking_code=bk_booking_code)
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            WHERE qt_unit_number_id = $unit
                            AND ct_active != 'cancelled';");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_contract_by_ct_code($ctCode){
      $query = $this->pdb->query("SELECT *
                            FROM tb_contract 
                            INNER JOIN tb_booking ON (ct_booking_code=bk_booking_code)
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            LEFT JOIN tb_unit_number ON (un_id=  qt_unit_number_id)
                            WHERE ct_code ='".$ctCode."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_min_contract_date(){
      $query = $this->pdb->query("SELECT MIN(ct_date) AS min_ct_date FROM tb_contract");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_sum_price_contract(){
      $query = $this->pdb->query("SELECT sum(rc_total_amount) Total_amount
                            FROM ".$this->project_database_sel.".tb_contract, ".$this->project_database_sel.".tb_receipt_offical 
                            where rc_booking_code = ct_booking_code 
                            AND rc_payfor = 'Contract Fee' 
                            AND rc_status = 'on'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_contract_by_date($start, $end) {
      	$query = $this->pdb->query("    SELECT * FROM tb_contract
                                        WHERE (ct_date BETWEEN  '".$start."' AND  '".$end."')
                                        AND ct_active != 'cancelled'");
      	return $query->result();
    }
    
    function get_contract_mapping($ct_id) {
        return $this->pdb->where('cm_crm_code', $ct_id)->get('tb_contract_mapping')->result()[0]->cm_rama9_code;
    }
    
    function get_count_con() {
        $query = $this->pdb->query("  SELECT count(*) countdate FROM tb_contract
                                      WHERE DATE_FORMAT(ct_temp_receipt_date,'%m-%d-%Y') = DATE_FORMAT(NOW(),'%m-%d-%Y')");
      $result = $query->result();
       return $result[0]->countdate;
    }
}

/* End of file tb_contract.php */
/* Location: ./application/models/tb_contract.php */