<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_regis_from_web extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function get_new_regis_id()
    {
        $this->load->database();
        $query = $this->db->query("SELECT Max(regis_id)+1 as MaxID from tb_regis_from_web");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    
    function record($array)
    {
      $this->db->insert('tb_regis_from_web', $array);
    }
    
    function fetch_regis_normal(){
      $this->load->database();
      $query = $this->db->query("SELECT * 
                                 FROM tb_regis_from_web
                                 WHERE regis_status != 'delete'
                                 ORDER BY regis_date DESC
                                ");
      return $query->result();
    }
    
    function update_regis($array,$regis_id)
    {
      $this->load->database();
      $this->db->where('regis_id', $regis_id);
      $this->db->update('tb_regis_from_web', $array); 
    }
}

/* End of file log_building.php */
/* Location: ./application/models/log_building.php */