<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_project extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('log_project', $array);
    }
}

/* End of file log_project.php */
/* Location: ./application/models/log_project.php */