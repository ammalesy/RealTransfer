<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_project extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_project', $array);
    }
    function update($array,$pj_id)
    {
      $this->pdb->where('pj_id', $pj_id);
      $this->pdb->update('tb_project', $array); 
    }
    function get_detail_project($pjid){
      $query = $this->pdb->query("SELECT * FROM tb_project 
                                 WHERE pj_active = 'on'  
                                 AND pj_id ='".$pjid."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_all_active_project()
    {
        $query = $this->pdb->query("SELECT *
                                   FROM tb_project 
                                   WHERE pj_active = 'on'");
  
        return $query->result();
    }
}

/* End of file tb_project.php */
/* Location: ./application/models/tb_project.php */