<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_unit_defect  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function fetch_all_defect_room($pj_id){
        $query = $this->db->query("
            SELECT * from $this->project_database_sel.tb_unit_defect JOIN $this->project_database_sel.tb_unit_number ON (un_id = df_un_id)
        ");
        return $query->result();
    }
    

}