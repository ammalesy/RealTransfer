<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_survey_answer extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array,$table)
    {
      $this->pdb->insert("$table", $array);

    }
    function update($array, $table, $cus)
    {
        $this->pdb->where('cus_id', $cus);
        $this->pdb->update(''.$table.'', $array); 
    }
    function get_all()
    {
        $this->load->database();
        $query = $this->pdb->query("SELECT * FROM tb_survey_group where sg_active = 'Y'");
        if (!$query->result()) {
            return null;
        } else {
            $table = $query->result();
        }

        $lastQuery = count($table);
        $num=0;
        foreach ($table as $_table) {
            if(($num+1) == $lastQuery){
                $sql .= "
                (
                select 
                    cus_id, 
                    sg.sg_id, 
                    sg_name, 
                    sg_name_en as nameEng,
                    timestamp, 
                    pers_prefix, 
                    pers_fname, 
                    pers_lname
                from $this->project_database_sel.$_table->sg_table_code s$_table->sg_id
                left JOIN $this->project_database_sel.tb_survey_group sg ON (s$_table->sg_id.sg_id = sg.sg_id)
                left JOIN tb_customer_personal_info ON (s$_table->sg_id.cus_id = pers_id_cus)
                )
                ";
            } else {
                $sql .= "
                (
                select 
                    cus_id, 
                    sg.sg_id, 
                    sg_name,
                    sg_name_en as nameEng,
                    timestamp, 
                    pers_prefix, 
                    pers_fname, 
                    pers_lname
                from $this->project_database_sel.$_table->sg_table_code s$_table->sg_id
                left JOIN $this->project_database_sel.tb_survey_group sg ON (s$_table->sg_id.sg_id = sg.sg_id)
                left JOIN tb_customer_personal_info ON (s$_table->sg_id.cus_id = pers_id_cus)
                )
                UNION ALL
                ";
            }
            $num++;
        }
        
        $query2 = $this->db->query($sql);
        $result = $query2->result();

        return $result;
    }
    function get_by_id($id)
    {
        return $this->pdb->where('sa_id', $id)->get('tb_survey_answer')->result()[0];
    }
    function check_cus($cus, $table)
    {
        $query = $this->pdb->query("
            select if(
                (
                    select id
                    from ".$table."
                    where cus_id = $cus
                ) is null,'false','true') as result
        ");
        if($query->result()[0]->result === 'true')
            return true;
        else
            return false;
    }
    
    function get_detail_by_date($group, $start, $end)
    {
        $this->load->database();
      	$query = $this->pdb->query("	SELECT * FROM tb_survey_answer
                                        WHERE (sa_timestamp BETWEEN  '".$start."' AND  '".$end."')
                                        AND sa_group = ".$group."");
      	return $query->result();
    }
    
    function get_min_date()
    {
        $this->load->database();
      	$query = $this->pdb->query("SELECT MIN(sa_timestamp) as minDate FROM tb_survey_answer");
      	$result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_count_answer_survey ($table, $quesID) {
        $this->load->database();
        $query = $this->pdb->query("    SELECT COUNT(`$quesID`) as count,sc_id, sc_name, sq_name FROM `tb_survey_choice`
                                        left JOIN $table ON FIND_IN_SET( sc_id, `$quesID`)
                                        INNER JOIN tb_survey_question ON (sc_question = sq_id)
                                        WHERE sc_question = $quesID
                                        AND sc_active = 'Y'
                                        GROUP BY sc_id");
        return $query->result();
    }
}
?>