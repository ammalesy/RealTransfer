<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_terms_and_condition extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('log_terms_and_condition', $array);
    }
}

/* End of file log_terms_and_condition.php */
/* Location: ./application/models/log_terms_and_condition.php */