<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_receipt_offical  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_receipt_offical', $array);
    }
    function update($array,$rc_receipt_id)
    {
      $this->pdb->where('rc_id', $rc_receipt_id);
      $this->pdb->update('tb_receipt_offical', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_receipt_offical', $array, $where);
    }
    function get_next_id() {
        $this->pdb->select_max('rc_id');
        $query = $this->pdb->get('tb_receipt_offical');
        return $query->result()[0]->rc_id + 1;
    }
    function fetch_full($project_id_sel){
        $this->load->database();
        $query = $this->db->query("
            SELECT rc_id,rc_code,rc_status,rc_payfor,rc_installment_time,rc_temp_code,pers_mobile,pers_tel,pers_email
            ,rc_customer_id,rc_total_amount,pers_fname,pers_lname,rc_confirm,bk_quotation_code
            FROM  $this->project_database_sel.tb_booking,
                  $this->project_database_sel.tb_receipt_offical,
                  tb_customer,
                  tb_customer_personal_info
            WHERE bk_leads_id = cus_id
            AND pers_id = cus_pers_id
            AND rc_booking_code = bk_booking_code
            AND bk_project_id = '".$project_id_sel."'
            ORDER BY rc_code DESC");//เพิ่มเพื่อแก้กระพริบ
      return $query->result();
    }
    function fetch_month($project_id_sel,$months){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM  $this->project_database_sel.tb_booking  ,
                  $this->project_database_sel.tb_receipt_offical , 
                  tb_customer ,
                  tb_customer_personal_info 
            WHERE bk_leads_id = cus_id 
            AND  pers_id = cus_pers_id 
            AND rc_booking_code = bk_booking_code
            AND  bk_project_id = '$project_id_sel'
            AND rc_time_stamp > DATE_ADD(NOW(),INTERVAL -$months MONTH)
            ORDER BY rc_code DESC
        ");//เพิ่มเพื่อแก้กระพริบ
        return $query->result();
    }
    function get_full_detail($rc_code){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM ".$this->project_database_sel.".tb_receipt_offical , tb_customer, tb_customer_personal_info 
            WHERE rc_customer_id = cus_id 
            AND  pers_id = cus_pers_id 
            AND rc_code ='".$rc_code."'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_full_detail_by_temp($rc_code){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM ".$this->project_database_sel.".tb_receipt_offical , tb_customer, tb_customer_personal_info 
            WHERE rc_customer_id = cus_id 
            AND  pers_id = cus_pers_id 
            AND rc_temp_code ='".$rc_code."'");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_by_booking($bkCode) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_offical
            WHERE rc_booking_code = '$bkCode'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_one_by($where)
    {
        return $this->pdb->get_where('tb_receipt_offical',$where)->result()[0];
    }
    function get_cancelled()
    {
        $query = $this->pdb->query("
            SELECT rc_id, rc_code, rc_total_amount, rc_status
            FROM tb_receipt_offical
            INNER JOIN tb_booking ON (bk_booking_code = rc_booking_code AND bk_status = 'cancelled')
            WHERE rc_status = 'on'
            ORDER BY rc_id DESC;");
        return $query->result();
    }
    function get_cancelled_all_status()
    {
        $query = $this->pdb->query("
            SELECT rc_id, rc_code, rc_total_amount, rc_status
            FROM tb_receipt_offical
            INNER JOIN tb_booking ON (bk_booking_code = rc_booking_code AND bk_status = 'cancelled')
            ORDER BY rc_id DESC;");
        return $query->result();
    }
    function get_by_ids($ids)
    {
//        return $this->pdb->where_in('rc_id', $ids)->get('tb_receipt_offical')->result();
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_offical
            WHERE rc_id in ($ids)
        ");
        return $query->result();
    }
    
    function get_details_income_by_date_and_cus_id($cusid, $start, $end)
    {
        $this->load->database();
      	$query = $this->pdb->query("	SELECT * FROM tb_receipt_offical
									WHERE (rc_official_date BETWEEN  '".$start."' AND '".$end."')
                                    AND rc_customer_id = ".$cusid."");
      	return $query->result();
    }
    
    function get_distinct_cus_by_date($start, $end)
    {
        $this->load->database();
      	$query = $this->pdb->query("    SELECT * FROM tb_receipt_offical 
                                        WHERE rc_customer_id IN 
                                            (   SELECT DISTINCT rc_customer_id FROM tb_receipt_offical
                                                WHERE (rc_official_date BETWEEN  '".$start."'  AND '".$end."')
                                            )
                                        AND rc_official_date BETWEEN  '".$start."'  AND '".$end."' ");
      	return $query->result();
    }
    
    function get_receipt_for_charge($start, $end, $cusID, $unID)
    {
        $this->load->database();
      	$query = $this->pdb->query(" SELECT * FROM tb_receipt_offical
                                     WHERE (rc_official_date BETWEEN  '".$start."' AND '".$end."')
                                     ".$cusID."
                                     ".$unID."");
      	return $query->result();
    }
    
    function get_distinct_un_name_for_income($start, $end, $cusID, $unID)
    {
        $this->load->database();
      	$query = $this->pdb->query(" SELECT DISTINCT rc_un_name FROM tb_receipt_offical, tb_unit_number
                                     WHERE (rc_official_date BETWEEN  '".$start."' AND '".$end."')
                                     ".$cusID."
                                     ".$unID."");
      	return $query->result();
    }
      
    function get_detail_by_un_name($unName)
    {
        $this->load->database();
      	$query = $this->pdb->query(" SELECT * FROM tb_receipt_offical
                                     WHERE rc_un_name = ".$unName."");
      	return $query->result();
    }
    function get_detail_booking($rc_id)
    {
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM ".$this->project_database_sel.".tb_receipt_offical , ".$this->project_database_sel.".tb_booking , 
            tb_customer, tb_customer_personal_info
            WHERE rc_id = '$rc_id' 
            AND  rc_customer_id = cus_id  
            AND cus_pers_id =  pers_id 
            AND rc_booking_code = bk_booking_code
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_detail_im_code_and_im_time($imCode, $imTime){
      $this->load->database();
      $query = $this->pdb->query("  SELECT * 
                                    FROM tb_receipt_offical
                                    WHERE rc_installment_code = '".$imCode."'
                                    AND rc_installment_time = ".$imTime."");

      $result = $query->result();
      if(count($result) > 0){
        return $result;
      }else{
        return NULL;
      }
        
    } 
    
    function get_detail_status_on_by_un_name($unName)
    {
        $this->load->database();
      	$query = $this->pdb->query(" SELECT * FROM tb_receipt_offical
                                     WHERE rc_un_name = ".$unName."
                                     AND rc_status = 'on'");
      	return $query->result();
    }
    
    function get_by_id($rc_id)
    {
        return $this->pdb->where('rc_id',$rc_id)->get('tb_receipt_offical')->result()[0];
    }
}
?>