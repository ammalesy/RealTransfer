<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_nationality extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_nationality', $array);
    }
    function fetch_all_nationality(){
      $this->load->database();
      $query = $this->db->query("SELECT nt_id,  nt_nationality 
                                 FROM tb_nationality");
      return $query->result();
    }
    function get_nationality_by_id($id){
        $this->load->database();
        $this->db->where('nt_id', $id);
        $query = $this->db->get('tb_nationality');
        $result = $query->result();
        return $result[0];
    }
}

/* End of file tb_nationality.php */
/* Location: ./application/models/tb_nationality.php */