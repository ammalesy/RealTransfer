<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_survey_choice extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_survey_choice', $array);
    }
    function update($array, $id)
    {
        $this->pdb->where('sc_id', $id)->update('tb_survey_choice', $array); 
    }
    function get_all()
    {
        return $this->pdb->get('tb_survey_choice')->result();
    }
    function get_by_question($ids)
    {
        return $this->pdb->where('sc_question',$ids)->get('tb_survey_choice')->result();
    }
    
    function get_detail_by_id($id){
        $this->load->database();
      	$query = $this->pdb->query("	SELECT * FROM tb_survey_choice
                                        WHERE sc_id = ".$id."");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_detail_by_question_id($id){
        $this->load->database();
      	$query = $this->pdb->query("	SELECT * FROM tb_survey_choice
                                        WHERE sc_question = ".$id."");
      	return $query->result();
    }
    function get_choice_survey ($sqID) {
        $this->load->database();
        $query = $this->pdb->query("    select 
                                            sc_id as id, 
                                            sc_name as nameTh,
                                            sc_name_en as nameEn,
                                            sc_type as type 
                                        from `tb_survey_choice` 
                                        where `sc_question` = '".$sqID."'
                                        and sc_active = 'Y'");
        return $query->result();
    }
    function get_answer_by_question_id ($groupID, $column, $cus_id) {
        $table = "survey$groupID";
        $this->load->database();
        $query = $this->pdb->query("  select `$column` as ans from $table where cus_id = '$cus_id' ");
        $result = $query->result();

        $query = $this->pdb->query("select 
                                        sc_name,
                                        sc_name_en as nameEng,
                                        sc_type, 
                                        sc_id 
                                    from `tb_survey_choice`
                                    where FIND_IN_SET( sc_id,'".$result[0]->ans."')  ");
        $result1 = $query->result();
        
        if ($result1 != null) {
            $lastQuery = count($result1);
            $num = 0;
            foreach ($result1 as $_result1) {
                // echo "$groupID /// $cus_id /// $_result1->sc_id ///////////";
                if ($_result1->sc_type == 'checkboxtextbox' || $_result1->sc_type == 'radiotextbox') {
                    $query = $this->pdb->query("    SELECT sat_text FROM tb_survey_ans_text 
                                                    WHERE sat_sg_id = '$groupID'
                                                    AND sat_cus_id = '$cus_id'
                                                    AND sat_sc_id = '$_result1->sc_id' ");
                    $result2 = $query->result();

                    
                    if (($num+1) == $lastQuery) {
                        $answer .= "".(($this->language === 'TH')?$_result1->sc_name:$_result1->nameEng)." ( ".$result2[0]->sat_text." )";
                    } else {
                        $answer .= "".(($this->language === 'TH')?$_result1->sc_name:$_result1->nameEng)." ( ".$result2[0]->sat_text." ), ";
                    }
                } else {
                    if (($num+1) == $lastQuery) {
                        $answer .= ($this->language === 'TH')?$_result1->sc_name:$_result1->nameEng;
                    } else {
                        $answer .= ($this->language === 'TH')?$_result1->sc_name.', ':$_result1->nameEng.', ';
                    }
                }
                
                $num++;
            }
        } else {
            $answer = 'N/A';
        }
        // exit();
        return $answer;
    }
}
?>