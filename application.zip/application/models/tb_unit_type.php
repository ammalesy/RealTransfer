<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_unit_type extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_unit_type', $array);
      return $this->pdb->insert_id();
    }
    function update($array,$unit_type_id)
    {
      $this->pdb->where('unit_type_id', $unit_type_id);
      $this->pdb->update('tb_unit_type', $array); 
    }
    function fetch_all_with_TbRoomType(){
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_unit_type, ".$this->dbCommon.".tb_room_type 
                                 WHERE  unit_type_room_type_id = room_type_id 
                                 AND unit_type_sts_active = 'on'");
      return $query->result();
    }
    function fetch_all_by_unit_type_room_type_id($unit_type_room_type_id){
      $query = $this->pdb->query("SELECT * 
                                  FROM tb_unit_type
                                  WHERE unit_type_room_type_id='".$unit_type_room_type_id."'");
      return $query->result();
    }
    function fetch_all(){
      $query = $this->pdb->query("SELECT * 
                                  FROM tb_unit_type
                                  ");
      return $query->result();
    }
    function get_detail_with_unit_type_name($unit_type_name){
      $query = $this->pdb->query("SELECT * 
                                 FROM tb_unit_type 
                                 WHERE unit_type_sts_active = 'on' 
                                 AND unit_type_name = '".trim($unit_type_name)."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
//          $query = $this->pdb->query("SELECT unit_type_name, un_name,  unit_type_area_sqm,  un_direction, room_type_name,room_type_id, un_status_room

    function get_detail_by_unit_type_id($unit_type_id){
      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_type 
                                 WHERE unit_type_sts_active = 'on' 
                                 AND unit_type_id ='".$unit_type_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_withTbRoomType_by_unit_type_id($unit_type_id){
      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_type , ".$this->dbCommon.".`tb_room_type` 
                                 WHERE  unit_type_room_type_id = room_type_id 
                                 AND unit_type_sts_active = 'on' 
                                 AND unit_type_id ='".$unit_type_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    
    function get_sqm_distinct() {
      	$query = $this->pdb->query("    SELECT DISTINCT(unit_type_area_sqm) FROM tb_unit_type");
      	return $query->result();
    }
}

/* End of file tb_unit_type.php */
/* Location: ./application/models/tb_unit_type.php */
