<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_update_promotion extends NZ_Model {
  
    function __construct()
    {
        parent::__construct();
    }

    function record($array)
    {
      $this->pdb->insert('tb_update_promotion', $array);
    }

    function update($array, $cp_id)
    {
      $this->pdb->where('up_id', $cp_id);
      $this->pdb->update('tb_update_promotion', $array);
    }

    function get_detail_by_bk_code($bk_code)
    {
      $this->pdb->where('up_booking_code', $bk_code);
      $query = $this->pdb->get('tb_update_promotion');
      return $query->result();
    }
    
    function getAllDetail()
    {
        return $this->pdb->query("
            SELECT *
            FROM tb_update_promotion
            INNER JOIN $this->dbCommon.tb_user_personal_info ON (user_pers_user_id = up_staff_id)
            INNER JOIN tb_booking ON (bk_booking_code = up_booking_code)
            INNER JOIN tb_quotation ON (qt_code = bk_quotation_code)
            INNER JOIN tb_unit_number ON (un_id = qt_unit_number_id)
            INNER JOIN tb_building ON (building_id = un_build_id)
            INNER JOIN $this->dbCommon.tb_customer_personal_info ON (pers_id_cus = bk_leads_id)
        ")->result();
    }
}
?>