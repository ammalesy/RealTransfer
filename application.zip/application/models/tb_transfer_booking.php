<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_transfer_booking extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_transfer_booking', $array);
    }
    function fetch_all_letter_transfer_booking(){
      $query = $this->pdb->query("SELECT *
                                 FROM tb_transfer_booking");
      return $query->result();
    }
    function fetch_all_by_tf_project_id($tf_project_id){
      $query = $this->pdb->query("SELECT *
                                 FROM tb_transfer_booking
                                  WHERE tf_project_id = '".$tf_project_id."'");
      return $query->result();
    }
    function get_detail_by_tf_code($tf_code){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_transfer_booking 
                                 WHERE tf_code = '".$tf_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
}

/* End of file tb_transfer_booking.php */
/* Location: ./application/models/tb_transfer_booking.php */