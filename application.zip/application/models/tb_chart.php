<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_chart extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function get_count_lead_by_date_report($start, $end, $projectID)
    {
    	$this->load->database();
      	$query = $this->db->query("	SELECT COUNT(cus_id) AS count_cus FROM tb_customer
									WHERE (cus_created_date BETWEEN  '".$start."' AND  '".$end."')");
//        echo($this->db->last_query());
      	$result = $query->result();
		if(count($result) > 0){
		  return $result[0];
		}else{
		  return NULL;
		}
    }
    
    function get_detail_lead_by_date_report($start, $end)
    {
    	$this->load->database();
      	$query = $this->pdb->query("	SELECT DISTINCT qt_leads_id , qt_date
                                        FROM tb_quotation
                                        WHERE (qt_date BETWEEN  '".$start."' AND  '".$end."')
                                        GROUP BY qt_leads_id");
      	return $query->result();
    }

    function get_count_customer_by_date_report($start, $end)
    {
    	$this->load->database();
      	$query = $this->db->query("	SELECT COUNT(cus_id) AS count_cus FROM tb_customer
									WHERE (cus_customer_date BETWEEN  '".$start."' AND  '".$end."')");
      	$result = $query->result();
		if(count($result) > 0){
		return $result[0];
		}else{
		return NULL;
		}
    }

    function get_detail_customer_by_date_report($start, $end)
    {
    	$this->load->database();
      	$query = $this->pdb->query("	SELECT DISTINCT bk_leads_id , bk_date_booking, pers_dob
                                        FROM tb_booking
                                        INNER JOIN condo_common.tb_customer_personal_info ON (bk_leads_id = pers_id)
                                        WHERE (bk_date_booking BETWEEN  '".$start."' AND  '".$end."')
                                        GROUP BY bk_leads_id");
      	return $query->result();
    }

    function get_count_quotation_by_date_report($start, $end)
    {
    	$this->load->database();
      	$query = $this->pdb->query("	SELECT COUNT(qt_code) AS count_cus FROM tb_quotation
										WHERE (qt_date BETWEEN  '".$start."' AND  '".$end."')");
      	$result = $query->result();

  		if(count($result) > 0){
  		    return $result[0];
  		}else{
  		    return NULL;
  		}
    }

    function get_count_booking_by_date_report($start, $end)
    {
    	$this->load->database();
      	$query = $this->pdb->query("	SELECT COUNT(bk_booking_code) AS count_cus FROM tb_booking
										WHERE (bk_date_booking BETWEEN  '".$start."' AND  '".$end."')");
      	$result = $query->result();
		if(count($result) > 0){
		return $result[0];
		}else{
		return NULL;
		}
    }

    function get_count_contract_by_date_report($start, $end)
    {
    	$this->load->database();
      	$query = $this->pdb->query("	SELECT COUNT(ct_code) AS count_cus FROM tb_contract
										WHERE (ct_date BETWEEN  '".$start."' AND  '".$end."')");
      	$result = $query->result();
		if(count($result) > 0){
		return $result[0];
		}else{
		return NULL;
		}
    }

    function get_rooms_income_report()
    {
      $this->load->database();
        $query = $this->pdb->query("   SELECT distinct rc_un_name FROM tb_receipt_offical
                                       WHERE rc_confirm = 'yes'
                                       ORDER BY rc_un_name ASC");
        return $query->result();
    }

    function get_details_income_report($room)
    {
    	$this->load->database();
      	$query = $this->pdb->query("    SELECT distinct * FROM tb_receipt_offical
                                        WHERE rc_un_name = '".$room."'");
      	return $query->result();
    }

    function get_total_price_by_date_report($start, $end)
    {
      $this->load->database();
        $query = $this->pdb->query("  SELECT SUM(rc_total_amount) AS count_cus FROM tb_receipt_offical
                                      WHERE rc_confirm = 'yes'
                                      AND (rc_official_date BETWEEN  '".$start."' AND  '".$end."')");
        $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }

    function get_count_receipt_by_date_report($start, $end)
    {
      $this->load->database();
        $query = $this->pdb->query("  SELECT COUNT(rc_code) AS count_cus FROM tb_receipt_offical
                                      WHERE (rc_official_date BETWEEN  '".$start."' AND  '".$end."')");
        $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_detail_sold_by_date($start, $end)
    {
        $this->load->database();
      	$query = $this->pdb->query("	SELECT * FROM tb_contract, tb_booking, tb_quotation, tb_unit_number, tb_unit_type, tb_price
                                        WHERE ct_paid = 'yes'
                                        AND ct_active = 'on'
                                        AND (ct_date BETWEEN  '".$start."' AND '".$end."')
                                        AND ct_booking_code = bk_booking_code
                                        AND bk_quotation_code = qt_code
                                        AND qt_unit_number_id = un_id
                                        AND un_unit_type_id = unit_type_id
                                        AND un_id = pr_unit_number_id");
      	return $query->result();
    }
    
    function get_count_sold_by_date($start, $end)
    {
      $this->load->database();
        $query = $this->pdb->query("  SELECT COUNT(ct_id) AS count_unit_month FROM tb_contract
                                      WHERE (ct_date BETWEEN  '".$start."' AND  '".$end."')
                                      AND ct_paid = 'yes'
                                      AND ct_active = 'on'");
        $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_count_cus_type_by_date($start, $end, $id)
    {
        $this->load->database();
        $query = $this->db->query("  SELECT COUNT(cus_id) AS count_visit_type FROM tb_customer
                                      WHERE (cus_customer_date BETWEEN  '".$start."' AND  '".$end."')
                                      AND cus_visit_type = '".$id."'");
        $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_count_booking_by_date($start, $end)
    {
        $this->load->database();
        $query = $this->pdb->query("  SELECT COUNT(bk_booking_id) AS count_booking FROM tb_booking
                                      WHERE (bk_date_booking BETWEEN  '".$start."' AND  '".$end."')
                                      AND bk_status != 'cancelled'");
        $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_count_cancel_by_date($start, $end)
    {
        $this->load->database();
        $query = $this->pdb->query("  SELECT COUNT(cc_id) AS count_cancel FROM tb_cancelation
                                      WHERE (cc_timestamp BETWEEN  '".$start."' AND  '".$end."')");
        $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_list_booking($start,$end)
    {
        $this->load->database();
        $query = $this->db->query("  select bk_leads_id,
                                      date_format(bk_date_booking,'%d/%m/%Y') booking_date,
                                      CONCAT(building_name,un_name) room, bk_booking_code,
                                      CONCAT('คุณ',pers_fname,'  ',pers_lname) cus_name, pers_mobile, work_position,
                                      CONCAT(addr_cur_address,' ',addr_cur_sub_district,' ',addr_cur_district,' ',addr_cur_province,' ',addr_cur_post_code) cus_addr,
                                      CONCAT(work_house_no,' ',work_road,' ',work_sub,' ',work_district,' ',work_province,' ',work_post_code) work_addr,
                                      'รายได้/เดือน', unit_type_area_sqm room_area, qt_unit_price unit_price,
                                      CONCAT(user_pers_fname,' ',user_pers_lname) staff, bk_remark 
                                      from ".$this->project_database_sel.".tb_booking, 
                                      tb_customer_address_current_info, tb_customer_working_info,
                                      tb_customer_personal_info, ".$this->project_database_sel.".tb_quotation,
                                      ".$this->project_database_sel.".tb_unit_number,
                                      ".$this->project_database_sel.".tb_unit_type,
                                      tb_user_personal_info, ".$this->project_database_sel.".tb_building 
                                      where bk_status != 'cancelled' 
                                      and (bk_date_booking BETWEEN  '".$start."' AND  '".$end."')
                                      and bk_leads_id = addr_cur_id
                                      and bk_leads_id = work_id and bk_leads_id = pers_id
                                      and bk_quotation_code = qt_code and qt_unit_number_id = un_id
                                      and un_unit_type_id = unit_type_id and bk_staff_id = user_pers_id 
                                      and qt_buliding_id = building_id
                                      order by date_format(bk_date_booking,'%Y/%m/%d') DESC
                                    ");
        return $query->result();
      }
    
    function get_price_contract_by_date($start, $end) {
      	$query = $this->pdb->query("    SELECT pr_asking_price FROM tb_contract
                                        LEFT JOIN tb_booking ON (ct_booking_code = bk_booking_code)   
                                        LEFT JOIN tb_quotation ON (bk_quotation_code = qt_code)    
                                        LEFT JOIN tb_price ON (qt_unit_number_id = pr_unit_number_id)
                                        WHERE (ct_date BETWEEN  '".$start."' AND  '".$end."')
                                        AND ct_active != 'cancelled'");
      	return $query->result();
    }
    
    function get_sqm_contract_by_date($start, $end) {
      	$query = $this->pdb->query("    SELECT unit_type_area_sqm FROM tb_contract
                                        LEFT JOIN tb_booking ON (ct_booking_code = bk_booking_code)   
                                        LEFT JOIN tb_quotation ON (bk_quotation_code = qt_code)    
                                        LEFT JOIN tb_unit_number ON (qt_unit_number_id = un_id)
                                        LEFT JOIN tb_unit_type ON (un_unit_type_id = unit_type_id)
                                        WHERE (ct_date BETWEEN  '".$start."' AND  '".$end."')
                                        AND ct_active != 'cancelled'");
      	return $query->result();
    }
    
    function get_value_contract_promotion() {
      	$query = $this->pdb->query("    SELECT pm_value FROM tb_contract_promotion
                                        LEFT JOIN tb_promotion ON (cp_promotion_id = pm_id)");
      	return $query->result();
    }
    
    function get_detail_for_chart_report ($start, $end, $cusID, $unID) {
        $query = $this->pdb->query ("   SELECT * FROM tb_receipt_offical LEFT JOIN condo_common.tb_customer_personal_info ON (pers_id = rc_customer_id)
                                        LEFT JOIN tb_unit_number ON (rc_un_name = un_name)
                                        LEFT JOIN tb_building ON (un_build_id = building_id)
                                        RIGHT JOIN tb_payment ON (rc_code = pm_receipt_code)
                                        WHERE pm_id IN (SELECT pm_id FROM tb_payment WHERE pm_status = 1 ORDER BY pm_id)
                                        AND (rc_official_date BETWEEN  '".$start."' AND '".$end."')
                                        ".$cusID."
                                        ".$unID."
                                        ORDER BY pm_id");
        return $query->result();
    }
    function getCountVisitByDate($start, $end, $visit,$typeQuery)
    {
        $this->load->database();
        $query = $this->db->query(" SELECT COUNT(DISTINCT(qt_leads_id)) AS visit
                                    FROM ".$this->project_database_sel.".tb_quotation
                                    INNER JOIN tb_customer ON(qt_leads_id = cus_id)
                                    WHERE (qt_date BETWEEN  '".$start."' AND '".$end."')
                                    AND cus_visit_type = '".$visit."'
                                    AND cus_flag = '".$typeQuery."'
                                    GROUP BY DATE(qt_date)");
        return $query->result();
    }
    function getCountBudgetByDate($start, $end, $budget,$typeQuery)
    {
        $this->load->database();
        $query = $this->db->query(" SELECT COUNT(DISTINCT(qt_leads_id)) AS budget
                                    FROM ".$this->project_database_sel.".tb_quotation
                                    INNER JOIN tb_customer ON(qt_leads_id = cus_id)
                                    WHERE (qt_date BETWEEN  '".$start."' AND '".$end."')
                                    AND cus_budget = '".$budget."'
                                    AND cus_flag = '".$typeQuery."'
                                    GROUP BY DATE(qt_date)");
//        print_r ($this->db->last_query());exit();
        return $query->result();
    }
    function getCountSexByDate($start, $end, $sex, $type) {
        $this->load->database();
        if ($type == 'lead') {
            $query = $this->db->query(" SELECT COUNT(DISTINCT(qt_leads_id)) as sex , qt_date
                                        FROM ".$this->project_database_sel.".tb_quotation
                                        INNER JOIN tb_customer_personal_info ON(qt_leads_id = pers_id)
                                        WHERE (qt_date BETWEEN  '".$start."' AND '".$end."')
                                        AND pers_sex = '".$sex."'
                                        GROUP BY DATE(qt_date)");
        } else if ($type == 'customer') {
            $query = $this->db->query(" SELECT COUNT(DISTINCT(bk_leads_id)) as sex , bk_date_booking
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_personal_info ON(bk_leads_id = pers_id)
                                        WHERE (bk_date_booking BETWEEN  '".$start."' AND '".$end."')
                                        AND pers_sex = '".$sex."'
                                        GROUP BY DATE(bk_date_booking)");
        }
        
        return $query->result();
    }
    function getCountStageByDate($start, $end, $stage)
    {
        $this->load->database();
        $query = $this->db->query(" SELECT COUNT(DISTINCT(qt_leads_id)) AS stages, qt_date
                                    FROM ".$this->project_database_sel.".tb_quotation
                                    INNER JOIN tb_customer ON(qt_leads_id = cus_id)
                                    WHERE (qt_date BETWEEN  '".$start."' AND '".$end."')
                                    AND cus_stages_id = '".$stage."'
                                    GROUP BY DATE(qt_date)");
        return $query->result();
    }
    function getTopTenAddressByDate($start, $end, $type) {
        $this->load->database();
        if ($type == 'district') {
            $query = $this->db->query(" SELECT addr_cur_district as district, COUNT(addr_cur_id) AS count_district FROM condo_common.tb_customer_address_current_info
                                        INNER JOIN (

                                        SELECT addr_cur_id AS addr
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_address_current_info ON(bk_leads_id = addr_cur_id)
                                        WHERE (bk_date_booking BETWEEN '".$start."' AND '".$end."')
                                        AND addr_cur_district != ''
                                        GROUP BY DATE(bk_date_booking)/*,addr_cur_district*/,bk_leads_id
                                        ) t ON t.addr = addr_cur_id
                                        GROUP BY addr_cur_district
                                        ORDER BY count_district DESC LIMIT 0,10");
        } else if ($type == 'subDistrict') {
            $query = $this->db->query(" SELECT addr_cur_sub_district as sub_district, COUNT(addr_cur_id) AS count_sub_district FROM condo_common.tb_customer_address_current_info
                                        INNER JOIN (

                                        SELECT addr_cur_id AS addr
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_address_current_info ON(bk_leads_id = addr_cur_id)
                                        WHERE (bk_date_booking BETWEEN '".$start."' AND '".$end."')
                                        AND addr_cur_sub_district != ''
                                        GROUP BY DATE(bk_date_booking)/*,addr_cur_sub_district*/,bk_leads_id
                                        ) t ON t.addr = addr_cur_id
                                        GROUP BY addr_cur_sub_district
                                        ORDER BY count_sub_district DESC LIMIT 0,10");
        } else if ($type == 'province') {
            $query = $this->db->query(" SELECT addr_cur_province as province, COUNT(addr_cur_id) AS count_province FROM condo_common.tb_customer_address_current_info
                                        INNER JOIN (

                                        SELECT addr_cur_id AS addr
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_address_current_info ON(bk_leads_id = addr_cur_id)
                                        WHERE (bk_date_booking BETWEEN '".$start."' AND '".$end."')
                                        AND addr_cur_province != ''
                                        GROUP BY DATE(bk_date_booking)/*,addr_cur_province*/,bk_leads_id
                                        ) t ON t.addr = addr_cur_id
                                        GROUP BY addr_cur_province
                                        ORDER BY count_province DESC LIMIT 0,10");
        } else if ($type == 'districtWork') {
            $query = $this->db->query(" SELECT work_district as district, COUNT(work_id) AS count_district FROM condo_common.tb_customer_working_info
                                        INNER JOIN (

                                        SELECT work_id AS addr
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_working_info ON(bk_leads_id = work_id)
                                        WHERE (bk_date_booking BETWEEN '".$start."' AND '".$end."')
                                        AND work_district != ''
                                        GROUP BY DATE(bk_date_booking)/*,addr_cur_district*/,bk_leads_id
                                        ) t ON t.addr = work_id
                                        GROUP BY work_district
                                        ORDER BY count_district DESC LIMIT 0,10");
            
        } else if ($type == 'subDistrictWork') {
            $query = $this->db->query(" SELECT work_sub as sub_district, COUNT(work_id) AS count_sub_district FROM condo_common.tb_customer_working_info
                                        INNER JOIN (

                                        SELECT work_id AS addr
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_working_info ON(bk_leads_id = work_id)
                                        WHERE (bk_date_booking BETWEEN '".$start."' AND '".$end."')
                                        AND work_sub != ''
                                        GROUP BY DATE(bk_date_booking)/*,addr_cur_sub_district*/,bk_leads_id
                                        ) t ON t.addr = work_id
                                        GROUP BY work_sub
                                        ORDER BY count_sub_district DESC LIMIT 0,10");
        } else if ($type == 'provinceWork') {
            $query = $this->db->query(" SELECT work_province as province, COUNT(work_id) AS count_province FROM condo_common.tb_customer_working_info
                                        INNER JOIN (

                                        SELECT work_id AS addr
                                        FROM ".$this->project_database_sel.".tb_booking
                                        INNER JOIN tb_customer_working_info ON(bk_leads_id = work_id)
                                        WHERE (bk_date_booking BETWEEN '".$start."' AND '".$end."')
                                        AND work_province != ''
                                        GROUP BY DATE(bk_date_booking)/*,addr_cur_province*/,bk_leads_id
                                        ) t ON t.addr = work_id
                                        GROUP BY work_province
                                        ORDER BY count_province DESC LIMIT 0,10");
        }
        
//        echo($this->db->last_query());
        return $query->result();
    }
    function getTopTenPromotionQuoByDate($start, $end) {
        $this->load->database();
        $query = $this->pdb->query(" SELECT pm_name, COUNT(pm_id) AS count_promotion
                                    FROM tb_promotion
                                    INNER JOIN tb_quotation ON FIND_IN_SET( pm_id, qt_promotion)
                                    WHERE (qt_date BETWEEN  '".$start."' AND  '".$end."')
                                    GROUP BY pm_id
                                    ORDER BY count_promotion DESC LIMIT 0,5");
        return $query->result();
    }
    function getTopTenUnitQuoByDate($start, $end) {
        $this->load->database();
        $query = $this->pdb->query(" SELECT CONCAT(building_name,un_name) AS unit, COUNT(qt_unit_number_id) AS count_unit
                                    FROM tb_quotation
                                    LEFT JOIN tb_unit_number ON (un_id = qt_unit_number_id)
                                    LEFT JOIN tb_building ON (building_id = qt_buliding_id)
                                    WHERE (qt_date BETWEEN  '".$start."' AND  '".$end."')
                                    GROUP BY qt_unit_number_id
                                    ORDER BY count_unit DESC LIMIT 0,5");
        return $query->result();
    }
    function getTopFiveQoutByDate($start, $end) {
        $this->load->database();
        $query = $this->db->query(" SELECT COUNT(qt_sale_id) countQout, CONCAT(user_pers_fname, ' ', user_pers_lname) employee
                                    FROM ".$this->project_database_sel.".tb_quotation,tb_user, tb_user_personal_info
                                    WHERE qt_date BETWEEN  '".$start."' AND  '".$end."'
                                    AND qt_sale_id = user_pers_id_ref
                                    AND user_pers_id_ref = user_pers_id
                                    GROUP BY qt_sale_id
                                    ORDER BY COUNT(qt_sale_id) DESC LIMIT 0,5");
        return $query->result();
    }
    function getCountMediaByDate($id,$typeQuery) {
        $this->load->database();
        $query = $this->db->query("     SELECT mt_name ,COUNT(mt_id) AS count_media
                                        FROM tb_customer
                                        LEFT JOIN tb_media_type ON FIND_IN_SET( mt_id, cus_media_type)
                                        WHERE cus_id='".$id."'
                                        AND cus_flag = '".$typeQuery."'
                                        GROUP BY mt_id");
        return $query->result();
    }
    function getMinDate($type) {
        if($type === 'lead' || $type === 'quotation') {
            $fieldName = 'qt_date';
            $tableName = 'tb_quotation';
        } else if ($type === 'customer' || $type === 'booking') {
            $fieldName = 'bk_date_booking';
            $tableName = 'tb_booking';
        } else if ($type === 'contract') {
            $fieldName = 'ct_date';
            $tableName = 'tb_contract';
        } else if ($type === 'receipt') {
            $fieldName = 'rc_official_date';
            $tableName = 'tb_receipt_offical';
        }
        
        $this->load->database();
        $this->pdb->select_min($fieldName, 'min_date');
        $query = $this->pdb->get($tableName);
        $result = $query->result();
        if(count($result) > 0) {
            return $result[0];
        } else {
            return NULL;
        }
    }
    function test ($value) {
      $this->load->database();
      $query = $this->pdb->query("  SELECT * FROM `tb_receipt_offical`
                                    limit ".$value." ,100");
      
      return $query->result();
    }
    function test10 () {
      $this->load->database();
      $query = $this->pdb->query("  SELECT COUNT(rc_id) as hello FROM `tb_receipt_offical`");
      $result = $query->result();
      if(count($result) > 0) {
        return $result[0];
      } else {
        return NULL;
      }
    }

    function get_details_drIncome ($cusID, $date) {
      $this->load->database();
      $query = $this->db->query("  SELECT `rc_payfor`,`rc_installment_time`,`rc_total_amount`,`rc_un_name`,`pers_prefix`,`pers_fname`,`pers_lname`,`building_name`,`qt_unit_price`,`qt_total_months`,`qt_total_down_payment` 
                                    FROM ".$this->project_database_sel.".tb_receipt_offical 
                                    INNER JOIN ".$this->project_database_sel.".tb_booking ON(rc_booking_code = bk_booking_code)
                                    INNER JOIN ".$this->project_database_sel.".tb_quotation ON(bk_quotation_code = qt_code)
                                    INNER JOIN tb_customer ON(bk_leads_id = cus_id)
                                    INNER JOIN tb_customer_personal_info ON(cus_pers_id = pers_id)
                                    INNER JOIN ".$this->project_database_sel.".tb_unit_number ON(rc_un_name = un_name)
                                    INNER JOIN ".$this->project_database_sel.".tb_building ON(un_build_id = building_id)
                                    WHERE rc_official_date = '".$date."'
                                    and `rc_customer_id` = '".$cusID."'");
      
      return $query->result();
    }
    function get_customer_id_drIncome ($date) {
      $this->load->database();
      $query = $this->pdb->query("  SELECT distinct(rc_customer_id) as cusID           
                                    FROM tb_receipt_offical
                                    WHERE rc_official_date = '".$date."' ");
      return $query->result();
    }
    function get_payment_drIncome ($cusID, $unID) {
      $this->load->database();
      $query = $this->pdb->query("  SELECT rc_total_amount 
                                    FROM tb_receipt_offical 
                                    WHERE `rc_un_name` = '".$unID."'
                                    and `rc_customer_id` = '".$cusID."'");
      return $query->result();
      
    }
    function get_detail_card_customer_summary ($status, $date, $query)
    {
      if ($status == 1) { 
        $sqlStatus = "";
      } else if ($status == 2) {
        $sqlStatus = "AND ct_active != 'cancelled'";
      } else if ($status == 3) {
        $sqlStatus = "AND ct_active = 'cancelled'";
      }

      if ($query != null) {
        $sqlLimit = "limit ".$query." ,100";
      } else {
        $sqlLimit = "";
      }
      $this->load->database();
      $query = $this->pdb->query("  
                                    SELECT 
                                      @rn:=@rn+1 AS row,
                                      unitNumber AS unitNumber,
                                      prefix AS prefix,
                                      fname AS fname,
                                      lname AS lname,
                                      contractCode AS contractCode,
                                      contractValue AS contractValue,
                                      allValue AS allValue,
                                      allPaid AS allPaid,
                                      remain AS remain,
                                      status AS status
                                    FROM (
                                      SELECT 
                                        un_name AS unitNumber,
                                        pers_prefix AS prefix,
                                        pers_fname AS fname,
                                        pers_lname AS lname,
                                        ct_code AS contractCode,
                                        qt_total_down_payment AS contractValue,
                                        qt_unit_price AS allValue,
                                        SUM(pm_amount) AS allPaid,
                                        (qt_total_down_payment - SUM(pm_amount)) AS remain,
                                        ct_active AS status
                                      FROM tb_contract
                                      LEFT JOIN $this->common_database.tb_customer_personal_info ON (ct_cus_id = pers_id_cus)
                                      LEFT JOIN tb_booking ON (bk_booking_code = ct_booking_code)
                                      LEFT JOIN tb_quotation ON (qt_code = bk_quotation_code)
                                      LEFT JOIN tb_unit_number ON (qt_unit_number_id = un_id)
                                      LEFT JOIN tb_receipt_offical ON (rc_booking_code = ct_booking_code)
                                      LEFT JOIN tb_payment ON (rc_code = pm_receipt_code)
                                      WHERE DATE(ct_time_stamp) = '$date'
                                      $sqlStatus
                                      GROUP BY rc_booking_code
                                      $sqlLimit  
                                    ) t1, (SELECT @rn:=0) t2;
                                    -- SELECT 
                                    --   @rn:=@rn+1 AS row,
                                    --   unitNumber AS unitNumber,
                                    --   prefix AS prefix,
                                    --   fname AS fname,
                                    --   lname AS lname,
                                    --   contractCode AS contractCode,
                                    --   contractValue AS contractValue,
                                    --   allValue AS allValue,
                                    --   allPaid AS allPaid,
                                    --   remain AS remain,
                                    --   status AS status,
                                    --   pro AS pro
                                    -- FROM (
                                    --   SELECT 
                                    --     un_name AS unitNumber,
                                    --     pers_prefix AS prefix,
                                    --     pers_fname AS fname,
                                    --     pers_lname AS lname,
                                    --     ct_code AS contractCode,
                                    --     qt_total_down_payment AS contractValue,
                                    --     qt_unit_price AS allValue,
                                    --     SUM(pm_amount) AS allPaid,
                                    --     (qt_total_down_payment - SUM(pm_amount)) AS remain,
                                    --     ct_active AS status,
                                    --     SUM(p.pm_value) AS pro
                                    --   FROM tb_contract
                                    --   LEFT JOIN $this->common_database.tb_customer_personal_info ON (ct_cus_id = pers_id_cus)
                                    --   LEFT JOIN tb_booking ON (bk_booking_code = ct_booking_code)
                                    --   LEFT JOIN tb_quotation ON (qt_code = bk_quotation_code)
                                    --   LEFT JOIN tb_unit_number ON (qt_unit_number_id = un_id)
                                    --   LEFT JOIN tb_receipt_offical ON (rc_booking_code = ct_booking_code AND rc_payfor = 'Contract Fee')
                                    --   LEFT JOIN tb_payment ON (rc_code = pm_receipt_code)
                                    --   LEFT JOIN tb_contract_promotion ON (cp_booking_code = ct_booking_code)
                                    --   LEFT JOIN tb_promotion p ON (cp_promotion_id = p.pm_id)
                                    --   WHERE DATE(ct_time_stamp) = '$date'
                                    --   $sqlStatus
                                    --   GROUP BY ct_code
                                    --   $sqlLimit  
                                    -- ) t1, (SELECT @rn:=0) t2;
                                    ");
      $value = $query->result();
      $query2 = $this->pdb->query  (" 
                                  SELECT SUM(pm_value) AS pro
                                  FROM tb_contract
                                  LEFT JOIN condo_common.tb_customer_personal_info ON (ct_cus_id = pers_id_cus)
                                  LEFT JOIN tb_booking ON (bk_booking_code = ct_booking_code)
                                  LEFT JOIN tb_quotation ON (qt_code = bk_quotation_code)
                                  LEFT JOIN tb_unit_number ON (qt_unit_number_id = un_id)
                                  LEFT JOIN tb_contract_promotion ON (cp_booking_code = ct_booking_code)
                                  LEFT JOIN tb_promotion ON (cp_promotion_id = pm_id)
                                  WHERE DATE(ct_time_stamp) = '2016-06-02'
                                  GROUP BY ct_booking_code
                                  ");
      $value2 = $query2->result();
      foreach ($value as $key => $valueTmp) {
        $value[$key]->pro = $value2[$key]->pro;
      }

      return $value;
    }
}
?>