<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_building extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
   
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_building', $array);
      return $this->pdb->insert_id();
    }
    function update($array,$building_id)
    {
      $this->pdb->where('building_id', $building_id);
      $this->pdb->update('tb_building', $array); 
    }
    function get_detail_building_by_building_id($building_id){

      $query = $this->pdb->query("SELECT  * FROM tb_building WHERE building_id = '".$building_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_building_by_un_nameAndun_build_id($un_name,$un_build_id){
 
      $query = $this->pdb->query("SELECT *
                                   FROM tb_unit_number,
                                            tb_building,
                                            tb_floor
                                   WHERE 
                                       building_id = un_build_id
                                       AND building_id = fl_build_id
                                       AND un_name =  '".trim($un_name)."' AND un_build_id = '".trim($un_build_id)."'
                                       AND un_floor_id = fl_id
                                       ");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_building_by_un_idAndun_build_id($un_id,$un_build_id){

      $query = $this->pdb->query("SELECT *
                                   FROM tb_unit_number,
                                            tb_building,
                                            tb_floor
                                   WHERE 
                                       building_id = un_build_id
                                       AND building_id = fl_build_id
                                       AND un_id =  '".trim($un_name)."' AND un_build_id = '".trim($un_build_id)."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_all_building(){
      $query = $this->pdb->query("SELECT  * FROM tb_building WHERE building_sts_active = 'on'");
      return $query->result();
    }
    function fetch_all_building_DESC_Name(){
      $query = $this->pdb->query("SELECT  * FROM tb_building WHERE building_sts_active = 'on' ORDER BY building_name DESC");
      return $query->result();
    }
    
    function get_building_name_by_id($building_id) {
        $this->pdb->where('building_id', $building_id);
        $query = $this->pdb->get('tb_building');
        $result = $query->result();
        return $result[0]->building_name;
    }
    
    function get_by_name($building_name)
    {
        return $this->pdb->where('building_name', $building_name)->get('tb_building')->result()[0];
    }
}

/* End of file tb_building.php */
/* Location: ./application/models/tb_building.php */