<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_payment_terms extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('log_payment_terms', $array);
    }
}

/* End of file log_payment_terms.php */
/* Location: ./application/models/log_payment_terms.php */