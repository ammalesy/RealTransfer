<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_transferred extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_transferred', $array);
    }
    function update($array,$tf_id)
    {
      $this->pdb->where('tf_id', $tf_id);
      $this->pdb->update('tb_transferred', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_transferred', $array, $where);
    }
    function get_booking_history()
    {
        $query = $this->pdb->query("
            SELECT CONCAT(building_name, ' ', un_name) as unit, DATE_FORMAT(tf_timestamp, '%d/%m/%Y') as tf_date, CONCAT(user_pers_fname, ' ', user_pers_lname) AS staff, tf_remark,
                (SELECT CONCAT(pers_fname, ' ', pers_lname) 
                FROM $this->dbCommon.tb_customer_personal_info 
                WHERE pers_id_cus = SUBSTRING_INDEX(tf_old_customer, ',', 1)) as old_name,
                (SELECT CONCAT(pers_fname, ' ', pers_lname) 
                FROM $this->dbCommon.tb_customer_personal_info 
                WHERE pers_id_cus = SUBSTRING_INDEX(tf_new_customer, ',', 1)) as new_name
            FROM tb_transferred
            LEFT JOIN tb_unit_number ON (un_id = tf_unit_id)
            LEFT JOIN tb_building ON (building_id = un_build_id)
            LEFT JOIN $this->dbCommon.tb_user_personal_info ON (user_pers_user_id = tf_staff_id)
            WHERE tf_old_contract IS NULL
        ");
        return $query->result();
    }
    function get_contract_history()
    {
        $query = $this->pdb->query("
            SELECT CONCAT(building_name, ' ', un_name) as unit, DATE_FORMAT(tf_timestamp, '%d/%m/%Y') as tf_date, CONCAT(user_pers_fname, ' ', user_pers_lname) AS staff, tf_remark, tf_id,
                (SELECT CONCAT(pers_fname, ' ', pers_lname) 
                FROM $this->dbCommon.tb_customer_personal_info 
                WHERE pers_id_cus = SUBSTRING_INDEX(tf_old_customer, ',', 1)) as old_name,
                (SELECT CONCAT(pers_fname, ' ', pers_lname) 
                FROM $this->dbCommon.tb_customer_personal_info 
                WHERE pers_id_cus = SUBSTRING_INDEX(tf_new_customer, ',', 1)) as new_name
            FROM tb_transferred
            LEFT JOIN tb_unit_number ON (un_id = tf_unit_id)
            LEFT JOIN tb_building ON (building_id = un_build_id)
            LEFT JOIN $this->dbCommon.tb_user_personal_info ON (user_pers_user_id = tf_staff_id)
            WHERE tf_old_contract IS NOT NULL
        ");
        return $query->result();
    }
    function get_by_contract($tid)
    {
        return $this->pdb->from('tb_transferred')->join('tb_contract','ct_code = tf_new_contract')->join('tb_booking','bk_booking_code = ct_booking_code')->join('tb_quotation','qt_code = bk_quotation_code')->where('tf_id',$tid)->get()->result()[0];
    }
    function get_frist_cus_by_contract($cid)
    {
        return $this->pdb->where('tf_new_contract',$cid)->get('tb_transferred')->result()[0]->tf_old_customer;
    }
}
?>