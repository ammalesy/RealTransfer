<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_user_personal_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('log_user_personal_info', $array);
    }
}

/* End of file log_user_personal_info.php */
/* Location: ./application/models/log_user_personal_info.php */