<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_project extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_project', $array);
    }
    function update($array,$pj_id)
    {
      $this->load->database();
      $this->db->where('pj_id', $pj_id);
      $this->db->update('tb_project', $array); 
    }
    function get_next_id()
    {
        return $this->db->select_max('pj_id')->get('tb_project')->result()[0]->pj_id +1;
    }

    function get_detail_project($pjid){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_project 
                                 WHERE pj_active = 'on'  
                                 AND pj_id ='".$pjid."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_project_by_dbName($dbName){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_project 
                                 WHERE pj_datebase_name ='".$dbName."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_project_ignoreStatusActive($pjid){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_project   
                                 WHERE pj_id ='".$pjid."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    
    function get_detail_project_ignoreStatusActive_by_pdb($pjid){
      $this->load->database();
      $query = $this->pdb->query("SELECT * FROM tb_project   
                                 WHERE pj_id ='".$pjid."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_user_project($user_id)
    {
    	  $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_assign_project , tb_project
                                   WHERE pj_id = assign_project_id 
                                   AND   pj_active = 'on' 
                                   AND   assign_sts_active = 'on' 
                                   AND   assign_user_id = '".$user_id."'");
  
        return $query->result();
    }
    function fetch_all_active_project()
    {
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_project 
                                   WHERE pj_active = 'on'");
  
        return $query->result();
    } 
    function get_total_month_by_pid($pid)
    {
        $query = $this->pdb->query("SELECT truncate(DATEDIFF(pj_end_downpayment, CURDATE())/30, 0) as total_month 
                                             FROM tb_project 
                                             WHERE pj_id = $pid");
        $result = $query->result();
        $temp1 = $result[0]->total_month;
        $query = $this->pdb->query("SELECT truncate(DATEDIFF(pj_end_downpayment, pj_start_downpayment)/30, 0) as total_month 
                                             FROM tb_project 
                                             WHERE pj_id = $pid");
        $result = $query->result();
        $temp2 = $result[0]->total_month + 1;
        
        return ($temp1 > $temp2)?$temp2:$temp1;
    }
    function get_detail_project_selected($pjid){
      $query = $this->pdb->query("SELECT * FROM tb_project 
                                 WHERE pj_id ='".$pjid."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
}

/* End of file tb_user.php */
/* Location: ./application/models/tb_user.php */