<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_receipt_temporary  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_receipt_temporary', $array);
    }
    function update($array,$rc_id)
    {
        $this->pdb->update('tb_receipt_temporary', $array, "rc_id = $rc_id");
    }
    function update_where($array,$where)
    {
        $this->pdb->update('tb_receipt_temporary', $array, $where);
    }
    
    function get_next_id() {
        $this->pdb->select_max('rc_id');
        $query = $this->pdb->get('tb_receipt_temporary');
        return $query->result()[0]->rc_id + 1;
    }
    function get_last(){
     
      $query = $this->pdb->query("SELECT rc_code, bk_leads_id
                                  FROM  tb_booking  ,tb_receipt_temporary  
                                  WHERE rc_booking_code = bk_booking_code 
                                  order by  rc_id desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function count_waiting_code(){
	 $query = $this->pdb->query("SELECT  COUNT(rc_code)  AS waitnumber 
                                  FROM tb_receipt_temporary  
                                  WHERE rc_confirm ='N' OR rc_confirm ='no'");
       $result = $query->result();
       return $result[0]->waitnumber;	
	}
    function get_by_booking($bkcode) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_temporary ,tb_booking 
            WHERE bk_booking_code = '$bkcode' 
            AND rc_booking_code = bk_booking_code
            AND rc_payfor = 'Booking Fee'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_detail_booking($rc_id){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM ".$this->project_database_sel.".tb_receipt_temporary , ".$this->project_database_sel.".tb_booking , 
            tb_customer, tb_customer_personal_info
            WHERE rc_id = '$rc_id' 
            AND  rc_customer_id = cus_id  
            AND cus_pers_id =  pers_id 
            AND rc_booking_code = bk_booking_code
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_by_contract($ctCode) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_temporary ,tb_contract
            WHERE ct_code = '$ctCode' 
            AND rc_contract_code = ct_code
            AND rc_payfor = 'Contract Fee'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_by_installment_id($imID) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_temporary ,tb_installment
            WHERE im_id = '$imID' 
            AND rc_installment_code = im_code
            AND rc_payfor = 'Installment Fee'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function fetch_full($type,$project_id_sel){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM  $this->project_database_sel.tb_booking  ,
                  $this->project_database_sel.tb_receipt_temporary , 
                  tb_customer ,
                  tb_customer_personal_info 
            WHERE bk_leads_id = cus_id 
            AND pers_id = cus_pers_id 
            AND rc_booking_code = bk_booking_code
            AND rc_status = 'on'
            AND bk_project_id = '".$project_id_sel."'
            ORDER BY rc_code DESC
        ");
        return $query->result();
    }
    function get_detail_receipt($rc_id){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM ".$this->project_database_sel.".tb_receipt_temporary , tb_customer, tb_customer_personal_info
            WHERE rc_id = '".$rc_id."' 
            AND  rc_customer_id =  cus_id  
            AND cus_pers_id =  pers_id");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_by_id($rid)
    {
        return $this->pdb->query("
            SELECT *
            FROM tb_receipt_temporary
            WHERE rc_id = '$rid'
            AND rc_status = 'on'
        ")->result()[0];
    }
    function get_receipt_by_booking($bkcode) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_temporary
            WHERE rc_booking_code = '$bkcode'
            AND rc_status = 'on'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    function get_receipt_by_code($rc_code)
    {
        return $this->pdb->query("
            SELECT *
            FROM tb_receipt_temporary
            WHERE rc_code = '$rc_code'
        ")->result()[0];
    }
    function get_installmentTime_by_contract($conid , $in_time) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_temporary ,tb_contract          
            WHERE ct_code = '".$conid."' 
            AND rc_contract_code = ct_code 
            AND rc_installment_time = '".$in_time."' 
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_one_by($where)
    {
        return $this->pdb->get_where('tb_receipt_temporary',$where)->result()[0];
    }
    function get_last_by_unit($un_name)
    {
        return $this->pdb->where('rc_un_name',$un_name)->order_by("rc_id","desc")->get('tb_receipt_temporary')->result()[0];
    }
    function get_full_detail($rc_id){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM ".$this->project_database_sel.".tb_receipt_temporary , 
                tb_customer, tb_customer_personal_info 
            WHERE rc_customer_id = cus_id 
            AND  pers_id = cus_pers_id 
            AND rc_code ='".$rc_id."'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_by_transfer_ownership($trCode) {
        $query = $this->pdb->query("
            SELECT * 
            FROM tb_receipt_temporary ,tb_contract
            WHERE rc_transfer_code = '$trCode' 
            AND rc_payfor = 'Transfer Ownership'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    
    function get_temp_receipt_by_rc_installment_code($rc_im_code) {
        $query = $this->pdb->query("
            SELECT * FROM tb_receipt_temporary WHERE rc_installment_code = '$rc_im_code' ORDER BY rc_id ASC
            ");
        return $query->result();
    }
    
    function get_temp_receipt_by_rc_id($rc_id) {
        $query = $this->pdb->query("
            SELECT * FROM tb_receipt_temporary WHERE rc_id = '$rc_id' ORDER BY rc_id ASC
            ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
}
?>