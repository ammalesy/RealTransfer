<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_user_personal_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_user_personal_info', $array);
    }
    function update($array,$user_id)
    {
      $this->load->database();
      $this->db->where('user_pers_id', $user_id);
      $this->db->update('tb_user_personal_info', $array); 
    }
    function get_new_personal_id()
    {

        $this->load->database();
        $query = $this->db->query("SELECT Max(user_pers_id)+1 as MaxID 
                                  FROM tb_user_personal_info");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    /*$cmd = " SELECT user_pers_id,user_pers_fname,user_pers_lname FROM 
        $databasecommonname.tb_user,
        $databasecommonname.tb_user_personal_info
        WHERE 
        user_pers_id = user_pers_id_ref 
        AND user_pers_id = ".$getbookine['ct_user_signature'] ;*/
    function get_detail_by_user_pers_id($user_pers_id)
    {
      $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_user,tb_user_personal_info
                                   WHERE user_pers_id = user_pers_id_ref 
                                   AND user_pers_id = '".$user_pers_id."'");
        $row = $query->result();
        return $row[0];
    }
    function get_detail_personal($user_id)
    {
      $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_user ,tb_user_personal_info 
                                   WHERE user_pers_id = user_pers_id_ref  
                                   AND user_sts_active = 'on' 
                                   AND user_id = '".$user_id."'");
        $row = $query->result();
        return $row[0];
    }
    function fetch_all_personal()
    {
        $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_user , tb_user_personal_info , tb_permission
                                   WHERE user_permission = pm_id 
                                   AND user_pers_id = user_pers_id_ref 
                                   AND user_sts_active = 'on'");
        return $query->result();
    }
    function fetch_all_personal_infoNormal()
    {
        $this->load->database();
        $query = $this->db->query("SELECT *
                                   FROM tb_user
                                   INNER JOIN tb_user_personal_info ON (user_pers_id_ref=user_pers_user_id)");
        return $query->result();
    }
    function fetch_all_personal_without_permission(){
        $this->load->database();
        $query = $this->db->query("SELECT * 
                                   FROM tb_user , tb_user_personal_info
                                   WHERE user_pers_id = user_pers_id_ref 
                                   AND user_sts_active = 'on'");
        return $query->result();
    }
    
    function get_by_name($fname, $lname)
    {
        return $this->db->query("
            SELECT *
            FROM tb_user_personal_info
            WHERE TRIM(user_pers_fname) = TRIM('$fname')
            AND TRIM(user_pers_lname) = TRIM('$lname')
        ")->result()[0];
    }
}

/* End of file tb_user_personal_info.php */
/* Location: ./application/models/tb_user_personal_info.php */