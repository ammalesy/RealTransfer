<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_district extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_district', $array);
    }
    function fetch_all_district(){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM tb_district
                                 ORDER BY d_name_th ASC");
      return $query->result();
    }
}

/* End of file tb_province.php */
/* Location: ./application/models/tb_province.php */