<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_contract_promotion extends NZ_Model {
  
    function __construct()
    {
        parent::__construct();
    }

    function record($array)
    {
      $this->pdb->insert('tb_contract_promotion', $array);
    }

    function update($array, $cp_id)
    {
      $this->pdb->where('cp_id', $cp_id);
      $this->pdb->update('tb_contract_promotion', $array);
    }

    function get_detail_by_bk_code($bk_code)
    {
      $this->pdb->where('cp_booking_code', $bk_code);
      $this->pdb->where('cp_status', 'on');
      $query = $this->pdb->get('tb_contract_promotion');
      return $query->result();
    }
    
    function get_promotion_by_bk_code($bk_code)
    {
        $query = $this->pdb->query("    SELECT * FROM tb_contract_promotion, tb_promotion
                                        WHERE cp_status = 'on'
                                        AND cp_booking_code = '".$bk_code."'
                                        AND cp_promotion_id = pm_id");
        return $query->result();
    }
    
    function get_promotion_by_ct_code($ct_code)
    {
        $query = $this->pdb->query("    SELECT * FROM tb_contract_promotion, tb_promotion
                                        WHERE cp_status = 'on'
                                        AND cp_contract_code = '".$ct_code."'
                                        AND cp_promotion_id = pm_id
                                        ORDER BY pm_type ASC");
        return $query->result();
    }
    
    function get_promotion_cash_only($bk_code)
    {
        $query = $this->pdb->query("    SELECT * FROM tb_contract_promotion, tb_promotion
                                        WHERE cp_status = 'on'
                                        AND cp_booking_code = '".$bk_code."'
                                        AND cp_promotion_id = pm_id
                                        and pm_type = 'Cash' ");
        return $query->result();
    }
}
?>