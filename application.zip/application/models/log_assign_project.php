<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_assign_project extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('log_assign_project', $array);
    }
}

/* End of file log_assign_project.php */
/* Location: ./application/models/log_assign_project.php */