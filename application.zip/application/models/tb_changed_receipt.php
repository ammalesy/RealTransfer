<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_changed_receipt  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_changed_receipt', $array);
    }
    function update($array,$rc_receipt_id)
    {
      $this->pdb->where('cr_id', $rc_receipt_id);
      $this->pdb->update('tb_changed_receipt', $array); 
    }
    function getAllDetail()
    {
        return $this->pdb->query("
            SELECT *
            FROM tb_changed_receipt
            INNER JOIN tb_unit_number ON (un_id = cr_unit)
            INNER JOIN tb_building ON (building_id = un_build_id)
            INNER JOIN $this->dbCommon.tb_user_personal_info ON (user_pers_user_id = cr_staff)
            ORDER BY cr_timestamp DESC
            ")->result();
    }
}
?>