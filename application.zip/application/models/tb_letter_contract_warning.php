<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_letter_contract_warning extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_letter_contract_warning', $array);
    }
    function fetch_all_letter_booking_warning(){
      $query = $this->pdb->query("SELECT *
                                 FROM tb_letter_contract_warning");
      return $query->result();
    }
    function fetch_all_by_lt_project_id($lt_project_id){
      $query = $this->pdb->query("SELECT
                                    lt_id,
                                    lt_code,
                                    lt_cus_id,
                                    lt_project_id,
                                    lt_contract_id,
                                    lt_timestamp
                                  FROM tb_letter_contract_warning
                                  WHERE lt_project_id = '".$lt_project_id."'");
      return $query->result();
    }
    function get_detail_by_lt_code($lt_code){
      $query = $this->pdb->query("SELECT *
                                  FROM tb_letter_contract_warning
                                  WHERE lt_code = '".$lt_code."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_new_letter_id()
    {

        $query = $this->pdb->query("SELECT COUNT(lt_id) as newid  
                                    FROM tb_letter_booking_warning  
                                    WHERE lt_project_id ='".$this->project_id_sel."'");
        $row = $query->result();
        $new_id = $row[0]->newid;
        if($new_id == NULL){ 
            return "1";
        }else{
            return ($new_id + 1);
        }
    }

}

/* End of file tb_letter_contract_warning.php */
/* Location: ./application/models/tb_letter_contract_warning.php */