<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_defect  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function fetch_defect_by_df_room_id($df_room_id){
        $query = $this->db->query("
            SELECT * FROM $this->project_database_sel.tb_defect WHERE df_room_id_ref = ".$df_room_id."
        ");
        return $query->result();
    }
    

}