<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_authentication extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
        $this->load->database();
        $this->db->insert('log_authentication', $array);
    }
    function get_last_by_user_id($uid)
    {
        $this->db->order_by("at_timestamp", "DESC");
        $this->db->where('at_user_id', $uid);
        return $this->db->get('log_authentication')->result()[0];
    }
}
?>