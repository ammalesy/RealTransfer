<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_customer_personal_info extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_customer_personal_info', $array);
    }
    function update($array,$pers_id)
    {
      $this->load->database();
      $this->db->where('pers_id', $pers_id);
      $this->db->update('tb_customer_personal_info', $array); 
    }
    function fetch_all_customer_smallInfo(){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname   
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE pers_id = cus_pers_id 
                                 AND cus_sts_active = 'on' ORDER BY fullname ASC");
      return $query->result();
    }
    function fetch_all_customer_smallInfo_NotLeads(){
      $this->load->database();
      $query = $this->db->query("SELECT cus_id, CONCAT(pers_fname,' ',pers_lname) AS fullname , pers_passport , pers_card_id  
                                 FROM tb_customer , tb_customer_personal_info 
                                 WHERE pers_id = cus_pers_id
                                 AND cus_sts_active = 'on' ORDER BY fullname ASC");
      return $query->result();
    }
    function get_detail_by_id($pers_id){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer_personal_info 
                                 WHERE pers_id = '".$pers_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_user_pers_id($pers_id){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer_personal_info 
                                 WHERE pers_id = '".$pers_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_pers_id_withCustomerTable($pers_id){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM  tb_customer , tb_customer_personal_info
                                 WHERE  cus_pers_id =  pers_id 
                                 AND pers_id = '". $pers_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_pers_id_withCustomerArr($pers_id){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM  tb_customer , tb_customer_personal_info
                                 WHERE  cus_pers_id =  pers_id 
                                 AND pers_id = '". $pers_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_cus_id_withCustomerTable($cus_id){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM tb_customer 
                                 INNER JOIN tb_customer_personal_info ON (cus_id = pers_id) 
                                 WHERE cus_id = '".$cus_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_pers_id_cus($pers_id_cus){
      $this->load->database();
      $query = $this->db->query("SELECT * FROM tb_customer_personal_info 
                                 WHERE pers_id_cus = '".$pers_id_cus."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_new_customer_personal_id()
    {

        $this->load->database();
        $query = $this->db->query("SELECT Max(pers_id)+1 as MaxID from tb_customer_personal_info");
        $row = $query->result();
        $new_id = $row[0]->MaxID;
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    function duplicateFnameLname($pers_fname,$pers_lname){
      $this->load->database();
      $query = $this->db->query("SELECT DISTINCT pers_id_cus 
                                 FROM tb_customer_personal_info
                                WHERE UPPER(TRIM(pers_fname)) = '".strtoupper(trim($pers_fname))."' 
                                AND UPPER(TRIM(pers_lname)) = '".strtoupper(trim($pers_lname))."'");
      $result = $query->result()[0];
      return $result->pers_id_cus;
    }
    
    function get_all()
    {
        return $this->db->select('pers_id_cus,pers_fname,pers_lname')->get('tb_customer_personal_info')->result();
    }
	
	function count_pers_id_cus(){
      $this->load->database();
      $query = $this->db->query("SELECT COUNT(pers_id) AS newid  
                                 FROM tb_customer_personal_info");
      $result = $query->result();
       return $result[0]->newid;
     
    }
    function list_customer($cuslist) {
        $this->load->database();
        $query = $this->db->query(
            "SELECT pers_fname, pers_lname
            FROM tb_customer_personal_info
            WHERE pers_id_cus in ($cuslist)"
        );
        return $query->result();
    }
    function check_id_card($idcard) {
        $result = $this->db->where('pers_card_id', $idcard)->get('tb_customer_personal_info')->result()[0];
        return empty($result)?FALSE:TRUE;
    }
    function check_cus_name($fname, $lname) {
        $result = $this->db->where('pers_fname', $fname)->where('pers_lname', $lname)->get('tb_customer_personal_info')->result()[0];
        return empty($result)?FALSE:TRUE;
    }
}

/* End of file tb_customer_personal_info.php */
/* Location: ./application/models/tb_customer_personal_info.php */