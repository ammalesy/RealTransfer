<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_installment  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_installment', $array);
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_installment', $array, $where);
    }
    function get_detail_by_in_contract_id($in_contract_id){
      $this->load->database(); 
      $query = $this->db->query("SELECT  *
                                 FROM ".$this->project_database_sel.".tb_installment
                                 WHERE im_contract_code = '".$in_contract_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result;
      }else{
        return NULL;
      }
        
    }
    function get_by_code($im_code, $ctCode){
        $query = $this->pdb->query("
            SELECT *
            FROM tb_installment
            WHERE im_code = '$im_code'
            AND im_contract_code = '$ctCode'
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_full_detail_by_id($in_id){
      $this->load->database();
      $query = $this->db->query("SELECT  *
                                 FROM ".$this->project_database_sel.".tb_installment , tb_customer,  tb_customer_personal_info
                                 WHERE im_id = '".$in_id."' 
                                 AND im_cus_id = cus_id  
                                 AND cus_pers_id = pers_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
        
    }
    function get_full_detail_by_code($im_code){
        $this->load->database();
        $query = $this->db->query("
            SELECT  *
            FROM ".$this->project_database_sel.".tb_installment , tb_customer,  tb_customer_personal_info
            WHERE im_code = '".$im_code."' 
            AND im_cus_id = cus_id  
            AND cus_pers_id = pers_id
            ORDER BY im_id DESC
        ");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_full_detail_im_id($im_id){
      $this->load->database();
      $query = $this->db->query("SELECT distinct im_contract_code,im_cus_id,im_installment_time,
                                        pers_prefix, pers_lname, pers_fname  ,im_duedate, im_remark,
                                        im_id, im_code,pers_mobile,pers_tel,pers_email
                                  FROM ".$this->project_database_sel.".tb_installment                
                                        INNER JOIN tb_customer_personal_info ON (im_cus_id = pers_id_cus)                
                                  WHERE im_id ='".$im_id."'");

      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
        
    } 
    function fetch_installment_customerInfoAndSmsInfo(){
      $this->load->database();
      $query = $this->db->query("SELECT i.*,c.*,inf.* ,sms.sms_ct_code
                                 FROM ".$this->project_database_sel.".tb_installment i 
                                 INNER JOIN tb_customer c ON (i.im_cus_id = c.cus_id)
                                 INNER JOIN tb_customer_personal_info inf ON ( c.cus_pers_id = inf.pers_id)
                                 LEFT JOIN  tb_sms sms ON ( sms.sms_ct_code = i.im_contract_code)
                                 WHERE cus_sts_active = 'on' AND im_code  LIKE 'Waiting%'");
      return $query->result();
    }

    function fetch_installment_by_in_contract_id($ctCode){
        $this->load->database();
        $query = $this->db->query("
            SELECT im_installment_time,im_code,im_amount,im_fee_define,im_duedate,im_status,im_paid,im_id,pers_fname,pers_lname,pers_mobile,pers_email,rc_code,rc_payfor,rc_confirm,rc_id,rc_status
            FROM ".$this->project_database_sel.".tb_installment
            LEFT JOIN tb_customer ON (im_cus_id =  cus_id)
            LEFT JOIN tb_customer_personal_info ON (cus_pers_id = pers_id)
            LEFT JOIN $this->project_database_sel.tb_receipt_temporary
                ON (rc_installment_code = im_code AND rc_contract_code = '$ctCode')
            WHERE im_contract_code = '$ctCode'
            AND cus_sts_active = 'on' 
            AND im_status != 'off'
            GROUP BY im_code ORDER BY im_id asc
        ");
        return $query->result();
    }
    function fetch_filtering_installment(){
      $query = $this->db->query(" 
         SELECT im_call_remark, im_contract_code, im_installment_time, im_code, im_duedate, im_status, 
            im_id, im_fee_define, im_cus_id,
            im_paid,
            bk_booking_code,
            qt_buliding_id, qt_unit_number_id, qt_avg_installment, 
            qt_months_installment4, qt_months_installment3, qt_months_installment2, qt_months_installment1,
            qt_installment5, qt_installment4, qt_installment3, qt_installment2, qt_installment1,
            pers_fname, pers_lname, pers_email, pers_mobile,
            building_name, un_name,
            rc_code, rc_payfor, rc_id, rc_status, rc_confirm
         FROM $this->project_database_sel.tb_installment  i
         LEFT JOIN $this->project_database_sel.tb_contract    ON (ct_code = im_contract_code)
         LEFT JOIN $this->project_database_sel.tb_booking     ON (bk_booking_code = ct_booking_code)
         LEFT JOIN $this->project_database_sel.tb_quotation   ON (qt_code = bk_quotation_code)
         LEFT JOIN tb_customer_personal_info ON (pers_id_cus = SUBSTRING_INDEX(im_cus_id,',',1))
         LEFT JOIN $this->project_database_sel.tb_building    ON (building_id = qt_buliding_id)
         LEFT JOIN $this->project_database_sel.tb_unit_number ON (un_id = qt_unit_number_id)
         LEFT JOIN $this->project_database_sel.tb_receipt_temporary ON (rc_installment_code = im_code)
         WHERE im_status != 'cancelled' 
         AND DATEDIFF(im_duedate,NOW()) < 0
         ORDER BY im_contract_code DESC
     ");
      return $query->result();
    }
    function get_frist_month_by_bookin($bk_code){
      $this->load->database();
      $query = $this->db->query("SELECT im_duedate FROM ".$this->project_database_sel.".tb_installment, ".$this->project_database_sel.".tb_contract 
                                 WHERE im_contract_id = ct_code 
                                 AND im_installment_time = '01' 
                                 AND ct_booking_code = '$bk_code'");

      foreach ($query->result() as $row)
        return $row->in_due_date;
      return NULL;
    }
    function update($array,$in_id)
    {
      $this->pdb->where('im_id', $in_id);
      $this->pdb->update('tb_installment', $array); 
    }
    
    function get_detail_by_ct_code($ct_code, $date) {
        $query = $this->pdb->query("    SELECT * FROM tb_installment
                                        WHERE im_contract_code = '".$ct_code."'
                                        AND im_paid = 'no'
                                        AND im_status = 'on'
                                        AND im_duedate < '".$date."'");
        return $query->result();
    }
    
    function get_contract_overdue_installment($date) {
        $query = $this->pdb->query("    SELECT DISTINCT im_contract_code, im_cus_id FROM tb_installment
                                        WHERE im_paid = 'no'
                                        AND im_status = 'on'
                                        AND im_duedate < '".$date."'
                                        ORDER BY im_code ASC");
        return $query->result();
    }
    function fetch_all_SMS_byProjectID($pj_id){
        $query = $this->db->query("
            SELECT distinct im_code, im_contract_code, im_fee_define, im_duedate, im_cus_id,
            ct_booking_code,
            pers_lname, pers_fname ,
            pers_mobile, pers_tel, pers_email,
            sms_installment_code
            FROM $this->project_database_sel.tb_installment 
            INNER JOIN $this->project_database_sel.tb_contract ON (ct_code = im_contract_code)  
            INNER JOIN tb_customer ON (cus_id = im_cus_id)  
            INNER JOIN tb_customer_personal_info ON (pers_id = cus_pers_id)
            LEFT JOIN  $this->project_database_sel.tb_sms ON (sms_installment_code = im_code)
            WHERE im_status ='on'
            AND `ct_project_id` = '$pj_id'
        ");
        return $query->result();
    }
    function fetch_all_Email_byProjectID($pj_id){
        $query = $this->db->query("
            SELECT distinct im_code, im_contract_code, im_fee_define, im_duedate, im_cus_id,
            im_installment_time, ct_booking_code,
            pers_lname, pers_fname ,
            pers_mobile, pers_tel, pers_email,
            email_installment_code
            FROM $this->project_database_sel.tb_installment 
            INNER JOIN $this->project_database_sel.tb_contract ON (ct_code = im_contract_code)  
            INNER JOIN tb_customer ON (cus_id = im_cus_id)  
            INNER JOIN tb_customer_personal_info ON (pers_id = cus_pers_id)
            LEFT JOIN  $this->project_database_sel.tb_email ON (email_installment_code = im_code)
            WHERE im_status ='on'
            AND `ct_project_id` = '$pj_id'
        ");
        return $query->result();
    }
    
    function get_distinct_contract_code_for_chart_overdue_installment($start, $end, $cusID, $unID)
    {
        $this->load->database();
      	$query = $this->pdb->query("	SELECT DISTINCT im_contract_code FROM tb_installment,tb_contract,tb_booking,tb_quotation
                                        WHERE (im_duedate BETWEEN  '".$start."' AND '".$end."')
                                        AND im_status = 'on'
                                        ".$cusID."
                                        AND im_contract_code = ct_code
                                        AND ct_booking_code = bk_booking_code
                                        AND bk_quotation_code = qt_code
                                        ".$unID."");
      	return $query->result();
    }

    function checkPaidForTransferOwnership ($contractCode) {
      $this->load->database();
      $query = $this->pdb->query("   SELECT COUNT(rc_installment_code) as allPaid FROM tb_receipt_offical 
                                    WHERE rc_contract_code = '".$contractCode."' AND rc_status = 'on' AND rc_payfor = 'Installment Fee' ");

      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function totalInstallmentByContractCode ($contractCode) {
      $this->load->database();
      $query = $this->pdb->query("  SELECT COUNT(im_contract_code) as totalInstallment FROM tb_installment 
                                  WHERE im_contract_code = '".$contractCode."'");

      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
}

/* End of file tb_paymant .php */
/* Location: ./application/models/tb_paymant .php */