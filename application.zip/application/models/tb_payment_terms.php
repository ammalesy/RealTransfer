<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_payment_terms extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_payment_terms', $array);
    }  
    function update($array,$pt_id)
    {
      $this->pdb->where('pt_id', $pt_id);
      $this->pdb->update('tb_payment_terms', $array); 
    }
    function fetch_all(){
        $query = $this->pdb->query("SELECT * 
                                   FROM tb_payment_terms 
                                   WHERE pt_sts_active = 'on' 
                                   ORDER BY pt_id ASC ");
        return $query->result();
    }
    function get_detail_by_id($pt_id){

      $query = $this->pdb->query("SELECT * 
                                FROM tb_payment_terms
                                WHERE pt_id = '".$pt_id."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_active_by_id($pt_id){

      $query = $this->pdb->query("SELECT * 
                                FROM tb_payment_terms
                                WHERE pt_sts_active = 'on' 
                                AND pt_id = '".$pt_id."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    
    function get_detail_by_unit_number($un_name){

      $query = $this->pdb->query("  SELECT * FROM tb_payment_terms 
                                    WHERE pt_name = '".$un_name."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    
    function get_by_name($pt_name)
    {
        return $this->pdb->where('pt_name', $pt_name)->get('tb_payment_terms')->result()[0];
    }
}

/* End of file tb_payment_terms.php */
/* Location: ./application/models/tb_payment_terms.php */