<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_fgf  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function record($array)
    {
      $this->pdb->insert('tb_fgf', $array);
    }
    
    function update_where($array,$where)
    {
      $this->pdb->update('tb_fgf', $array, $where);
    }
    
    function fetch_all_friend($project_id_sel){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM ".$this->project_database_sel.".tb_fgf , tb_project, tb_customer, tb_customer_personal_info
                                 WHERE pers_id = cus_pers_id
                                 AND fgf_cus_id1 = cus_id
                                 AND cus_sts_active = 'on'  
                                 AND pj_id = fgf_project_id 
                                 AND pj_id = '".$project_id_sel."'");
      return $query->result();
    }
    
    function get_friend_by_id($id){
      $this->load->database();
      $query = $this->pdb->query("  SELECT * 
                                    FROM tb_fgf,tb_contract,tb_booking,tb_quotation,tb_unit_number
                                    WHERE fgf_id = '".$id."'
                                    AND fgf_contract_code1 = ct_code
                                    AND ct_booking_code = bk_booking_code
                                    AND bk_quotation_code = qt_code
                                    AND qt_unit_number_id = un_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
}

/* End of file tb_quotation .php */
/* Location: ./application/models/tb_quotation .php */