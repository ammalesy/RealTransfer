<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_budget extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->load->database();
      $this->db->insert('tb_budget', $array);
    }
    // function update($array,$pj_id)
    // {
    //   $this->load->database();
    //   $this->db->where('pj_id', $pj_id);
    //   $this->db->update('tb_project', $array); 
    // }
    
    function fetch_all()
    {
          $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_budget ORDER BY id");
  
        return $query->result();
    }
    function get_budget_by_id($id)
    {
        $this->load->database();
        $query = $this->db->query("SELECT * FROM tb_budget WHERE id = ".$id."");
  
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }

}

/* End of file tb_budget.php */
/* Location: ./application/models/tb_budget.php */