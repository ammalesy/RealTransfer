<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_transfer_ownership extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_transfer_ownership', $array);
    }
    function update($array,$tr_code)
    {
      $this->pdb->where('tr_code', $tr_code);
      $this->pdb->update('tb_transfer_ownership', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_transfer_ownership', $array, $where);
    }
    
    function get_next_id()
    {
        $result = $this->pdb->select_max('tr_id')->get('tb_transfer_ownership')->result();
        foreach($result as $val)
            return empty($val->tr_id)?1:$val->tr_id+1;
    }
    
    function get_by_code($tr_code)
    {
        return $this->pdb->where('tr_code',$tr_code)->get('tb_transfer_ownership')->result()[0];
    }
    
    function fetch_transfer_ownership_by_project_id($pj_id)
    {
        $query = $this->pdb->query("
            SELECT *
            FROM tb_transfer_ownership
            LEFT JOIN tb_contract ON (ct_project_id = '$pj_id')
            LEFT JOIN $this->dbCommon.tb_customer_personal_info ON (ct_cus_id = pers_id)
            LEFT JOIN $this->dbCommon.tb_user_personal_info ON (ct_staff_id = user_pers_id)
            LEFT JOIN tb_unit_number ON (tr_unit_number_id = un_id)
            WHERE ct_code = tr_contract_code
            ORDER BY tr_id DESC
        ");
        return $query->result();
    }
    
    function get_by_ct_code($ct_code)
    {
        return $this->pdb->where('tr_contract_code',$ct_code)->get('tb_transfer_ownership')->result()[0];
    }
}
?>