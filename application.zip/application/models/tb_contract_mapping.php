<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_contract_mapping extends NZ_Model {

    function __construct()
    {
        parent::__construct();
    }
    
    function getMapping($ccode) {
        $this->pdb->where('cm_crm_code', $ccode);
        $query = $this->pdb->get('tb_contract_mapping');
        foreach( $query->result() as $result) {
            return $result->cm_rama9_code;
        }
        return NULL;
    }
    
    function getMappingByContractID($ccode) {
     $query = $this->pdb->query("SELECT *
                                 FROM tb_contract_mapping  
                                 WHERE cm_crm_code = '".$ccode."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
}
?>