<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_letter_referred extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_letter_refferred', $array);
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_letter_refferred', $array, $where);
    }
    function fetch_allFullInfo_by_lt_project_id($lt_project_id){
      $query = $this->pdb->query("SELECT 
                                 lt_letter_id,
                                 lt_referredfee_id,
                                 lt_ct_code,
                                 lt_contract_referfrom,
                                 lt_new_customer,
                                 lt_letter_date,
                                 lt_deadline,           
                                 lt_staffid,
                                 lt_project_id,
                                 lt_status,           
                                 lt_approve_by,
                                 lt_approve_date,
                                 pers_prefix,pers_fname,pers_lname,pers_email,pers_tel
                                  FROM tb_letter_referred 
                                  INNER  JOIN  ".$this->dbCommon.".tb_customer ON (lt_new_customer=cus_id)
                                  INNER JOIN ".$this->dbCommon.".tb_customer_personal_info ON (lt_new_customer=pers_id_cus)
                                  WHERE cus_sts_active = 'on' 
                                  AND lt_project_id = '".$lt_project_id."'");
      return $query->result();
    }
    function fetch_allFullInfo_by_lt_project_id_And_lt_referredfee_id($lt_project_id,$lt_referredfee_id){
      $query = $this->pdb->query("SELECT 
                                 lt_letter_id,
                                 lt_referredfee_id,
                                 lt_ct_code,
                                 lt_contract_referfrom,
                                 lt_new_customer,
                                 lt_letter_date,
                                 lt_deadline,           
                                 lt_staffid,
                                 lt_project_id,
                                 lt_status,           
                                 lt_approve_by,
                                 lt_approve_date,
                                 pers_prefix,pers_fname,pers_lname,pers_email,pers_tel
                                  FROM tb_letter_referred 
                                  INNER  JOIN  ".$this->dbCommon.".tb_customer ON (lt_new_customer=cus_id)
                                  INNER JOIN ".$this->dbCommon.".tb_customer_personal_info ON (lt_new_customer=pers_id_cus)
                                  WHERE lt_referredfee_id = '".$lt_referredfee_id."' 
                                  AND lt_project_id = '".$lt_project_id."'");
      return $query->result();
    }
    function get_new_letter_id()
    {

        $query = $this->pdb->query("SELECT COUNT(lt_letter_id) as newid  FROM tb_letter_referred
                                    WHERE  lt_project_id ='".$this->project_id_sel."'");
        $row = $query->result();
        $new_id = $row[0]->newid;
        if($new_id == NULL){ 
            return "1";
        }else{
            return ($new_id + 1);
        }
    }

}

/* End of file tb_letter_referred.php */
/* Location: ./application/models/tb_letter_referred.php */