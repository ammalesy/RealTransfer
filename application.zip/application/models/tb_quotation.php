<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_quotation  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_quotation ', $array);
    }
    function update($array,$qt_code)
    {
      $this->pdb->where('qt_code', $qt_code);
      $this->pdb->update('tb_quotation ', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_quotation', $array, $where);
    }
    function getDetail_by_id($qt_code){
      
      $query = $this->pdb->query("SELECT  * FROM tb_quotation WHERE qt_code = '".$qt_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function getDetail_by_id_withStatus_ON($qt_code){
     
      $query = $this->pdb->query("SELECT  * FROM tb_quotation  WHERE qt_code = '".$qt_code."' AND qt_status = 'on'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function getDetail_by_id_withStatus_OFF($qt_code){
     
      $query = $this->pdb->query("SELECT  * FROM tb_quotation  WHERE qt_code = '".$qt_code."' AND qt_status = 'off'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function getDetail_by_id_withProjectTable($qt_code){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM ".$this->project_database_sel.".tb_quotation , tb_project 
                                 WHERE pj_id = qt_project_id 
                                 AND qt_code = '".$qt_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function getDetail_by_ct_project_id_And_ct_cus_id_overload1($ct_project_id,$ct_cus_id){
    
      $query = $this->pdb->query("SELECT *
                                  FROM tb_quotation
                                  INNER JOIN tb_booking ON  (qt_code=bk_quotation_code)
                                  INNER JOIN tb_contract ON (bk_booking_code = ct_booking_code )
                                  WHERE ct_project_id ='".$ct_project_id."'          
                                  AND  ct_cus_id = '".$ct_cus_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function getDetail_by_ct_project_id_And_ct_cus_id($ct_project_id,$ct_cus_id){
    
      $query = $this->pdb->query("SELECT *
         FROM tb_quotation
         INNER JOIN tb_booking ON  (qt_code=bk_quotation_code)
         INNER JOIN tb_contract ON (bk_booking_code = ct_booking_code )
         INNER JOIN tb_unit_number ON (un_id=qt_unit_number_id)
         WHERE ct_project_id ='".$ct_project_id."' 
         AND  ct_cus_id = '".$ct_cus_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function getDetail_by_bk_booking_code_withBookingTable($bk_booking_code){
    
      $query = $this->pdb->query(" SELECT *
                                  FROM tb_booking  ,tb_quotation 
                                  WHERE bk_quotation_code = qt_code 
                                  AND  bk_booking_code = '".$bk_booking_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }

    function getDetail_by_ct_code_withContractTable($ct_code){
    
      $query = $this->pdb->query("SELECT *
                                  FROM tb_booking, tb_quotation ,tb_contract
                                  WHERE  bk_booking_code = ct_booking_code 
                                  AND bk_quotation_code =  qt_code
                                  AND ct_code = '". $ct_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function fetch_quotation_by_qt_unit_number_id($qt_unit_number_id,$project_id_sel){
 
      $query = $this->pdb->query("SELECT *
                                 FROM tb_booking ,  tb_quotation 
                                 WHERE qt_code = bk_quotation_code  
                                 AND bk_project_id = '".$project_id_sel."' 
                                 AND qt_unit_number_id = '".$qt_unit_number_id."'");
      return $query->result();
    }
   
    /*
    * Provide For DashBoard Module
    */
    function fetch_all_quotation($project_id_sel){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM ".$this->project_database_sel.".tb_quotation , tb_project, tb_customer, tb_customer_personal_info
                                 WHERE pers_id = cus_pers_id 
                                 AND cus_sts_active = 'on'  
                                 AND qt_leads_id = cus_id 
                                 AND pj_id = qt_project_id 
                                 AND pj_id = '".$project_id_sel."'
                                 ORDER BY qt_id DESC");
      return $query->result();
    }
    function get_last_quotation_lead(){
    
      $query = $this->pdb->query("SELECT qt_code,  qt_leads_id , qt_buliding_id
                                 FROM tb_quotation   
                                 order by  qt_code desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function count_qt_code(){
      
       $query = $this->pdb->query("SELECT  COUNT(qt_code)as quonumber 
                                  FROM tb_quotation ");
       $result = $query->result();
       return $result[0]->quonumber;
    }
    function get_new_id($qt_project_id){
       
       $query = $this->pdb->query("SELECT COUNT(qt_code) as newid  
                                  FROM tb_quotation   
                                  WHERE qt_project_id ='".$qt_project_id."'");
       $result = $query->result();
       return ($result[0]->newid) + 1;
    }
    
    function getDetail_by_ct_code_and_unit_code($ctCode, $unitCode){
    
      $query = $this->pdb->query("  SELECT * FROM tb_quotation 
                                    WHERE qt_leads_id = '".$ctCode."'
                                    AND	qt_unit_number_id = '".$unitCode."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function getDetail_over_due($ct_code){
    
      $query = $this->pdb->query("SELECT *
                                  FROM tb_booking, tb_quotation ,tb_contract, tb_unit_number, tb_unit_type, tb_floor, ".$this->dbCommon.".tb_customer_personal_info
                                  WHERE  bk_booking_code = ct_booking_code 
                                  AND bk_quotation_code =  qt_code
                                  AND qt_unit_number_id = un_id
                                  AND un_unit_type_id = unit_type_id
                                  AND qt_floor_id = fl_id
                                  AND qt_leads_id = pers_id
                                  AND ct_code = '". $ct_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_max_quo_date() {
        $query = $this->pdb->query("  SELECT DATE_FORMAT(max(qt_date),'%d / %m / %y') maxdatequo FROM tb_quotation");
        $result = $query->result();
        return $result[0]->maxdatequo;
    }

    function get_min_date () {
      $query = $this->pdb->query("SELECT min(qt_date) as minDate FROM `tb_quotation`");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
}

/* End of file tb_quotation .php */
/* Location: ./application/models/tb_quotation .php */