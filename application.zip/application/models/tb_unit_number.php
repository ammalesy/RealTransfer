<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_unit_number extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_unit_number', $array);
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_unit_number', $array, $where);
    }
    function get_detail_unit_withUnitTypeRoomTypeAndPrice_by_un_id($un_id){

      $query = $this->pdb->query("SELECT *
                                  FROM tb_unit_number 
                                  INNER JOIN tb_unit_type ON (un_unit_type_id=unit_type_id)
                                  INNER JOIN ".$this->dbCommon.".tb_room_type ON (unit_type_room_type_id=room_type_id)
                                  LEFT JOIN tb_price ON (pr_unit_number_id=un_id)
                                  WHERE un_id ='".$un_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_unit_withUnitTypeRoomType_by_un_id($un_id){

      $query = $this->db->query("SELECT *
                                  FROM tb_unit_number, tb_unit_type, ".$this->dbCommon.".tb_room_type
                                  WHERE unit_type_id = un_unit_type_id 
                                  AND unit_type_room_type_id = room_type_id 
                                  AND un_id =  '".$un_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function _get_detail_unit_withUnitTypeRoomType_by_un_id($un_id){

      $query = $this->pdb->query("SELECT *
                                  FROM tb_unit_number, tb_unit_type, ".$this->dbCommon.".tb_room_type
                                  WHERE unit_type_id = un_unit_type_id 
                                  AND unit_type_room_type_id = room_type_id 
                                  AND un_id =  '".$un_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_max_room_by_un_build_id($un_build_id){

      $query = $this->pdb->query("SELECT MAX( cn ) 
                                  FROM ( SELECT COUNT( un_id ) AS cn, un_floor_id, un_build_id
                                         FROM  tb_unit_number 
                                         WHERE un_build_id = '".$bid."'
                                         GROUP BY un_floor_id, un_build_id
                                        ) AS mx");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_unit_by_un_id($un_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_number  
                                 WHERE  un_id =  '".$un_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_unit_by_un_id_andBuildingID($un_id,$building_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_number
                                 LEFT JOIN tb_floor ON (un_floor_id = fl_id)
                                 WHERE un_id =  ".$un_id."
                                 AND un_build_id =  ".$building_id);
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_unit_by_un_id_withBuildingTable($un_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_number ,tb_building
                                 WHERE building_id = un_build_id 
                                 AND  un_id =  '".$un_id."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function fetch_full_unit_number(){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_number, tb_floor, tb_unit_type, tb_building
                                 WHERE un_floor_id = fl_id 
                                 AND  un_unit_type_id = unit_type_id 
                                 AND building_id = un_build_id 
                                 AND fl_sts_active = 'on' 
                                 AND unit_type_sts_active = 'on'  
                                 AND building_sts_active = 'on' 
                                 AND un_sts_active = 'on'
                                 order by building_name asc , 
                                          un_id asc, 
                                          fl_name asc");
      return $query->result();
    }
    function fetch_unit_by_un_build_id($un_build_id){

      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_number  
                                 WHERE  un_build_id =  '".$un_build_id."'");
      return $query->result();
    }
    function fetch_FullUnitDetail_by_un_build_id($un_build_id){

      $query = $this->pdb->query("SELECT un_id,un_name ,un_status_room,building_name,
                                        fl_name,unit_type_name,unit_type_area_sqm
                                 FROM tb_unit_number LEFT JOIN tb_building ON (un_build_id = building_id) 
                                                     LEFT JOIN tb_floor ON (fl_id = un_floor_id)
                                                     LEFT JOIN tb_unit_type ON (unit_type_id=un_unit_type_id)
                                  WHERE un_build_id = '".$un_build_id."' 
                                  ORDER BY ABS(fl_name) DESC,ABS(un_name) ASC");
      return $query->result();
    }
    
    function get_count_type_by_build_id_and_type($un_build_id, $type){

      $query = $this->pdb->query("SELECT COUNT(un_id) AS num_status
                                 FROM tb_unit_number LEFT JOIN tb_building ON (un_build_id = building_id) 
                                                     LEFT JOIN tb_floor ON (fl_id = un_floor_id)
                                                     LEFT JOIN tb_unit_type ON (unit_type_id=un_unit_type_id)
                                  WHERE un_build_id = '".$un_build_id."'
                                  AND un_status_room = '".$type."' 
                                  ORDER BY ABS(fl_name) DESC,ABS(un_name) ASC");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    
    function get_full_detail_unit_by_un_id($un_id){
      $databasecommonname = $this->dbCommon;

      $query = $this->pdb->query("SELECT *
                                 FROM tb_unit_number , tb_unit_type , $databasecommonname.tb_room_type
                                 WHERE unit_type_id =  un_unit_type_id 
                                 AND unit_type_room_type_id = room_type_id 
                                 AND un_id =  '".$un_id."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_un_id_by_un_buildAndun_name($un_build_id,$un_name){

      $query = $this->pdb->query("SELECT un_id 
                                  FROM tb_unit_number
                                  WHERE un_build_id = '".$un_build_id."' 
                                  AND TRIM(un_sts_active) ='on' 
                                  AND TRIM(un_status_room) ='Available' 
                                  AND TRIM(un_name)= '".trim($un_name)."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_room_NotAvailable($numberid,$bulidingid){

      $query = $this->pdb->query("SELECT un_id 
                                 FROM tb_unit_number 
                                 WHERE un_status_room != 'Available' 
                                 AND un_sts_active = 'on' 
                                 AND un_build_id = '".$bulidingid."' 
                                 AND un_id = '".$numberid."'");
      $row = $query->result();

      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_idAndName($un_build_id,$un_name){

      $query = $this->pdb->query("SELECT * 
                                 FROM tb_unit_number 
                                 WHERE un_sts_active = 'on' 
                                 AND un_build_id = '".$un_build_id."' 
                                 AND un_name = '".$un_name."'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    function count_un_id_by_un_build_id($un_build_id){
      $query = $this->pdb->query("SELECT COUNT(un_id) as row 
                                 FROM tb_unit_number 
                                 WHERE un_build_id = '".$un_build_id."' 
                                 AND un_sts_active ='on'");
      $row = $query->result();
      if(count($row) > 0){
        return $row[0];
      }else{
        return NULL;
      }
    }
    public function get_id_by_name($un_name) {
        return $this->pdb->where('un_name', $un_name)->get('tb_unit_number')->result()[0]->un_id;
    }
    
    function get_detail_by_un_name($un_name){
        $query = $this->pdb->query("SELECT *
                                     FROM tb_unit_number 
                                     WHERE un_name = '".$un_name."'");
        $row = $query->result();
        if(count($row) > 0){
        return $row[0];
        }else{
        return NULL;
        }
    }
    
    function get_count_unit_number(){
        $databasecommonname = $this->dbCommon;

        $query = $this->pdb->query("SELECT count(un_id) as count_un_id from tb_unit_number");
        $row = $query->result();

        if(count($row) > 0){
            return $row[0];
        }else{
            return NULL;
        }
    }
    
    function get_sum_unit_number_sqm(){
        $databasecommonname = $this->dbCommon;

        $query = $this->pdb->query("SELECT SUM(unit_type_area_sqm) AS sum_area_sqm FROM tb_unit_number,tb_unit_type 
                                    WHERE un_unit_type_id = unit_type_id");
        $row = $query->result();

        if(count($row) > 0){
            return $row[0];
        }else{
            return NULL;
        }
    }
    
    function get_detail_by_status($type){
        $databasecommonname = $this->dbCommon;

        $query = $this->pdb->query("SELECT * FROM tb_unit_number, tb_unit_type, tb_price
                                    WHERE un_status_room = '".$type."'
                                    AND un_unit_type_id = unit_type_id
                                    AND un_id = pr_unit_number_id");
        return $query->result();
    }
    //need buildig_id by un_name
    function get_building_id_by_name($un_name) {
        $this->pdb->where('un_name', $un_name);
        $query = $this->pdb->get('tb_unit_number');
        $result = $query->result();
        return $result[0]->un_build_id;
    }
    function get_detail_unit($un_id)
    {
        return $this->pdb->query("
            SELECT *
            FROM tb_unit_number
            INNER JOIN tb_unit_type ON (unit_type_id = un_unit_type_id)
            INNER JOIN tb_floor ON (fl_id = un_floor_id)
            INNER JOIN tb_building ON (building_id = un_build_id)
            WHERE un_id = $un_id
        ")->result()[0];
    }
    
    function get_count_avai(){

        $query = $this->pdb->query("SELECT count(*) AS count_avai FROM tb_unit_number");
        $row = $query->result();

        if(count($row) > 0){
            return $row[0]->count_avai;
        }else{
            return NULL;
        }
    }
    
    function get_total_size_room_sold(){

        $query = $this->db->query("SELECT room_type_id, un_id, room_type_name, sum(unit_type_area_sqm) Total_Size,
                                    count(unit_type_room_type_id) Total_room,
                                    min(pr_asking_price) min, max(pr_asking_price) max, sum(REPLACE(pr_asking_price, ',', '')) total_price,
                                    sum(REPLACE(pr_asking_price, ',', ''))/(sum(pr_asking_price)) price_sqm
                                    from ".$this->project_database_sel.".tb_unit_number LEFT JOIN ".$this->project_database_sel.".tb_unit_type ON (un_unit_type_id = unit_type_id)
                                    right JOIN tb_room_type ON (room_type_id = unit_type_room_type_id)
                                    LEFT JOIN ".$this->project_database_sel.".tb_price ON (pr_unit_number_id = un_id)
                                    group by room_type_id");
        return $query->result();
    }
    
    function get_balance_room_sqm_price($room_type_id){
        $query = $this->db->query("SELECT room_type_id, un_id, room_type_name, sum(unit_type_area_sqm) Total_Size,
                                    count(unit_type_room_type_id) Total_room, sum(REPLACE(pr_asking_price, ',', '')) total_price,
                                    sum(REPLACE(pr_asking_price, ',', ''))/(sum(pr_asking_price)) price_sqm,
                                    sum(REPLACE(pr_asking_price, ',', ''))/sum(unit_type_area_sqm) avg_pricr_sqm
                                    from ".$this->project_database_sel.".tb_unit_number LEFT JOIN ".$this->project_database_sel.".tb_unit_type ON (un_unit_type_id = unit_type_id and un_status_room = 'Available')
                                    right JOIN tb_room_type ON (room_type_id = unit_type_room_type_id)
                                    LEFT JOIN ".$this->project_database_sel.".tb_price ON (pr_unit_number_id = un_id)
                                    group by room_type_id");
        return $query->result();
    }
    
    function get_total_room_sold(){

        $query = $this->db->query("SELECT room_type_id, un_id, room_type_name, sum(unit_type_area_sqm) Total_Size,
                                    count(unit_type_room_type_id) Total_room, sum(REPLACE(pr_asking_price, ',', '')) total_price,
                                    sum(REPLACE(pr_asking_price, ',', ''))/(sum(pr_asking_price)) price_sqm
                                    from ".$this->project_database_sel.".tb_unit_number LEFT JOIN ".$this->project_database_sel.".tb_unit_type ON (un_unit_type_id = unit_type_id and un_status_room in ('Sold','booked'))
                                    right JOIN tb_room_type ON (room_type_id = unit_type_room_type_id)
                                    LEFT JOIN ".$this->project_database_sel.".tb_price ON (pr_unit_number_id = un_id)
                                    group by room_type_id");
        return $query->result();
    }
}

/* End of file tb_unit_number.php */
/* Location: ./application/models/tb_unit_number.php */