<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_customer_credit  extends NZ_Model {
    function __construct()
    {
        parent::__construct();
    }
    
    function record($data)
    {
        $this->db->insert('log_customer_credit', $data);   
    }
    
    function update($data, $id)
    {
        $this->db->where('cc_id', $id)->update('log_customer_credit', $data);   
    }
    
    function on($cus)
    {
        return $this->db->where('cc_status', 'on')->where('cc_cus_id', $cus)->get('log_customer_credit')->result()[0];
    }
}