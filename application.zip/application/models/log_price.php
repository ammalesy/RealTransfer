<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log_price extends NZ_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('log_price', $array);
    }
}

/* End of file log_price.php */
/* Location: ./application/models/log_price.php */