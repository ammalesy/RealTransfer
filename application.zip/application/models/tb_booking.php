<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_booking  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
      $this->pdb->insert('tb_booking', $array);
    }
    function update($array,$bk_booking_code)
    {
      $this->pdb->where('bk_booking_code', $bk_booking_code);
      $this->pdb->update('tb_booking', $array); 
    }
    function update_where($array,$where)
    {
      $this->pdb->update('tb_booking', $array, $where);
    }
    function get_detail_by_bk_quotation_code($bk_quotation_code){

      $query = $this->pdb->query("SELECT * FROM tb_booking 
                                  WHERE bk_quotation_code = '".$bk_quotation_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_bk_booking_code($bk_booking_code){

      $query = $this->pdb->query("SELECT * FROM tb_booking 
                                 WHERE bk_booking_code = '".$bk_booking_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_bk_booking_code_overload1($bk_booking_code){

      $query = $this->pdb->query("SELECT * FROM tb_booking 
                                  WHERE bk_booking_code = '".$bk_booking_code."'
                                  AND bk_project_id =  '".$this->project_id_sel."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_fullDetail_by_bk_booking_code($bk_booking_code){
      $this->load->database();
      $query = $this->db->query("SELECT *
                                 FROM ".$this->project_database_sel.".tb_booking , tb_customer, tb_customer_personal_info , tb_project
                                 WHERE pers_id = cus_pers_id 
                                 AND bk_leads_id = cus_id 
                                 AND bk_booking_code ='".$bk_booking_code."' 
                                 AND pj_id = bk_project_id");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_fullDetail_innerJoinQuotaion_by_booking_code($bk_booking_code){

      $query = $this->pdb->query("SELECT * 
                                 FROM tb_booking  
                                 INNER JOIN tb_quotation  ON (bk_quotation_code = qt_code)        
                                 WHERE bk_booking_code = '".$bk_booking_code."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function get_detail_by_building_id($building_id){

      $query = $this->pdb->query("SELECT * FROM tb_booking 
                                 WHERE building_id = '".$building_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function fetch_all_ststusON(){
      $query = $this->pdb->query("SELECT *  
                                  FROM tb_booking 
                                  WHERE  bk_status = 'on' ORDER BY bk_booking_code ASC");
      return $query->result();
    }
    function fetch_all_by_bk_booking_codeAndbk_project_id($bk_booking_code,$bk_project_id){

      $query = $this->pdb->query("SELECT bk_booking_code, bk_quotation_code, pers_lname, pers_fname  , bk_contract_date, bk_letter_warning
                                  FROM tb_booking, ".$this->dbCommon.".tb_customer, 
                                        ".$this->dbCommon.".tb_customer_personal_info
                                  WHERE pers_id = cus_pers_id 
                                  AND bk_leads_id = cus_id 
                                  AND bk_booking_code = '".$bk_booking_code."'
                                  AND bk_project_id = '".$bk_project_id."'");
      return $query->result();
    }
    function fetch_all_by_ct_codeAndbk_project_id($ct_code,$bk_project_id){

      $query = $this->pdb->query("SELECT bk_booking_code, bk_quotation_code, pers_lname, pers_fname  , bk_contract_date, bk_letter_warning  ,c.*
                                  FROM tb_booking, ".$this->dbCommon.".tb_customer,".$this->dbCommon.".tb_customer_personal_info, tb_contract c
                                  WHERE 
                                  pers_id = cus_pers_id
                                   AND cus_pers_id = cus_id  
                                   AND  bk_booking_code = ct_booking_code
                                   AND  ct_cus_id = cus_id
                                   AND  ct_code = '".$ct_code."'  
                                   AND  bk_project_id = '".$bk_project_id."'");
      return $query->result();
    }
    function getBookingInfo_by_ct_codeAndbk_project_id($ct_code,$bk_project_id){

      $query = $this->pdb->query("SELECT bk_booking_code, bk_quotation_code, pers_lname, pers_fname  , bk_contract_date, bk_letter_warning  ,c.*
                                  FROM tb_booking, ".$this->dbCommon.".tb_customer,".$this->dbCommon.".tb_customer_personal_info, tb_contract c
                                  WHERE 
                                  pers_id = cus_pers_id
                                   AND cus_pers_id = cus_id  
                                   AND  bk_booking_code = ct_booking_code
                                   AND  ct_cus_id = cus_id
                                   AND  ct_code = '".$ct_code."'  
                                   AND  bk_project_id = '".$bk_project_id."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function fetch_all_BookingInfoSms_byProjectID($pj_id){
        $query = $this->db->query("
            SELECT distinct bk_booking_code,bk_quotation_code, 
            pers_lname, pers_fname  ,bk_contract_date,bk_letter_warning,
            bk_status ,bk_leads_id  ,pers_mobile,pers_tel,pers_email,bk_remark,
            bk_transfer_to,bk_transfer_letter,bk_money_amount,
            sms_booking_code
            FROM $this->project_database_sel.tb_booking 
            INNER JOIN tb_customer ON (bk_leads_id = cus_id)  
            INNER JOIN tb_customer_personal_info ON (pers_id = cus_pers_id)
            LEFT JOIN  $this->project_database_sel.tb_sms ON (sms_booking_code = bk_booking_code)
            WHERE bk_status ='on'
            AND `bk_project_id` = '$pj_id'
        ");
        return $query->result();
    }
    function fetch_all_BookingInfoEmail_byProjectID($pj_id){
        $query = $this->db->query("
            SELECT distinct bk_booking_code,bk_quotation_code, 
            pers_lname, pers_fname  ,bk_contract_date,bk_letter_warning,
            bk_status ,bk_leads_id  ,pers_mobile,pers_tel,pers_email,bk_remark,
            bk_transfer_to,bk_transfer_letter,bk_money_amount,email_booking_code
            FROM $this->project_database_sel.tb_booking 
            INNER JOIN tb_customer ON (bk_leads_id = cus_id)  
            INNER JOIN tb_customer_personal_info ON (pers_id = cus_pers_id)
            LEFT JOIN  $this->project_database_sel.tb_email ON (email_booking_code = bk_booking_code)
            WHERE bk_status ='on'
            AND `bk_project_id` = '$pj_id'
        ");
        return $query->result();
    }
    function fetch_all_BookingInfoSms_byProjectID__overload1($pj_id){
        $query = $this->db->query("
            SELECT distinct bk_booking_code,bk_quotation_code, 
                pers_lname, pers_fname  ,bk_contract_date,bk_letter_warning,
                bk_status ,bk_leads_id  ,pers_mobile,pers_tel,pers_email,bk_remark,
                bk_transfer_to,bk_transfer_letter,bk_money_amount,
                sms_booking_code
            FROM $this->project_database_sel.tb_booking  
            INNER JOIN tb_customer_personal_info ON (bk_leads_id = pers_id_cus)
            LEFT JOIN  $this->project_database_sel.tb_sms ON (sms_booking_code = bk_booking_code)
            WHERE bk_status ='on'
            AND `bk_project_id` = '$pj_id'
        ");
        return $query->result();
    }
    
    function fetch_all_BookingInfo_byProjectID($pj_id){
        $query = $this->db->query("
            SELECT DISTINCT bk_booking_code, bk_quotation_code, bk_contract_date, bk_status, bk_leads_id, bk_transfer_letter,
                cp.pers_lname, cp.pers_fname, cp.pers_mobile, cp.pers_tel, cp.pers_email,
                CONCAT(tp.pers_fname,' ',tp.pers_lname) AS old_name, tp.pers_mobile AS old_mobile,
                tp.pers_tel AS old_tel, tp.pers_email AS old_email
            FROM ".$this->project_database_sel.".tb_booking
            INNER JOIN tb_customer_personal_info cp ON (cp.pers_id_cus = bk_leads_id)
            LEFT JOIN $this->project_database_sel.tb_transferred
                ON (tf_old_booking = bk_booking_code AND tf_old_contract IS NULL)
            LEFT JOIN tb_customer_personal_info tp ON (tp.pers_id_cus = tf_old_customer)
            WHERE  bk_project_id = '".$pj_id."'
            GROUP BY bk_booking_code
            ORDER BY bk_booking_code DESC
        ");
        return $query->result();
    }

    function fetch_all_BookingInfo_Overdue_byProjectID($pj_id){
      $this->load->database();
      $query = $this->db->query("SELECT distinct bk_booking_code,bk_quotation_code, pers_lname, pers_fname  ,bk_contract_date,bk_letter_warning, bk_call_remark,
                                        bk_status ,bk_leads_id  ,pers_mobile,pers_tel,pers_email,bk_remark,bk_transfer_to,bk_transfer_letter,bk_money_amount
                                 FROM ".$this->project_database_sel.".tb_booking  
                                      INNER JOIN tb_customer ON (bk_leads_id = cus_id)  
                                      INNER JOIN tb_customer_personal_info ON (pers_id = cus_pers_id)
                                 WHERE  bk_project_id = '".$pj_id."'
                                 AND CURDATE() > bk_contract_date
                                 AND bk_status = 'on'
                                 ORDER BY bk_booking_code DESC ");
      return $query->result();
    }

    function fetch_all_BookingInfoContract_byProjectID($pj_id){
        $this->load->database();
        $query = $this->db->query("
            SELECT  bk_quotation_code, bk_booking_code,
                ct_code, ct_type, ct_date, ct_paid, ct_active, ct_pdf,
                cp.pers_mobile, cp.pers_tel, cp.pers_email, CONCAT(cp.pers_fname,' ',cp.pers_lname) AS pers_name,
                CONCAT(tp.pers_fname,' ',tp.pers_lname) AS old_name, tp.pers_mobile AS old_mobile,
                tp.pers_tel AS old_tel, tp.pers_email AS old_email
            FROM ".$this->project_database_sel.".tb_booking  
            INNER JOIN ".$this->project_database_sel.".tb_contract  ON (ct_booking_code = bk_booking_code)
            INNER JOIN tb_customer_personal_info cp ON (cp.pers_id_cus = SUBSTRING_INDEX(ct_cus_id, ',', 1))
            LEFT JOIN ".$this->project_database_sel.".tb_transferred ON (tf_old_contract = ct_code)
            LEFT JOIN tb_customer_personal_info tp ON (tp.pers_id_cus = SUBSTRING_INDEX(tf_old_customer, ',', 1))
            WHERE bk_project_id = '$pj_id'
            GROUP BY ct_code
            ORDER BY ct_code desc
        ");
        return $query->result();
    }
    function getBookingInfo_byBookingCode($bookingcode){
        $this->load->database();
        $query = $this->db->query("
            SELECT *
            FROM $this->project_database_sel.tb_receipt_temporary,
                 $this->project_database_sel.tb_booking,
                 tb_customer, tb_customer_personal_info, tb_project
            WHERE pers_id = cus_pers_id 
            AND rc_customer_id = cus_id
            AND bk_booking_code ='".$bookingcode."' 
            AND  pj_id = bk_project_id
            AND bk_booking_code = rc_booking_code
            AND rc_payfor = 'Booking Fee'
        ");
            $result = $query->result();
            if(count($result) > 0){
                return $result[0];
            }else{
                return NULL;
            }
    }

    function getBookingInfo_byBookingCode_andProjectID($bk_booking_code,$project_id_sel)
    {
      $this->load->database();
      $query = $this->db->query("SELECT distinct bk_booking_code,
                                                 pers_prefix, pers_lname, pers_fname  ,
                                                 bk_leads_id ,pers_mobile,pers_tel,pers_email,bk_money_amount
                                  FROM ".$this->project_database_sel.".tb_booking                
                                  INNER JOIN tb_customer_personal_info ON (bk_leads_id = pers_id_cus)                
                                  WHERE TRIM(bk_booking_code) ='".trim($bk_booking_code)."'
                                  AND bk_project_id = '".$project_id_sel."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    function getBookingInfo_byBookingCode_andProjectID_overload1($bk_booking_code,$project_id_sel){
      $this->load->database();
      $query = $this->db->query("SELECT distinct bk_booking_code,bk_contract_date,qt_unit_number_id,
                                                pers_prefix, pers_lname, pers_fname  ,
                                                bk_leads_id ,pers_mobile,pers_tel,pers_email,bk_money_amount
                                  FROM ".$this->project_database_sel.".tb_booking`                   
                                  INNER JOIN tb_customer_personal_info ON (bk_leads_id = pers_id_cus)    
                                  INNER JOIN ".$this->project_database_sel.".tb_quotation ON (bk_quotation_code=qt_code)
                                  WHERE bk_booking_code ='".$bk_booking_code."'
                                  AND bk_project_id = '".$project_id_sel."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }

    function get_new_booking_id($bk_project_id)
    {

        $query = $this->pdb->query("SELECT MAX(bk_booking_id) as newid  
                                   FROM tb_booking   
                                   WHERE  bk_project_id = '".$bk_project_id."'");
        $row = $query->result();
        $new_id = ($row[0]->newid + 1);
        if($new_id == NULL){ 
            return "1";
        }else{
            return $new_id;
        }
    }
    /*
    * Provide For DashBoard Module
    */
    function count_booking_code(){

      $query = $this->pdb->query("SELECT COUNT(bk_booking_code) as bookingnumber  
                                 FROM tb_booking ");
      $result = $query->result();
      return $result[0]->bookingnumber;
    }
    function get_last_bookingContract(){

      $query = $this->pdb->query("SELECT bk_booking_code , bk_contract_date  
                                FROM tb_booking   
                                order by bk_booking_code desc");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_booking_by_unit_name($unit){

      $query = $this->pdb->query("SELECT *
                            FROM tb_booking
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            LEFT JOIN tb_unit_number ON (un_id = qt_unit_number_id)
                            WHERE un_name ='".$unit."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_booking_by_bk_code($bkCode){

      $query = $this->pdb->query("SELECT *
                            FROM tb_booking
                            INNER JOIN tb_quotation ON (qt_code=bk_quotation_code)
                            LEFT JOIN tb_unit_number ON (un_id = qt_unit_number_id)
                            WHERE bk_booking_code = '".$bkCode."'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_detail_for_chart_overdue_contract($start, $end, $cusID, $unID)
    {
        $this->load->database();
      	$query = $this->pdb->query("    SELECT * FROM tb_booking, tb_quotation
                                        WHERE (bk_contract_date BETWEEN  '".$start."' AND '".$end."')
                                        AND bk_quotation_code = qt_code
                                        ".$unID."
                                        ".$cusID."");
      	return $query->result();
    }
    
    function get_sum_price_booking(){

      $query = $this->pdb->query("SELECT sum(rc_total_amount) Total_amount
                            FROM ".$this->project_database_sel.".tb_booking, ".$this->project_database_sel.".tb_receipt_offical 
                            WHERE rc_booking_code = bk_booking_code 
                            AND rc_payfor = 'Booking Fee' 
                            AND rc_status = 'on'");
      $result = $query->result();
      if(count($result) > 0){
        return $result[0];
      }else{
        return NULL;
      }
    }
    
    function get_booking_by_date($start, $end) {
      	$query = $this->pdb->query("    SELECT * FROM tb_booking
                                        WHERE (bk_date_booking BETWEEN  '".$start."' AND  '".$end."')
                                        AND bk_status != 'cancelled'");
      	return $query->result();
    }
    
    function get_max_book_date() {
        $query = $this->pdb->query("  SELECT DATE_FORMAT(max(bk_date_booking),'%d / %m / %y') maxdatebook FROM tb_booking");
        $result = $query->result();
        return $result[0]->maxdatebook;
    }
}

/* End of file tb_booking.php */
/* Location: ./application/models/tb_booking .php */