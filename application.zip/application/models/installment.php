<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Installment extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function fetch_all_installment($project_id_sel){
      $this->load->database();
      $query = $this->db->query(" SELECT *
                                  FROM ".$this->project_database_sel.".tb_booking  , ".$this->project_database_sel.".tb_contract  , tb_customer ,  tb_customer_personal_info
                                  WHERE ct_cus_id = cus_id 
                                  AND cus_sts_active = 'on' 
                                  AND cus_pers_id = pers_id 
                                  AND ct_active = 'on' 
                                  AND ct_booking_code = bk_booking_code 
                                  AND bk_project_id = '".$project_id_sel."'"); 
      return $query->result();
     
    }

}

/* End of file installment.php */
/* Location: ./application/models/installment.php */