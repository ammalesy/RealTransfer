<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tb_bank  extends NZ_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function record($array)
    {
        $this->db->insert('tb_bank', $array);
    }
    function get_next_id()
    {
        $this->db->select_max('b_id');
        return $this->db->get('tb_bank')->result()[0]->b_id + 1;
    }
    function get_all_bank()
    {
        $query = $this->db->query("SELECT *
                                   FROM tb_bank");
        $result = $query->result();
        if(count($result) > 0){
            return $result;
        }else{
            return NULL;
        }
    }
    
    function get_bank_from_id($id)
    {
        $query = $this->db->query("SELECT *
                                   FROM tb_bank
                                   WHERE b_id = '".$id."'");
        $result = $query->result();
        if(count($result) > 0){
            return $result[0];
        }else{
            return NULL;
        }
    }
    function get_id_by_name_th($name)
    {
        $this->db->where('bank_name_th', $name);
        return $this->db->get('tb_bank')->result()[0]->b_id;
    }
    
    function get_id_by_abbreviation($name)
    {
        $this->db->where('bank_abbreviation', $name);
        return $this->db->get('tb_bank')->result()[0]->b_id;
    }
}
?>