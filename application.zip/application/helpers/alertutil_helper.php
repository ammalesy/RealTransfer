<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
* AlertUtil Helpers
*
* @package		AlertUtil
* @author     Ammales Yansompong < usegame14@gmail.com >
*/

// ------------------------------------------------------------------------
/**
  * Standard alert helper
  *
  * Helps alert message to browser screen
  *
  * @access		public
  * @param		string    the message of the detail alert message
  * @return		string    Display alert message
  */

function alert($message)
{
	  echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
    echo "<script>javascript:alert('".$message."');</script>";
}
function alert_redirect($message,$uri)
{
    echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
    echo "<script>javascript:alert('".$message."'); window.location = '".BASE_URL.$uri."'</script>";
}