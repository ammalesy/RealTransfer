<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class NZ_Controller extends Base_Controller{

	var $user_id = NULL;
    var $user_username = NULL;
	var $user_permission = NULL;
    var $project_id_sel = NULL;
    var $project_name_sel = NULL;
    var $project_database_sel = NULL;
    var $project_image_sel = NULL;
    var $common_database = NULL;
    var $pdb = NULL;
    var $m_conn = NULL;
    var $m_trans_status = TRUE;
    var $language = 'TH';

    /*---Variable for parse data to view.*/
    var $data = array();

	function __construct()
    {
        parent::__construct();
        $this->refreshSession();
        $this->pdb = $this->load->database('project_selected', TRUE);
        
        $ses = $this->session->all_userdata();
        if( $this->session->userdata('user_id') !== FALSE ) {
            $this->load->model('log_authentication');
            $auth = $this->log_authentication->get_last_by_user_id($ses['user_id']);
            if($auth->at_ip !== $ses['ip_address']) {
                $this->session->sess_destroy();
                alert_redirect('Sign into account from another device.','/authen');
                exit;
            }
        }
        
        if( !empty($this->session->userdata('language')) ) {
            $this->language = $this->session->userdata('language');
        }
    }
    protected function load_3rdParty($lib){
        include("application/third_party".$lib);
    }
    protected function generateSession($user_id,$user_username,$user_permission){
		
		$sessionData = array(
                   'user_id' => $user_id,
                   'user_username' => $user_username,
                   'user_permission' => $user_permission
               );

		$this->session->set_userdata($sessionData);
		$this->refreshSession();
        
        $ses = $this->session->all_userdata();
        $this->load->model('log_authentication');
        $data = array(
            'at_ip' => $ses['ip_address'],
            'at_user_id' => $user_id,
            'at_agent' => $ses['user_agent']
        );
        $this->log_authentication->record($data);
	}
    protected function checkSessionTimeout(){
    	if($this->session->userdata('user_id') == NULL){
    		redirect('/authen','refresh'); 
    	}
    }
    protected function manualDataBase($query){
        $this->load->database();
        $hostnameorservername = $this->db->hostname;
        $serverusername = $this->db->username;
        $serverpassword = $this->db->password;

        $conn = mysql_connect($hostnameorservername, $serverusername, $serverpassword);
        mysql_select_db($this->db->database);    
        mysql_query($query);
    }
    protected function manualProjectDataBase($query){
        $dbp = $this->load->database('project_selected', TRUE);
        $hostnameorservername = $dbp->hostname;
        $serverusername = $dbp->username;
        $serverpassword = $dbp->password;

        $this->manualConnection = mysql_connect($hostnameorservername, $serverusername, $serverpassword);
        mysql_select_db($dbp->database);  
        mysql_query($query);
    }
    protected function refreshSession(){
    	$this->user_id = $this->session->userdata('user_id');
        $this->user_permission = $this->session->userdata('user_permission');
        $this->project_id_sel = $this->session->userdata('project_id_sel');
        $this->project_name_sel = $this->session->userdata('project_name_sel');
        $this->project_database_sel = $this->session->userdata('project_database_sel');
        $this->project_image_sel = $this->session->userdata('project_image_sel');
        $this->user_username = $this->session->userdata('user_username');
        $this->load->database();
        $this->common_database = $this->db->database;
    }
    protected function send_to_view($key,$data){
        $this->data[$key] = $data;
    }
    public function upload_image($attribute_file_form,$folder,$newName){
        
        $folderName = "./Images/".$folder;
 
        if(!is_dir($folderName))
        {
           mkdir($folderName,0777,TRUE);
        }

        $config['upload_path'] = $folderName."/";
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '500';
        $config['max_width']  = '4096';
        $config['max_height']  = '2160';
        $config['file_name'] = $newName;


        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if ($attribute_file_form == NULL) {
            $result_upload = $this->upload->do_upload();
        }else{
            $result_upload = $this->upload->do_upload($attribute_file_form);
        }
        if (!$result_upload)
        {
            $result['error_message'] = $this->upload->display_errors();
            $result['error_status'] = TRUE;        
        }else{
            $result['error_status'] = FALSE;
            $file_details = $this->upload->data();
            $result['image_url'] = "Images/".$folder."/".$file_details['file_name'];
        }
        return $result;

    }
    public function upload_multiple_image($attribute_file_form,$index,$folder,$newName){
        return $this->upload_image($this->parse_multi($_FILES[$attribute_file_form],$index),$folder,$newName);  
    }
    public function parse_multi($file,$index){
            $_FILES['Image[]']['name'] = $file['name'][$index];
            $_FILES['Image[]']['type'] = $file['type'][$index];
            $_FILES['Image[]']['tmp_name'] = $file['tmp_name'][$index];
            $_FILES['Image[]']['error'] = $file['error'][$index];
            $_FILES['Image[]']['size'] = $file['size'][$index];
            return 'Image[]';
    }
    public function isEmptyFile($attr){
        if (empty($_FILES[$attr]['name'])) {
            return TRUE;
        }else{
            return FALSE;
        }
    }
    public function mysql_connection_common_db(){
        $this->load->database();
        $hostnameorservername = $this->db->hostname;
        $serverusername = $this->db->username;
        $serverpassword = $this->db->password;
        $dbname = $this->db->database;
        mysql_connect($hostnameorservername, $serverusername, $serverpassword);
        mysql_select_db($dbname);
    }
    public function mysql_connection_pj_db(){
        
        $hostnameorservername = $this->pdb->hostname;
        $serverusername = $this->pdb->username;
        $serverpassword = $this->pdb->password;
        $dbname = $this->pdb->database;
        mysql_connect($hostnameorservername, $serverusername, $serverpassword);
        mysql_select_db($dbname);
    }
    //////// PERMISSION //////
    //////////////////////////
    protected function get_user_permission()
    {
        $this->load->model('tb_permission');
        return $this->tb_permission->get_user_permission($this->user_id);
    }
    
    public function LoadView ($view, $data) {
        $this->checkSessionTimeout();
		/////////////////////////////
		/////////////////////////////
		$data['permission'] = $this->get_user_permission();
		
        $this->load->view('header',$data);
        $this->load->view('menu', $data);
		$this->load->view($view, $data);
        $this->load->view('footer', $data);
    }

}
