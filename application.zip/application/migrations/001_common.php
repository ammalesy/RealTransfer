<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Add_blog extends CI_Migration {

	public function up()
	{
		$this->dbforge->add_field(array(
			'AMPHUR_ID' => array(
				'type' => 'INT',
				'constraint' => 5,
				'auto_increment' => TRUE
			),
			'AMPHUR_CODE' => array(
				'type' => 'VARCHAR',
				'constraint' => '4'
			),
			'AMPHUR_NAME' => array(
				'type' => 'VARCHAR',
                'constraint' => '150'
			),
            'AMPHUR_NAME_ENG' => array(
				'type' => 'VARCHAR',
                'constraint' => '150'
			),
            'GEO_ID' => array(
				'type' => 'INT',
                'constraint' => '5',
                'default' => 0
			),
            'PROVINCE_ID' => array(
				'type' => 'INT',
                'constraint' => '5',
                'default' => 0
			),
		));
        $this->dbforge->add_key('AMPHUR_ID', TRUE);
		$this->dbforge->create_table('amphur');
	}

	public function down()
	{
		$this->dbforge->drop_table('amphur');
	}
}
?>