<?php

 $html = '
 
<style>
.tablefone{
  font-size:12px;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:justify;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}
table.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}
td.no-line {
    border-bottom-width:1px;
    border-top-width:1px;
    border-left-width:1px;
    border-right-width:1px;
    border-style: solid;
    border-color: #FFF #FFF #FFF #FFF;
  }
</style>

<table width="700" border="0" align="center"  cellspacing="0">
    <tr>
        <td align="center" colspan="4"><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
	<tr>
		<td align="center" colspan="4" ><h5>หนังสือจองซื้อห้องชุด</h5></td>
	</tr>
	<tr>
		<td align="center" colspan="4" ><h5>โครงการ '.$pj_name.'</td>
	</tr>
</table>
<br>
<table width="700" border="0"  align="center"  cellspacing="5">
	<tr>
    	<td width="400px"><!--หนังสือจองเลขที่ <span class="under">&nbsp;&nbsp;'.$bid.'&nbsp;&nbsp;--></td>
    	<td width="100px" align="right">ทำที่  : </td>
    	<td style="border-bottom-width:1px; border-bottom-style:solid;" width="200px">สำนักงานขายโครงการ</td>
  	</tr>
  	<tr>
    	<td width="400px">&nbsp;</td>
    	<td width="150px" align="right">วันที่ : </td>
    	<td style="border-bottom-width:1px; border-bottom-style:solid;" width="150px">'.$DateFormat->thaiDate(date('Y-m-d',strtotime($dateBooking))).' </td>
  	</tr>
</table>
<br>
<table  width="750px" border="0" cellpadding="0" cellspacing="0">
  	<tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="120"><pre><b>กรณีบุคคลธรรมดา</b></pre></td>
    	<td style="border-bottom-width:0px; border-bottom-style:solid;" width="47"><pre>ข้าพเจ้า</pre></td>
    	<td style="border-bottom-width:1px; border-bottom-style:solid;" width="268"><pre> '.$pers_prefix.' '.$pers_fname.' '.$pers_lname.'</pre></td>
    	<td style="border-bottom-width:0px; border-bottom-style:solid;" width="42"><pre>(ผู้จอง)</pre></td>
		<td style="border-bottom-width:0px; border-bottom-style:solid;" width="23"><pre>อายุ</pre></td>
		<td style="border-bottom-width:1px; border-bottom-style:solid;" width="43" align="center"><pre>'.$age.'</pre></td>
		<td style="border-bottom-width:0px; border-bottom-style:solid;" width="15"><pre>ปี</pre></td>
		<td style="border-bottom-width:0px; border-bottom-style:solid;" width="48"><pre>สัญชาติ</pre></td>
		<td style="border-bottom-width:1px; border-bottom-style:solid;" width="94" align="center"><pre>'.$nationality.'</pre></td>
  	</tr>
</table>

<table width="750px" border="0" cellpadding="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="130px"><pre><b>ที่อยู่ตามทะเบียนบ้าน : </b></pre></td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="620px">'.$getaddress->addr_address.'</td>
    <tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="69">ตำบล/แขวง</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">'.$getaddress->addr_sub_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="64" >อำเภอ/เขต</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">'.$getaddress->addr_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="49">จังหวัด</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="169" align="center">'.$getaddress->addr_province.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="43">ประเทศ</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="146" align="center">'.$country.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="76">รหัสไปรษณีย์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="158" align="center">'.$getaddress->addr_post_code.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="96">โทรศัพท์(มือถือ)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="184" align="center">'.$getaddress->pers_mobile.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">(บ้าน)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="106" align="center">'.(!empty($getaddress->pers_tel)?$getaddress->pers_tel:'-').'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="61">(ที่ทำงาน)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="107" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">แฟกซ์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="108" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30">อีเมล์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="201" align="center">'.(!empty($getaddress->pers_email)?$getaddress->pers_email:'-').'</td>
    </tr>
</table>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="110px" ><b>ที่อยู่สำหรับติดต่อ : </b></td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="640px" >
        (เฉพาะกรณีแตกต่างกับที่อยู่ตามทะเบียนบ้าน)&nbsp;&nbsp;'.$getaddresscur->addr_cur_address.'
        </td>
    <tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="69">ตำบล/แขวง</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">'.$getaddresscur->addr_cur_sub_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="64">อำเภอ/เขต</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">'.$getaddresscur->addr_cur_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="49">จังหวัด</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="169" align="center">'.$getaddresscur->addr_cur_province.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="43">ประเทศ</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="289" align="center">'.$country.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="76">รหัสไปรษณีย์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="309" align="center">'.$getaddresscur->addr_cur_post_code.'</td>
    </tr>
</table>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="468"><b>กรณีเป็นนิติบุคคล</b> ข้าพเจ้า (<input type="checkbox"> บริษัท <input type="checkbox"> ห้างหุ้นส่วนจำกัด <input type="checkbox"> คณะบุคคล)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="263" align="center"> - </td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="24">โดย</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="393" align="center"> - </td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" align="right" width="307">กรรมการผู้มีอำนาจ / หุ้นส่วนผู้จัดการ / ผู้รับมอบอำนาจ</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="130px" ><b>สำนักงานตั้งอยู่เลขที่ : </b></td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="620px" align="center">-</td>
    <tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="69">ตำบล/แขวง</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="64">อำเภอ/เขต</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="49">จังหวัด</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="169" align="center">-</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="43">ประเทศ</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="146" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="76">รหัสไปรษณีย์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="158" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="96">โทรศัพท์(มือถือ)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="184" align="center">-</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">(บ้าน)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="106" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="61">(ที่ทำงาน)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="107" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">แฟกซ์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="108" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30">อีเมล์</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="201" align="center">-</td>
    </tr>
    
</table>
<table><tr><td height="90">
<pre>ซึ่งต่อไปในหนังสือจองนี้จะเรียกว่า “ผู้จอง” มีความประสงค์ทำหนังสือจองนี้ไว้กับ <b>บริษัท กีธา พร็อพเพอร์ตี้ส์ จำกัด</b>
ซึ่งต่อไปในหนังสือจองนี้จะเรียกว่า “บริษัทฯ” ตามรายละเอียด ดังนี้</pre>
</td></tr></table>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="340" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;โดยหนังสือจองนี้ ผู้จองตกลงจองซื้อห้องชุดในโครงการ</td>
        <td >'.$pj_name.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">จำนวน</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">1</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="100px">ห้อง&nbsp;&nbsp;ห้องชุดเลขที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$un_name.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">(รหัสห้องชุด</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$unit_type_name.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">) ชั้นที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$Floorname.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">อาคาร</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$building_name.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td>พื้นที่ห้องชุด (รวมพื้นที่ระเบียง/พื้นที่ทรัพย์ส่วนบุคคลทั้งภายในและภายนอกห้องชุด/พื้นที่อื่นๆ ที่ต่อเนื่องกับห้องชุด ตามที่ปรากฎในหนังสือโอนกรรมสิทธิ์ห้องชุด)</td>
    </tr>
</table>
<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>ผู้จอง</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px">ประมาณ</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$unit_type_area_sqm.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="205px">ตารางเมตร (ต่อห้องชุด) ในราคาทั้งสิ้น</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.number_format($qt_unit_price,2).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">บาท</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td width="5">(</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$Currency->bahtThai(trim($qt_unit_price)).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="252px" align="right">)&nbsp;&nbsp;และตกลงชำระเงินมัดจำเพื่อการจองซื้อห้องชุด</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="60px">เป็นจำนวนเงิน</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.number_format($BookingFee,2).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="37px">บาท&nbsp;(</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$Currency->bahtThai(trim($BookingFee)).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="133px" align="right">)&nbsp;&nbsp;ตกลงจ่ายเงินทำสัญญา</td>
    </tr>
</table>


<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="42">จำนวน</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="136" align="center">'.number_format($ContractFee,2).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="25">บาท</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="213" align="center">'.$Currency->bahtThai(trim($ContractFee)).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="294">โดยชำระเป็น</td>
    </tr>
</table>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40"><input name="input" type="checkbox" value="" '.$flagCash.'/></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="90">เงินสด จำนวน</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="212" align="center" align="center">'.(!empty($moneyCash)?number_format($moneyCash,2):"").'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="355">บาท</td>
    </tr>
</table>
';

$i = 0;
foreach($credit_bank as $key=>$value) {

$creditno = substr_replace($this->encrypt->decode($credit_no[$key]),"xxxxxxxx",4,8);


    $html .= '
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="140px">'.(($i++ == 0)?'<input name="input" type="checkbox" value="" '.$flagCrCard.' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บัตรเครดิต ':'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บัตรเครดิต ').'</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="200px" align="center">'.$credit_holder[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">ประเภท</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="150px" align="center">'.$credit_type[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">ธนาคาร</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="150px" align="center">'.$credit_bank[$key].'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="81">หมายเลขบัตร</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="164" align="center">'.$creditno.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="41">ลงวันที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="151" align="center">'.$crdate[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="42">จำนวน</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="145" align="center">'.(!empty($moneyCrCard[$key])?number_format($moneyCrCard[$key],2):"").'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="25">บาท</td>
    </tr>
</table>
';
}
if($i==0)
    $html .= '
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="140px">'.(($i++ == 0)?'<input name="input" type="checkbox" value="" '.$flagCrCard.' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บัตรเครดิต ':'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;บัตรเครดิต '.$i++.'.').'</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="200px" align="center"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">ประเภท</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="150px" align="center"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">ธนาคาร</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="150px" align="center">'.$credit_bank[$key].'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="80px">หมายเลขบัตร</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$this->encrypt->decode($credit_no[$key]).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">ลงวันที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$crdate[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50px">จำนวน</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($moneyCrCard[$key])?number_format($moneyCrCard[$key],2):"").'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">บาท</td>
    </tr>
</table>

';

$html .= '
    '.$htmlPaymentOther.'
<pre class="tab"><b>ในกรณีที่ชำระเงินด้วยเช็ค หรือบัตรเครดิต จะถือว่าหนังสือจองนี้มีผลสมบูรณ์ต่อเมื่อบริษัทฯได้รับเงินตามเช็คหรือ บัตรเครดิตดังกล่าวข้างต้นครบถ้วนเรียบร้อยแล้วเท่านั้น</b></pre>
<pre class="tab"><b>ผู้จองตกลงจะปฏิบัติตามเงื่อนไขดังต่อไปนี้</b></pre>
<pre class="tab">ข้อ 1. ผู้จองตกลงจะเข้าทำสัญญาจะซื้อจะขายห้องชุดกับบริษัทฯ ต่อไป ณ<span class="under">&nbsp;'.$project->pj_address.'&nbsp;</span>หรือสำนักงานขายประจำโครงการ ภายในวันที่ <span class="under">'.$DateFormat->thaiDate(date('Y-m-d', strtotime($dateBooking. '+ 14 day'))).'</span></pre>
<pre class="tab"><span class="under"><b>หากผู้จองไม่มาทำสัญญาจะซื้อจะขายห้องชุดภายในกำหนดเวลาดังกล่าวข้างต้นผู้จองตกลงให้หนังสือจองนี้เป็นอัน สิ้นสุดลงทันที และยินยอมให้บริษัทฯริบเงินที่ผู้จองได้ชำระไว้แล้วทั้งหมดพร้อมทั้งมีสิทธินำห้องชุดตามหนังสือจองนี้ไป จำหน่ายจ่ายโอนให้แก่ผู้สนใจรายอื่นต่อไปได้ โดยผู้จองตกลงจะไม่โต้แย้งและเรียกร้องค่าเสียหายใดๆ จากบริษัทฯทั้งสิ้น ในกรณีที่เป็นการชำระเงินค่าจองด้วยบัตรเครดิตหรือเช็ค ผู้จองจะไม่อายัดหรือดำเนินการใดๆอันเป็นเหตุให้บริษัทฯ ไม่สามารถริบเงินจองได้</b></span></pre>
<pre class="tab">ข้อ 2. ในกรณีที่ผู้จองได้เข้าทำสัญญาจะซื้อจะขายตามกำหนดเวลาในข้อ 1. ผู้จองตกลงชำระราคาห้อง ชุดส่วนที่เหลือ และค่าใช้จ่ายอื่นๆ ตามรายละเอียดดังต่อไปนี้</pre>

<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>ผู้จอง</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<table border="0" width="100%" align="center">
	<tr>
		<td width="40%">&nbsp;</td>
		<td width="40%" align="center"><b>วันที่</b></td>
		<td width="20%" align="center"><b>จำนวนเงิน (บาท)</b></td>
	</tr>
</table>
<table border="1" class="oneLine" width="100%" align="center">';
//    <tr>
//		<td width="40%">ชำระเงินจองแล้ว ณ วันที่ทำหนังสือจอง</td>
//		<td width="40%" align="left">วันที่ '.$DateFormat->thaiDate(date('Y-m-d', strtotime($dateBooking))).'</td>
//		<td width="20%" align="right">'.number_format($BookingFee,2).'</td>
//	</tr>
    $html.='<tr>
		<td width="40%">ชำระในวันทำสัญญา</td>
		<td width="40%" align="left"> '.$DateFormat->thaiDate(date('Y-m-d', strtotime($dateContract))).'</td>
		<td width="20%" align="right">'.number_format($ContractFee,2).'</td>
	</tr>  
    <tr>
		<td width="40%">ชำระเงินดาวน์</td>
		<td width="40%" align="left"> '.$DateFormat->thaiDate($dateDownpay).'</td>
		<td width="20%" align="right">'.number_format($TotalInstallmentFee,2).'</td>
	</tr>
    <tr>
		<td width="40%" colspan="2" style="border-bottom-width:0px; border-bottom-style:solid;">รวม '.$TotalDownMonth.' งวด<br/>ชำระทุกวันที่ '.$getbooking->bk_pay_day.' ของทุกเดือน</td>
		<td width="20%" align="center" style="border-bottom-width:0px;"></td>
	</tr>
    <tr>
		<td width="40%" valign="top" style="border-right-width:1px; border-top-width:0px; border-right-style:solid;">'.$htmlTotalDownMonth.'</td>
        <td width="40%" valign="top" style="border-left-width:0px; border-top-width:0px; ">'.$htmlTotalDownMonth2.'</td>
		<td width="20%" align="center" style="border-top-width:0px;"></td>
	</tr>
    <tr>
		<td align="left" colspan="2">ชำระในวันโอนกรรมสิทธิ์</td>
		<td align="right">'.number_format($totalTransfer,2).'</td>
	</tr>
	<tr>
		<td colspan="3" align="left" bgcolor="#DDD">รายการค่าใช้จ่ายอื่นๆ ที่ผู้จองต้องชำระให้แก่บริษัทฯ ในวันโอนกรรมสิทธิ์ ดังนี้</td>
	</tr>
    <tr>
		<td colspan="3" align="left"><b>เงินกองทุน</b> จัดเก็บครั้งเดียว / ชำระในวันโอนกรรมสิทธิ์<u> 500.00 </u>บาท/ตรม.</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>ค่าใช้จ่ายส่วนกลาง</b> จัดเก็บล่วงหน้าเป็นรายปี / เว้นแต่ครั้งแรก ชำระในวันโอนกรรมสิทธิ์<u> '.number_format($getProject->pj_amenities_fee,2).' </u>บาท/ตรม./เดือน</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>ค่าธรรมเนียม / ค่าใช้จ่ายในการติดตั้ง และเงินประกันมิเตอร์ไฟฟ้า</b><br/>จัดเก็บครั้งเดียว / ชำระให้กับการไฟฟ้า แจ้งค่าใช้จ่ายให้ทราบเมื่อก่อสร้างอาคารเสร็จ</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>ค่าธรรมเนียมการโอนกรรมสิทธิ์ 1 % </b>ของราคาประเมินหรือตามอัตราที่กฎหมายกำหนด</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>ค่าจดจำนอง 1 % </b>ของวงเงินสินเชื่อ หรือตามอัตราที่กฎหมายกำหนด (เฉพาะกรณีกู้เงินกับสถาบันการเงิน)</td>
	</tr>
</table>
<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>ผู้จอง</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<br>
<pre class="tab">ผู้จองรับทราบและตกลงว่า หากการก่อสร้างห้องชุดแล้วเสร็จก่อนที่ผู้จองจะชำระราคาห้องชุดข้างต้น ครบถ้วนบริษัทฯจะแจ้ง ให้ผู้จองทราบเป็นลายลักษณ์อักษร หากผู้จองมีความประสงค์จะรับโอนกรรมสิทธิ์ห้องชุด ก่อนกำหนดระยะเวลาให้ผู้จองตอบรับกับ บริษัทฯ เป็นลายลักษณ์อักษร เพื่อนัดหมายกับบริษัทฯ เพื่อกำหนดรับโอนกรรมสิทธิ์ห้องชุด ทั้งนี้เมื่อบริษัทฯ และผู้จองสามารถตกลง วันรับโอนกรรมสิทธิ์ห้องชุดได้แล้ว บริษัทฯจะมีหนังสือบอกกล่าวกำหนดนัดโอนกรรมสิทธิ์ส่งให้ผู้จองล่วงหน้าไม่น้อยกว่า 30 (สามสิบ) วัน ก่อนกำหนดการโอนกรรมสิทธิ์ ผู้จองตกลงให้บรรดาค่างวดหรือเงินจำนวนใดๆที่ต้องผ่อนชำระที่ยังไม่ถึงกำหนดชำระ เป็นอันถึง กำหนดชำระทั้งหมดในวันโอนกรรมสิทธิ์ โดยผู้จองตกลงไปจดทะเบียนรับโอนกรรมสิทธิ์ห้องชุด และชำระราคาห้องชุดทั้งหมดให้ครบ ถ้วนในวันที่ได้นัดหมายให้ไปโอนกรรมสิทธิ์ดังกล่าว พร้อมปฏิบัติตามเงื่อนไขในสัญญาจะซื้อจะขายห้องชุดให้ครบ ถ้วนด้วย</pre>
<pre class="tab">ข้อ 3. ผู้จองตกลงว่าเมื่อการก่อสร้างอาคารชุดแล้วเสร็จ หากปรากฏว่า พื้นที่ห้องชุดที่ปรากฏในหนังสือแสดงกรรมสิทธิ์ห้อง ชุดเพิ่มขึ้น หรือลดน้อยลงจากที่ระบุไว้ในหนังสือนี้ ผู้จองตกลงผูกพันตามพื้นที่ในหนังสือ กรรมสิทธิ์ห้องชุด โดยให้คิดราคาพื้นที่ส่วนที่ เพิ่มขึ้นหรือลดลง ในอัตราตารางเมตรละ <span class="under"> '.number_format(floatval(str_replace(',', '', $pr_selling_sqm)),2).' </span> บาท (<span class="under">'.$Currency->bahtThai(floatval(str_replace(',', '', $pr_selling_sqm))).'</span>) และให้ผู้จองชำระราคาพื้นที่ส่วนที่เพิ่มขึ้น หรือบริษัทฯคืนเงินในส่วนราคาที่ลดลงดังกล่าวในวันโอนกรรมสิทธิ์ แล้วแต่กรณี</pre>
<pre class="tab">ข้อ 4. ผู้จองไม่สามารถโอนสิทธิ์การจองซื้อห้องชุดตามหนังสือจองให้นี้ให้แก่ผู้อื่น เว้นแต่จะได้รับความยินยอมเป็น ลายลักษณ์จากบริษัทฯ ก่อนเท่านั้น และต้องปฎิบัติตามเงื่อนไขที่บริษัทฯ กำหนดทุกประการ</pre>
<pre class="tab">ข้อ 5. ผู้จองได้รับทราบเงื่อนไขและข้อตกลงอื่นๆ ที่บริษัทฯ ได้แจ้งให้ทราบล่วงหน้า ณ วันที่จองซื้อ ห้องชุดดังกล่าวแล้ว และตกลงปฏิบัติตามทุกประการ</pre>
<br>
<table border="1" class="oneLine">
    <tr>
        <td align="left" height="40"><span class="under"><b>เงื่อนไข หรือ ข้อตกลงเพิ่มเติมอื่นๆดังนี้</b></span></td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="1" cellspacing="5">
                <tr>
                    <td>&nbsp;</td>
                </tr>
                '.$htmlGift.'
                '.$htmlDiscount.'
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>ผู้จอง</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<pre>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ราคาที่เสนอตามใบเสนอราคานี้ เป็นราคาโปรโมชั่นหรือส่วนลดพิเศษ ดังนั้นผู้ซื้อจะโอนสิทธิ์ตามสัญญาจะซื้อจะขายไม่ได้จนถึงวันที่ วันที่ '.$DateFormat->thaiDate(date('Y-m-d', strtotime($project->pj_cannot_transfer_date))).'
</pre>

<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เพื่อให้การจองซื้อดังกล่าวข้างต้นเป็นไปตามความประสงค์ ผู้จองจึงลงลายมือชื่อไว้เป็นหลักฐาน
</pre>
<br>
<table border="0" width="100%">
	<tr>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">ผู้จอง</td>
		<td width="10%"></td>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พนักงานขาย</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$pers_fname.' '.$pers_lname.'</td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$nameSale.'</td>
		<td align="left">)</td>
	</tr>
</table>
<br>
<br>
<table border="1" class="oneLine" align="center">
    <tr>
        <td><pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>เอกสารที่ผู้จองซื้อต้องจัดเตรียมมาเพื่อใช้ประกอบการจัดทำสัญญาจะซื้อจะขาย ดังนี้</b>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. หนังสือจองฉบับนี้
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. ใบเสร็จรับเงิน
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. สำเนาบัตรประจำตัวประชาชน พร้อมรับรองสำเนาถูกต้อง
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4. สำเนาทะเบียนบ้าน พร้อมรับรองสำเนาถูกต้อง
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5. สำเนาหนังสือเดินทาง (Passport) เฉพาะชาวต่างชาติ

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;กรณีมอบอำนาจให้บุคคลอื่นกระทำการแทนในการลงนามสัญญาจะซื้อจะขาย <span class="under">ต้อง</span>มีหนังสือมอบอำนาจ
 และสำเนาบัตรประจำตัวประชาชนของผู้มอบอำนาจและผู้รับมอบอำนาจ พร้อมรับรองสำเนาถูกต้องมาให้ครบถ้วน
 ในวันนัดด้วย	
</pre></td>
    </tr>
</table>
';
?>

<?php
/*echo $html;

include("application/third_party/MPDF/mpdf.php");

$nameFile = "$bid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	
// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);
$mpdf->Output($nameFile,'I');

exit;*/

include("application/third_party/MPDF/mpdf.php");

$nameFile = "$bid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
$mpdf->setHeader("หนังสือจองเลขที่ $bid แผ่นที่ {PAGENO} จาก {nb}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);
$mpdf->Output($nameFile,'I');


exit;


?>
