<?php
 $html = '
 
<style>
.tablefone{
  font-size:12px;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:justify;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}
table.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}
td.no-line {
    border-bottom-width:1px;
    border-top-width:1px;
    border-left-width:1px;
    border-right-width:1px;
    border-style: solid;
    border-color: #FFF #FFF #FFF #FFF;
  }
</style>

<table width="700" border="0" align="center"  cellspacing="0">
    <tr>
        <td align="center" colspan="4"><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
	<tr>
		<td align="center" colspan="4" ><h5>Reservation Letter for Purchase the Condominium Unit</h5></td>
	</tr>
	<tr>
		<td align="center" colspan="4" ><h5>'.$pj_name.' Condominium</td>
	</tr>
</table>
<br>
<table width="700" border="0"  align="center"  cellspacing="5">
	<tr>
    	<td width="400px"></td>
    	<td width="100px" align="right">At  : </td>
    	<td style="border-bottom-width:1px; border-bottom-style:solid;" width="200px">Sale office</td>
  	</tr>
  	<tr>
    	<td width="400px">&nbsp;</td>
    	<td width="150px" align="right">Date : </td>
    	<td style="border-bottom-width:1px; border-bottom-style:solid;" width="150px">'.date('d F Y',strtotime($dateBooking)).' </td>
  	</tr>
</table>
<br>
<table  width="750px" border="0" cellpadding="0" cellspacing="0">
  	<tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="140"><pre><b>For a Natural Person</b></pre></td>
    	<td style="border-bottom-width:0px; border-bottom-style:solid;" width="16"><pre>I,</pre></td>
    	<td style="border-bottom-width:1px; border-bottom-style:solid;" width="287"><pre> '.$pers_prefix.' '.$pers_fname.' '.$pers_lname.'</pre></td>
		<td style="border-bottom-width:0px; border-bottom-style:solid;" width="40"><pre>, Age</pre></td>
		<td style="border-bottom-width:1px; border-bottom-style:solid;" width="50" align="center"><pre>'.$age.'</pre></td>
		<td style="border-bottom-width:0px; border-bottom-style:solid;" width="80"><pre>, Nationality</pre></td>
		<td style="border-bottom-width:1px; border-bottom-style:solid;" width="121" align="center"><pre>'.$nationality.'</pre></td>
  	</tr>
</table >

<table width="750px" border="0" cellpadding="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="130px"><pre><b>Domicile Address : </b></pre></td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="620px">'.$getaddress->addr_address.'</td>
    <tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="69">Sub-District</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">'.$getaddress->addr_sub_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50" >District</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="190" align="center">'.$getaddress->addr_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="49">Province</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="169" align="center">'.$getaddress->addr_province.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="43">Country</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="146" align="center">'.$country.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="76">Postal Code</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="108" align="center">'.$getaddress->addr_post_code.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="150">Contact Number(Mobile)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="180" align="center">'.$getaddress->pers_mobile.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">(Home)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="106" align="center">'.(!empty($getaddress->pers_tel)?$getaddress->pers_tel:'-').'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="51">(Office)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="107" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">FAX</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="108" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30">Email</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="211" align="center">'.(!empty($getaddress->pers_email)?$getaddress->pers_email:'-').'</td>
    </tr>
</table>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="508px" ><b>Contact Address: </b>(only in the case where it is different from the Domicile Address)</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="217px" ></td>
    </tr>
    <tr>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" colspan="2" >'.$getaddresscur->addr_cur_address.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="69">Sub-district</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">'.$getaddresscur->addr_cur_sub_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50">District</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="190" align="center">'.$getaddresscur->addr_cur_district.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="49">Province</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="169" align="center">'.$getaddresscur->addr_cur_province.'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="43">Country</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="289" align="center">'.$country.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="76">Postal Code</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="309" align="center">'.$getaddresscur->addr_cur_post_code.'</td>
    </tr>
</table>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="535"><b>For a Juristic Person</b> we, a (<input type="checkbox"> company <input type="checkbox"> limited liability partnership <input type="checkbox"> คณะบุคคล)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="190" align="center"> - </td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="15">by</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="350" align="center"> - </td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" align="right" width="359">,an Authorized Director/Managing Partner/Attorney-in-fact,</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="245" ><b>having an operating office located at</b></td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="486" align="center">-</td>
    <tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="69">Sub-District</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="176" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="50">District</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="190" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="49">Province</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="169" align="center">-</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="43">Country</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="146" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="76">Postal Code</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="108" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="155">Contact number (Mobile)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="175" align="center">-</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">(Home)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="106" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="61">(Office)</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="107" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="38">FAX</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="108" align="center">-</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30">Email</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="201" align="center">-</td>
    </tr>
    
</table>
<table><tr><td height="90">
<pre>, hereinafter in this reservation letter referred to as the “Customer”, wishes to make and place this letter with Kitha Properties Co., Ltd., hereinafter referred to as the “Company”, having its detail as follows:</pre>
</td></tr></table>

<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For this reservation letter, the Customer agrees to reserve the right to purchase a unit of</pre>
<table width="750px" border="0" cellspacing="5" cellpadding="0">
    <tr>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="237">'.$pj_name.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="24">for</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="20" align="center">1</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="188">unit(s) of which is the Unit No. </td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="61" align="center">'.$un_name.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="74">( Unit Code</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="61" align="center">'.$unit_type_name.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="24">)</td>
    </tr>
</table>
<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>Customer</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<p>Floor <span class="under">&nbsp;&nbsp;'.$Floorname.'&nbsp;&nbsp;</span> Building <span class="under">&nbsp;&nbsp;'.$building_name.'&nbsp;&nbsp;</span>Area of Unit (including its balcony/ spaces for installing its compressor of air conditioner/ internal and external spaces of the unit that are deemed to be personal property/ other spaces connecting with the unit, according to an agreement of transfer of ownership in the unit) approximately.</p>

<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$unit_type_area_sqm.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="205px">Sq.m. (per unit) at the amount of </td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.number_format($qt_unit_price,2).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">Baht</td>
    </tr>
</table>

<p>(<span class="under">&nbsp;&nbsp;'.$Currency->bahtEng(trim($qt_unit_price)).'&nbsp;&nbsp;</span>) &nbsp;&nbsp;and agrees to place a deposit for such reservation at the amount of <span class="under">&nbsp;&nbsp;'.number_format($BookingFee,2).'&nbsp;&nbsp;</span> Baht ( <span class="under">&nbsp;&nbsp;'.$Currency->bahtEng(trim($BookingFee)).'&nbsp;&nbsp;</span> )&nbsp;&nbsp;by</p>


<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40"><input name="input" type="checkbox" value="" '.$flagCash.'/></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="150">Cash for the amount of</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" width="212" align="center" align="center">'.(!empty($moneyCash)?number_format($moneyCash,2):"").'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="295">Baht</td>
    </tr>
</table>
';

$i = 0;
foreach($credit_bank as $key=>$value) {

$creditno = substr_replace($this->encrypt->decode($credit_no[$key]),"xxxxxxxx",4,8);

    $html .= '
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="115px">'.(($i++ == 0)?'<input name="input" type="checkbox" value="" '.$flagCrCard.' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Credit Card ':'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Credit Card ').'</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$credit_holder[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="28px">Type</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$credit_type[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">Bank</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$credit_bank[$key].'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="97">Credit Card No.</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$creditno.'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="28">Date</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$crdate[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="109">for the amount of</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($moneyCrCard[$key])?number_format($moneyCrCard[$key],2):"").'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30">Baht</td>
    </tr>
</table>
';
}
if($i==0)
    $html .= '
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="115px">'.(($i++ == 0)?'<input name="input" type="checkbox" value="" '.$flagCrCard.' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Credit Card ':'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Credit Card '.$i++.'.').'</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="28px">Type</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">Bank</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$credit_bank[$key].'</td>
    </tr>
</table>
<table width="750px" border="0" cellspacing="5">
    <tr>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="40px"></td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="97px">Credit Card No.</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$this->encrypt->decode($credit_no[$key]).'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="28px">Date</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.$crdate[$key].'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="109px">for the amount of</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid;" align="center">'.(!empty($moneyCrCard[$key])?number_format($moneyCrCard[$key],2):"").'</td>
        <td style="border-bottom-width:0px; border-bottom-style:solid;" width="30px">Baht</td>
    </tr>
</table>';
////////////  end if  /////////////////
$html .= '
    '.$htmlPaymentOther.'
<pre class="tab"><b>In the event where the payment is made by cheque or credit card, this reservation letter shall be valid once the Company completely receives the payment of such cheque or credit card in full.</b></pre>
<pre class="tab"><b>The Customer agrees to comply with the following terms and conditions:</b></pre>
<pre class="tab">Section 1. The Customer shall make and enter into the Condominium Sale and Purchase Agreement with the Company at <span class="under">'.$project->pj_owner_en.'&nbsp;&nbsp;'.$project->pj_address_en.'&nbsp;</span>, or its sale office for this condominium within <span class="under">'.date('d F Y', strtotime($dateBooking. '+ 14 day')).'</span></pre>
<pre class="tab"><span class="under"><b>In the case where the Customer fails to make and enter into the Agreement within the aforesaid period, the Customer shall agree to allow this letter to be immediately, automatically terminated, and to entitle the Company to immediately confiscate the whole amount paid by the Customer, and to entitle the Company to resell or dispose the unit specified herein to the others. The Customer shall not object the said undertakings or claim for any losses and damages from the Company. In the case that the payment for reservation is made by cheque or credit card, the Customer shall not freeze such payment or take any other act which shall result in the Company’s failure to confiscate such payment.</b></span></pre>
<pre class="tab">Section 2. In the case where the Customer makes and enters into the Agreement within the specific period under the Section 1, the Customer shall make payments of unit price and other expenses under the following terms.</pre>

<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>Customer</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<table border="0" width="100%" align="center">
	<tr>
		<td width="40%">&nbsp;</td>
		<td width="40%" align="center"><b>Date</b></td>
		<td width="20%" align="center"><b>Amount (Baht)</b></td>
	</tr>
</table>
<table border="1" class="oneLine" width="100%" align="center">';
//    <tr>
//		<td width="40%">ชำระเงินจองแล้ว ณ วันที่ทำหนังสือจอง</td>
//		<td width="40%" align="left">วันที่ '.$DateFormat->thaiDate(date('Y-m-d', strtotime($dateBooking))).'</td>
//		<td width="20%" align="right">'.number_format($BookingFee,2).'</td>
//	</tr>
    $html.='<tr>
		<td width="40%">Payment on the contracting date</td>
		<td width="40%" align="left"> '.date('d F Y', strtotime($dateContract)).'</td>
		<td width="20%" align="right">'.number_format($ContractFee,2).'</td>
	</tr>  
    <tr>
		<td width="40%">Down Payment</td>
		<td width="40%" align="left"> '.date('d F Y', strtotime($dateDownpay)).'</td>
		<td width="20%" align="right">'.number_format($TotalInstallmentFee,2).'</td>
	</tr>
    <tr>
		<td width="40%" colspan="2" style="border-bottom-width:0px; border-bottom-style:solid;">Total '.$TotalDownMonth.' installments<br/>Paid on every date of '.$getbooking->bk_pay_day.' each month</td>
		<td width="20%" align="center" style="border-bottom-width:0px;"></td>
	</tr>
    <tr>
		<td width="40%" valign="top" style="border-right-width:1px; border-top-width:0px; border-right-style:solid;">'.$htmlTotalDownMonth.'</td>
        <td width="40%" valign="top" style="border-left-width:0px; border-top-width:0px; ">'.$htmlTotalDownMonth2.'</td>
		<td width="20%" align="center" style="border-top-width:0px;"></td>
	</tr>
    <tr>
		<td align="left" colspan="2">Payment on the date of transfer of ownership</td>
		<td align="right">'.number_format($totalTransfer,2).'</td>
	</tr>
	<tr>
		<td colspan="3" align="left" bgcolor="#DDD">Other expenses which our customers shall pay on the date of transfer of ownership are as follows.</td>
	</tr>
    <tr>
		<td colspan="3" align="left"><b>Sinking Funds</b> Pay at once/Pay on the date of transfer of ownership<u> 500.00 </u>Baht/Sq.m.</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>Common Management Fee</b> Pay in advance on annual basis/ Exclude the first installment, immediately upon transference of transfer of ownership<u> '.number_format($getProject->pj_amenities_fee,2).' </u>Baht/Sq.m./month</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>Fee/Cost of Installation and Guarantee Deposit of Electrical Meter</b><br/>Pay at once/Pay to the Electricity Authority (The amount shall later be informed after the completion of construction.)</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>Fee of Transfer of Ownership  1% </b>of assessed price or other rate specified by laws</td>
	</tr>
	<tr>
		<td colspan="3" align="left"><b>Cost of Registration of Mortgage 1% </b>of credit limit or other rate specified by laws (only for the credit facility made with a financial institution)</td>
	</tr>
</table>
<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>Customer</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<br>
<pre class="tab">The Customer understands and agrees that if construction of the unit is completed before the full payment of the above specified unit price has been paid by the Customer, the Company shall inform the Customer in writing. In the case that the Customer wishes to accept the transfer of ownership in the certain unit prior to the specific time, the Customer shall reply the Company in writing to make an appointment with the Company to determine the date of transfer of ownership of the unit. Upon the mutually agreed date of transfer of ownership, the Company shall serve a notice to inform the date at least 30 days prior to such date. The Customer agrees that any undue instalment and amount behind in payment shall be all due on such date. In this regard, the Customer shall come to make a registration of acceptance of the transfer and pay all outstanding amount of the unit price on the same day, together with fulfilling all obligations under the Condominium Sale and Purchase Agreement.</pre>
<pre class="tab">Section 3. The Customer agrees that if an area of delivered unit, as specified in the condominium title deed, is less or more than the area contracted for, the Customer shall accept it and pay the proportionate price at the rate of <span class="under"> '.number_format(floatval(str_replace(',', '', $pr_selling_sqm)),2).' </span> Baht per Sq.m. (<span class="under">'.$Currency->bahtEng(floatval(str_replace(',', '', $pr_selling_sqm))).'</span>) ., or, if the case may be, shall accept it together with the return of the reduced amount, on the date of transfer of ownership.</pre>
<pre class="tab">Section 4. The Customer shall not assign the right of reservation for purchasing the unit under this letter to others, except obtaining consent in writing from the Company, as well as complying with all conditions determined by the Company.</pre>
<pre class="tab">Section 5. The Customer acknowledges and understands all additional terms and conditions informed on the date when the reservation was made and shall comply with all of them.</pre>
<br>
<table border="1" class="oneLine">
    <tr>
        <td align="left" height="40"><span class="under"><b>Additional terms and conditions are as follows.</b></span></td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="1" cellspacing="5">
                <tr>
                    <td>&nbsp;</td>
                </tr>
                '.$htmlGift.'
                '.$htmlDiscount.'
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid;" width="750px">&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<div class="footer">
	<table align="right" border="0" width="100%">
		<tr>
			<td width="400px">&nbsp;</td>
			<td width="250px" style="border-bottom-width:1px; border-bottom-style:solid;">&nbsp;</td>
			<td>Customer</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</table>
</div>
<pagebreak>
<pre>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The price offered herein is a promotion price or specially discounted price, therefore, the Customer cannot assign his/her/its right under the contract to others until the '.date('d', strtotime($project->pj_cannot_transfer_date)).' day of  '.date('F Y', strtotime($project->pj_cannot_transfer_date)).'</pre>

<pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;IN WITNESS WHEREOF the undersigned customer have hereunto set his/her/its signature.</pre>
<br>
<table border="0" width="100%">
	<tr>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">the Customer</td>
		<td width="10%"></td>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Attorney-in-fact</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$pers_fname.' '.$pers_lname.'</td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;">'.$nameSale.'</td>
		<td align="left">)</td>
	</tr>
</table>
<br>
<br>
<table border="1" class="oneLine" align="center">
    <tr>
        <td><pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>A list of documents the Customer shall prepare for making the Condominium Sale and Purchase Agreement</b>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. This reservation letter
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. A receipt
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. A certified true copy of I.D. card 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4. A certified true copy of house registration book 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5. A certified true copy of passport – for a foreigner only

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In the case where an authority to sign in the agreement is given to another person, the power of attorney and copies of I.D. cards of the principal and the authorized person shall be presented on the appointment date.</pre></td>
    </tr>
</table>
';
?>

<?php
/*echo $html;

include("application/third_party/MPDF/mpdf.php");

$nameFile = "$bid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	
// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);
$mpdf->Output($nameFile,'I');

exit;*/

include("application/third_party/MPDF/mpdf.php");

$nameFile = "$bid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
$mpdf->setHeader("Reservation Letter No. $bid Sheets {PAGENO} of {nb}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);
$mpdf->Output($nameFile,'I');


exit;


?>
