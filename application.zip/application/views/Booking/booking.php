<div class="booking-view">
    <div class="content">
        <div class="content-header">
            <font color="#78ad13">View Booking</font> <label class="table-total">...</label>
        </div>

        <div class="content-body">
            <!-- Table -->
            <table class="dynamicTable colVis table">
                <!-- Table heading -->
                <thead>
                    <tr>
                        <th>Booking</th>
                        <th>Customer</th>
                        <th>Quotation</th>
                        <th>Unit Number</th>
                        <th class="center">Contract Date</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <!-- // Table heading END -->

                <!-- Table body -->
                <tbody>
                    <!-- Table row -->
                    <?php foreach($list_booking as $booking): ?>
                    <?php
    					$today = date("Y-m-d"); 
    					$warningDue = '';
    					$contractFlag  =FALSE;

                        if ($booking->contact == NULL){
                            $contractFlag  =TRUE;
                        }

                        $letterFlag = FALSE;
                        if (date('Y-m-d',strtotime($booking->bk_contract_date)) < $today&&$contractFlag) {
                            $warningDue = trim($booking->bk_status) !=='cancelled'?'style="color:red"':'';
                            $letterFlag = TRUE;
                        }
    					
    					$cancelled = '';
                        if (trim($booking->bk_status) =='cancelled') { $cancelled = 'style="color:#BBB"'; }
                    ?>
                        <tr <?=$cancelled?>>
                            <td <?php echo $warningDue; ?> >
                                <?php echo $booking->bk_booking_code; ?>
                                <?php 
                                    if (trim($booking->bk_status) =='cancelled') 
                                        echo '<br/>(Cancelled)';
                                    else if  ( trim($booking->bk_status) === 'transferred' ) { ?>
                                        <br>(<a onmouseover="Tip('Old Customer : <b><?=$booking->old_name?></b><br/>Mobile : <b><?=$booking->old_mobile ?></b><br> Tel : <b><?= $booking->old_tel ?></b><br> Email : <b><?= $booking->old_email ?></b>', SHADOW, true, SHADOWCOLOR, '#cccccc',BORDERCOLOR,'#cccccc')" onmouseout="UnTip()"><font size='2'>Transferred</font></a>)
                                <?php } ?>
                            </td>
                            <td <?php echo $warningDue; ?> >
<!--
                                <a href="#" onmouseover="Tip('Mobile :&nbsp;<b> <?php echo $booking->pers_mobile." </b>
                                    <br> Tel : ".$booking->pers_tel. '
                                    <br> Email :'.$booking->pers_email; ?>', SHADOW, true, SHADOWCOLOR, '#cccccc',BORDERCOLOR,'#cccccc')" onmouseout="UnTip()"><?php echo $booking->pers_fname." ".$booking->pers_lname; ?></a>
-->
                               <a class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Mobile : <?php echo $booking->pers_mobile. " | Tel : ".$booking->pers_tel. ' | Email : '.$booking->pers_email; ?>" href="#" ><?php echo $booking->pers_fname." ".$booking->pers_lname; ?></a>
                            </td>
                            <td <?php echo $warningDue; ?> >
                                <?php echo $booking->bk_quotation_code; ?>
                            </td>
                            <td <?php echo $warningDue; ?> >
                                <?php echo $booking->building_name; ?>&nbsp;
                                <?php echo $booking->un_name; ?>
                            </td>
                            <td <?php echo $warningDue; ?> >
                                <?php echo date('d/m/Y', strtotime($booking->bk_contract_date)); ?>
                            </td>
                            <td align="left">
                                <div class="btn-group btn-group-xs ">
                                    <?php
                                    if (strpos($permission->pm_booking,'2') !== false) {
                                        $getReceipt = $this->tb_receipt_temporary->get_by_booking($booking->bk_booking_code);
                                    ?>    
                                        View: 
                                        <a href="<?php echo BASE_DOMAIN; ?>booking/report/<?php echo $booking->bk_booking_code; ?>/TH" target="_blank"><font color="#0e7ccb">TH</font></a> / 
                                        <a href="<?php echo BASE_DOMAIN; ?>booking/report/<?php echo $booking->bk_booking_code; ?>/EN" target="_blank"><font color="#0e7ccb">EN</font></a>

                                    <?php 
                                    }
                                    ?>
                                    
                                    <?php
                                    if (strpos($permission->pm_receipt,'2') !== false) {
                                        $getReceipt = $this->tb_receipt_temporary->get_by_booking($booking->bk_booking_code);
                                    ?>
                                    <a href="<?php echo BASE_DOMAIN; ?>receipt/report/th/<?php echo $getReceipt->rc_code; ?>" target="_blank"><font color="#78ad13">Temp Receipt</font></a>
                                    <?php 
                                    }
                                    ?>
                                    
                                    <?php
                                    if (strpos($permission->pm_contract,'1') !== false && strpos($permission->pm_receipt,'3') !== false) {
                                        if ($contractFlag) {
                                            if ($room->un_status_room!='Sold') {
                                                if ( trim($booking->bk_status) != 'cancelled') { ?>
                                    <a href="<?php echo BASE_DOMAIN; ?>contract/adding/<?php echo $booking->bk_booking_code; ?>/<?php echo $booking->bk_leads_id;?>?from=book"><font color="#FF7F00">Make Contact</font></a>
                                            <?php
												}
											}
										}
                                    } 
                                ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- // Table row END -->
                </tbody>
                <!-- // Table body END -->
            </table>
            <!-- // Table END -->
        </div>
    </div>
</div>
<!-- // Content END -->

<script>
    
    $(document).ready(function(){
        $('.tooltipped').tooltip({delay: 50});
    });
        
    $("#form1").submit(function(event) {

        if ($("#reason").val() != '') {

            $("#target").submit();
        } else {
            var s = $("#reason").val() == '' ? '-Not specify reason to Watiting booking letter ' : '';
            event.preventDefault();
        }

    });

    $("#form2").submit(function(event) {

        if ($("#docno").val() == '') {
            //$( "#docno" ).focus();
            event.preventDefault();
        } else if ($("#customername").val() == '') {
            //$( "#docno" ).focus();
            event.preventDefault();
        } else if ($("#contact").val() == '') {
            //$( "#docno" ).focus();
            event.preventDefault();
        } else $("#target").submit();

    });

    function Remark_WarningBookingletter(bookcode, cusid, cusname, buildingid, buildingname, untid, unitname, duedate) {

        $("#cus").val(cusid);
        $("#unitid").val(untid);
        $("#bcode").val(bookcode);
        $("#bookingcode").val(bookcode);
        $("#customer").val(cusname);
        $("#buildingid").val(buildingid);
        $("#building").val(buildingname);
        $("#unitname").val(unitname);
        $("#contractdate").val(duedate);

    }

    function Sentmessage(msgtype, bookno, custno, customer, contact, duedate, bkfee) {

        $("#msgtype").val(msgtype);
        $("#docno").val(bookno);
        $("#custno").val(custno);
        $("#customername").val(customer);
        $("#contact").val(contact);
        $("#defaultmsg").val(duedate);
        $("#lblmessage").text(msgtype == 'email' ? 'Sent Email' : 'Sent SMS Message');
        $("#paymentamt").val(bkfee);

    }
</script>