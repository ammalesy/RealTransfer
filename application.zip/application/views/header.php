<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
    <head>
        <title>
            <?php echo $title; ?>
        </title>

        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
      
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"  media="screen,projection"/>

        <!-- Global -->
        <script>
            var basePath = '',
                commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
                rootPath = '<?php echo BASE_DOMAIN; ?>',
                DEV = false,
                componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

            var primaryColor = '#cb4040',
                dangerColor = '#b55151',
                infoColor = '#466baf',
                successColor = '#8baf46',
                warningColor = '#ab7a4b',
                inverseColor = '#45484d';

            var themerPrimaryColor = primaryColor;
        </script>
        
        <link href="<?php echo BASE_DOMAIN; ?>assets/components/plugins/select2/css/select2.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/js/givethechange.js"></script>
        <!--select2-->
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/select2/js/select2.min.js"></script>
        <!--javascript for realcrm-->
        <script src="<?php echo BASE_DOMAIN; ?>assets/js/realcrm/customer.js"></script>
        <!--sass-->
        <link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>
        <!-- HighChart -->
        <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/chart.js"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/highcharts.js"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/modules/exporting.js"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/highcharts-3d.js"></script>  
        <!--select materialize-->
        <script>
            $(document).ready(function() {
                $('select').material_select();
            }); 
            function fixSelect () {
                //แก้ไข scrollbar ของ materialize 
                var onMouseDown = function(e) {
                  if (e.clientX >= e.target.clientWidth || e.clientY >= e.target.clientHeight) {
                    e.preventDefault();
                  }
                };
                $('select').siblings('input.select-dropdown').on('mousedown', onMouseDown);
                //แก้ไข scrollbar ของ materialize
            } 
        </script>
        
        <!--fgf_adding-->
        <script type="text/javascript">
            function leadsCheck()
            {
                $('#leads-id').val('0');
            }

            function leadsCheck2()
            {
                $('#leads-id2').val('0');
            }
        </script>
        
        <!--receipt_form-->
    </head>

    <body >
