
<script type="text/javascript">
	function CreateNewRow()
	{
		var intLine = $('#hdnMaxLine').val();
		intLine++;
			
		var theTable = document.all.tbExp
		var newRow = theTable.insertRow(theTable.rows.length)
		newRow.id = newRow.uniqueID
		
		var item1 = 1
		var newCell
		
		//*** Column 1 ***//
		newCell = newRow.insertCell(0)
		 
		newCell.innerHTML = "<table  width=\"100%\"><tr><td><div class=\"col-md-4\"><div class=\"form-group\"><label class=\"col-md-4 control-label\" for=\"company\">Company</label><div class=\"col-md-8\"><input class=\"form-control\" id=\"company\" name=\"company[]\"   maxlength=\"100\" /></div></div><div class=\"form-group\"><label class=\"col-md-4 control-label\" for=\"empId\">Employee ID</label><div class=\"col-md-8\"><input class=\"form-control\" id=\"empId\" name=\"empId[]\"   maxlength=\"100\" /></div></div></div><div class=\"col-md-8\"><div class=\"form-group\"><label class=\"col-md-4 control-label\" for=\"position\">Position</label><div class=\"col-md-8\"><input class=\"form-control\" id=\"position\" name=\"position[]\"   maxlength=\"100\" /></div></div></div></div></td></tr>	</table> ";
		 
		$('#hdnMaxLine').val(intLine);
	}
	
	function RemoveRow()
	{
		intLine =$('#hdnMaxLine').val();
		
		if(parseInt(intLine) > 0)
		{
				theTable = (document.all) ? document.all.tbExp : 
				document.getElementById("tbExp")
				theTableBody = theTable.tBodies[0];
				theTableBody.deleteRow(intLine);
				intLine--;
				$('#hdnMaxLine').val(intLine) ;
		}	
	}	
	
	
function idcardcall(){
				$.ajax({
				url: "<?php echo BASE_DOMAIN; ?>assets/ajaxIDcardUser.php",
				data: ({ nextList : 'idcard', idcard: $('#idcard').val() }),
				dataType: "json",
				beforeSend: function() {
				},
				success: function(json){
					$.each(json, function(index, value) {
							
						 			if($("#idcard").val() == value.user_pers_card_id)
									  {
									  		$("#idcard").val('');
									  		alert('ID card number is already');
									  		$("#idcard").focus();
									  }
						});
					}
				});

	};
		
	function usernameCheck(){
		
				$.ajax({
				url: "<?php echo BASE_DOMAIN; ?>assets/ajaxUsername.php",
				data: ({ nextList : 'username', username: $('#username').val() }),
				dataType: "json",
				beforeSend: function() {
				},
				success: function(json){
					$.each(json, function(index, value) {
							
						 			if($("#username").val() == value.user_username)
									  {
									  		alert('Username is already... Please change new Username');
									  		$("#username").focus();
									  }
						});
					}
				});
	};
	</script>


		<div id="menu" class="hidden-print hidden-xs">
			<?php
				// if (strpos($permission->pm_authorize_user,'2') == false) {
				// 	alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
				// }
			?>
		</div>
		
<div class="setting_authorized">
	
<div class="innerAll spacing-x2">
    
    <div class="content-header">
       <a href="<?php echo BASE_URL; ?>/authorized/view" class="back-head"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
        <font color="#78ad13">Authorize Details</font>
    </div><br/><br/>

	<!-- Form -->
<form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off"  action="<?php echo BASE_URL; ?>/authorized/update/<?php echo $uid; ?>">
		
		<div class="widget-body">
		
			<!-- Row -->
			<div class="row">
				<!-- Column -->
				<div class="col-md-4">
				
					<!-- Group -->
					<div class="form-group">
						<label class="col-md-4 control-label" for="firstname">Document Name</label>
						<div class="col-md-8">
						<select class="form-control" id="docname" name="docname">
						<?php foreach($list_auth as	$get): ?>
                            <option value="<?php echo trim($get->au_document); ?>"<?php echo (trim($auth->au_document)==trim($get->au_document))?"selected":""; ?>><?php echo $get->au_document; ?></option>
                       	<?php endforeach; ?>
						</select>

					</div>
					</div>
					</div>
				<!-- Column -->
				<div class="col-md-8">
				<!-- Group -->	
                <!-- Group -->
					<div class="form-group">
						<label class="col-md-4 control-label" for="Permission">Authorize User</label>
						<div class="col-md-8">
							<select class="form-control" id="Permission" name="Permission" style="width: 200px">
						 		<?php
							         echo '<option value="" >------- Select ------</option>';
											
											foreach($list_personal as $pers):
												if ($auth->au_user_id ==$pers->user_pers_id_ref) {
													echo '<option value="', $pers->user_pers_id_ref, '" selected>'.$pers->user_pers_fname.' '.$pers->user_pers_lname.'</option>';
												} else {
													echo '<option value="', $pers->user_pers_id_ref, '">'.$pers->user_pers_fname.' '.$pers->user_pers_lname.'</option>';
												}
											endforeach;
									?>
							</select> 
						</div>
					</div>
					<!-- // Group END -->
                </div>
				
			</div>
			<!-- // Row END -->
				<hr class="separator" />
			<!-- Form actions -->
			<div class="form-actions" align="center">
				<button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Save</button>
				<a href="<?php echo BASE_URL; ?>/authorized/view"><button type="button"  class="btn btn-default"><i class="fa fa-times"></i> Cancel</button></a>
				</div>
			<!-- // Form actions END -->
			
		</div>
	<!-- // Widget END -->
	
</form>
<!-- // Form END -->


	
</div>	

		</div>
		<!-- // Content END -->
		
		<div class="clearfix"></div>
	
<script>
	
$(function()
{
	
    $("#idcard").inputmask({"mask": "9-9999-99999-99-9"});
 
});
	
</script>
