	
		<div id="menu" class="hidden-print hidden-xs">
			<?php
			if ($permission->pm_user<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
			}
			?>
		</div>


	<div class="setting_authorized">
		
<div class="innerAll spacing-x2">

    <div class="content-header">
       <a href="<?php echo BASE_URL; ?>" class="back-head"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
        <font color="#78ad13">View Authorize User</font>
        <label class="table-total">...</label>
    </div><br/><br/>

		<div class="widget-body padding-bottom-none">
			<!-- Table -->
			<?php
            if (strpos($permission->pm_authorize_user,'1') !== false) {
            ?>
<!--
                <a href="<?php echo BASE_URL; ?>/authorized/adding">
                <button class="btn btn-inverse"><i class="fa fa-user"></i> New </button>
                </a>
-->
                <div class="content-add">
                <a href="<?php echo BASE_URL; ?>/authorized/adding" class="btn-floating btn-medium waves-effect waves-light red"><i class="material-icons">add</i></a>
            </div>
			<?php } ?>
<table class="dynamicTable colVis table">

	<!-- Table heading -->
	<thead class="bg-gray">
		<tr>
			<th>ID</th>
			<th>Documents</th>
			<th>Authorize Person to Sign </th>
			<th>Action </th>
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody>
		<!-- Table row -->
		
			<?php foreach($list_auth as $auth): ?>
					<tr>
						<td ><?php echo $auth->au_id; ?></td>
						<td ><?php echo $auth->au_document; ?></td>
						<td ><?php echo $auth->user_pers_fname.' '.$auth->user_pers_lname; ?></td>
                        <td>
                        <?php
                        if (strpos($permission->pm_authorize_user,'2') !== false) {
                        ?>
<!--                            <a href="<?php echo BASE_URL; ?>/authorized/editing/<?php echo $auth->au_id; ?>" ><?php echo image_asset('image/Edit.gif',NULL,array('title'=>'Edit')); ?></a>-->
                            <a href="<?php echo BASE_URL; ?>/authorized/editing/<?php echo $auth->au_id; ?>"><i class="material-icons icon-hover">settings</i></a>
                        <?php } ?>
                        </td>
					</tr>
			<?php endforeach; ?>
			
		<!-- // Table row END -->
	</tbody>
	<!-- // Table body END -->
	
</table>
<!-- // Table END -->


		</div>
	</div>
	<!-- // Widget END -->
	

	
</div>
		
		<div class="clearfix"></div>
	

	

	