<style>
    .labelPromotion {
        padding-top: 4px;
        padding-left: 15px;
        margin-top: 0;
        margin-bottom: 0;
    }
    
    .bigCB {
        width: 60px;
        height: 10px;
        left: -150px;
        vertical-align: bottom;
        position: relative;
        top: -9px;
        display: inline-block;
        font-size: 12pt;
    }
</style>
<!-- CUSTOMER -->
<script type="text/javascript">
    function cusCheck1() {
        $('#cus-id').val('0');
    }

    function cusCheck2() {
        $('#cus-id2').val('0');
    }

    function cusCheck3() {
        $('#cus-id3').val('0');
    }

    function cusCheck4() {
        $('#cus-id4').val('0');
    }
</script>
<style>
    #cus-label {
        display: block;
        font-weight: bold;
        margin-bottom: 1em;
    }
    
    #cus-icon {
        float: left;
        height: 32px;
        width: 32px;
    }
</style>

<div class="booking-form">
    <div>
    <?php
        if (strpos($permission->pm_quotation,'1') == FALSE) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');		
        }
    ?>
    </div>
    <div class="content">
        <div class="content-header">
            <a href="<?php echo BASE_URL; ?>/quotation/view" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <span class="title-header">Booking and Contract</span>
        </div>
        <form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off" action="<?= BASE_DOMAIN; ?>bookingcontract/record">
            <input name="qtCode" type="hidden" value="<?=$qtCode ?>" />
            <div class="quotation-detail">
                <div class="row">
                    <div class="col l4 title-info">Quatation Detail</div>
                    <?php
						$comma = '';
						$allCus = '';
						foreach($list_leads as $row):
							$allCus .= $comma.'{value: "'.$row->cus_id.'",label: "'.$row->fullname.'"}';
							if($comma==='') $comma = ',';
						endforeach;
						$allCus = '['. $allCus . ']';
					?>
                        <input type="hidden" name='cusid' id="cus-id" value="<?php echo $leads; ?>" />
                        <div class="col l8 form-info">
                            <div class="input-field name-1">
                                <input id="user_fullname" type="text" class="validate" name="user_fullname1" value="<?php echo $leadsname; ?>" required="required" onkeypress="JavaScript:cusCheck1();" >
                                <label for="user_fullname">Customer Name #1*</label>
                                <input type="hidden" name='cusid[]' id="cus-id" value="<?=$leads?>" />
                            </div>
                            <div class="input-field name-2">
                                <input id="user_fullname2" type="text" class="validate" name="user_fullname2" value="" onkeypress="JavaScript:cusCheck2();">
                                <label for="user_fullname2">Customer Name #2</label>
                                <input type="hidden" name='cusid[]' id="cus-id2" value="" />
                            </div>
                            <div class="input-field name-3">
                                <input id="user_fullname3" type="text" class="validate" name="user_fullname3" value="" onkeypress="JavaScript:cusCheck3();">
                                <label for="user_fullname3">Customer Name #3</label>
                                <input type="hidden" name='cusid[]' id="cus-id3" value="" />
                            </div>
                            <div class="input-field name-4">
                                <input id="user_fullname4" type="text" class="validate" name="user_fullname4" value="" onkeypress="JavaScript:cusCheck4();">
                                <label for="user_fullname4">Customer Name #4</label>
                                <input type="hidden" name='cusid[]' id="cus-id4" value="" />
                            </div>
                 
                            <div class="quotation-number show-detail">
                                Quotation Number : <span class="query-result"><?php echo $qtCode; ?></span>
                            </div>
                            <div class="pay-date show-detail">
                                <label class="pay-date-title">Pay Date : </label>
                                <div class="input-field">
                                    <select class="browser-default" name="payDay">
                                        <?php for($i=1;$i<31;$i++): ?>
                                            <option value="<?=$i?>" <?=$i==15? 'selected': ''?>>
                                                <?=strlen($i)<2?'0'.$i:$i?>
                                            </option>
                                            <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="unit-number show-detail">
                                Unit Number : <span class="query-result"><?php echo $un_name; ?></span>
                            </div>
                            <div class="direction show-detail">
                                Direction : <span class="query-result"><?php echo $un_direction; ?></span>
                            </div>
                            <div class="building show-detail">
                                Building : <span class="query-result"><?php echo $building_name; ?></span>
                            </div>
                            <div class="area show-detail">
                                Area : <span class="query-result"><?php echo $unit_type_area_sqm; ?></span>
                            </div>
                            <div class="unit-type show-detail">
                                Unit Type : <span class="query-result"><?php echo $unit_type_name; ?></span>
                            </div>
                            <div class="price-per-sqm show-detail">
                                Price per sq.m. : <span class="query-result"><?php echo number_format(floatval(str_replace(',', '', str_replace('.', '', $pr_selling_sqm))),2). ' Baht'; ?></span>
                            </div>
                            <div class="room-type show-detail">
                                Room Type : <span class="query-result"><?php echo $room_type_name; ?></span>
                            </div>
                            <div class="total-unit-price show-detail">
                                Total Unit Price : <span class="query-result"><?php echo number_format(floatval(str_replace(',', '', str_replace('.', '', $pr_asking_price))),2).' 	Baht'; ?></span>
                            </div>
                        </div>
                </div>
                <div class="row promotion-detail">
                    <div class="col l4 title-info">Promotion</div>
                    <div class="col l8 form-info">
                        <div class="promotion">
                            Current Promotion :
                            <ul>
                                <?php foreach ($getPromotion as $key => $value): ?>
                                    <li>
                                        <?= $value->pm_name ?>
                                    </li>
                                    <?php endforeach; ?>
                            </ul>
                        </div>
                        <a class="waves-effect waves-light btn btn-add" onclick="promotion()">Add / Remove Promotion</a>
                    </div>
                </div>




                <div class="promotion-edit" style="display: none">
                    <div class="promotion-title">Promotion</div>
                    <div class="giftHide">
                        <div class="promotion-title text-center">Gift</div>
                        <div class="row" id="gift"></div>
                    </div>
                    <div class="cashHide">
                        <div class="cash-title text-center">Cash</div>
                        <div class="row" id="cash"></div>
                    </div>
                    <div class="furHide">
                        <div class="furniture-title text-center">Furniture</div>
                        <div class="row" id="fur"></div>
                    </div>
                </div>
                
                <div class="credit-promotion" style="margin-top: 30px;">
                <div class="row">
                    <div class="col l4 title-info">Credit Promotion</div>
                    <div class="col l8 form-info">
						<?php foreach ($allCredit as $val): ?>
                        <div class="credit-detail">
                            <input class="visit" name="pro[]" type="radio" id="promotion<?= $val->pm_id ?>" value="<?= $val->pm_id ?>">
                            <label for="promotion<?= $val->pm_id ?>"><?= $val->pm_detail ?></label>
                        </div>
						<?php endforeach; ?>
                    </div>
                </div>
            </div>



            </div>
            <input type="hidden" name="projectid" value="<?php echo $Project; ?>" />
            <input type="hidden" name="buildingid" value="<?php echo $Building; ?>" />
            <input type="hidden" name="unitnumber" value="<?php echo $un_name; ?>" />
            <input type="hidden" name="unitnumberid" value="<?php echo $Number; ?>" />
            <input type="hidden" name="unitreserv" id="unitreserv" value="<?php echo $BookingFee; ?>" />
            <input type="hidden" name="building" value="<?=$building?>" />
            <?php 
	            $data['definefee'] = $definefee;
                $data['banklist'] = $banklist;
                $data['credittypelist'] = $credittypelist;
                $data['submit'] = 'Submit';
                $data['cancel'] = 'quotation/view';
                if(strpos($permission->pm_receipt,'4') !== false) {
                    $data['receipt'] = 'yes';
                    $data['receiptList'] = $receiptList;
                }
                $this->load->view("form_payment", $data);
	        ?>
        </form>
        <div class="clearfix"></div>
    </div>
</div>



<!--
                    <div class="widget widget-inverse">
                        <div class="widget-head" align='center'>
                            <h4 class="heading"><b>Promotion</b></h4></div>
                        <div class="row">

                            <div class="col-xs-12">
                                <table border="0">
                                    <tr id="trGift">
                                        <td>
                                            <br>
                                            <div id="checkboxesgift" style="padding-left: 10px"><b>Gift</b>
                                                <br>
                                                <table id="tbGift" width="100%"></table>
                                            </div>
                                        </td>
                                        <tr id="trCash">
                                            <td>
                                                <div id="checkboxescash" style="padding-left: 10px"><b>Cash</b>
                                                    <br>
                                                    <table id="tbCash" width="100%"></table>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr id="trFur">
                                            <td>
                                                <div id="checkboxesfur" style="padding-left: 10px"><b>Furniture</b>
                                                    <br>
                                                    <table id="tbFur" width="100%"></table>
                                                </div>
                                            </td>
                                        </tr>
                                </table>
                            </div>
                        </div>
                        <br>
                    </div>
-->


<script>
    var show = false;
	function promotion () {
		if (show) {
			$('.promotion-edit').hide();
		} else {
			$('.promotion-edit').show();
		}
		show = !show;
	}
    
    ////// customer //////
    $(function() {
        $.ajax({
            url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
            data: { project_database_sel:'<?php echo $project_database_sel; ?>' },
            dataType: "json",
            success: function(json) {
                var Cash = 0;
                var Gift = 0;
                var Furniture = 0;
                var trCashID = 1;
                var trGiftID = 1;
                var trFurID = 1;
                $('.cashHide').hide();
                $('.giftHide').hide();
                $('.furHide').hide();

				var arr = [<?=$promotion?>];
                $.each(json, function() {
                	var check = '';
                    var id = parseInt(this.pm_id);
                    $.each(arr,function(index, value){
                        if(value == id) {
                            check = 'checked';
                            return;
                        }
                    });

	                if (this.pm_type == 'Cash') {
	                    if (Cash++ == 0)
	                        $('.cashHide').show();
	                    $("#cash").append('<div class="promotion-checkbox pull-left"><input type="checkbox" id="cash'+Cash+'" name="pro[]" value="'+this.pm_id+'" '+check+'/><label for="cash'+Cash+'">'+this.pm_name+'</label></div>');
	                    Cash++;
	                } else if (this.pm_type == 'Gift') {
	                    if (Gift++ == 0)
	                        $('.giftHide').show();
	                    $("#gift").append('<div class="promotion-checkbox pull-left"><input type="checkbox" id="gift'+Gift+'" name="pro[]" value="'+this.pm_id+'" '+check+'/><label for="gift'+Gift+'">'+this.pm_name+'</label></div>');
                        Gift++;
                    } else if (this.pm_type == 'Furniture') {
                        if (Furniture++ == 0)
                            $('.furHide').show();
                        $("#fur").append('<div class="promotion-checkbox pull-left"><input type="checkbox" id="fur'+Furniture+'" name="pro[]" value="'+this.pm_id+'" '+check+'/><label for="fur'+Furniture+'">'+this.pm_name+'</label></div>');
                        Furniture++;
                    }

                });
            }
        });
        
        
        <?php
                $comma = '';
                $allCus = '';
                foreach($list_customer as $customer):
                    $allCus .= $comma.'{value: "'.$customer->cus_id.'",label: "'.$customer->fullname.'"}';
                    if($comma==='') $comma = ',';
                endforeach;
                $allCus = '['. $allCus . ']';
            ?>
        var autoCompleteData = <?php echo $allCus?>;

        //            if(!autoCompleteData) var autoCompleteData = new Array();
        <?php $id = '';
                for($i=2;$i<6;$i++): ?>
        $("#user_fullname<?=$id?>").autocomplete({
                minLength: 3,
                source: autoCompleteData,
                focus: function(event, ui) {
                    $("#user_fullname<?=$id?>").val(ui.item.label);
                    $("#cus-id<?=$id?>").val(ui.item.value);
                    return false;
                },
                select: function(event, ui) {
                    $("#user_fullname<?=$id?>").val(ui.item.label);
                    $("#cus-id<?=$id?>").val(ui.item.value);
                    return false;
                }
            })
            .data("ui-autocomplete")._renderItem = function(ul, item) {
                return $("<li>")
                    .append("<a>" + item.label + "</a>")
                    .appendTo(ul);
            };
        <?php $id = $i;
                endfor; ?>
    });
    ///// end cus  //////
    $(function() {
        $('#trCash').hide();
        $('#trGift').hide();
        $('#trFur').hide();
        $('#trCredit').hide();
        $.ajax({
            url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonQuotation_Project_Promotion.php",
            data: ({
                nextList: 'Project',
                Project: $('#Project').val(),
                project_database_sel: '<?php echo $project_database_sel; ?>'
            }),
            dataType: "json",

            success: function(json) {
                $('#trLoad').hide();
                var tbWidth = 400;
                var Cash = 0;
                var Gift = 0;
                var Furniture = 0;
                var Credit = 0;
                var trCashID = 1;
                var trGiftID = 1;
                var trFurID = 1;
                var trCreditID = 1;
                var arr = [<?=$promotiom?>];
                $.each(json, function() {
                    var check = false;
                    var id = parseInt(this.pm_id);
                    $.each(arr, function(index, value) {
                        if (value == id) {
                            check = true;
                            return false;
                        }
                    });
                    if (this.pm_type == 'Cash') {
                        if (Cash++ == 0)
                            $('#trCash').show();
                        if (Cash % 3 == 1)
                            $("#tbCash").append('<tr id="tdCash' + trCashID + '">');
                        $('#tdCash' + trCashID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_name).prepend(
                            $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                        if (Cash % 3 == 0) {
                            $('#tdCash' + trCashID).append('</tr>');
                            trCashID++;
                        }
                    } else if (this.pm_type == 'Gift') {
                        if (Gift++ == 0)
                            $('#trGift').show();
                        if (Gift % 3 == 1)
                            $("#tbGift").append('<tr id="tdGift' + trGiftID + '">');
                        $('#tdGift' + trGiftID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_name).prepend(
                            $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                        if (Gift % 3 == 0) {
                            $('#tdGift' + trGiftID).append('</tr>');
                            trGiftID++;
                        }
                    } else if (this.pm_type == 'Furniture') {
                        if (Furniture++ == 0)
                            $('#trFur').show();
                        if (Furniture % 3 == 1)
                            $("#tbFur").append('<tr id="tbFur' + trFurID + '">');
                        $('#tbFur' + trFurID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_name).prepend(
                            $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                        if (Furniture % 3 == 0) {
                            $('#tbFur' + trFurID).append('</tr>');
                            trFurID++;
                        }
                    } else if (this.pm_type == 'Credit') {
                        if (Credit++ == 0)
                            $('#trCredit').show();
                        if (Credit % 3 == 1)
                            $("#tbCredit").append('<tr id="tbCredit' + trCreditID + '">');
                        $('#tbCredit' + trCreditID).append($('<td width="' + tbWidth + '">' + '<label class="labelPromotion" > ' + '</td>').text(' ' + this.pm_detail).prepend(
                            $('<input name="pro[]">').attr('type', 'checkbox').val(this.pm_id).prop('checked', check)));
                        if (Credit % 3 == 0) {
                            $('#tbCredit' + trCreditID).append('</tr>');
                            trCreditID++;
                        }
                    }
                });
                if (Cash % 3 > 0) {
                    var td = 3 - (Cash % 3);
                    $('#tdCash' + trCashID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                }
                if (Gift % 3 > 0) {
                    var td = 3 - (Gift % 3);
                    $('#tdGift' + trGiftID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                }
                if (Furniture % 3 > 0) {
                    var td = 3 - (Furniture % 3);
                    $('#tbFur' + trFurID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                }
                if (Credit % 3 > 0) {
                    var td = 3 - (Credit % 3);
                    $('#tbCredit' + trCreditID).append('<td width="' + tbWidth + '" colspan="' + td + '"></td></tr>');
                }
                if (Credit + Gift + Furniture + Cash == 0) {
                    $('#trLoad').show();
                    $('#logPromotion').val('None');
                }
            }
        });
    });
</script>