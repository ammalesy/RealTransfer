   
<script>
    $(window).load(function(){
        $('#loading').remove();
        $('#dataTable').css('visibility','visible');
    });
</script>
    
 
<style>
    a {color:rgb(19, 46, 232);}
</style>

		<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>

<div class="installment-view">
	<div class="content">

		<div class="content-header">
            <font color="#78ad13">View Defect</font> <label class="table-total">...</label>
    </div>

		<div class="content-body">

			<table class="dynamicTable colVis table">
				<!-- Table heading -->
				<thead>
					<tr>
						<th>Defect No.</th>
						<th>Room No.</th>
			            <th>Direction</th>
			            <th>Date</th>
						<th class="center">Action</th>
					</tr>
				</thead>
				<!-- // Table heading END -->
				
				<!-- Table body -->
				<tbody>
					<!-- Table row -->
					<?php foreach($list_room as $defect): ?>
						<tr>
							<td><?php echo $defect->df_room_id; ?></td>
							<td ><?php echo $defect->un_name; ?></td>
							<td ><?php echo $defect->un_direction; ?></td>
							<td ><?php echo $defect->df_check_date; ?></td>
							<td class="center"><a href="<?php echo BASE_DOMAIN; ?>defect/report/th/<?php echo $defect->df_room_id; ?>/<?php echo $defect->df_un_id; ?>"  ><font color="#0e7ccb">Report</font></a></td>
								
						</tr>
			        <?php endforeach; ?>
						
					<!-- // Table row END -->
				</tbody>
				<!-- // Table body END -->
				
			</table>
<!-- // Table END -->
<br/>

	<!-- // Widget END -->
	
</div>
		</div>
		<!-- // Content END -->
</div>
