
<script>
    $(window).load(function(){
        $('#loading').remove();
        $('#dataTable').css('visibility','visible');
    });
</script>


<style>
    a {color:rgb(19, 46, 232);}
</style>

		<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>
    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/moment.min.js"></script>

<div class="installment-view">
	<div class="content">

		<div class="content-header">
          <?php
            $title = "View Defect";
            if ($isGuarantee == TRUE) {
                $title = "View Defect Guarantee";
            }
           ?>
            <font color="#78ad13"><?php echo $title; ?></font> <label class="table-total">...</label>
    </div>

		<div class="content-body">

			<table class="dynamicTable colVis table">
				<!-- Table heading -->
				<thead>
					<tr>
						<th>Item No.</th>
						<th>Unit No.</th>
			      <th>Customer Name.</th>
            <!-- <th>Check step.</th> -->
			      <th>Date</th>
						<th class="center">Action</th>
            <th class="center">Print Date</th>
            <th class="center">Print Command</th>
					</tr>
				</thead>
				<!-- // Table heading END -->

				<!-- Table body -->
				<tbody>
					<!-- Table row -->
					<?php foreach($list_room as $defect): ?>
						<tr>
							<td><?php echo $defect->df_room_id; ?></td>
							<td ><?php echo $defect->building_name." ".$defect->un_name; ?></td>
              <?php if($defect->user->pers_fname == "") { ?>
              <td >N/A</td>
              <?php }else{ ?>
							<td ><?php echo $defect->user->pers_prefix.$defect->user->pers_fname." ".$defect->user->pers_lname; ?></td>
              <?php } ?>
              <!--
              <?php if($defect->df_sync_status == "0") { ?>
              <td >การตรวจรับครั้งที่ 1 </td>
              <?php }else{ ?>
							<td >การตรวจรับครั้งที่ 2 </td>
              <?php } ?>-->
							<td >

              <?php

              $date = $defect->df_check_date;
              $explodDate = explode("|",$date);
              echo $explodDate[0]." ".$explodDate[1];

              ?></td>
							<td class="center">
                <a href="<?php echo BASE_DOMAIN; ?>defect/unlock/<?php echo $defect->df_room_id; ?>">
                  <font color="red">&nbsp;Unlock&nbsp;</font>
                </a>
                <?php
                $pathViewDefect = "viewDefect";
                $pathReport = "report";
                  if ($isGuarantee == TRUE) {
                      $pathViewDefect = "viewDefectGuarantee";
                      $pathReport = "reportGuarantee";
                  }
                ?>
                <a href="<?php echo BASE_DOMAIN; ?>defect/<?php echo $pathViewDefect; ?>/<?php echo $defect->df_room_id; ?>/<?php echo $defect->df_un_id; ?> ">
                  <font color="#005BCF">&nbsp;View&nbsp;</font>
                </a>


              </td>
              <td class="center">
                <?php
                    echo $lastPrintDate = $defect->last_print_date;
                 ?>
              </td>
              <td class="center">

                    <button type="button" data-value="<?php echo $lastPrintDate; ?>" id="print_th_<?php echo $defect->df_room_id; ?>" data-href="<?php echo BASE_DOMAIN; ?>defect/<?php echo $pathReport; ?>/th/<?php echo $defect->df_room_id; ?>/<?php echo $defect->df_un_id; ?>" class="btn btn-primary datepicker" >TH</button>
                    <button type="button" data-value="<?php echo $lastPrintDate; ?>" id="print_en_<?php echo $defect->df_room_id; ?>" data-href="<?php echo BASE_DOMAIN; ?>defect/<?php echo $pathReport; ?>/en/<?php echo $defect->df_room_id; ?>/<?php echo $defect->df_un_id; ?>" class="btn btn-primary datepicker">EN</button>

                <script>


                $('#print_th_<?php echo $defect->df_room_id; ?>').on('click', function(event) {

                  var href = $(this).attr("data-href");
                  var $input = $('.datepicker').pickadate({
                      selectMonths: true,
                      selectYears: 15,
                      format: 'yyyy-mm-dd',
                      formatSubmit: 'yyyy-mm-dd',
                      onSet: function(context) {
                          var dateVal = moment(context.select).format('YYYY-MM-DD');
                          window.location.href = href+"/"+dateVal;
                      }
                  });
                  var picker = $input.pickadate('picker');
                  picker.open();
                });
                $('#print_en_<?php echo $defect->df_room_id; ?>').on('click', function(event) {
                  var href = $(this).attr("data-href");
                  var $input = $('.datepicker').pickadate({
                      selectMonths: true,
                      selectYears: 15,
                      format: 'yyyy-mm-dd',
                      formatSubmit: 'yyyy-mm-dd',
                      onSet: function(context) {
                          var dateVal = moment(context.select).format('YYYY-MM-DD');
                          window.location.href = href+"/"+dateVal;
                      }
                  });
                  var picker = $input.pickadate('picker');
                  picker.open();
                });
                </script>
              </td>

						</tr>
			        <?php endforeach; ?>

					<!-- // Table row END -->
				</tbody>
				<!-- // Table body END -->

			</table>
<!-- // Table END -->
<br/>

	<!-- // Widget END -->

</div>
		</div>
		<!-- // Content END -->
</div>

<script>
$(function() {
  // $('.datepicker').on('click', function(event) {
  //   var currentDate = $(this).attr("data-value");
  //   alert();
  // });
  // $('.datepicker#print_th_5').pickadate({
  //     selectMonths: true,
  //     selectYears: 15,
  //     format: 'yyyy-mm-dd',
  //     formatSubmit: 'yyyy-mm-dd'
  // });
  // $('.datepicker#print_th_84').pickadate({
  //     selectMonths: true,
  //     selectYears: 15,
  //     format: 'yyyy-mm-dd',
  //     formatSubmit: 'yyyy-mm-dd'
  // });
});
</script>
