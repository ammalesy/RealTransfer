
<script>
    $(window).load(function(){
        $('#loading').remove();
        $('#dataTable').css('visibility','visible');
    });
</script>


<style>
    a {color:rgb(19, 46, 232);}
</style>

		<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>

<div class="installment-view">
	<div class="content">

    <?php
    $pathViewDefect = "view";
    $pathReport = "report";
      if ($isGuarantee == TRUE) {
          $pathViewDefect = "viewGuarantee";
          $pathReport = "reportGuarantee";
      }
    ?>
		<div class="content-header">
            <a href="<?php echo BASE_DOMAIN; ?>defect/<?php echo $pathViewDefect; ?>/">
            <button type="button" class="btn btn-primary">Back</button></font>
            </a>
            <!-- <a href="<?php echo BASE_DOMAIN; ?>defect/<?php echo $pathReport; ?>/th/<?php echo $df_room_id; ?>/<?php echo $un_id; ?> "target=_blank>
              <button type="button" class="btn btn-primary">Print</button></font>
            </a> -->
    </div>

		<div class="content-body">

			<table class="dynamicTable colVis table">
				<!-- Table heading -->
				<thead>
					<tr>
						<th>Defect No.</th>
            <th>Image</th>
						<th>Detail</th>
			      <th>Date</th>
            <th>Status</th>
					</tr>
				</thead>
				<!-- // Table heading END -->

				<!-- Table body -->
				<tbody>
					<!-- Table row -->
					<?php foreach($list_defect as $defect): ?>
            <?php
            // $icon_status = "../../../../Service/icon/fail.png";
            // if($defect->complete_status == "1"){
            //   $icon_status = "../../../../Service/icon/pass.png";
            // }
            $text_status = "<b>รอการตรวจสอบ</b>";
            if($defect->complete_status == "1"){
              $text_status = "<font color=green><b>ตรวจสอบแล้ว</b></font>";
            }
            ?>
						<tr>
							<td><?php echo $defect->df_id; ?></td>
              <td><?php echo '<img src="../../../../Service/images/'.$pj_db.'/'.$un_id.'/'.$defect->df_image_path.'.jpg" alt="" width="100" />'; ?></td>
							<td >
                  Category: <b><?php echo $defect->df_category; ?></b><br>
                  Sub Category: <b><?php echo $defect->df_sub_category; ?></b><br>
                  Detail: <b><?php echo $defect->df_detail; ?></b>
              </td>
              <td >
              <?php

              $date = $defect->df_date;
              $explodDate = explode("|",$date);
              echo $explodDate[0]." ".$explodDate[1];

              ?></td>
              <!-- <td ><?php echo '<img src="'.$icon_status.'" alt="" width="80"  />'; ?></td> -->
              <td ><?php echo $text_status; ?></td>

						</tr>
			        <?php endforeach; ?>

					<!-- // Table row END -->
				</tbody>
				<!-- // Table body END -->

			</table>
<!-- // Table END -->
<br/>

	<!-- // Widget END -->

</div>
		</div>
		<!-- // Content END -->
</div>
