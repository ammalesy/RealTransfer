<script src="<?php echo BASE_DOMAIN; ?>assets/report/js/highcharts.js">
</script>
<script src="<?php echo BASE_DOMAIN; ?>assets/report/js/chart.js"></script>

<script type="text/javascript">
    $(function() {

        $(document).ready(function() {

            // Build the chart
            $('#PieLead').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie',
                    height: 170,
                    margin: [0, 0, 0, 0],
                    spacingTop: 0,
                    spacingBottom: 0,
                    spacingLeft: 0,
                    spacingRight: 0,
                },
                credits: {
                    enabled: false
                },
                title: {
                    text: null
                },
                tooltip: {
                    pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: false
                    }
                },
                series: [{
                    type: 'pie',
                    name: 'Percents',
                    data: [
                        ['Website', <?php echo !empty($website)?$website:0; ?>],
                        ['Call in', <?php echo !empty($callin)?$callin:0; ?>],
                        ['Walk in', <?php echo !empty($walkin)?$walkin:0; ?>],
                        /*{
                                name: 'Walk in',
                                y: <?php echo !empty($walkin)?$walkin:0; ?>,
                                sliced: true,
                                selected: true
                    },*/
                        ['SMS', <?php echo !empty($sms)?$sms:0; ?>],
                        ['Online Media', <?php echo !empty($online)?$online:0; ?>],
                        ['Project Poster', <?php echo !empty($poster)?$poster:0; ?>],
                        ['Billboard', <?php echo !empty($billboard)?$billboard:0; ?>],
                        ['Booth', <?php echo !empty($booth)?$booth:0; ?>],
                        ['Friends', <?php echo !empty($friends)?$friends:0; ?>],
                        ['Newspaper', <?php echo !empty($news)?$news:0; ?>],
                        ['Leaflet', <?php echo !empty($leaflet)?$leaflet:0; ?>],
                        ['Others', <?php echo !empty($others)?$others:0 ?>]
                    ]
                }]
            });
        });
    });
</script>

<script type="text/javascript">
    $(function() {
        $('#ChartQuo').highcharts({
            chart: {
                type: '<?php echo $format_chart; ?>'
            },
            title: {
                text: ''
            },
            credits: {
                enabled: false
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $xAxis; ?>],

                labels: {
                    step: [<?php echo $date_cut; ?>],
                    <?php echo $rotation; ?>
                },
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total <?php echo $type_name; ?>'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">Total: </td>' +
                    '<td style="padding:0"><b>{point.y} <?php echo $type_name; ?></b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [{
                showInLegend: false,
                name: 'Quotation',
                data: [<?php echo $count_cus; ?>]

            }]
        });
    });
</script>

<?php
	$CI =& get_instance();
	$CI->load->library('/chart/Hightchart');
   	$chart = $CI->hightchart;
   	$param      =   !empty($_GET["from"])?"'".$_GET["from"]."'":'';
   	$param      .=  !empty($_GET["to"])?" AND '".$_GET["to"]."'":'';
   	$searchby   =   !empty($_GET["by"])?$_GET["by"]:'';
   	$ago        =   !empty($_GET["term"])?$_GET["term"]:'';
   	$back       =   !empty($_GET["back"])?$_GET["back"]:'';
   	$bill_status   =   !empty($_GET["bill"])?$_GET["bill"]:'';
   	$project    =   !empty($_GET["project"])?$_GET["project"]:'';

   $tab = !empty($searchby)?$searchby:($back==''?'1week':$back);
   if ( $tab == '1week' || $tab == '1month' || $tab == '3month' )
   {    
     $ago = $tab == '1week'?'week':'month';
     $back = $tab;
     $searchby = 'ago';    
   }

   echo $chart->api_Leads($param,$searchby,$ago,$back);
   echo $chart->api_Opportunitystage();
   echo $chart->api_Type($param,$searchby);
   echo $chart->api_Customers($param,$searchby,$ago,$back);
   echo $chart->api_CustomerData_Ages();
   echo $chart->api_CustomerData_Nationality();
   echo $chart->api_Proportion_CustomersAndLeads($param,$searchby,$ago,$back);	
   echo $chart->api_Bookings($project,$param,$searchby,$ago,$back);
   echo $chart->api_Quatations($project,$param,$searchby,$ago,$back);
   echo $chart->api_Receipts_Dashboard($project,$bill_status,$param,$searchby,$ago,$back);
   
 
   echo $chart->api_topunit_Dashboard($project,$param,'5',$searchby,$ago,$back);

   
    $tab = $back;
?>

    <div class="dashboard-view">
        <div class="content main-dash">
            <div class="header">
                <label>Dash Board</label>
            </div>
            <div class="row">
                <div class="col m12 l3">
                    <div class="card style1">
                        <div class="card-form">
                            <span class="activator span-card-title">Total Quotations <a href="#"><i class="material-icons right"> more_vert</i></a></span>
                            <div data-percent="85" data-size="140" data-scale-color="false" data-track-color="#ffffff" data-line-width="5">
                                <p class="lead text-center"><span class="span-card-data1"><?php echo number_format($QuoWaiting) ?> </span><br/><span class="unit">&nbsp;</span></p>
                            </div>
                        </div>
                        <div class="card-action">
                            <label><span class="span-card-footer">Lastest Quotation : <?php echo $maxdatequo ?> </span></label>
                        </div>
                    </div>
                </div>

                <div class="col m12 l3">
                    <div class="card style2">
                        <div class="card-form">
                            <span class="activator span-card-title">Total Booking
                            <a href="#"><i class="material-icons right"> more_vert</i></a>
                            </span>
                            <div data-percent="85" data-size="140" data-scale-color="false" data-track-color="#ffffff" data-line-width="5">
                                <p class="lead text-center"><span class="span-card-data1"><?php echo number_format($countBook) ?> </span><br/><span class="unit">Units</span></p>
                            </div>
                        </div>
                        <div class="card-action">
                            <label><span class="span-card-footer">Lastest Booking : <?php echo $maxdatebook ?> </span></label>
                        </div>
                    </div>
                </div>

                <div class="col m12 l3">
                    <div class="card style3">
                        <div class="card-form">
                            <span class="activator span-card-title">Total Sold
                            <a href="#"><i class="material-icons right"> more_vert</i></a>
                            </span>
                            <div data-percent="85" data-size="140" data-scale-color="false" data-track-color="#ffffff" data-line-width="5">
                                <p class="lead text-center"><span class="span-card-data1"><?php echo number_format($countSold) ?> </span><br/><span class="unit">Units</span></p>
                            </div>
                        </div>
                        <div class="card-action">
                            <label><span class="span-card-footer">Today Sold : <?php echo number_format($countdatecon) ?> Unit</span></label>
                        </div>
                    </div>
                </div>

                <div class="col m12 l3">
                    <div class="card style4">
                        <div class="card-form">
                            <span class="activator span-card-title">Unit Available
                            <a href="#"><i class="material-icons right"> more_vert</i></a>
                            </span>
                            <div data-percent="85" data-size="140" data-scale-color="false" data-track-color="#ffffff" data-line-width="5">
                                <p class="lead text-center"><span class="span-card-data1"><?php echo number_format($countAvai) ?></span><br/><span class="unit">&nbsp;</span></p>
                            </div>
                        </div>
                        <div class="card-action">
                            <label><span class="span-card-footer">of <?php echo number_format($sumavai) ?> Units (<?php echo number_format($persofavai,2) ?> %)</span></label>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col m12 l6">
                    <div class="card style1">
                        <div class="card-form">
                            <span class="activator span-card-title">Booking income
                            <a href="#"><i class="material-icons right"> more_vert</i></a>
                            </span>
                            <div class="rectangle text-right"><span class="span-card-data2"><?php echo number_format($pricebooking) ?></span><span class="unit">THB</span></div>
                        </div>
                    </div>
                </div>

                <div class="col m12 l6">
                    <div class="card style3">
                        <div class="card-form">
                            <span class="span-card-title activator">Contract income
                            <a href="#"><i class="material-icons right"> more_vert</i></a>
                            </span>
                            <div class="rectangle text-right"><span class="span-card-data2"><?php echo number_format($pricecontract) ?></span><span class="unit">THB</span></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col m12 l6">
                    <div class="card">
                        <div class="card-form">
                            <span class="activator span-card-title">Quotations</span>
                            <span style='font-size:12pt; float:right;'><?php echo $date_show; ?>
                        <span><a href="#"><i class="material-icons right"> more_vert</i></a></span>
                            </span>
                        </div>
                        <div class="innerAll">
                            <div class="tab-content ">
                                <div class="chart-quo" id="ChartQuo"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col m12 l3">
                    <div class="card">
                        <div class="card-form">
                            <span class="activator span-card-title">Lead Opportunities
                            <a href="#"><i class="material-icons right"> more_vert</i></a>
                            </span>
                        </div>
                        <div class="chart-lead" id="PieLead" ></div>
                    </div>
                </div>
            </div>

        </div>
        <div style='margin-top:2px;clear:both'></div>
    </div>

    <!-- Global -->
    <script>
        //AddHbd('<?php echo $msg?>')
    </script>

    <script>
        //Agofocus('<?php echo $searchby; ?>', '<?php echo $back; ?>')
    </script>