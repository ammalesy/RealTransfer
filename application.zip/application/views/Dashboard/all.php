<!DOCTYPE html>
<!--[if lt IE 7]> <html class="ie lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="ie lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="ie lt-ie9"> <![endif]-->
<!--[if gt IE 8]> <html> <![endif]-->
<!--[if !IE]><!--><html><!-- <![endif]-->
<head>
	<title>Admin System</title>
	
	<!-- Meta -->
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
	
	<!-- 
	**********************************************************
	In development, use the LESS files and the less.js compiler
	instead of the minified CSS loaded by default.
	**********************************************************
	<link rel="stylesheet/less" href="assets/less/admin/module.admin.page.form_validator.less" />
	-->
	
		<!--[if lt IE 9]><link rel="stylesheet" href="../assets/components/library/bootstrap/css/bootstrap.min.css" /><![endif]-->
	<link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/setting.css" />
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>	

<script type="text/javascript">

</script>
</head>
<body class="">
	<div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
		<?php
			include "application/views/menu_top.php";
		?>
	</div>

	<div id="menu" class="hidden-print hidden-xs">
		<?php
			 //include "getmenu.php";
		?>
	</div>
		
	<div id="content"><h1 class="bg-white content-heading border-bottom">Dashboard</h1>
	<div class="innerAll spacing-x2">
		<div class="col-md-3 col-sm-6">
			<div class="panel-3d">
				<div class="front">

					<div class="widget text-center">
						<div class="widget-body padding-none">
							<div>
								<div class="innerAll bg-default">
									<p class="lead strong margin-none"><i class="icon-add-to-cart"></i><br/>Total Customers</p>
									<p class="lead strong margin-none"><?php echo $countidcus; ?></p>						
								</div>
								<div class="innerAll">
									<button class="btn btn-default">View Latest Customer</button>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="back">
					<div class="widget widget-inverse widget-scroll" data-scroll-height="165px">
						<div class="widget-head">
							<button class="btn btn-xs btn-default pull-right"><i class="fa fa-times"></i></button>
							<h4 class="heading">Latest Customer</h4>
						</div>
						<div class="widget-body padding-none">
							<div>
								<div class="box-generic border-none text-center">
									<p class="margin-none"><br/><br/></p>
									<p><strong class="text-large "><?php echo $fullnamelastcus; ?></strong></p>
									<p class="margin-none"><br/><br/></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-6">
			<div class="panel-3d">
				<div class="front">

					<div class="widget text-center">
						<div class="widget-body padding-none">
							<div>
								<div class="innerAll bg-info">
									<p class="lead strong margin-none"><i class="icon-add-to-cart"></i><br/>Total Leads</p>
									<p class="lead strong margin-none"><?php echo $countidleads; ?></p>						
								</div>
								<div class="innerAll">
									<button class="btn btn-default">View Latest Leads</button>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="back">
					<div class="widget widget-inverse widget-scroll" data-scroll-height="165px">
						<div class="widget-head">
							<button class="btn btn-xs btn-default pull-right"><i class="fa fa-times"></i></button>
							<h4 class="heading">Latest Leads</h4>
						</div>
						<div class="widget-body padding-none">
							<div>
								<div class="box-generic border-none text-center">
									<p class="margin-none"><br/><br/></p>
									<p><strong class="text-large "><?php echo $fullnamelastleads; ?></strong></p>
									<p class="margin-none"><br/><br/></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-6">
			<div class="panel-3d">
				<div class="front">
					
					<div class="widget text-center">
						<div class="widget-body padding-none">
							<div>
								<div class="innerAll bg-success">
									<p class="lead strong margin-none text-white"><i class="icon-note-pad"></i><br/>Total Bookings</p>
									<p class="lead strong margin-none"><?php echo $bookingWaiting; ?></p>
								</div>
								<div class="innerAll">
									<button class="btn btn-success">View Latest Booking</button>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="back">
					<div class="widget widget-inverse widget-scroll" data-scroll-height="165px">
						<div class="widget-head">
							<button class="btn btn-xs btn-default pull-right"><i class="fa fa-times"></i></button>
							<h4 class="heading">Latest Booking</h4>
						</div>
						<div class="widget-body padding-none">
							<div>
								<div class="box-generic border-none text-center">
									<p class="lead strong margin-none"><br/><?php echo $bookingcodelast; ?></p>
									<p class="lead strong margin-none">Contract Date <br/><?php echo $bookingcontractdatelast; ?></p>
									<p class="margin-none"><br/></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
				<div class="col-md-3 col-sm-6">
			<div class="panel-3d">
				<div class="front">
					
					<div class="widget text-center">
						<div class="widget-body padding-none">
							<div>
								<div class="innerAll bg-info">
									<p class="lead strong margin-none text-white"><i class="icon-note-pad"></i><br/>Total Quotation</p>
									<p class="lead strong margin-none"><?php echo $QuoWaiting; ?></p>
								</div>
								<div class="innerAll">
									<button class="btn btn-info">View Latest Quotation</button>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="back">
					<div class="widget widget-inverse widget-scroll" data-scroll-height="165px">
						<div class="widget-head">
							<button class="btn btn-xs btn-default pull-right"><i class="fa fa-times"></i></button>
							<h4 class="heading">Latest Quotation</h4>
						</div>
						<div class="widget-body padding-none">
							<div>
								<div class="box-generic border-none text-center">
									<p class="lead strong margin-none"><br/><?php echo $Quolast; ?></p>
									<p class="lead strong margin-none"><?php echo $fullnamelastcus; ?></p>
									<p class="margin-none"><br/></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-md-3 col-sm-6">
			<div class="panel-3d">
				<div class="front">
					
					<div class="widget text-center">
						<div class="widget-body padding-none">
							<div>
								<div class="innerAll bg-success">
									<p class="lead strong margin-none text-white"><i class="icon-note-pad"></i><br/>Total Contract</p>
									<p class="lead strong margin-none"><?php echo $ConWaiting; ?></p>
								</div>
								<div class="innerAll">
									<button class="btn btn-success">View Latest Contract</button>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="back">
					<div class="widget widget-inverse widget-scroll" data-scroll-height="165px">
						<div class="widget-head">
							<button class="btn btn-xs btn-default pull-right"><i class="fa fa-times"></i></button>
							<h4 class="heading">Latest Contract</h4>
						</div>
						<div class="widget-body padding-none">
							<div>
								<div class="box-generic border-none text-center">
									<p class="lead strong margin-none"><br/><?php echo $Conlast; ?></p>
									<p class="lead strong margin-none"><?php echo $fullnamelastConcus; ?></p>
									<p class="margin-none"><br/></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		<div class="col-md-3 col-sm-6">
			<div class="panel-3d">
				<div class="front">
					
					<div class="widget text-center">
						<div class="widget-body padding-none">
							<div>
								<div class="innerAll bg-default">
									<p class="lead strong margin-none "><i class="icon-note-pad"></i><br/> Receipt waiting </p>
									<p class="lead strong margin-none"><?php echo $RecwaitWaiting; ?></p>
								</div>
								<div class="innerAll">
									<button class="btn btn-default">View Latest Receipt waiting</button>
								</div>
							</div>
						</div>
					</div>

				</div>
				<div class="back">
					<div class="widget widget-inverse widget-scroll" data-scroll-height="165px">
						<div class="widget-head">
							<button class="btn btn-xs btn-default pull-right"><i class="fa fa-times"></i></button>
							<h4 class="heading">Latest Receipt waiting</h4>
						</div>
						<div class="widget-body padding-none">
							<div>
								<div class="box-generic border-none text-center">
									<p class="lead strong margin-none"><br/><?php echo $Recwaitlast; ?></p>
									<p class="lead strong margin-none"><?php echo $fullnamelastRecwaitcus; ?></p>
									<p class="margin-none"><br/></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		
	</div>
	</div>
	<!-- // Content END -->
		
	<div class="clearfix"></div>
	<!-- // Sidebar menu & content wrapper END -->
		
	<div id="footer" class="hidden-print">
	</div>
	<!-- // Footer END -->
		
	</div>
	<!-- // Main Container Fluid END -->
	

	

	<!-- Global -->
	<script>
	var basePath = '',
		commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
		rootPath = '<?php echo BASE_DOMAIN; ?>',
		DEV = false,
		componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';
	
	var primaryColor = '#cb4040',
		dangerColor = '#b55151',
		infoColor = '#466baf',
		successColor = '#8baf46',
		warningColor = '#ab7a4b',
		inverseColor = '#45484d';
	
	var themerPrimaryColor = primaryColor;
	</script>
	
	<script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/validator/assets/lib/jquery-validation/dist/jquery.validate.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/validator/assets/custom/form-validator.user.js"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>	
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/lib/jquery.inputmask.bundle.min.js?v=v1.2.3"></script>
<script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/custom/inputmask.user.js"></script>
</body>
</html>