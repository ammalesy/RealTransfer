<script type="text/javascript">
    $(function() {
        $('#container').highcharts({
            chart: {
                type: '<?php echo $format_chart; ?>'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $xAxis; ?>],

                labels: {
                    step: [<?php echo $date_cut; ?>],
                    <?php echo $rotation; ?>
                },
                crosshair: true



            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total <?php echo $type_name; ?>'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">Total: </td>' +
                    '<td style="padding:0"><b>{point.y} <?php echo $type_name; ?></b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [{
                name: '<?php echo $type_name; ?>',
                data: [<?php echo $count_cus; ?>]

            }]
        });
    });
    
    function next() 
    {
        $('#load').modal('hide');
    }
        
    $(function() {
        $("#search").submit(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
        
        $(".subm").click(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
    });
</script>

<div id="menu" class="hidden-print hidden-xs">
    <?php		
    if ($permission->pm_chart_report<1) {
        alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
    }
    ?>
</div>
<div class="customer-report">
    <div class="content">
           <div class="modal fade" id="load" data-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Loading...</h3>
                        </div>
                    </div>
                </div>
            </div>
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Bookings</a>
                        <ul class="right hide-on-med-and-down">
                            <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/booking/total">Total</a></li>
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/booking/today" class="subm">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/booking/week" class="subm">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/booking/month" class="subm">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
                            <li>
                                <div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="slide" style="display:none">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/booking/custom" method="post" id="search">
                    <div class="custom-date col l10">
                        <input class="datepicker" type="date" name="start" required="required" value="<?php echo date( "Y-m-d", strtotime("-30 days ", strtotime(date('Y-m-d'))) ); ?>" title="Please enter Start Date">
                        <label><b>TO</b></label>
                        <input class="datepicker" type="date" name="end" required="required" value="<?php echo date('Y-m-d'); ?>" title="Please enter End Date">
                    </div>

                    <div class="col l2 button-submit">
                        <button class="btn waves-effect waves-light" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
		<div class="content-body" id="printPage">
            <div class="customer-report">
        		<div class="widget widget-inverse">
                    <div class="widget-head">
                        <h4 class="heading">Bookings</h4><span style='float:right;right:10px;color:#ffffff'><?php echo $date_show; ?></span>
                    </div>
                    <div class="widget-body">
                        <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>

<script>
    function printDiv() {
        var chart = $('#container').highcharts();
        chart.setSize(1070,500, false);

        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
        
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();

        

    }
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script>