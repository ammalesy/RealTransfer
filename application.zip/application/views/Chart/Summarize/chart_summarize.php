    <div id="menu" class="hidden-print hidden-xs">
        <?php
			
//			if ($permission->pm_project_building<1) {
//				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
//			}
			?>
    </div>
<div class="summarize-report">
    <input type="hidden" id="loading" value="no"/>
    <div class="content">
    
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Leads</a>
                        <ul class="right hide-on-med-and-down">
<!--
                            <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/total" class="subm">Total</a></li>
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/today" class="subm">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/week" class="subm">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/lead/month" class="subm">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
-->
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print ">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    <?php
//        include "application/views/Chart/Summarize/summarize_menu.php";
    ?>
            <div class="summarize-report innerAll spacing-x2" id="printPage">


                <!-- Widget -->
                <div class="widget widget-inverse">
<!--
                    <div class="widget-head">
                        <h4 class="heading">View Summarize</h4>
                    </div>
-->                   
                    <div class="card-content">
                        <span class="card-title layout-title grey-text text-white">View Summarize</span>
                    </div>
                    <div class="widget-body">
                        <div class="select_year">
                                  <table>
                                        <tr>
                                            <th style="width:70px;">Year : </th>
                                            <th>
                                                <select class="form-control" id="year" onchange="LoadYear(this.value)">
                                        <?php for($y=2014;$y <= date("Y");$y++): ?>
                                            <option <?= $y==date( "Y")? 'selected': '' ?>><?= $y ?></option>
                                            <?php endfor; ?>
                                    </select>
                                            </th>
                                        </tr>
                                        <?php echo $tableTopUnit; ?>
                                    </table>
<!--
                                   <span>Year&nbsp;</span>
                                    <select class="form-control" id="year" onchange="LoadYear(this.value)">
                                        <?php for($y=2014;$y <= date("Y");$y++): ?>
                                            <option <?= $y==date( "Y")? 'selected': '' ?>><?= $y ?></option>
                                            <?php endfor; ?>
                                    </select>
-->
                        </div>
                        <br/>
                        <div class="center">
                            <lable id="load">Loading...</lable>
                        </div>
                        <!-- Table -->
                        <table border="1" style="font-size:10pt;display:none;" id="tbList">
                            <thead class="bg-gray" style="font-weight:bold;text-align:center">
                                <tr id="thead">
                                    <th style="text-align:center">Type</th>
                                    <th style="text-align:center">ม.ค.</th>
                                    <th style="text-align:center">ก.พ.</th>
                                    <th style="text-align:center">มี.ค.</th>
                                    <th style="text-align:center">เม.ย.</th>
                                    <th style="text-align:center">พ.ค.</th>
                                    <th style="text-align:center">มิ.ย.</th>
                                    <th style="text-align:center">ก.ค.</th>
                                    <th style="text-align:center">ส.ค.</th>
                                    <th style="text-align:center">ก.ย.</th>
                                    <th style="text-align:center">ต.ค.</th>
                                    <th style="text-align:center">พ.ย.</th>
                                    <th style="text-align:center">ธ.ค.</th>
                                    <th style="text-align:center">Total</th>
                                </tr>
                            </thead>
                            <tbody id="tdList">
                                <!-- Table row -->
                            </tbody>

                        </table>
                        <!-- // Table END -->
                    </div>
                </div>
                <!-- // Widget END -->
            </div>
    </div>
    <!-- // Content END -->

    <div class="clearfix"></div>
    <!-- // Sidebar menu & content wrapper END -->

    <div id="footer" class="hidden-print">
</div>



    </div>
    
    <script>
        function LoadYear(year) {
            $('#loading').val('yes');
            $('#load').show();
            $('#tbList').hide();
            $.ajax({
                url: '<?= BASE_DOMAIN ?>chart/jsonvisityear/' + year,
                dataType: 'json',
                success: function (json) {
                    var list = '';
                    $('#tdList').html('');
                    $.each(json, function (id, val) {
                        var sum = 0;
                        list += '<tr><td>' + id + '</td>';
                        for (var i = 1; i < 13; i++) {
                            sum += parseInt(val[i]);
                            list += '<td>' + val[i] + '</td>';
                        }
                        list += '<td>' + sum + '</td></tr>';
                    });
                    $('#load').hide();
                    $('#tbList').show();
                    $('#tdList').html(list);
                    $('#loading').val('no');
                }
            });
        }
        
        function LoadMont() {
            $('#loading').val('yes');
            var year = $('#mYear').val();
            var month = $('#month').val();
            var max = 31;
            if(month == '04' || month == '06' || month == '09' || month == '11')
                max = 30;
            else if(month == '02')
                max = 29;
            $('#load').show();
            $('#tbList').hide();
            $.ajax({
                url: '<?= BASE_DOMAIN ?>chart/jsonvisitmonth/' + year + '/' + month,
                dataType: 'json',
                success: function (json) {
                    var list = '';
                    $('#tdList').html('');
                    $.each(json, function (id, val) {
                        var sum = 0;
                        list += '<tr><td>' + id + '</td>';
                        for (var i = 1; i <= max; i++) {
                            sum += parseInt(val[i]);
                            list += '<td>' + val[i] + '</td>';
                        }
                        list += '<td>' + sum + '</td></tr>';
                    });
                    
                    var header = '<th style="text-align:center">Type</th>';
                    for(var i=1;i<=max;i++) header += '<th style="text-align:center">'+i+'</th>';
                    header += '<th style="text-align:center">Total</th>';
                    $('#thead').html(header);
                    
                    $('#load').hide();
                    $('#tbList').show();
                    $('#tdList').html(list);
                    $('#loading').val('no');
                }
            });
        }
        $(document).ready(function () {
            LoadYear($('#year').val());
        });
        
        function printDiv() {
            var DocumentContainer = document.getElementById('printPage');
            var WindowObject = window.open();

            WindowObject.document.writeln('<!DOCTYPE html>');
            WindowObject.document.writeln('<html><head><title></title>');
            WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
            WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
            WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');

            WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
            WindowObject.document.writeln('</head><body>');
            WindowObject.document.writeln(DocumentContainer.innerHTML);
            WindowObject.document.writeln('</body></html>');

            WindowObject.document.close();
            WindowObject.focus();
            WindowObject.print();
            WindowObject.close();
        }
    </script>
