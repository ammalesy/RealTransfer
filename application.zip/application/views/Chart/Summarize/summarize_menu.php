<div class="innerAll bg-white border-bottom">
    <ul class="menubar">
        <li class="active" id="menu1"><a href="#" onclick="MenuYear()"><span>รวมยอดทั้งสิ้น</span></a></li>
        <li id="menu2"> <a href="#" onclick="MenuMonth()"><span>สรุปยอดเดือน</span></a></li>
    </ul>
</div>
<script>
    function MenuYear() {
        if($('#loading').val() == 'no') {
            $('#content').css('width', '');
            $('#stYear').show();
            $('#stMonth').hide();
            $('#thead').html(
                '<th style="text-align:center">Type</th>'+
                '<th style="text-align:center">ม.ค.</th>'+
                '<th style="text-align:center">ก.พ.</th>'+
                '<th style="text-align:center">มี.ค.</th>'+
                '<th style="text-align:center">เม.ย.</th>'+
                '<th style="text-align:center">พ.ค.</th>'+
                '<th style="text-align:center">มิ.ย.</th>'+
                '<th style="text-align:center">ก.ค.</th>'+
                '<th style="text-align:center">ส.ค.</th>'+
                '<th style="text-align:center">ก.ย.</th>'+
                '<th style="text-align:center">ต.ค.</th>'+
                '<th style="text-align:center">พ.ย.</th>'+
                '<th style="text-align:center">ธ.ค.</th>'+
                '<th style="text-align:center">Total</th>'
            );
            $('#menu1').addClass('active');
            $('#menu2').removeClass('active');
            $('#menu3').removeClass('active');
            $('#menu4').removeClass('active');
            LoadYear($('#year').val());
        }
    }
    function MenuMonth() {
        if($('#loading').val() == 'no') {
            $('#content').css('width', '1200px');
            $('#stYear').hide();
            $('#stMonth').show();
            
            $('#menu1').removeClass('active');
            $('#menu2').addClass('active');
            $('#menu3').removeClass('active');
            $('#menu4').removeClass('active');
            LoadMont();
        }
    }
</script>