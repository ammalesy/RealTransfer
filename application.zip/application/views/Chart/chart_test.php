
    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.finances.min.css" />
    
    <!-- Include Required Prerequisites -->
    <script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap/latest/css/bootstrap.css" />

    <!-- Include Date Range Picker -->
    <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
    
    <!-- Highchart -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/drilldown.js"></script>

    <div id="content">
        
        <div class="innerAll text-center">
            <div class="widget widget-inverse">
                <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
                    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                    <span></span> <b class="caret"></b>
                </div>
            </div>
            <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
        </div>
        
    </div>
    <script type="text/javascript">
    $(function() {

        function cb(start, end) {
            var typeDate = ''; 
            if(start.format('YYYY-MM-DD') == moment().format('YYYY-MM-DD') && end.format('YYYY-MM-DD') == moment().format('YYYY-MM-DD')) {
                typeDate = 'today';
            } else if(start.format('YYYY-MM-DD') == moment().subtract(1, 'days').format('YYYY-MM-DD') && end.format('YYYY-MM-DD') == moment().subtract(1, 'days').format('YYYY-MM-DD')) {
                typeDate = 'yesterday';
            } else if(start.format('YYYY-MM-DD') == moment().subtract(6, 'days').format('YYYY-MM-DD') && end.format('YYYY-MM-DD') == moment().format('YYYY-MM-DD')) {
                typeDate = '7days';
            } else if(start.format('YYYY-MM-DD') == moment().subtract(29, 'days').format('YYYY-MM-DD') && end.format('YYYY-MM-DD') == moment().format('YYYY-MM-DD')) {
                typeDate = '30days';
            } else if(start.format('YYYY-MM-DD') == moment().startOf('month').format('YYYY-MM-DD') && end.format('YYYY-MM-DD') == moment().endOf('month').format('YYYY-MM-DD')) {
                typeDate = 'thisMonth';
            } else if(start.format('YYYY-MM-DD') == moment().subtract(1, 'month').startOf('month').format('YYYY-MM-DD') && end.format('YYYY-MM-DD') == moment().subtract(1, 'month').endOf('month').format('YYYY-MM-DD')) {
                typeDate = 'lastMonth';
            } else {
                typeDate = 'custom';
            }

            $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            $.ajax({
                url:"<?php echo BASE_URL; ?>chart/AllCusByDate/" + start.format('YYYY-MM-DD') + "/" + end.format('YYYY-MM-DD') + "/" + typeDate,
                dataType: 'json',
                success: function (res) { 
                    
                    chartData = '[{name: "Customers",colorByPoint: true,data: ['+res.data+']}]';
                    Chart(eval("(" + chartData + ")"), eval("(" + res.drill + ")"), start.format('MMMM D, YYYY'), end.format('MMMM D, YYYY'));
                },
                error: function (err) {
                    alert('error');
                }
            });
        }
        cb(moment(), moment());

        $('#reportrange').daterangepicker({
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb);

    });
        
    function Chart(dataChart, dataDrill, start, end) {
        //Create the chart
        $('#container').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'Customers. ' + start + ' to ' + end
            },
            subtitle: {
                text: 'Click the columns to view media types.'
            },
            xAxis: {
                type: 'category'
            },
            yAxis: {
                title: {
                    text: 'Total Customers'
                }

            },
            legend: {
                enabled: false
            },
            plotOptions: {
                series: {
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true,
                        format: '{point.y}'
                    }
                }
            },

            tooltip: {
                headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b><br/>'
            },

            series: dataChart,
            drilldown: {
                series: dataDrill
            }
        });
    }
    </script>

