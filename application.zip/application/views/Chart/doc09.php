<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}

</style>

<table width="100%">
    <tr>
        <td width="80%" align="right"><pre>เลขที่เอกสาร</pre></td>
        <td width="20%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
    </tr>
</table>
<br>
<table width="100%" border="1">
    <tr>
        <td align="center">
            <table width="100%">
                <tr>
                    <td align="center"><pre><b>แบบคำขอยกเลิกหนังสือจองซื้อ / สัญญาจะซื้อจะขายห้องชุด โดยยินยอมให้ริบเงินมัดจำ</b></pre></td>
                </tr>
                <tr>
                    <td align="center"><pre><b>โครงการ <font color="red">แดนลิฟวิ่ง รัชดา – วงศ์สว่าง</font></b></pre></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<br>
<table width="100%">
    <tr>
        <td width="80%" align="right"><pre>วันที่</pre></td>
        <td width="20%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
    </tr>
</table>
<table width="100%" border="0">
    <tr>
        <td width="10%"><pre>เรียน</pre></td>
        <td width="90%"><pre>ผู้รับมอบอำนาจกระทำการแทน <font color="red">บริษัท กีธา พร็อพเพอร์ตี้ส์ จำกัด</font></pre></td>
    </tr>
    <tr>
        <td><pre>อ้างถึง</pre></td>
        <td>
            <table>
                <tr>
                    <td width="95px"><pre><input type="checkbox" checked="checked"> ห้องชุดเลขที่</pre></td>
                    <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width=""><pre>(รหัสขาย</pre></td>
                    <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width=""><pre>) ชั้นที่</pre></td>
                    <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td><pre>ใน โครงการ <font color="red">แดนลิฟวิ่ง รัชดา – วงศ์สว่าง</font></pre></td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre><input type="checkbox" checked="checked"> พื้นที่ใช้สอยประมาณ</pre></td>
                    <td width="100px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width=""><pre>ตารางเมตร</pre></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre><input type="checkbox" checked="checked"> ในราคาเป็นจำนวนเงิน</pre></td>
                    <td width="200px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width=""><pre>บาท</pre></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre>ตามหนังสือจองเลขที่</pre></td>
                    <td width="200px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width=""><pre>ลงวันที่</pre></td>
                    <td width="100px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table>
                <tr>
                    <td width=""><pre>ตามสัญญาจะซื้อ จะขายห้องชุดเลขที่</pre></td>
                    <td width="120px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width=""><pre>ลงวันที่</pre></td>
                    <td width="100px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <table width="100%">
                <tr>
                    <td width="10%"><pre>ข้าพเจ้า</pre></td>
                    <td width="90%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td><pre><span class="under">ในฐานะ</span></pre></td>
        <td>(โปรดทำเครื่องหมาย <input type="checkbox" checked="checked"> หน้าข้อที่ต้องการเพียงข้อเดียว)</td>
    </tr>
    <tr>
        <td></td>
        <td><input type="checkbox"> ผู้จอง (โปรดกรอกข้อ 1)</td>
    </tr>
    <tr>
        <td></td>
        <td><input type="checkbox"> ผู้จะซื้อ (โปรดกรอกข้อ 2)</td>
    </tr>
</table>
<br>
<table border="1">
    <tr>
        <td>สำหรับกรณีเป็นผู้จอง</td>
    </tr>
</table>
<table width="100%">
    <tr>
        <td width="10%" align="right"></td>
        <td width="90%"><input type="checkbox"> 1.  ข้าพเจ้าขอเรียนให้ท่านทราบว่า เนื่องจากข้าพเจ้ามีเหตุจำเป็นที่ทำให้ไม่สามารถเข้าทำสัญญาจะซื้อจะขายห้องชุดดังกล่าวกับท่านได้ ดังนั้น จึงใคร่ขอแจ้งความประสงค์ว่า ข้าพเจ้าประสงค์ขอยกเลิกหนังสือจองซื้อ ที่อ้างถึง โดยข้าพเจ้าตกลงยินยอมให้ท่าน ริบเงินมัดจำ การจองซื้อ ห้องชุดทั้งหมดซึ้งข้าพเจ้าได้ชำระต่อท่านไว้แล้ว</td>
    </tr>
</table>
<br>
<table border="1">
    <tr>
        <td>สำหรับกรณีเป็นผู้จะซื้อ</td>
    </tr>
</table>
<table width="100%">
    <tr>
        <td width="10%" align="right"></td>
        <td width="90%"><input type="checkbox"> 2. ข้าพเจ้าขอเรียนให้ท่านทราบว่า เนื่องจากข้าพเจ้ามีเหตุจำเป็นที่ทำให้ไม่สามารถปฎิบัติตามเงื่อนไขตามสัญญาจะซื้อจะขายห้องชุด โดยผู้จะขายไม่ได้ปฏิบัติ ผิดสัญญาจะซื้อจะขาย ข้าพเจ้าจึงประสงค์ขอยกเลิกสัญญาจะซื้อจะขายห้องชุดที่อ้าง โดยข้าพเจ้าตกลงยินยอมให้ผู้จะขาย ริบเงินมัดจำทั้งหมด ซึ่งข้าพได้ชำระต่อท่านไว้แล้ว เนื่องจากข้าพเจ้าไม่ปฏิบัติตามสัญญาจะซื้อจะขาย</td>
    </tr>
</table>
<br>
<table width="100%">
    <tr>
        <td width="50%" valign="top" align="center"><pre>จึงเรียนมาเพื่อโปรดพิจารณาอนุมัติ</pre></td>
        <td width="50%" align="right">
            <table width="100%">
                <tr>
                    <td width="10px"><pre>ลงชื่อ</pre></td>
                    <td width="300px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                    <td width="100px"><pre>ผู้จอง / ผู้จะซื้อ</pre></td>
                </tr>
                <tr>
                    <td colspan="3">&nbsp;</td>
                </tr>
                <tr> 
                    <td align="right">(</td>
                    <td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                    <td align="left">)</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<br>
<table border="1" width="100%">
    <tr>
        <td colspan="4" align="center"><pre><b>สำหรับเจ้าหน้าที่ของบริษัทเท่านั้น</b></pre></td>
    </tr>
    <tr>
        <td>
            <table>
                <tr>
                    <td><pre>A/C_____________รับทราบ</pre></td>
                </tr>
                <tr>
                    <td><pre>วันที่__________________</pre></td>
                </tr>
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td><pre>ผู้อนุมัติ___________</pre></td>
                </tr>
                <tr>
                    <td><pre>วันที่_____________</pre></td>
                </tr>
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td><pre>เจ้าหน้าที่บริษัท (Sale/CS)</pre></td>
                </tr>
                <tr>
                    <td><pre>ลงชื่อ____________________</pre></td>
                </tr>
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td><pre>เงื่อนไข______________</pre></td>
                </tr>
                <tr>
                    <td><pre>____________________</pre></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
';?>

<?php


include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>