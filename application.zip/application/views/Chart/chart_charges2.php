<!DOCTYPE html>
<!--[if lt IE 7]> <html class="ie lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="ie lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="ie lt-ie9"> <![endif]-->
<!--[if gt IE 8]> <html> <![endif]-->
<!--[if !IE]><!-->
<html>
<!-- <![endif]-->

<head>
    <title>
        <?php echo $title; ?>
    </title>

    <!-- Meta -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

    <!-- 
	**********************************************************
	In development, use the LESS files and the less.js compiler
	instead of the minified CSS loaded by default.
	**********************************************************
	<link rel="stylesheet/less" href="<?php echo BASE_DOMAIN; ?>assets/less/admin/module.admin.page.tables.less" />
	-->

    <!--[if lt IE 9]><link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/css/bootstrap.min.css" /><![endif]-->
    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.finances.min.css" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>

    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/chart.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/highcharts.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/modules/exporting.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/report/js/highcharts-3d.js"></script>
    <script>
        $(document).ready(function(){
//            $("#bt").live("click",function(){
////                $.get("chart/get",{id:"1"},function(res){
////                    alert(res);
////                });
//                 $.ajax({
//                    url:"<?php echo BASE_URL; ?>chart/getAjax",
//                    data:"id=1&name=kob",
//                    type:"POST",
//                    success:function(res){
////                        alert("ok"+res);
//                        $("#show").html(res);
//                    },
//                    error:function(err){
//                        alert("ERROR:"+err);    
//                    }
//                });
//            });
            
            $.ajax({
                url:"<?php echo BASE_URL; ?>chart/test",
                data:({ 
                    test: $("#start").val()
                }),
                type: "POST",
                success:function(tests){
                    $("#show").html(tests);
                },
                error:function(err){
                    alert("ERROR:"+err);
                }
            });
        });
    </script>
    
    

</head>

<body class="">

    <div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
        <?php
			include "application/views/menu_top.php";
			?>
    </div>

    <div id="menu" class="hidden-print hidden-xs">
        <?php
			include "application/views/menu_left.php";
			
			if ($permission->pm_chart_report<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			
			?>
    </div>

    <div id="content">
        <input type=date id="start"/>
        <input type="button" id="bt" name="bt" value="Click"/>
        <div id="show"></div>
    </div>


    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
    <script>
        // Timelabel('<?php echo $chart->topic_label?>');
    </script>
</body>

</html>