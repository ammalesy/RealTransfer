<div id="menu" class="hidden-print hidden-xs">
    <?php
			
			if ($permission->pm_chart_report<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			
			?>
</div>

<div class="content">
    <!-- <h3 class="bg-white content-heading border-bottom" id='dvtimelabel'></h3>-->
    <div class="innerAll text-center">


        <div class="widget">

            <!-- Widget heading -->
            <div class="widget-head">
                <h4 class="heading" style="color:#fff">Report Of Charges</h4><span style='float:right;right:10px;color:#ffffff'><?php echo $date_show; ?></span>
            </div>
            <!-- // Widget heading END -->

            <div class="widget-body widget-inverse">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/charge" method="post">
                    <div class="form-inline">
                        <div class="form-group">
                            <label for="beginDate">ช่วงวันที่&nbsp;</label>
                            <input type="date" class="form-control" style="width:145px;" name="beginDate" id="beginDate" required="required" value="<?php echo $beginDate; ?>" title="กรุณากรอกวันที่เริ่มต้น">
                            <label for="col-sm-1">&nbsp;&nbsp;ถึง&nbsp;&nbsp;</label>
                            <input type="date" class="form-control" style="width:145px" name="endDate" id="endDate" required="required" value="<?php echo $endDate; ?>" title="กรุณากรอกวันที่สิ้นสุด">
                        </div>

                        <div class="form-group">
                            <label for="cusID">ชื่อลูกค้า</label>
                            <select class="form-control threeWord" name="cusID" id="cusID" style="width:200px" required>
                                <option value='all'>All</option>
                                <?php
                                        foreach($list_customer as $customer):
                                            echo "<option value='$customer->cus_id'>$customer->fullname</option>";
                                        endforeach; 
                                    ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-inline">
                        <div class="form-group">
                            <label for="unID">&nbsp;&nbsp;&nbsp;&nbsp;เลขที่ห้อง</label>
                            <select class="form-control threeWord" name="unID" id="unID" style="width:200px" required>
                                <option value='all,all'>All</option>
                                <?php
                                        foreach($list_unit_number as $_list_unit_number)
                                        {
                                            $getBuilding = $this->tb_building->get_detail_building_by_building_id($_list_unit_number->un_build_id);
                                            echo "<option value='$_list_unit_number->un_build_id,$_list_unit_number->un_id'>$getBuilding->building_name  $_list_unit_number->un_name</option>";
                                        }
                                    ?>
                            </select>
                        </div>&nbsp;&nbsp;
                        <input class="btn btn-default" type="submit" value="ค้นหา">&nbsp;
                        <a href="<?php echo BASE_DOMAIN; ?>chart/charge/excel/<?php echo $exBeginDate;?>/<?php echo $exEndDate;?>/<?php echo $exCusID;?>/<?php echo $exBuildID;?>/<?php echo $exUnID;?>"><?php echo image_asset('image/downloadexcel.gif',NULL,array('title'=>'Download Diary report for incomes')); ?></a>
                    </div>
                </form>
            </div>
            <script>
                $(".threeWord").select2({
                    minimumInputLength: 3
                });

            </script>

            <div class="widget-body">
                <table class="table table-striped colVis" border="1" style="font-size:10pt">
                    <thead class="bg-gray" style="font-weight: bold;text-align:center">
                        <tr>
                            <th style="text-align:center">ลำดับ</th>
                            <th style="text-align:center">ตึก</th>
                            <th style="text-align:center">เลขที่</th>
                            <th style="text-align:center">คำนำหน้า</th>
                            <th style="text-align:center">ชื่อลูกค้า</th>
                            <th style="text-align:center">รายรับก่อนหักธรรมเนียม</th>
                            <th style="text-align:center">ค่าธรรมเนียมธนาคาร</th>
                            <th style="text-align:center">รายรับจริง</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $html; ?>
                    </tbody>
                </table>
                <label style="text-align: left;">* หมายเหตุ กรณีที่ติดบัตรเครดิต จะแสดงค่าธรรมเนียมด้วย</label>
            </div>
        </div>
    </div>
</div>
