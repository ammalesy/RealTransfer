<div id="menu" class="hidden-print hidden-xs">
    <?php
	if ($permission->pm_chart_report<1) {
		alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
	}
	?>
</div>
<div class="income-report">
    <div class="content" >
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Daily Report For Overdue</a>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body">
            <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/drOverdue" method="post">
                <div class="date-form row">
                    <div class="col l12"><input class="datepicker" type="date" name="beginDate" required="required" value="<?php echo $beginDate; ?>" title="Please enter Start Date"></div>
                </div>
                <div class="button-form">
                    <button class="btn waves-effect waves-light" type="submit" name="action">Search
                        <i class="material-icons left">search</i>
                    </button>
                </div>
                <!-- <a href="<?php echo BASE_DOMAIN; ?>chart/drOverdue/<?php echo $typeDr; ?>/<?php echo $beginDate; ?>"><?php echo image_asset('image/downloadexcel.gif',NULL,array('title'=>'Download Diary report for sale')); ?></a> -->
            </form>
            <div class="table-form">
                <table class="table table-hover" border="1" style="font-size:10pt">
                    <thead>
                        <tr>
                            <td align="center" colspan="7" bgcolor="#606060"><font color="white"><b>รายงานลูกหนี้คงค้าง ณ วันที่ <?php echo $this->dateformat->thaiDate(date('Y-m-d', strtotime($beginDate))); ?></b></font></td>
                        </tr>
                        <tr>
                            <td align="center"><b>No.</b></td>
                            <td align="left"><b>Customer</b></td>
                            <td align="center"><b>Building</b></td>
                            <td align="center"><b>Unit Number</b></td>
                            <td align="center"><b>จำนวนงวดที่ค้าง</b></td>
                            <td align="right"><b>งวดละ</b></td>
                            <td align="right"><b>Total</b></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $html; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
            $(".threeWord").select2({
                minimumInputLength: 3
            });
        </script>
    </div>
</div>
<script type="text/javascript">
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script>
