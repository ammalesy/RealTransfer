<script type="text/javascript">
    $(function() {
        var defaultOption = '<option value="all">All</option>';
        $('#Build').change(function() {
            $("#Floor").html(defaultOption);
            //                console.log($('#Build').val());
            $.ajax({
                url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonChartBuilding.php",
                data: ({
                    Build: $('#Build').val(),
                    project_database_sel: '<?php echo $project_database_sel; ?>'
                }),
                dataType: "json",

                success: function(json) {
                    $.each(json, function(index, value) {
                        $("#Floor").append('<option value="' + value.fl_id + '">' + value.fl_name + '</option>');

                    });
                }
            })
        });

        $('#Floor').change(function() {
            $("#Number").html(defaultOption);

            $.ajax({
                url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonChartFloorNumber.php",
                data: ({
                    Floor: $('#Floor').val(),
                    project_database_sel: '<?php echo $project_database_sel; ?>',
                    common_database: '<?=$common_database?>'
                }),
                dataType: "json",

                success: function(json) {
                    $.each(json, function(index, value) {
                        $("#Number").append('<option value="' + value.un_id + '">' + value.un_name + '</option>');

                    });
                    //                console.log(roomType[5]);
                }
            });
        });
    });
    
    function next() 
    {
        $('#load').modal('hide');
    }
        
    $(function() {
        $("#search").submit(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
        
        $(".subm").click(function (event) {
            $('#load').openModal({
                dismissible: false, // Modal can be dismissed by clicking outside of the modal
            });
            self.setTimeout('next()', 1000000)
        });
    });
</script>

<div id="menu" class="hidden-print hidden-xs">
    <?php
			if ($permission->pm_chart_report<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
			}
			
			?>
</div>

<div class="income-report">
    <div class="content" >
           <div class="modal fade" id="load" data-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title">Loading...</h3>
                        </div>
                    </div>
                </div>
            </div>
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Contract Overdue</a>
                        <ul class="right hide-on-med-and-down">
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body">
            <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/overdueContract" method="post" id="search">
                <div class="date-form row">
                    <div class="title col l4">Date</div>
                    <div class="col l8">
                        <input class="datepicker" type="date" name="beginDate" required="required" value="<?php echo $beginDate; ?>" title="Please enter Start Date">
                        <span>TO</span>
                        <input class="datepicker" type="date" name="endDate" required="required" value="<?php echo $endDate; ?>" title="Please enter End Date">
                    </div>
                </div>
                <div class="row">
                    <div class="title col l4">Building Detials</div>
                    <div class="col l8">
                        <div class="row">
                            <div class="customer-form col l6">
                                <label for="cusID">Customer name</label>
                                <div class="row">
                                    <div class="customer-select input-field col l3">
                                        <select class="form-control threeWord" name="cusID" id="cusID" required>
                                            <option value='all'>All</option>
                                            <?php
                                            foreach($list_customer as $customer):
                                                echo "<option value='$customer->cus_id'>$customer->fullname</option>";
                                            endforeach; 
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="building-form col l6">
                                <label for="Build">Building</label>
                                <div class="row">
                                    <div class="input-field col l3">
                                        <select id="Build" name="buildID" required>
                                            <option value=''>--------SELECT--------</option>
                                            <?php
                                            foreach($list_building as $_list_building)
                                            {
                                                echo "<option value='$_list_building->building_id'>$_list_building->building_name</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="floor-form col l6">
                                <label for="Floor">Floor</label>
                                <div class="row">
                                    <div class="input-field col l3">
                                        <select id="Floor" name="floorID" required>
                                            <option value='all'>All</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="unit-number-form col l6">
                                <label for="Number">Unit No.</label>
                                <div class="row">
                                    <div class="input-field col l3">
                                        <select id="Number" name="unID" required>
                                            <option value='all'>All</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="button-form">
                    <button class="btn waves-effect waves-light" type="submit" name="action">Search
                        <i class="material-icons left">search</i>
                    </button>
                </div>
                <!-- <a href="<?php echo BASE_DOMAIN; ?>chart/overdueContract/excel/<?php echo $exBeginDate;?>/<?php echo $exEndDate;?>/<?php echo $exCusID;?>/<?php echo $exBuildID;?>/<?php echo $exFloorID;?>/<?php echo $exUnID;?>"><?php echo image_asset('image/downloadexcel.gif',NULL,array('title'=>'Download Diary report for incomes')); ?></a> -->
            </form>
            <div class="table-form table-scroll" id="printPage">
                <div class="income-report">
                    <table class="table table-striped colVis" border="1" style="font-size:10pt">
                        <thead class="bg-gray" style="font-weight: bold;">
                            <tr>
                                <th width="50px" class="border-th" rowspan="2">ลำดับ</th>
                                <th width="40px" class="border-th" rowspan="2">ชั้น</th>
                                <th width="50px" class="border-th" rowspan="2">ห้อง</th>
                                <th width="180px" class="border-th" rowspan="2">ชื่อลูกค้า</th>
                                <th width="80px" class="border-th" rowspan="2">พื้นที่ขาย</th>
                                <th width="120px" class="border-th" rowspan="2">ราคาตามสัญญา</th>
                            </tr>
                            <tr>
                                <th class="border-th">จำนวนเงิน</th>
                                <th class="border-th">วันครบกำหนดชำระตามสัญญา</th>
                                <th class="border-th">ระยะเวลาที่ค้างชำระ (วัน)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $html; ?>
                                <tr>
                                    <td colspan="6">ทั้งหมด</td>
                                    <td>
                                        <?php echo $totalContractAmount; ?>
                                    </td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <script>
            $(".threeWord").select2({
                minimumInputLength: 3
            });
        </script>
    </div>
</div>
<script type="text/javascript">
    function printDiv() {
        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
        
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();
    }
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script>






