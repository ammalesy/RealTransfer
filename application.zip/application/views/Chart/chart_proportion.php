<script type="text/javascript">
    $(function() {
        $('#container').highcharts({
            chart: {
                type: '<?php echo $format_chart; ?>'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: [<?php echo $xAxis; ?>],

                labels: {
                    step: [<?php echo $date_cut; ?>],
                    <?php echo $rotation; ?>
                },
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total <?php echo $type_name; ?> & <?php echo $type_name_2; ?>'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">Total: </td>' +
                    '<td style="padding:0"><b>{point.y} {series.name}</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [{
                name: '<?php echo $type_name; ?>',
                data: [<?php echo $count_cus; ?>]

            }, {
                name: '<?php echo $type_name_2; ?>',
                data: [<?php echo $count_cus_2; ?>]
            }]
        });
        $(document).ready(function() {
            // Build the chart
            $('#pi1').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false
                },
                title: {
                    text: ''
                },
                tooltip: {
                    pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    type: 'pie',
                    name: 'Percents',
                    data: [
                        ['Website', <?php echo $website; ?>],
                        ['Call in', <?php echo $callin; ?>], {
                            name: 'Walk in',
                            y: <?php echo $walkin; ?>,
                            sliced: true,
                            selected: true
                        },
                        ['SMS', <?php echo $sms; ?>],
                        ['Online Media', <?php echo $online; ?>],
                        ['Project Poster', <?php echo $poster; ?>],
                        ['Billboard', <?php echo $billboard; ?>],
                        ['Booth', <?php echo $booth; ?>],
                        ['Friends', <?php echo $friends; ?>],
                        ['Newspaper', <?php echo $news; ?>],
                        ['Leaflet', <?php echo $leaflet; ?>],
                        ['Others', <?php echo $others; ?>]
                    ]
                }]
            });
        });
    });
</script>

<div id="menu" class="hidden-print hidden-xs">
    <?php
        if ($permission->pm_chart_report<1) {
            alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
        }
        ?>
</div>

<div class="customer-report">
    <div class="content">
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report Customers</a>
                        <ul class="right hide-on-med-and-down">
                            <!-- <li class='<?php echo $time_index==' total ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/proportion/total">Total</a></li> -->
                            <li class='<?php echo $time_index==' today ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/proportion/today">Today</a></li>
                            <li class='<?php echo $time_index==' week ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/proportion/week">7 Days</a></li>
                            <li class='<?php echo $time_index==' month ' ? "active": ' '?>'><a href="<?php echo BASE_URL; ?>/chart/proportion/month">30 Days</a></li>
                            <li class='<?php echo $time_index==' custom ' ? "active": ' '?>'>
                                <div class="waves-effect waves-light first">Custom Date</div>
                            </li>
                            <!-- <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div></li> -->
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="slide" style="display:none">
                <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/proportion/custom" method="post">
                    <div class="custom-date col l10">
                        <input class="datepicker" type="date" name="start" required="required" value="<?php echo date( "Y-m-d", strtotime("-30 days ", strtotime(date('Y-m-d'))) ); ?>" title="Please enter Start Date">
                        <label><b>TO</b></label>
                        <input class="datepicker" type="date" name="end" required="required" value="<?php echo date('Y-m-d'); ?>" title="Please enter End Date">
                    </div>

                    <div class="col l2 button-submit">
                        <button class="btn waves-effect waves-light" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="content-body" id="printPage">
            <div class="widget widget-inverse">
                <div class="widget-head">
                    <h4 class="heading">Leads & Customers</h4><span style='float:right;right:10px;color:#ffffff'><?php echo $date_show; ?></span>
                </div>
                <div class="widget-body">
                    <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script> 