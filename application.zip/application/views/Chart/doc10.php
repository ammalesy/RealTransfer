<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}

.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}

</style>

<table border="1" width="100%">
    <tr>
        <td align="center"><pre>แบบคำขอโอนสิทธิ หน้าที่ หนี้ และความรับผิด ตามสัญญาจะซื้อจะขายห้องชุด</pre></td>
    </tr>
</table>
<table align="right">
    <tr>
        <td><pre>วันที่</pre></td>
        <td width="50px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
        <td><pre>เดือน</pre></td>
        <td width="100px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
        <td><pre>พ.ศ.</pre></td>
        <td width="70px" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
    </tr>
</table>
<pre><b><span class="under">รายละเอียดผู้จะซื้อ</span> :</b> นาย/ นาง/ นางสาว/ บริษัท __________________________________________________________</pre>
<pre><b><span class="under">รายละเอียดห้องชุด</span> :</b> โครงการ <font color="red">แดนลิฟวิ่ง รัชดา – วงศ์สว่าง</font> ห้องชุดเลขที่___________รหัสห้องชุด(________) พื้นที่ประมาณ___________ตารางเมตร ราคา______________________บาท สัญญาจะซื้อจะขายห้องชุด เลขที่ ______________ ฉบับลงวันที่__________________</pre>
<p>ด้วยผู้จะซื้อมีความประสงค์จะขอโอนสิทธิและหน้าที่ตามสัญญาจะซื้อจะขายห้องชุดดังกล่าวข้างต้นให้แก่<span class="under"><b>บุคคลตามที่ปรากฏชื่อในตารางด้านล่างนี้</b></span> (“ผู้รับโอนสิทธิ”) โดยข้าพเจ้าตกลงจะดำเนินการให้ผู้รับโอนสิทธิเข้าลงนามในบันทึกข้อตกลงโอนสิทธิ หน้าที่ หนี้ และความรับผิดรวมตลอดถึงบันทึกข้อตกลงอื่นๆ และ/หรือ เอกสาร, หนังสือแจ้งบอกกล่าวใดๆ ที่มีผลผูกพันข้าพเจ้าด้วยทั้งหมด และให้ผู้รับโอนสิทธิรับโอนสิทธิและหน้าที่ตามสัญญาจะซื้อจะขายห้องชุด และข้อตกลงอื่นๆ ต่อไปด้วยทุกประการ และในการโอนสิทธิดังกล่าว ข้าพเจ้าตกลงให้ถือเอาเงินค่าห้องชุดที่ข้าพเจ้าได้ชำระไว้แก่บริษัทฯ  แล้วเป็นเงินส่วนหนึ่งของผู้รับโอนสิทธิที่ได้ชำระค่าห้องชุดต่อไปด้วย  จึงใครขอบริษัทฯท่านโปรดพิจารณาและให้ความยินยอมด้วยจักขอบพระคุณยิ่ง</p>
<table border="1" width="100%" class="oneLine">
    <tr>
        <td>
            <table>
                <tr>
                    <td><pre><span class="under"><b>รายละเอียดผู้รับโอนสิทธิ (ปรากฏตามสำเนาบัตรประชาชนและทะเบียนบ้าน หรือ สำเนาหนังสือรับรองนิติบุคคลอายุไม่เกิน 3 เดือน</b></span></pre></td>
                </tr>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td><pre>นาย/นาง/นางสาว/บริษัท</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                                <td><pre>อายุ</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                                <td><pre>สัญชาติ</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td><pre><span class="under"><b>ที่อยู่ที่ติดต่อได้</b></span> อาคาร/โครงการ</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td><pre>ตำบล/แขวง</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                                <td><pre>อำเภอ/เขต</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                                <td>จังหวัด</td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                                <td><pre>รหัสไปรษณีย์</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td><pre>เบอร์โทรศัพท์</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                                <td><pre>เบอร์มือถือ</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                                <td><pre>email</pre></td>
                                <td style="border-bottom-width:1px; border-bottom-style:solid;"><pre></pre></td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table border="1" class="oneLine">
    <tr>
        <td><span class="under"><b>ผู้จะซื้อต้องดำเนินการตามเงื่อนไขเพื่อการโอนสิทธิ พร้อมส่งมอบเอกสารให้แก่ผู้รับโอนสิทธิ ในวันที่ยื่นแบบคำขอโอนสิทธิฉบับนี้แก่บริษัทฯ ดังต่อไปนี้</b></span></td>
    </tr>
</table>
<table border="1" class="oneLine">
    <tr>
        <td><input type="checkbox"></td>
        <td><pre>1. สำเนาเอกสารตรวจรับมอบงานก่อสร้างห้องชุด<b>(defect list)</b> หรือ เอกสารรับมอบงาน/ห้องชุด พร้อมลงลายมือชื่อของผู้จะซื้อและผู้รับโอนสิทธิให้ครบถ้วนทุกฝ่าย จำนวน_________แผ่น(การตรวจรับมอบงานให้ยึดถือตามเอกสารดังกล่าวนี้เป็นสำคัญ หากผู้รับโอนสิทธิมีรายการแก้ไขเพิ่มเติมบริษัทฯ ขอสงวนสิทธิ์เก็บรายการเพิ่มเติมภายหลังโอนกรรมสิทธิ์)</pre></td>
    </tr>
    <tr>
        <td><input type="checkbox"></td>
        <td><pre>2. สำเนาหนังสือของผู้จะขายแจ้งกำหนดนัดโอนกรรมสิทธิ์ : นัดโอนกรรมสิทธิ์ในวันที่ ______เดือน ________________พ.ศ._______พร้อมลงลายมือชื่อของผู้จะซื้อ และผู้รับโอนสิทธิ ให้ครบถ้วนทุกฝ่าย</pre></td>
    </tr>
    <tr>
        <td><input type="checkbox"></td>
        <td><pre>3. สำเนาบัตรประชาชน และสำเนาทะเบียนบ้านของผู้รับโอนสิทธิ หรือ สำเนาหนังสือรับรองนิติบุคคล พร้อมรับรองสำเนาถูกต้อง</pre></td>
    </tr>
    <tr>
        <td colspan="2"><pre><b>เอกสารสำคัญที่ผู้จะซื้อต้องส่งมอบให้แก่ผู้รับโอนสิทธิ <span class="under">ในวันลงนามบันทึกข้อตกลงโอนสิทธิ</span></b></pre></td>
    </tr>
    <tr>
        <td><input type="checkbox"></td>
        <td><pre>1.   สัญญาจะซื้อจะขายห้องชุด พร้อมบันทึกข้อตกลงแนบท้ายสัญญาทุกฉบับ</pre></td>
    </tr>
    <tr>
        <td><input type="checkbox"></td>
        <td><pre>2.   ใบเสร็จ/หลักฐานการชำระเงินค่าห้องชุด (ถ้ามี) : ผู้จะซื้อได้ชำระเงินไว้จนถึงวันที่___________________________________</pre></td>
    </tr>
    <tr>
        <td><input type="checkbox"></td>
        <td><pre>3.   เอกสารอื่นๆ (ถ้ามี) ______________________________________________________________________________________________________________________________________________________________________________</pre></td>
    </tr>
    <tr>
        <td colspan="2"><pre><b><span class="under">เงื่อนไขการชำระเงิน</span> :</b>   ผู้จะซื้อขอรับรองว่า ได้ชำระเงินไว้แก่บริษัทฯ แล้ว วันที่___________________________เป็นเงินทั้งสิ้นจำนวน_________________________________บาท โดยผู้รับโอนสิทธิรับทราบแล้ว และตกลงจะชำระเงินตามเงื่อนไขในสัญญาจื้อจะขายต่อไป</pre></td>
    </tr>
</table>
<table width="100%" border="1">
    <tr>
        <td width="50%">
            <table>
                <tr>
                    <td><pre>ผู้จะซื้อ</td>
                </tr>
                <tr>
                    <td>(ลงชื่อ) _____________________________</td>
                </tr>
                <tr>
                    <td>วันที่_____/_____/________</td>
                </tr>
            </table>
        </td>
        <td width="50%">
            <table>
                <tr>
                    <td>ผู้รับโอนสิทธิ</td>
                </tr>
                <tr>
                    <td>(ลงชื่อ) _____________________________</td>
                </tr>
                <tr>
                    <td>วันที่_____/_____/________</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2"><pre><b>ส่วนนี้สำหรับบริษัทฯ</b></pre></td>
    </tr>
    <tr>
        <td colspan="2"><pre><b><span class="under">เงื่อนไขสำคัญในการพิจารณาอนุมัติการโอนสิทธิเป็นดังนี้</span></b>
        <br>1. ในการโอนสิทธิ และหน้าที่ตามสัญญาจะซื้อจะขายห้องชุดข้างต้นจะมีผลต่อเมื่อผู้จะซื้อ และผู้รับโอนสิทธิได้ลงนามบันทึกข้อตกลงโอนสิทธิฯ กับบริษัทฯ เรียบร้อยแล้ว
        <br>2. แบบคำขอฉบับนี้เป็นเพียงการแจ้งความประสงค์ของผู้จะซื้อแต่ฝ่ายเดียวเท่านั้น ยังไม่ถือเป็นการโอนสิทธิ</pre></td>
    </tr>
</table>
<table border="1" width="100%" class="oneLine">
    <tr>
        <td rowspan="2"><pre>เจ้าหน้าที่</pre></td>
        <td>&nbsp;</td>
        <td rowspan="2"><pre>อนุมัติโดย</pre></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td><pre>Sale /CS</pre></td>
        <td><pre>VP (CR)/PH/PL</pre></td>
    </tr>
    <tr>
        <td><pre>วันที่</pre></td>
        <td><pre>_____/________/_______</pre></td>
        <td><pre>วันที่</pre></td>
        <td><pre>_____/________/_______</pre></td>
    </tr>
</table>
';?>

<?php


include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");

// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>