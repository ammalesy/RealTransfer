

    <div id="menu" class="hidden-print hidden-xs">
        <?php
			
			
//			if (strpos("'".$menu->pm_chart_report."'",'i') == false) {
//				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
//			}
			
			?>
    </div>

    <div class="content">
        <!-- <h3 class="bg-white content-heading border-bottom" id='dvtimelabel'></h3>-->
        <div class="innerAll text-center">


            <div class="widget">

                <!-- Widget heading -->
                <div class="widget-head">
                    <h4 class="heading" style="color:#fff">Report Visit Type</h4><span style='float:right;right:10px;color:#ffffff'><?php echo $date_show; ?></span>
                </div>
                <!-- // Widget heading END -->

                <div class="widget-body widget-inverse">
                    <table>
                        <tr>
                            <td width="100">
                                <select class="form-control" id="visittype">
                                    <?php foreach($visittypes as $type): ?>
                                    <option>
                                        <?=$type->vt_name ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td width="100" align="right">
                                <input type="radio" name="time" id="date" value="date" checked/>
                                <label class="control-lable lable-radio" id="lable-date" for="date"> Walk in</label>
                            </td>
                            <td>
                                <div class="col-md-2">
                                    <input class="form-control" id="dateStart" style="width:100px" value="<?=date('Y-m-1')?>" />
                                </div>
                            </td>
                            <td>-</td>
                            <td>
                                <div class="col-md-2">
                                    <input class="form-control" id="dateEnd" style="width:100px" value="<?=date('Y-m-d')?>" />
                                </div>
                            </td>
                            <td width="150" align="left" style="padding-left:20px">
                                <input type="radio" name="time" id="total" value="total" />
                                <label class="control-lable lable-radio" id="lable-total" for="total"> Total Walk in </label>
                            </td>
<!--
                            <td>
                                <button class="btn btn-primary" onclick="LoadList()"><i class="glyphicon glyphicon-search"></i> Search</button>
                            </td>
-->
                        </tr>
                    </table>
                </div>

                <div class="widget-body">
                    <label class="control-lable" id="load">Loading ...</label>
                    <label class="control-lable" id="none">No Data</label>
                    <table class="table table-striped colVis" border="1" style="font-size:10pt; display:none;" id="tbList">
                        <thead class="bg-gray" style="font-weight: bold;text-align:center">
                            <tr>
                                <th style="text-align:center">ลำดับ</th>
                                <th style="text-align:center">วันที่ติดต่อ</th>
                                <th style="text-align:center">ชื่อลูกค้า</th>
                                <th style="text-align:center">เบอร์โทร</th>
                                <th style="text-align:center">ที่อยู่บ้าน</th>
                                <th style="text-align:center">ชื่อ บริษัทที่ทำงาน</th>
                                <th style="text-align:center">ที่อยู่ที่ทำงาน</th>
                                <th style="text-align:center">อาชีพ</th>
                                <th style="text-align:center">สื่อ</th>
                                <th style="text-align:center">งบ</th>
                                <th style="text-align:center">รายละเอียด Sale</th>
                                <th style="text-align:center">สถานะ</th>
                            </tr>
                        </thead>
                        <tbody id="list">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        $("#dateStart").bdatepicker({
            format: 'yyyy-mm-dd',
            startDate: "2013-02-14"
        });
        $("#dateEnd").bdatepicker({
            format: 'yyyy-mm-dd',
            startDate: "2013-02-14"
        });
        $("#dateEnd").change(function(){
            var dateStart = new Date($("#dateStart").val());
            var dateEnd = new Date($("#dateEnd").val());
            if(dateStart > dateEnd) {
                $("#dateEnd").val($("#dateStart").val());
            }
            $('.datepicker').hide();
            LoadList();
        });
        $("#dateStart").change(function(){
            var dateStart = new Date($("#dateStart").val());
            var dateEnd = new Date($("#dateEnd").val());
            if(dateStart > dateEnd) {
                $("#dateStart").val($("#dateEnd").val());
            }
            $('.datepicker').hide();
            LoadList();
        });
        
        $('#visittype').change(function(){
            $('#lable-date').html($('#visittype').val());
            $('#lable-total').html('Total '+$('#visittype').val());
            LoadList();
        });
        $('input[name="time"]').change(function () {
            if ($('input[value="date"]').prop('checked')) {
                $('#dateStart').prop('disabled', false);
                $('#dateEnd').prop('disabled', false);
            }else {
                $('#dateStart').prop('disabled', true);
                $('#dateEnd').prop('disabled', true);
            }
            LoadList();
        });
        
        function LoadList() {
            $('#load').show();
            $('#tbList').hide();
            $('#none').hide();
            var type = $('#visittype').val();
            var dateStart = '';
            var dateEnd = '';
            if ($('input[value="date"]').prop('checked')) {
                dateStart = $("#dateStart").val();
                dateEnd   = $("#dateEnd").val();
            }
            $.ajax({
                url: "<?= BASE_DOMAIN ?>assets/ajax/chartVisitType.php",
                data: ({ type: type, dateStart: dateStart, dateEnd: dateEnd }),
                dataType: 'json',
                success: function (json) {
                    var count = 1;
                    var list = '';
                    $.each(json, function(id, val){
                        list += '<tr>';
                        list += '<td>'+(count++)+'</td>';
                        list += '<td>'+val.date_contact+'</td>';
                        list += '<td>'+val.cus_name+'</td>';
                        list += '<td>'+val.mobile+'</td>';
                        list += '<td>'+(val.cus_address==null?'-':val.cus_address)+'</td>';
                        list += '<td>'+(val.work_company==null||val.work_company==''?'-':val.work_company)+'</td>';
                        list += '<td>'+(val.work_address==null||val.work_address==''?'-':val.work_address)+'</td>';
                        list += '<td>'+(val.work_position==null||val.work_position==''?'-':val.work_position)+'</td>';
                        list += '<td>'+val.cus_media+'</td>';
                        list += '<td>'+val.cus_budget+'</td>';
                        list += '<td>'+(val.cus_remark==null||val.cus_remark==''?'-':val.cus_remark)+'</td>';
                        list += '<td>'+val.cus_status+'</td>';
                        list += '</tr>';
                    });
                    $('#list').html(list);
                    $('#load').hide();
                    if(list == '')
                        $('#none').show()
                    else
                        $('#tbList').show();
                }
            });
        }
        
        $( document ).ready(function(){
            $('#lable-date').html($('#visittype').val());
            $('#lable-total').html('Total '+$('#visittype').val());
            LoadList();
        });
    </script>
