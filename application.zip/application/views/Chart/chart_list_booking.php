<script type="text/javascript">
    $(function() {
        var defaultOption = '<option value="all">All</option>';
        $('#Build').change(function() {
            $("#Floor").html(defaultOption);
            //                console.log($('#Build').val());
            $.ajax({
                url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonChartBuilding.php",
                data: ({
                    Build: $('#Build').val(),
                    project_database_sel: '<?php echo $project_database_sel; ?>'
                }),
                dataType: "json",

                success: function(json) {
                    $.each(json, function(index, value) {
                        $("#Floor").append('<option value="' + value.fl_id + '">' + value.fl_name + '</option>');

                    });
                }
            })
        });

        $('#Floor').change(function() {
            $("#Number").html(defaultOption);

            $.ajax({
                url: "<?php echo BASE_DOMAIN; ?>assets/ajax/jsonChartFloorNumber.php",
                data: ({
                    Floor: $('#Floor').val(),
                    project_database_sel: '<?php echo $project_database_sel; ?>',
                    common_database: '<?=$common_database?>'
                }),
                dataType: "json",

                success: function(json) {
                    $.each(json, function(index, value) {
                        $("#Number").append('<option value="' + value.un_id + '">' + value.un_name + '</option>');

                    });
                    //                console.log(roomType[5]);
                }
            });
        });
    });
</script>

<div id="menu" class="hidden-print hidden-xs">
    <?php
	if ($permission->pm_chart_report<1) {
		alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
	}
	?>
</div>
<div class="income-report">
    <div class="content" >
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Report List Bookings</a>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body">
            <form role="form" class="row" action="<?php echo BASE_URL; ?>/chart/listBooking" method="post">
                <div class="date-form row">
                    <div class="col l12"><input class="datepicker" type="date" name="beginDate" required="required" value="<?php echo $beginDate; ?>" title="Please enter Start Date">
                    <span>TO</span>
                    <input class="datepicker" type="date" name="endDate" required="required" value="<?php echo $endDate; ?>" title="Please enter End Date"></div>
                </div>
                <div class="button-form">
                    <button class="btn waves-effect waves-light" type="submit" name="action">Search
                        <i class="material-icons left">search</i>
                    </button>
                </div>
                <!-- <a href="<?php echo BASE_DOMAIN; ?>chart/overdueContract/excel/<?php echo $exBeginDate;?>/<?php echo $exEndDate;?>/<?php echo $exCusID;?>/<?php echo $exBuildID;?>/<?php echo $exFloorID;?>/<?php echo $exUnID;?>"><?php echo image_asset('image/downloadexcel.gif',NULL,array('title'=>'Download Diary report for incomes')); ?></a> -->
            </form>
            <div class="table-form">
                <table class="table table-striped colVis" border="1" style="font-size:10pt">
                    <thead class="bg-gray" style="font-weight: bold;">
                        <tr>
                            <td >ที่</td>
                            <td >ว/ด/ป ที่จอง</td>
                            <td >ห้อง</td>
                            <td >ชื่อ - นามสกุล</td>
                            <td >เบอร์ติดต่อ</td>
                            <td >อาชีพ</td>
                            <td >บริษัท</td>
                            <td >เขต(ที่พักอาศัย)</td>
                            <td >เขต(ที่ทำงาน)</td>
                            <td >สื่อ</td>
                            <td >รายได้/เดือน</td>
                            <td >ขนาด (SQM)</td>
                            <td >ราคา M</td>
                            <td >ส่วนลด</td>
                            <td >ราคา Y</td>
                            <td >Sale</td>
                            <td >Promotion</td>
                            <td >หมายเหตุ</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $html; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
            $(".threeWord").select2({
                minimumInputLength: 3
            });
        </script>
    </div>
</div>
<script type="text/javascript">
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script>
