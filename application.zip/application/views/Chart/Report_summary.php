<div id="menu" class="hidden-print hidden-xs">
    <?php
	if ($permission->pm_chart_report<1) {
		alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
	}
	?>
</div>
<div class="income-report" >
    <div class="content" >
        <div class="content-header">
            <div class="navbar">
                <nav class="select-date">
                    <div class="nav-date nav-wrapper">
                        <a href="#!" class="brand-logo">Summary report</a>
                        <ul class="right hide-on-med-and-down">
                            <li><div onclick="printDiv('printPage')" class="waves-effect waves-light print">Print</div></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-body">
            <input type="date" value="<?php echo date('Y-m-d',strtotime($start));?>" class="dateStart" hidden>
            <input type="date" value="<?php echo date('Y-m-d',strtotime($end));?>" class="dateEnd" hidden>
            <div class="table-form income-report" id="printPage">
                <div class="row">
                    <div class="col l12">
                        <div class="widget">
                            <div class="widget-head">
                                <h4 class="heading glyphicons coins" style='color:#ffffff'><i></i><b>มูลค่าโครงการ</b></h4>
                            </div>
                            <table class="table cart_total margin-none" style="table-layout: fixed;">
                                <tbody>
                                    <tr>
                                        <td class="border-top-none" align="left">มูลค่าโครงการ <font color="red" size="1px">base price</font></td>
                                        <td class="right border-top-none "><font size="4px" color="black">&#3647;<?php echo number_format($totalBasePrice,2); ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">มูลค่าขาย <font color="red" size="1px">asking price</font></td>
                                        <td class="right"><font size="4px" color="black">&#3647;<?php echo number_format($totalAskingPrice,2); ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">มูลค่าขายสุทธิ <font color="red" size="1px">asking price</font></td>
                                        <td class="right"><font size="4px" color="black">&#3647;<?php echo number_format($totalAskingPrice,2); ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">โปรโมชั่นที่ใช้ไป</td>
                                        <td class="right"><font size="4px" color="black">&#3647;<?php echo number_format($sumPromotion,2); ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">เปอร์เซ็นต์ (มูลค่าขายหักส่วนลด)</td>
                                        <td class="right"><font size="4px" color="black"><?php echo number_format((($totalAskingPrice - $sumPromotion) * 100 / $totalAskingPrice),2); ?> %</font></td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- // Table END -->

                        </div>
                        <!-- // List Widget END -->
                    </div>
                    <div class="col l6">
                        <div class="widget">
                            <div class="widget-head">
                                <h4 class="heading glyphicons building" style='color:#ffffff'><i></i><b>จำนวนห้องในโครงการ</b></h4>
                            </div>

                            <!-- Table -->
                            <table class="table cart_total margin-none" style="table-layout: fixed;">
                                <tbody>
                                    <tr>
                                        <td class="border-top-none" align="left">จำนวนห้องทั้งหมด</td>
                                        <td class="right border-top-none "><font size="4px" color="black"><?php echo $totalRoom; ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">จำนวนห้องที่ขาย</td>
                                        <td class="right"><font size="4px" color="black"><?php echo $soldRoom; ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">จำนวนห้องคงเหลือ</td>
                                        <td class="right"><font size="4px" color="black"><?php echo $totalRoom - $soldRoom; ?></font></td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- // Table END -->
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="widget">
                            <div class="widget-head">
                                <h4 class="heading glyphicons vector_path_all" style='color:#ffffff'><i></i><b>พื้นที่ขายของโครงการ</b></h4>
                            </div>

                            <!-- Table -->
                            <table class="table cart_total margin-none" style="table-layout: fixed;">
                                <tbody>
                                    <tr>
                                        <td class="border-top-none" align="left">พื้นที่ขายทั้งหมด</td>
                                        <td class="right border-top-none "><font size="4px" color="black"><?php echo number_format($totalSqm); ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">จำนวนพื้นที่ที่ขาย</td>
                                        <td class="right"><font size="4px" color="black"><?php echo number_format($soldSqm); ?></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">จำนวนพื้นที่คงเหลือ</td>
                                        <td class="right"><font size="4px" color="black"><?php echo number_format($totalSqm - $soldSqm); ?></font></td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- // Table END -->
                        </div>
                    </div>
                    <div class="col l6">
                        <div class="widget">
                            <div class="widget-head">
                                <h4 class="heading glyphicons vector_path_all" style='color:#ffffff'><i></i><b>ลูกค้า</b></h4>
                            </div>

                            <!-- Table -->
                            <table class="table cart_total margin-none" style="table-layout: fixed;">
                                <tbody>
                                    <tr>
                                        <td class="border-top-none" align="left">ลูกค้าจอง</td>
                                        <td class="right border-top-none "><font size="4px" color="black"><p id="booking" ><?php echo $booking; ?></p></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">รวมทำสัญญา</td>
                                        <td class="right"><font size="4px" color="black"><p id="contract"><?php echo $contract; ?></p></font></td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- // Table END -->
                        </div>
                    </div>

                    <div class="col l6">
                        <div class="widget">
                            <!-- <div class="widget-head">
                                <h4 class="heading glyphicons coins" style='color:#ffffff'><i></i><b>มูลค่าโครงการ</b></h4>
                            </div>

                            <div class="widget" id="loadSum">
                                <label>Loading...</label>
                            </div>

                            <div class="widget">
                                <div id="summary"></div>
                            </div> -->
                            <div class="widget-head">
                                <h4 class="heading glyphicons vector_path_all" style='color:#ffffff'><i></i><b>สรุปยอดขาย</b></h4>
                            </div>

                            <!-- Table -->
                            <table class="table cart_total margin-none" style="table-layout: fixed;">
                                <tbody>
                                    <tr>
                                        <td class="border-top-none" align="left"><span id="showDate"><?php echo $this->dateformat->thaiShortDate(date('Y-m-d',strtotime($start))).' ถึง '.$this->dateformat->thaiShortDate(date('Y-m-d',strtotime($end))); ?></span></td>
                                        <td class="right"><font size="4px" color="black">&#3647;<span id="Price"><?php echo number_format($price, 2); ?></span></font></td>
                                    </tr>
                                    <tr>
                                        <td align="left">ยอดขายสะสม</td>
                                        <td class="right"><font size="4px" color="black">&#3647;<?php echo number_format($totalSold, 2); ?></font></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(".threeWord").select2({
                minimumInputLength: 3
            });
        </script>
    </div>
</div>
<script type="text/javascript">
    function printDiv() {
        var DocumentContainer = document.getElementById('printPage');
        var WindowObject = window.open();

        WindowObject.document.writeln('<!DOCTYPE html>');
        WindowObject.document.writeln('<html><head><title></title>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/css/materialize.min.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/main.css"/>');
        WindowObject.document.writeln('<link type="text/css" rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/realcrm.css" />');
        
        WindowObject.document.writeln('<style type="text/css" media="print">@media print {.page-break {page-break-after: always;}</style>');
        WindowObject.document.writeln('</head><body>');
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.writeln('</body></html>');

        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        // WindowObject.close();
    }
    $(function() {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });
        $('.first').on('click', function(event) {
            $('.slide').toggle(300);
        });
    });
</script>
<script>
    
    Number.prototype.format = function(n, x) {
        var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
        return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
    };

    // $("#dateEnd").change(function() {
    //     var dateStart = new Date($("#dateStart").val());
    //     var dateEnd = new Date($("#dateEnd").val());
    //     if (dateStart > dateEnd) {
    //         $("#dateEnd").val($("#dateStart").val());
    //     }
    //     // $('.datepicker').hide();
    //     LoadList();
    // });
    // $("#dateStart").change(function() {
    //     var dateStart = new Date($("#dateStart").val());
    //     var dateEnd = new Date($("#dateEnd").val());
    //     if (dateStart > dateEnd) {
    //         $("#dateStart").val($("#dateEnd").val());
    //     }
    //     // $('.datepicker').hide();
    //     LoadList();
    // });

    function LoadList() {
        $('#load').show();
        $('#tbList').hide();
        $('#none').hide();

        var dateStart = '';
        var dateEnd = '';
        var typeVisit = ["walk", "totalWalk", "call", "totalCall"];
        var typePrice = ["byDate", "total"];
        var typeRoom = ["soldDate", "soldSqmDate"];

        // $('#showDate').text(convertDate($("#dateStart").val()) + " - " + convertDate($("#dateEnd").val()));

        // Booking();
        // for (var _type in typeVisit) {
        //     VisitType(typeVisit[_type]);
        // }
        // Contract();
        // for (var _type in typePrice) {
        //     Price(typePrice[_type]);
        // }
        for (var _type in typeRoom) {
            Room(typeRoom[_type]);
        }

    }

    $(document).ready(function() {
        LoadList();
    });

    // function Booking() {
    //     dateStart = $("#dateStart").val();
    //     dateEnd = $("#dateEnd").val();

    //     $.ajax({
    //         url: "<?php echo BASE_URL; ?>/chart/Booker/" + dateStart + "/" + dateEnd,
    //         dataType: 'json',
    //         success: function(res) {
    //             $('#booking').text(res);
    //         },
    //         error: function(err) {
    //             alert('error');
    //         }
    //     });
    // }

    function VisitType(type) {
        dateStart = $("#dateStart").val();
        dateEnd = $("#dateEnd").val();

        $.ajax({
            url: "<?php echo BASE_URL; ?>/chart/VisitType/" + type + "/" + dateStart + "/" + dateEnd,
            dataType: 'json',
            success: function(res) {
                if (type == "walk") {
                    $('#walk').text(res);
                } else if (type == "totalWalk") {
                    $('#totalWalk').text(res);
                } else if (type == "call") {
                    $('#call').text(res);
                } else if (type == "totalCall") {
                    $('#totalCall').text(res);
                }

            },
            error: function(err) {
                alert('error');
            }
        });
    }

    // function Contract() {
    //     dateStart = $("#dateStart").val();
    //     dateEnd = $("#dateEnd").val();

    //     $.ajax({
    //         url: "<?php echo BASE_URL; ?>/chart/Contracter/" + dateStart + "/" + dateEnd,
    //         dataType: 'json',
    //         success: function(res) {
    //             $('#contract').text(res);
    //         },
    //         error: function(err) {
    //             alert('error');
    //         }
    //     });
    // }

    function Price(type) {
        if (type == 'byDate') {
            dateStart = $("#dateStart").val();
            dateEnd = $("#dateEnd").val();
        } else {
            dateStart = null;
            dateEnd = $("#dateEnd").val();
        }


        $.ajax({
            url: "<?php echo BASE_URL; ?>/chart/Price/totalAsking/" + dateStart + "/" + dateEnd,
            dataType: 'json',
            success: function(res) {
                if (type == 'byDate') {
                    $('#Price').text(parseFloat(res).format(2));
                } else {
                    $('#totalPrice').text(parseFloat(res).format(2));
                }

            },
            error: function(err) {
                alert('error');
            }
        });
    }

    var percentArr = [];

    function Room(type) {
        dateStart = $(".dateStart").val();
        dateEnd = $(".dateEnd").val();
        // dateStart = new Date("<?php echo date('Y-m-d',strtotime($start)); ?>");
        // dateEnd = new Date("<?php echo date('Y-m-d', strtotime($end)); ?>");
        
        $.ajax({
            type : "POST",
            url: "<?php echo BASE_URL; ?>/chart/Room/" + type + "/" + dateStart + "/" + dateEnd,
            // dataType: 'json',
            success: function(res) {
                console.log(res);
                if (type == "soldDate") {
                    $('#soldRoom').text(res);
                    $('#balance').text(<?php echo ($totalRoom - $soldRoom); ?> - res);
                } else if (type == "soldSqmDate") {
                    var num = 0;
                    var sum = 0;
                    for (var id in res) sum += parseInt(res[id]);
                    for (var id in res) {
                        console.log(id);
                        $('#area' + id).text(res[id]);
                        $('#percentArea' + id).text(parseFloat(res[id] * 100 / sum).format(2));

                        if (parseInt(res[id]) > 0) {
                            $('#trArea' + id).show();
                            percentArr[num++] = ['$('#tdSqm' + id).text()', parseFloat(res[id] * 100 / sum)];
                        } else {
                            $('#trArea' + id).hide();
                        }
                    }

                    Summary();
                }

                //                    $('#Price').text(parseFloat(res).format(2));     
            },
            error: function(err) {
                alert('error' + err);
            }
        });
    }

    function Summary() {

        $('#loadSum').hide();
        // Build the chart
        $('#summary').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                doAnimation: true
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: 'Total {point.y} : <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                type: 'pie',
                name: 'Percents',
                data: percentArr
            }]
        });
    }

    function convertDate(inputFormat) {
        function pad(s) {
            return (s < 10) ? '0' + s : s;
        }
        var d = new Date(inputFormat);
        return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/');
    }
</script>