<div class="customer-view">
    <div class="content">
        <?php if (strpos($permission->pm_customer,'1') !== false) { ?>
            <div class="content-add">
                <a class="btn-floating btn-large waves-effect waves-light red" href="<?= BASE_DOMAIN ?>customer/adding"><i class="material-icons">add</i></a>
            </div>
        <?php } ?>

        <div class="content-header">
            <font color="#78ad13">View Customer</font> <label class="table-total">...</label>
            <input type="hidden" id="lead"/>
        </div>
        
        <div class="overlay"></div>

        <div class="content-body">
            <!-- Table -->
            <table class="dynamicTable colVis table">
                <!-- Table heading -->
                <thead>
                    <tr>
                        <th style="width:50px;">ID</th>
                        <th style="width:150px;">Name</th>
                        <th>Note</th>
                        <th style="width:120px;">Mobile</th>
                        <th style="width:200px;">E-mail</th>
                        <th>Project ID</th>
                        <th style="width:60px;"></th>
                    </tr>
                </thead>
                <!-- // Table heading END -->

                <!-- Table body -->
                <tbody>
                    <!-- Table row -->
                    <?php foreach($list_customer as $aCustomer): ?>
                        <tr>
                            <td><?=$aCustomer->cus_id?></td>
                            <td><?php echo $aCustomer->pers_fname." ".$aCustomer->pers_lname; ?></td>
                            <td>
                                <?php //if (strpos($permission->pm_leads,'4') !== false) { ?>
                                        <a href="#remark" onclick="LoadRemark(<?= $aCustomer->cus_id ?>)">
                                            <?php 
                                                echo !empty($aCustomer->lr_remark) ? 
                                                    date('Y/m/d', strtotime($aCustomer->lr_timestamp)) . ' : ' . mb_substr($aCustomer->lr_remark, 0,20,'UTF-8'). (strlen($aCustomer->lr_remark)>30?'':' ...') : 'Remark Here ...'; 
                                            ?>
                                        </a>
                                    <?php //} ?>
                            </td>
                            <td><?php echo $aCustomer->pers_mobile; ?></td>
                            <td><?php echo $aCustomer->pers_email; ?></td>
                            <td><?= $aCustomer->pid ?></td>
                            <td align="left">
                                <div class="btn-group btn-group-xs ">
                                <?php if (strpos($permission->pm_customer,'2') !== false) { ?>
                                    <a href="<?php echo BASE_URL; ?>/customer/editing/<?php echo $aCustomer->cus_id; ?>"><i class="material-icons icon-hover">settings</i></a>
                                <?php }?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- // Table row END -->
                </tbody>
                <!-- // Table body END -->
            </table>
            <!-- // Table END -->
        </div>
    </div>
</div>
<!-- // Content END -->

<div class="clearfix"></div>
<!-- // Sidebar menu & content wrapper END -->

<script>
    var unFadeOut = false;
    $('document').ready(function() {
        // $('.modal-trigger').leanModal();

        $('.overlay').click(function() {
            if (!unFadeOut) {
                var _this = $(this);
                _this.animate({
                    opacity: 0
                }, 400, function() {
                    _this.removeAttr('style');
                });
                window.location.reload();
            } else {
                unFadeOut = false;
            }
        });
    });
    
    var addRemark = '';
    addRemark += '<li class="newRemark">';
        addRemark += '<div class="remark-add">';
            addRemark += '<a href="#" class="btn-floating btn-medium waves-effect waves-light red" onclick="AddRemark();">';
            addRemark += '<i class="material-icons">add</i>';
            addRemark += '</a>';
        addRemark += '</div>';
    addRemark += '</li>';

    var UnFadeOut = function () {
        unFadeOut = true;
    }

    var fucSuccess = function(json) {
        var list = '<ul class="ulOverlay">';
        var count = json.length;
        list += addRemark;
        
        $.each(json, function(index, value) {
            if (value.lr_remark.trim() != '') {
                var date = new Date(value.lr_timestamp);
                date = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear() + " " + date.getHours() + ":" + date.getMinutes();
                
                list += '<li class="card" onclick="UnFadeOut()">';
                    list += '<div class="card-content">';
                        list += '<lable>';
                            list += '<span class="remark-date">' + date + '</span>';
//                            list += '<span class="remark-del"><a href="#" onclick="DeleteRemark(' + value.lr_id + ');window.location.reload();"><font color="red">Delete</font></a></span>';
                            list += '<span class="remark-page">' + (count--) + ' of ' + (Object.keys(json).length) + '</span>';// - 1
                        list += '</lable>';
                    list += '</div>';
                    list += '<div class="card-action">' + value.lr_remark + '</div>';
                    list += '<div class="remark-footer"> Remark โดย : ' + value.lr_user_remark + '</div>';
                list += '</li>';
            }
        });
        list += '</ul>';

        if (list.trim() == '')
            list = '<lable>None</lable>';
        // $('#listRemark').html(list);

        $('.overlay')
            .html(list)
            .fadeIn();
    };

    function LoadRemark(lead) {
        $('#listRemark').html('<lable>loading...</lable>');
        $('#lead').val(lead);
        $.ajax({
            url: "<?= BASE_DOMAIN; ?>assets/ajax/jsonLeadRemark.php",
            data: ({
                lead: lead
            }),
            dataType: "json",

            success: function (json) { fucSuccess(json); }
        });
    }

    function AddRemark () {
        UnFadeOut();
        var html = '';
        html += '<li class="card" onclick="UnFadeOut();">';
            html += '<div class="card-content">';
                html += '<lable>';
                    html += '<span class="remark-del"><a href="#"><font color="red" onclick="UpdateRemark();">Save</font></a></span>';
                    html += '<span class="remark-page">New Remark</span>';
                html += '</lable>';
            html += '</div>';
            html += '<div class="card-action">';
                html += '<textarea id="newRemark" rows="8" placeholder="Write your remark here ......."></textarea>';
            html += '</div>';
        html += '</li>';
//        $('.newRemark').remove ();
        $('.newRemark')
            .after(html)
            .fadeIn();
    }

    function UpdateRemark() {
        if ($('#newRemark').val().trim() == '') {
            alert('Please enter remark.');
            $('#newRemark').focus();
            return 0;
        }
        var lead = $('#lead').val();
        var remark = $('#newRemark').val();
        var user = '<?= $userid; ?>';
        $('#newRemark').val('');

        $('#listRemark').html('<lable>loading...</lable>');
        $.ajax({
            url: "<?= BASE_DOMAIN; ?>assets/ajax/jsonLeadRemark.php",
            data: ({
                lead: lead,
                remark: remark,
                user: user
            }),
            dataType: "json",

            // success: function(json) {
            //     var list = '';
            //     var count = 1;
            //     $.each(json, function(index, value) {
            //         if (value.lr_remark.trim() != '') {
            //             var date = new Date(value.lr_timestamp);
            //             date = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
            //             list += '<div class="row"><div class="col-md-3"><lable>' + date + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remark #' + (count++) + ' : </lable></div><div class="col-md-8"><lable>"' + value.lr_remark + '"</lable></div></div>';
            //         }
            //     });
            //     $('#listRemark').html(list);
            // }

            success: function (json) { fucSuccess(json); }

        });
    }

    function DeleteRemark (id) {
        var lead = $('#lead').val();
        $.ajax({
            url: "<?= BASE_DOMAIN; ?>assets/ajax/jsonLeadRemark.php",
            data: {
                lead: lead,
                delete: id 
            },
            dataType: "json",

            success: function (json) { fucSuccess(json); }
        });
    }
    
</script>
