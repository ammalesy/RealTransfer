<!--customer-->
<script type="text/javascript">
    $(function() {
        $('#Nationality').material_select(function() {
            $('input.select-dropdown').trigger('close');
        });
        fixSelect (); 

        var defaultOption = '<option value="all">All</option>';

        flagCard();
        $('#Nationality').change(function() {
            $('#Passport').val('');
            $('#idcard').val('');
        });
    });
    function flagCard() {}

    function idcardcall() {
        $.ajax({
            url: "ajaxIDcardCus.php",
            data: ({
                nextList: 'idcard',
                idcard: $('#idcard').val()
            }),
            dataType: "json",
            beforeSend: function() {},
            success: function(json) {
                $.each(json, function(index, value) {

                    if ($("#idcard").val() == value.pers_card_id) {
                        $("#idcard").val('');
                        alert('ID card number is already');
                        $("#idcard").focus();
                    }
                });
            }
        });
    };
</script>
<div class="customer-form">
    <div class="content">
        <div class="content-header">
            <a href="<?php echo BASE_URL; ?>/customer/view" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <span class="title-header">New Customer</span>
        </div>
        <form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off" action="<?php echo BASE_DOMAIN; ?>customer/<?=empty($customer)?'record':'update'?>/<?php echo $cid; ?>">
            <div class="basic-info">
                <div class="row col-row">
                    <div class="col l4 title-info">Gender</div>
                    <div class="col l8 form-info">
                        <div class="radio-pt">
                            <?php           
                                $flagsex1= '';
                                $flagsex2= '';
                                $flagsex3= '';
                                $disable1 = '';
                                $disable2 = '';
                                if ($customer->pers_sex=='Male' || empty($customer->pers_sex)) {
                                    $flagsex1= 'checked="checked"';
                                    $disable2 = 'disabled';
                                }else if ($customer->pers_sex=='Female')  {
                                    $flagsex2= 'checked="checked"';
                                    $disable1 = 'disabled';
                                }else  {
                                    $flagsex3= 'checked="checked"';
                                }
                            ?>
                        <!--sex-->
                            <div class="left">
                                <input name="sex" type="radio" id="male" value="Male" <?=$flagsex1?>/>
                                <label for="male" >Male</label>
                            </div >
                            <div class="left">
                                <input name="sex" type="radio" id="female" value="Female" <?=$flagsex2?>/>
                                <label for="female">Female</label>
                            </div >
                            <div class="left">
                                <input name="sex" type="radio" id="other" value="Other" <?=$flagsex3?>/>
                                <label for="other">Others</label>
                            </div >
                        </div>
                    </div>
                    <input type="hidden" name="qid" value="<?php echo $qid; ?>" />
                </div>
                <div class="row col-row">
                    <div class="col l4 title-info">Basic information</div>
                    <div class="col l8 form-info">
                        <div class="radio-pt">
                            <div class="left">
                                <input name="Prefix" type="radio" id="Mr" value="Mr." <?php 
                                echo $customer->pers_prefix==""?"checked":"";
                                echo $customer->pers_prefix=="Mr."?"checked":"";
                                echo $customer->pers_prefix=="นาย"?"checked":"";?>/>
                                <label for="Mr" class="lMr">Mr.</label>
                            </div>
                            <div class="left">
                                <input name="Prefix" type="radio" id="Miss" value="Miss" <?php 
                                echo $customer->pers_prefix=="Miss"?"checked":"";
                                echo $customer->pers_prefix=="นางสาว"?"checked":"";?>/>
                                <label for="Miss" class="lMiss">Miss</label>
                            </div>
                            <div class="left">
                                <input name="Prefix" type="radio" id="Mrs" value="Mrs." <?php 
                                echo $customer->pers_prefix=="Mrs."?"checked":"";
                                echo $customer->pers_prefix=="นาง"?"checked":"";?>/>
                                <label for="Mrs" class="lMrs">Mrs.</label>
                            </div>
                        </div> 
                    </div>
                </div>
                <div class="row col-row">
                    <div class="col l4 title-info">&nbsp;</div>
                    <div class="col l8 form-info">
                        <div class="input-field left-content">
                            <input id="firstname" name="firstname" type="text" class="validate" maxlength="50" value="<?php echo $customer->pers_fname; ?>" required="required">
                            <label for="firstname">Name*</label>
                        </div>
                        <div class="input-field right-content">
                            <input id="lastname" name="lastname" type="text" class="validate" maxlength="50" value="<?php echo $customer->pers_lname; ?>" required="required" >
                            <label for="lastname">Last Name*</label>
                        </div>
                        <div class="input-field left-content">
                            <select class="form-select" id="Nationality" name="Nationality" onChange="chksatatus(this.value);">
                                <?php
                                echo '<option value="" disabled selected>Nationality</option>';
                                $nationality = !empty($customer->pers_nationality)?$customer->pers_nationality:'171';
                                foreach($list_nationality as $aNationality):
                                    if ($aNationality->nt_id == $nationality) {
                                        echo '<option value="'.$aNationality->nt_id.'" selected>'. $aNationality->nt_nationality.'</option>';   
                                    } else {
                                        echo '<option value="'.$aNationality->nt_id.'">'. $aNationality->nt_nationality.'</option>';
                                    }
                                endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="input-field right-content">
                            <div id="thai-id">
                                <input id="idcard" name="idcard" type="text" class="validate" maxlength="13" value="<?php echo $customer->pers_card_id; ?>" required>
                                <label for="idcard">Thai ID Card*</label>
                            </div>
                            <div id="pass-port">
                                <input id="Passport" name="Passport" type="text" class="validate" maxlength="50" value="<?php echo $customer->pers_passport; ?>">
                                <label for="Passport">ID / Passport Number</label>
                            </div>
                        </div>
                        <div class="input-field left-content">
                            <input id="tel" name="tel" type="text" class="validate" maxlength="10" value="<?php echo $customer->pers_tel; ?>">
                            <label for="tel">Telephone</label>
                        </div>
                        <div class="input-field right-content">
                            <input id="mobile" name="mobile" type="text" class="validate" maxlength="10" value="<?php echo $customer->pers_mobile; ?>" required="required" >
                            <label for="mobile">Mobile*</label>
                        </div>
                        <div class="input-field left-content">
                            <input id="email" name="email" type="text" class="validate" maxlength="50" value="<?php echo $customer->pers_email; ?>">
                            <label for="email">Email</label>
                        </div>
                        <div class="input-field date_of_birth right-content">
                            <div class="row col-row">

                            <?php $dobArr = implode('-', $dob); ?>
                            <label class="date-title">Date of Birth: </label>
                            <div class="col l8 offset-l4">
                                <input class="datepicker" type="date" name="dob" id="dob" value="<?php echo date('Y-m-d',strtotime($dob)); ?>" />
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="address-info">
                <div class="row col-row">
                    <div class="col l4 title-info">Home address ( ที่อยู่ตามทะเบียนบ้าน )</div>
                    <div class="col l8 form-info">
                        <input type="checkbox" class="filled-in addr" id="filled-in-box" name="bookingaddr1" checked="checked" data-checktype="default" data-checkindex="1"/>
                        <label for="filled-in-box">Default Address ( ที่อยู่จัดส่งเอกสาร )</label>
                        <div class="input-field address">
                            <input id="address" name="address" type="text" class="validate" maxlength="100" value="<?php echo $customer->addr_address; ?>" required="required" >
                            <label for="address">Address</label>
                        </div>
                        <div class="addr-country left-content input-field">
                            <input type="hidden" id="country" name="country" value="<?= $customer->addr_country ?>" />
                            <?php $country = json_decode($countries); ?>
                            <input type="text" class="validate countries" value="<?php
                            if (empty($customer->addr_country)) {
                                echo "Thailand";
                            } else {
                                foreach ($country as $key => $value) {
                                    if ($value->val == $customer->addr_country) {
                                        echo $value->label;
                                        break;
                                    }
                                }
                            } ?>">
                            <label for="country">Country</label>
                        </div>
                        <div class="addr-province right-content input-field">
                            <input id="province" type="text" class="validate provinces" name="province" value="<?= $customer->addr_province ?>" >
                            <label for="province">Province</label>
                        </div>
                        <div class="addr-district left-content input-field">
                            <input id="district" type="text" class="validate districts" name="district" value="<?= $customer->addr_district ?>">
                            <label for="district">District</label>
                        </div>
                        <div class="addr-sub-district right-content input-field">
                            <input id="sub-district" type="text" class="validate sub-districts" name="sub_district" value="<?= $customer->addr_sub_district ?>">
                            <label for="sub-district">Sub District</label>
                        </div>
                        <div class="addr-postcode left-content input-field">
                            <input id="postcode" type="text" class="validate postcodes" name="post" value="<?= $customer->addr_post_code ?>">
                            <label for="postcode">Post Code</label>
                        </div>
                    </div>
                </div>
                <div class="row col-row">
                    <div class="col l4 title-info">Current address ( ที่อยู่ปัจจุบัน )</div>
                    <div class="col l8 form-info">
                        <input type="checkbox" class="filled-in" id="current_same" onclick="copyAdd()" />
                        <label for="current_same">Same as Above</label>
                        <div class="form-content">
                            <input type="checkbox" class="filled-in current_default" id="current_default" name="bookingaddr2" disabled="disabled" data-checktype="default" data-checkindex="2"/>
                            <label for="current_default">Default Address ( ที่อยู่จัดส่งเอกสาร )</label>
                            <div class="form-content__input">
                                <div class="input-field address">
                                    <input id="cur_address" name="cur_address" type="text" class="validate" maxlength="100" value="<?php echo $customer->addr_cur_address; ?>" required="required" >
                                    <label for="current_address">Address</label>
                                </div>
                                <div class="cur-addr-country left-content input-field">
                                    <input type="hidden" id="cur_country"  name="cur_country" value="<?= $customer->addr_cur_country ?>" />
                                    <input type="text" class="validate cur-countries" value="<?php
                                    if (empty($customer->addr_cur_country)) {
                                        echo "Thailand";
                                    } else {
                                        foreach ($country as $key => $value) {
                                            if ($value->val == $customer->addr_cur_country) {
                                                echo $value->label;
                                                break;
                                            }
                                        }
                                    } ?>">
                                    <label for="cur-country">Country</label>
                                </div>
                                <div class="cur-addr-province right-content input-field">
                                    <input id="cur-province" type="text" class="validate cur-provinces" name="cur_province" value="<?= $customer->addr_cur_province ?>">
                                    <label for="cur-province">Province</label>
                                </div>
                                <div class="cur-addr-district left-content input-field">
                                    <input id="cur-district" type="text" class="validate cur-districts" name="cur_district" value="<?= $customer->addr_cur_district ?>">
                                    <label for="cur-district">District</label>
                                </div>
                                <div class="cur-addr-sub-district right-content input-field">
                                    <input id="cur-sub-district" type="text" class="validate cur-sub-districts" name="cur_sub_district" value="<?= $customer->addr_cur_sub_district ?>">
                                    <label for="cur-sub-district">Sub District</label>
                                </div>
                                <div class="cur-addr-postcode left-content input-field">
                                    <input id="cur-postcode" type="text" class="validate cur-postcodes" name="cur_post" value="<?= $customer->addr_cur_post_code ?>">
                                    <label for="cur-postcode">Post Code</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row col-row">
                    <div class="col l4 title-info">Other address ( ที่อยู่อื่นๆ )</div>
                    <div class="col l8 form-info">
                        <div class="form-content">
                            <input type="checkbox" class="filled-in other_default" id="other_default" name="bookingaddr3" disabled="disabled" data-checktype="default" data-checkindex="3"/>
                            <label for="other_default">Default Address ( ที่อยู่จัดส่งเอกสาร )</label>
                            <div class="form-content__input">
                                <div class="input-field address">
                                    <input id="other_address" name="lastest_address" type="text" class="validate" maxlength="100" value="<?php echo $customer->addr_lastest_address; ?>">
                                    <label for="other_address">Address</label>
                                </div>
								<div class="other-addr-country left-content input-field">
                                    <input type="hidden" id="lastest_country" name="lastest_country" value="<?= $customer->addr_lastest_country ?>" />
                                    <input type="text" class="validate other-countries" value="<?php
                                    if (empty($customer->addr_lastest_country)) {
                                        echo "Thailand";
                                    } else {
                                        foreach ($country as $key => $value) {
                                            if ($value->val == $customer->addr_lastest_country) {
                                                echo $value->label;
                                                break;
                                            }
                                        }
                                    } ?>">
                                    <label for="other-country">Country</label>
                                </div>
                                <div class="other-addr-province right-content input-field">
                                    <input id="other-province" type="text" class="validate other-provinces" name="lastest_province" value="<?php echo $customer->addr_lastest_province; ?>">
                                    <label for="other-province">Province</label>
                                </div>
                                <div class="other-addr-district left-content input-field">
                                    <input id="other-district" type="text" class="validate other-districts" name="lastest_district" value="<?php echo $customer->addr_lastest_district; ?>">
                                    <label for="other-district">District</label>
                                </div>
                                <div class="other-addr-sub-district right-content input-field">
                                    <input id="other-sub-district" type="text" class="validate other-sub-districts" name="lastest_sub_district" value="<?php echo $customer->addr_lastest_sub_district; ?>">
                                    <label for="other-sub-district">Sub District</label>
                                </div>
                                <div class="other-addr-postcode left-content input-field">
                                    <input id="other-postcode" type="text" class="validate other-postcodes" name="lastest_post" value="<?php echo $customer->addr_lastest_post_code; ?>">
                                    <label for="other-postcode">Post Code</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="working-info">
                <div class="row col-row">
                    <div class="col l4 title-info">Working information</div>
                    <div class="col l8 form-info">
                        <div class="input-field left-content company">
                            <input id="company" name="company" type="text" class="validate" maxlength="50" value="<?php echo $customer->work_company; ?>">
                            <label for="company">Company</label>
                        </div>
                        <div class="input-field position right-content">
                            <input id="position" name="position" type="text" class="validate" maxlength="50" value="<?php echo $customer->work_position; ?>" >
                            <label for="position">Position</label>
                        </div>
                        <div class="input-field left-content house_number">
                            <input id="house_number" name="workinghouseno" type="text" class="validate" maxlength="50" value="<?php echo $customer->work_house_no; ?>" >
                            <label for="house_number">House No.</label>
                        </div>
                        <div class="input-field road right-content">
                            <input id="road" name="workingroad" type="text" class="validate" maxlength="50" value="<?php echo $customer->work_road; ?>" >
                            <label for="road">Road</label>
                        </div>			
						<div class="work-addr-country input-field left-content">
                            <input type="hidden" id="workingcountry" name="workingcountry" value="<?= $customer->addr_lastest_country ?>" />
							<input type="text" class="validate work-countries" value="<?php
                                    if (empty($customer->work_country)) {
                                        echo "Thailand";
                                    } else {
                                        foreach ($country as $key => $value) {
                                            if ($value->val == $customer->work_country) {
                                                echo $value->label;
                                                break;
                                            }
                                        }
                                    } ?>">
							<label for="work-country">Country</label>
						</div>
						<div class="work-addr-province input-field right-content">
							<input id="work-province" type="text" class="validate work-provinces" name="working_province" value="<?= $customer->work_province ?>">
							<label for="work-province">Province</label>
						</div>
						<div class="work-addr-district input-field left-content">
							<input id="work-district" type="text" class="validate work-districts" name="working_district" value="<?= $customer->work_district ?>">
							<label for="work-district">District</label>
						</div>
						<div class="work-addr-sub-district input-field right-content">
							<input id="work-sub-district" type="text" class="validate work-sub-districts" name="working_sub_district" value="<?= $customer->work_sub ?>">
							<label for="work-sub-district">Sub District</label>
						</div>
						<div class="work-addr-postcode input-field left-content">
							<input id="work-postcode" type="text" class="validate work-postcodes" name="working_post" value="<?= $customer->work_post_code ?>">
							<label for="work-postcode">Post Code</label>
						</div>
					</div>
				</div>
			</div>
            <div class="contact-info">
                <div class="row col-row">
                    <div class="col l4 title-info">Contact person</div>
                    <div class="col l8 form-info">
                        <div class="input-field firstname left-content">
                            <input id="cfirstname" name="ConFname" type="text" class="validate" value="<?php echo $customer->con_fname; ?>" >
                            <label for="cfirstname">First Name</label>
                        </div>
                        <div class="input-field lastname right-content">
                            <input id="clastname" name="ConLname" type="text" class="validate" value="<?php echo $customer->con_lname; ?>" >
                            <label for="clastname">Last Name</label>
                        </div>
                        <div class="input-field tel left-content">
                            <input id="tel" name="contel" type="text" class="validate" value="<?php echo $customer->con_tel; ?>" >
                            <label for="tel">Tel</label>
                        </div>
                        <div class="input-field email right-content">
                            <input id="conMail" name="conMail" type="text" class="validate" value="<?php echo $customer->con_email; ?>" >
                            <label for="conMail">Email</label>
                        </div>
                        <div class="contactButton">
                            <button type="submit" class="waves-effect waves-light btn btn-save"><i class="fa fa-check-circle"></i>Save</button>
                            <a class="waves-effect waves-light btn btn-discard" href="<?= BASE_DOMAIN ?>customer"><i class="fa fa-times"></i>Discard</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8" style="display: none">
                <label class="col-md-4 control-label" for="identification">Identification </label>
                <?php 
					$flag1= '';
					$flag2= '';
				 	if($customer->pers_identification_flag == 'passport') {
						$flag1 = 'checked="checked"';
					}else{
						$flag2 = 'checked="checked"';
					}
                 ?>
                <label class="radio">
                    <input type="radio" class="radio" name="identification" value="IDCard" id="IDCardflag" <?php echo $flag2; ?> onclick="return flagCard()"/>Thai ID Card
                </label>
                <label class="radio">
                    <input type="radio" class="radio" name="identification" value="passport" id="passportflag" <?php echo $flag1; ?> onclick="return flagCard()"/>Passport
                </label>
            </div>
        </form>
    </div>
</div>
<!-- // Content END -->

<div class="clearfix"></div>
<!-- // Sidebar menu & content wrapper END -->

<script type="text/javascript">
    var provinceSpell = "";
    
    $(document).ready(function() {
        <?php
        if ($customer->addr_country == null) {
            echo "$('#country').val('213');";
        } 
        if ($customer->addr_cur_country == null) {
            echo "$('#cur_country').val('213');";
        } 
        if ($customer->addr_lastest_country == null) {
            echo "$('#lastest_country').val('213');";
        } 
        if ($customer->addr_lastest_country == null) {
            echo "$('#workingcountry').val('213');";
        }
        ?>

        $('#male').prop('checked', true);
        $('input:radio[name="Prefix"][value="Mr."]').attr('disabled', false);
        $('input:radio[name="Prefix"][value="Mr."]').prop('checked', true);
        $('input:radio[name="Prefix"][value="Mrs."]').attr('disabled', true);
        $('input:radio[name="Prefix"][value="Miss"]').attr('disabled', true);
        $('.lMr').css('cursor','pointer');
        $('.lMrs').css('cursor','not-allowed');
        $('.lMiss').css('cursor','not-allowed');
        
		var ob = [
		{
			Country: {
				element: ".countries",
				appendTo: ".addr-country",
                valueTo: "#country"
			},
			Province: {
				element: ".provinces",
				appendTo: ".addr-province"
			},
			District: {
				element: ".districts",
				appendTo: ".addr-district"
			},
			SubDistrict: {
				element: ".sub-districts",
				appendTo: ".addr-sub-district"
			},
			PostCode: {
				element: ".postcodes",
				appendTo: ".addr-postcode"
			}
		},{
			Country: {
				element: ".cur-countries",
				appendTo: ".cur-addr-country",
                valueTo: "#cur_country"
			},
			Province: {
				element: ".cur-provinces",
				appendTo: ".cur-addr-province"
			},
			District: {
				element: ".cur-districts",
				appendTo: ".cur-addr-district"
			},
			SubDistrict: {
				element: ".cur-sub-districts",
				appendTo: ".cur-addr-sub-district"
			},
			PostCode: {
				element: ".cur-postcodes",
				appendTo: ".cur-addr-postcode"
			}
		},{
			Country: {
				element: ".other-countries",
				appendTo: ".other-addr-country",
                valueTo: "#lastest_country"
			},
			Province: {
				element: ".other-provinces",
				appendTo: ".other-addr-province"
			},
			District: {
				element: ".other-districts",
				appendTo: ".other-addr-district"
			},
			SubDistrict: {
				element: ".other-sub-districts",
				appendTo: ".other-addr-sub-district"
			},
			PostCode: {
				element: ".other-postcodes",
				appendTo: ".other-addr-postcode"
			}
		},{
			Country: {
				element: ".work-countries",
				appendTo: ".work-addr-country",
                valueTo: "#workingcountry"
			},
			Province: {
				element: ".work-provinces",
				appendTo: ".work-addr-province"
			},
			District: {
				element: ".work-districts",
				appendTo: ".work-addr-district"
			},
			SubDistrict: {
				element: ".work-sub-districts",
				appendTo: ".work-addr-sub-district"
			},
			PostCode: {
				element: ".work-postcodes",
				appendTo: ".work-addr-postcode"
			}
		}];
        pageReady (ob);
		autocompleteCustom (ob);
    });

    function provinceProcess () {
        console.log("province :" + window.event);
    }

    function pageReady (ob) {
        $.each(ob, function (id, ob) {
            if ($(ob.Country.element).val() == "Thailand") {
                autocompleteProvince (ob.Province.element, ob.Province.appendTo, function (data) {
                    autocompleteDistrict (data, ob.District.element, ob.District.appendTo, function (data) {
                        autocompleteSubDistrict (data, ob.SubDistrict.element, ob.SubDistrict.appendTo);
                    }, function (data) {
                        autocompletePostCode (data, ob.PostCode.element, ob.PostCode.appendTo);
                    });
                });
            }
        });
    }
	
	function autocompleteCustom(ob) {
		$.each(ob, function (id, ob) {

			autocompleteCountry (ob.Country.element, ob.Country.appendTo, ob.Country.valueTo, ob.Province.element, function() {
    			autocompleteProvince (ob.Province.element, ob.Province.appendTo, function (data) {
    				autocompleteDistrict (data, ob.District.element, ob.District.appendTo, function (data) {
    					autocompleteSubDistrict (data, ob.SubDistrict.element, ob.SubDistrict.appendTo);
    				}, function (data) {
    					autocompletePostCode (data, ob.PostCode.element, ob.PostCode.appendTo);
    				});
    			});
            });

		});
	}
	
	function autocompleteCountry (country, appendTo, valueTo, provinces, callback) {
		var Countries = <?php echo $countries; ?>;
        $(country).autocomplete({
            source: Countries,
            minLength: 0,
            scroll: true,
            open: function() {
                $(this).autocomplete("widget")
                       .appendTo(appendTo)
                       .css({
                            top :'inherit',
                            left :'0px',
                            marginTop :'-15px'
                       })
            },
            select: function(event, ui) {
                $(valueTo).val(ui.item.val);
                if ($(this).val() == 'Thailand') {
                    console.log("thai");
                    callback();
                } else {
                    $(provinces).autocomplete({"source": null});       
                }
            }
        }).focus(function() {
            // $(this).autocomplete("search", "");
        })
	}
	function autocompleteProvince (provinces, appendTo, fucDistrict) {
		var provinceID;
        var Provinces = <?php echo $provinces; ?>;
        $(provinces).autocomplete({
            source: Provinces,
            minLength: 0,
            scroll: true,
            open: function() {
                $(this).autocomplete("widget")
                       .appendTo(appendTo)
                       .css({
                            top :'inherit',
                            left :'0px',
                            marginTop :'-15px'
                       })
                provinceProcess ();
                console.log("here1");
            },
            select: function(event, ui) {
                var districtArr = [];
                $.ajax({
                    url: "<?php echo BASE_URL; ?>/customer/FetchAllProvince/json",
                    dataType: 'json',
                    success: function (res) {

                            $.each(res, function(index, value) {
                                if ($(provinces).val() == value.pv_name_th) {
                                    provinceID = value.pv_id;
                                }
                            });

                        console.log("here2");
                    },
                    error: function (err) {
                        alert('error');
                    }
                });
                
                $.ajax({
                    url: "<?php echo BASE_URL; ?>/customer/FetchAllDistrict/json",
                    dataType: 'json',
                    success: function (res) {
                        $.each(res, function(index, value) {
                            if (provinceID == value.d_province_id) {
                                districtArr.push( { label: value.d_name_th, id: value.d_id } );
                            }
                        });
                        
                        fucDistrict(districtArr);
                    },
                    error: function (err) {
                        alert('error');
                    }
                });
            }
        }).focus(function() {
            $(this).autocomplete("search", "");
        });
	}
	function autocompleteDistrict (data, districts, appendTo, fucSubDistrict, fucPostCode) {
		var Districts = data;
        $(districts).autocomplete({
            source: Districts,
            minLength: 0,
            scroll: true,
            open: function() {
                $(this).autocomplete("widget")
                   .appendTo(appendTo)
                   .css({
                        top :'inherit',
                        left :'0px',
                        marginTop :'-15px'
                   })
            },
            select: function(event, ui) {
                $(districts).val(ui.item.label);
                var subDistrictArr = [];
                var postCodeArr = [];
                var districtID;
                console.log('test'+$(districts).val());
                $.each(Districts, function(index, value) {
                    if ($(districts).val() == value.label) {
                        districtID = value.id;
                    }
                });
                console.log(districtID);
                $.ajax({
                    url: "<?php echo BASE_URL; ?>/customer/FetchAllSubDistrict/json",
                    dataType: 'json',
                    success: function (res) {
                        $.each(res, function(index, value) {
                            if (districtID == value.sd_district_id) {
                                subDistrictArr.push(value.sd_name_th);
                            }
                        });
                        fucSubDistrict(subDistrictArr);
                    },
                    error: function (err) {
                        alert('error');
                    }
                });
                 $.ajax({
                    url: "<?php echo BASE_URL; ?>/customer/FetchAllPostCode/json",
                    dataType: 'json',
                    success: function (res) {
                        $.each(res, function(index, value) {
                            if (districtID == value.pc_district_id) {
                                postCodeArr.push(value.pc_code);
                            }
                        });
                        fucPostCode(postCodeArr);
                    },
                    error: function (err) {
                        alert('error');
                    }
                });
            }
        }).focus(function(event, ui ) {
            $(this).autocomplete("search", "");
        });  
	}
	function autocompleteSubDistrict (data, subDistrict, appendTo) {
        // alert ('hello'+data);
		var subDistricts = data;
        $(subDistrict).autocomplete({
            source: subDistricts,
            minLength: 0,
            scroll: true,
            open: function() {
                $(this).autocomplete("widget")
                       .appendTo(appendTo)
                       .css({
                            top :'inherit',
                            left :'0px',
                            marginTop :'-15px'
                       })
            },
        }).focus(function() {
            $(this).autocomplete("search", "");
        });  
	}
	function autocompletePostCode (data, postcode, appendTo) {
		var postcodes = data;
        $(postcode).autocomplete({
            source: postcodes,
            minLength: 0,
            scroll: true,
            open: function() {
                $(this).autocomplete("widget")
                       .appendTo(appendTo)
                       .css({
                            top :'inherit',
                            left :'0px',
                            marginTop :'-15px'
                       })
            },
        }).focus(function() {
            $(this).autocomplete("search", "");
        });  
	}
	
	function copyAdd () {
		if ($('#current_same').prop('checked')) {
			$('input[name="cur_address"]').val($('input[name="address"]').val());
			$('input[name="cur_province"]').val($('input[name="province"]').val());
			$('input[name="cur_district"]').val($('input[name="district"]').val());
			$('input[name="cur_sub_district"]').val($('input[name="sub_district"]').val());
			$('input[name="cur_post"]').val($('input[name="post"]').val());
		} else {
			$('input[name="cur_address"]').val('');
			$('input[name="cur_province"]').val('');
			$('input[name="cur_district"]').val('');
			$('input[name="cur_sub_district"]').val('');
			$('input[name="cur_post"]').val('');
		}
	}
    
    function chksatatus(nation){
//        console.log('test : <?$customer->pers_nationality?>' + nation);
        if (nation=="171"){
            $("#thai-id").show();
            $("#pass-port").hide();
            document.getElementById('idcard').required = true;
            document.getElementById('Passport').required = false;
//            document.getElementById('thai-id').style.display='block';
//            document.getElementById('pass-port').style.display='none';
        }else{
            $("#thai-id").hide();
            $("#pass-port").show();
            document.getElementById('idcard').required = false;
            document.getElementById('Passport').required = true;
//            document.getElementById('thai-id').style.display='none';
//            document.getElementById('pass-port').style.display='block';
            
        }
    }
    
    $(document).ready(function(){
        var nation = '<?=$customer->pers_nationality?>';
        if (nation=="171" || nation==''){
            $("#thai-id").show();
            $("#pass-port").hide();
            document.getElementById('idcard').required = true;
            document.getElementById('Passport').required = false;
            console.log('ไทยโว้ย <?=$customer->pers_nationality?>');
//            document.getElementById('thai-id').style.display='block';
//            document.getElementById('pass-port').style.display='none';
        }else{
            $("#thai-id").hide();
            $("#pass-port").show();
            document.getElementById('idcard').required = false;
            document.getElementById('Passport').required = true;
            console.log('ฝรั่งโว้ย <?=$customer->pers_nationality?>');
//            document.getElementById('thai-id').style.display='none';
//            document.getElementById('pass-port').style.display='block';
            
        }
    });
	

       $('input[data-checktype="default"]').on('change', function() {
           var _this = $(this);
           var _bool = _this.is(':checked') ? 'disabled' : '';

           $.each($('input[data-checktype="default"]'), function() {
               var _current = $(this);
               if (_current.data('checkindex') !== _this.data('checkindex')) _current.prop('disabled', _bool);
           });
           $('input[data-checktype="sameabove"]').prop('disabled', '');
           $.each($('input[data-checktype="sameabove"]'), function() {
               var _current = $(this);
               var isChecked = '';
               console.log(_current.data('checkindex'), _this.data('checkindex'));
               if (_current.data('checkindex') === _this.data('checkindex') || $('input[data-checktype="default"]:checked').length == 0) {
                   isChecked = 'disabled';
                   _current.prop('checked', '');
               }
               _current.prop('disabled', isChecked);

           });
       });    

    $(document).ready(function() {
        $('#bookingaddr1').click(function() {
            if ($(this).is(':checked')) {

                $('#bookingaddr2').prop('checked', false); // Checks it
                $('#bookingaddr3').prop('checked', false); // Unchecks it   
            } else {
                $('#bookingaddr1').prop('checked', true); // Checks it
                $('#bookingaddr3').prop('checked', true); // Unchecks it   
            }
        });

        $('#bookingaddr2').click(function() {
            if ($(this).is(':checked')) {

                $('#bookingaddr1').prop('checked', false); // Checks it
                $('#bookingaddr3').prop('checked', false); // Unchecks it   
            } else {
                $('#bookingaddr1').prop('checked', true); // Checks it
                $('#bookingaddr3').prop('checked', true); // Unchecks it   
            }
        });

        $('#bookingaddr3').click(function() {
            if ($(this).is(':checked')) {

                $('#bookingaddr1').prop('checked', false); // Checks it
                $('#bookingaddr2').prop('checked', false); // Unchecks it   
            } else {
                $('#bookingaddr1').prop('checked', true); // Checks it
                $('#bookingaddr2').prop('checked', true); // Unchecks it   
            }
        });


    });

    jQuery(':radio[name="sex"]').click(function() {
        if ((jQuery(this).val() == 'Male')) {
            $('input:radio[name="Prefix"][value="Mr."]').attr('disabled', false);
            $('input:radio[name="Prefix"][value="Mr."]').prop('checked', true);
            $('input:radio[name="Prefix"][value="Mrs."]').attr('disabled', true);
            $('input:radio[name="Prefix"][value="Miss"]').attr('disabled', true);
            $('.lMr').css('cursor','pointer');
            $('.lMrs').css('cursor','not-allowed');
            $('.lMiss').css('cursor','not-allowed');
        } else if ((jQuery(this).val() == 'Female')) {
            $('input:radio[name="Prefix"][value="Mr."]').attr('disabled', true);
            $('input:radio[name="Prefix"][value="Mrs."]').attr('disabled', false);
            $('input:radio[name="Prefix"][value="Miss"]').attr('disabled', false);
            $('input:radio[name="Prefix"][value="Mrs."]').prop('checked', true);
            $('.lMr').css('cursor','not-allowed');
            $('.lMrs').css('cursor','pointer');
            $('.lMiss').css('cursor','pointer');
        } else {
            $('input:radio[name="Prefix"][value="Mr."]').attr('disabled', false);
            $('input:radio[name="Prefix"][value="Mrs."]').attr('disabled', false);
            $('input:radio[name="Prefix"][value="Miss"]').attr('disabled', false);
            $('input:radio[name="Prefix"][value="Mr."]').prop('checked', true);
            $('.lMr').css('cursor','pointer');
            $('.lMrs').css('cursor','pointer');
            $('.lMiss').css('cursor','pointer');
        }
    });
</script>

