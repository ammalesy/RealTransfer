<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $title; ?>
    </title>

    <!-- Meta -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />


    <link rel="stylesheet" href="<?= BASE_DOMAIN; ?>assets/css/admin/module.admin.page.calendar.min.css" />
    <link rel="stylesheet" href="<?= BASE_DOMAIN; ?>assets/css/realcrm.css" />

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>

    <!--
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>
    <link href="<?php echo BASE_DOMAIN; ?>assets/components/plugins/select2/css/select2.min.css" rel="stylesheet"   />
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/select2/js/select2.min.js"></script>
-->

    <!--
    <link href='<?= BASE_DOMAIN; ?>assets/components/modules/admin/fullcalendar/fullcalendar.css' rel='stylesheet' />
    <link href='<?= BASE_DOMAIN; ?>assets/components/modules/admin/fullcalendar/fullcalendar.print.css' rel='stylesheet' media='print' />
    <script src='<?= BASE_DOMAIN; ?>assets/components/modules/admin/fullcalendar/lib/moment.min.js'></script>
    <script src='<?= BASE_DOMAIN; ?>assets/components/modules/admin/fullcalendar/lib/jquery.min.js'></script>
    <script src='<?= BASE_DOMAIN; ?>assets/components/modules/admin/fullcalendar/fullcalendar.min.js'></script>
-->
    <!--
    <script type="text/javascript">
        $(window).load(function() {
            $('#loading').remove();
            $('#dataTable').css('visibility', 'visible');
        });
    </script>
-->
    <style>
        #external-events li.glyphicons i:before {
            height: 80px;
            line-height: 80px;
        }
    </style>
    <script>
        function ChangeText(val) {
            $('#event').html('<i></i> <input class="form-control" onchange="ChangeText(this.value)"><br/>' + val);
            AddEvent('#event');
        }

        $(function () {
            $(".btn-primary").click(function () {
                UpdateCalendar();
            });
        });
    </script>
</head>

<body>
    <!--    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>-->
    <div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
        <?php
            include "application/views/menu_top.php";
        ?>
    </div>

    <div id="menu" class="hidden-print hidden-xs">
        <?php
			include "application/views/menu_left.php";
            if ($menu->pm_calendar < 1) {
                alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');
            }
        ?>
    </div>
    <div id="content">
        <div class="innerAll text-center">
            <div class="widget">
                <div class="widget-head">
                    <h4 class="heading" style='color:#ffffff'>Calendar</h4>
                </div>
                <!-- // Widget heading END -->

                <div class="widget-body widget-inverse">
                    <div class="innerAll spacing-x2">

                        <div class="row">
                            <div id="external-events">
                                <ul>
                                    <li class="glyphicons move" id="event" style="width:230px;height:80px"><i></i>
                                        <input class="form-control" onchange="ChangeText(this.value)">
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <input type="checkbox" id="removeEvent" style="width:20px;height:20px;" />
                            <label for="removeEvent"> Remove event when click enent in calendar</label>
                        </div>
                        <div class="row">
                            <!-- Widget -->
                            <div class="widget">
                                <div class="widget-body">
                                    <div data-component>
                                        <div class="calendar"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- // Widget END -->
                        </div>

                        <div class="row center">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Submit</button>
                            <a href="<?= BASE_DOMAIN ?>calendar">
                                <button type="button" class="btn"><i class="fa fa-times"></i> Cancel</button>
                            </a>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <!--    ///////////  load  ////////////////////////-->
    <div class="modal fade" id="load" data-backdrop="static">

        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal heading -->
                <div class="modal-header">
                    <h3 class="modal-title">Loading...</h3>
                </div>
            </div>
        </div>

    </div>
    <!-- Global -->
    <script>
        var basePath = '',
            commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
            rootPath = '<?= BASE_DOMAIN ?>',
            DEV = false,
            componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

        var primaryColor = '#cb4040',
            dangerColor = '#b55151',
            infoColor = '#466baf',
            successColor = '#8baf46',
            warningColor = '#ab7a4b',
            inverseColor = '#45484d';

        var themerPrimaryColor = primaryColor;
    </script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>-->
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>-->
    <!--    <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>-->
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/calendar/assets/lib/js/fullcalendar.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/calendar/assets/custom/js/calendar.init.js?v=v1.2.3"></script>
</body>

</html>