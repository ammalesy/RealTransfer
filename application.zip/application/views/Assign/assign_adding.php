

		<div id="menu" class="hidden-print hidden-xs">
			<?php
				if (strpos($permission->pm_assign,'1') == false) {
					alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/assign/view');	
			}
			?>
		</div>
		
<div class="setting_assign">
		
<div class="innerAll spacing-x2">
    <div class="content-header">
       <a href="<?php echo BASE_URL; ?>/assign/view" class="back-head"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
        <font color="#78ad13">Assign user to project</font>
    </div><br/><br/>

	<!-- Form -->
<form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off"  action="<?php echo BASE_URL; ?>/assign/record">
	
		<div class="widget-body">
		
			<!-- Row -->
			<div class="row">
				<div class="col-md-4">
				
					<!-- Group -->
					<div class="form-group">
						<label class="col-md-4 control-label" for="User">Project</label>
						<div class="col-md-8">
							<select class="form-control" id="Project" name="Project" style="width: 200px">
						 		<?php
							         echo '<option value="" >------- Select ------</option>';
											
											foreach($list_project as $aProject):
												echo '<option value="', $aProject->pj_id, '">', $aProject->pj_name.'</option>';
											endforeach;
									?>
							</select> 
						</div>
					</div>
					<!-- // Group END -->
					
				</div>
				<!-- // Column END -->
				
				<!-- Column -->
				<div class="col-md-8">
				<!-- Group -->
					<div class="form-group">
						<label class="col-md-4 control-label" for="User">User</label>
						<div class="col-md-8">
							<select class="form-control" id="User" name="User" style="width: 200px">
						 		<?php
							         echo '<option value="" >------- Select ------</option>';
											foreach($list_personal as $aPersonal):
												echo '<option value="', $aPersonal->user_id, '">', $aPersonal->user_pers_fname.' '.$aPersonal->user_pers_lname,'</option>';
											endforeach;
									?>
							</select> 
						</div>
					</div>
					<!-- // Group END -->
				</div>
				<!-- // Column END -->
				
			</div>
			<!-- // Row END -->
			
				<hr class="separator" />

			<!-- Form actions -->
			<div class="form-actions" align="center">
				<button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Save</button>
				<a href="<?php echo BASE_URL; ?>/assign/view"><button type="button"  class="btn btn-default"><i class="fa fa-times"></i> Cancel</button></a>
				
			</div>
			<!-- // Form actions END -->
			
		</div>
		
		<div class="clearfix"></div>
	

	