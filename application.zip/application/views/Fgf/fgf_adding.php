<div class="fgf-adding">
    <div class="content">
        <div class="content-header">
            <a href="<?php echo BASE_DOMAIN; ?>fgf" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <span class="title-header">New Friend Get Friend</span>
        </div>
        <form class="form-horizontal margin-none" id="validateSubmitForm" method="post" autocomplete="off" action="<?php echo BASE_DOMAIN; ?>fgf/record">
            <div class="form-padding">
                <div class="row">
                    <?php
                        $comma = '';
                        $allEmp = '';
                        foreach($list_customer as $aCustomer):
                            $allEmp .= $comma.'{value: "'.$aCustomer->cus_id.'",label: "'.$aCustomer->fullname.'"}';
                            if($comma==='') $comma = ',';
                        endforeach;
                        
                        $allEmp = '['. $allEmp . ']';  
                    ?>
                    <div class="col l4 title-info">Customer</div>
                    <div class="col l8 form-info">
                        <div class="input-field left-content">
                            <select name="leadsid" id="leadsid">
                                <option value="" disabled selected>Select Cusotmer</option>
                                <?php
                                    foreach($list_customer as $customer):
                                        echo "<option value=\"$customer->cus_id\">$customer->fullname</option>";
                                    endforeach;
                                ?>
                            </select>
                            <label>Name</label>
                        </div>
                        <div class="input-field right-content">
                            <select name="unit" id="unit">
                                <option value="" disabled selected>Unit Number</option>
                                <?php 
                                    foreach($list_unit as $unit):
                                        echo "<option value=\"$unit->un_id\">$unit->building_name$unit->un_name</option>";
                                    endforeach;
                                ?>
                            </select>
                            <label>Unit Number</label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col l4 title-info">Suggest to</div>
                    <div class="col l8 form-info">
                        <div class="input-field half-width">
                            <select name="leadsid2" id="leadsid2">
                                <option value="" disabled selected>Select Cusotmer</option>
                                <?php
                                    foreach($list_customer as $customer):
                                        echo "<option value=\"$customer->cus_id\">$customer->fullname</option>";
                                    endforeach;
                                ?>
                            </select>
                            <label>Name</label>
                        </div>
                        <div class="input-field half-width">
                            <input type="date" class="datepicker validate" name="end" id="end">
                            <label>End Date</label>
                        </div>
                    </div>
                </div>
                <div class="row margin-top-30">
                    <div class="col l4 title-info">&nbsp</div>
                    <div class="col l8 form-info">
                        <button type="submit" class="waves-effect waves-light btn btn-save"><i class="fa fa-check-circle"></i> Submit</button>
                        <a href="<?php echo BASE_URL; ?>/fgf/view" class="waves-effect waves-light btn btn-discard"><i class="fa fa-times"></i>Discard</a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="clearfix"></div>
<script type="text/javascript">
    $(function() {
        $('#modal-url').val('<?=BASE_DOMAIN?>fgf/adding');

        // $('#leadsid2').select2({
        //     minimumInputLength: 3
        // });

        // $('#leadsid').select2({
        //     minimumInputLength: 3
        // });

        // $('#unit').select2();

        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15,
            format: 'yyyy-mm-dd',
            formatSubmit: 'yyyy-mm-dd'
        });

        $('#unit').change(function() {
            $.ajax({
                url: "<?=BASE_DOMAIN?>assets/ajax/jsonCusByUnit.php",
                data: ({
                    unitID: $('#unit').val(),
                    project_database_sel: '<?= $project_database_sel; ?>'
                }),
                dataType: 'json',
                success: function(json) {
                    $.each(json, function(index, value) {
                        if (value.ct_cus_id != '') {
                            var arr = value.ct_cus_id.split(',');
                            $('#leadsid').select2('val', arr[0]);
                        }
                    });
                }
            });
        });
    });
</script>
