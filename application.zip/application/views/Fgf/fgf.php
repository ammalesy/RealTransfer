<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>
<script>
    $(function() {
        $('select').material_select();
        $('.modal-trigger').leanModal();

         
    });
    function CheckApprover(conid, id, name2, name) {
//             $('#ckconfirm').prop('checked', false)
             $('#conid').val(conid);
             $('#id').val(id);
             $('#name2').val(name2);
             $('#name').val(name);
         $('.oldCustomerName').html(name);
         $('.oldCustomerId').html(id);
         $('.newCustomerName').html(name2);
         $('.newCustomerId').html(conid);
     }
    $(function(){
        var defaultOption = '<option value=""> ------- Select ------ </option>';

        // Bind an event handler to the "change" JavaScript event, or trigger that event on an element.
        $("#checkboxes" ).empty();
        $("#Sbuilding-confirm").html(defaultOption);

        $.ajax({
            url: "<?php echo BASE_DOMAIN; ?>/assets/ajax/jsonQuotation_Project_Building.php",
            data: ({ Project: '<?php echo $project_name_sel; ?>',project_database_sel:'<?php echo $project_database_sel; ?>' }),
            dataType: "json",

            success: function(json){
                $.each(json, function(index, value) {
                     $("#building-confirm").append('<option value="' + value.building_id + '">' + value.building_name + '</option>');
                });
                $('select').material_select();
            }
        });
    });

</script>

<!-- Modal Approver-->
<div class="modal fade" id="modal-compose" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div align="center" id="lblconfirm" style="font-size:14px;padding-top:5px;padding-bottom:5px;font-weight:bolder;color:#6B8E23">Confirm By Approver</div>

            <form class="form-horizontal" role="form" action='<?php echo BASE_URL; ?>/fgf/confirm_approver' method="post" name='form' id='form'>
                <!-- Modal body -->
                <div class="modal-body padding-none">

                    <div class="bg-gray innerAll border-bottom">
                        <div class="innerLR">
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Contract Code</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="conid" name='conid' disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Old Customer</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="name" name='name' disabled>
                                    </div>
                                </div>
                            </div>
                            <hr color="black">
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">New Customer</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="name2" name='name2' disabled>
                                    </div>
                                </div>
                            </div>
                            <!-- Group -->
                            <div class="form-group">
                                <label class="col-sm-3 control-label" for="Building">Building Name</label>
                                <div class="col-sm-8">
                                    <select class="form-control" id="Building" name="building" style="width: 200px" required="required" title="Please Select Floor Name">
                                        <?php
                                                 echo '<option value="" >------- Select ------</option>';
                                                ?>
                                    </select>
                                </div>
                            </div>
                            <!-- // Group END -->
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Unit Number Of New Customer</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="unit-cus2" name='unit-cus2' required="required" title="Please enter unit number">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-4 control-label">Promotion FGF for :</label>
                                <div class="col-sm-8">
                                    <div class="checkbox-inline">
                                        <label>
                                            <input type="checkbox" class="checkbox-inline" style="width:20px; height:20px;" id="one" name='one' checked> &nbsp;Old Customer</label>
                                    </div>
                                    <div class="checkbox-inline">
                                        <input type="checkbox" class="checkbox-inline" style="width:20px; height:20px;" id="two" name='two' checked>
                                        <label for=two> &nbsp;New Customer</label>
                                    </div>
                                </div>
                            </div>


                            <div class="clearfix"></div>
                        </div>
                    </div>

                    <div style='padding-left:10px'>
                        <input type='checkbox' class="checkbox-inline" style="width:20px; height:20px;" name='ckconfirm' id='ckconfirm' required="required" title="Please confirm check box">
                        <label for=ckconfirm> &nbsp;Check box to confirm if Approver confirms</label>
                    </div>

                </div>
                <!-- // Modal body END -->

                <div class="innerAll text-center border-top">
                    <input type="submit" class="btn btn-primary" value="Confirm">
                    <a class="btn btn-default" data-dismiss="modal"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                </div>
            </form>

        </div>
    </div>
</div>

<div class="fgf-view">
    <div class="content">
        <?php if (strpos($permission->pm_quotation,'1') !== false) { ?>
        <div class="content-add">
            <a class="btn-floating btn-medium waves-effect waves-light red" href="<?= BASE_DOMAIN ?>fgf/adding"><i class="material-icons">add</i></a>
        </div>
        <?php } ?>

        <div class="content-header">
            <font color="#78ad13">Friend Get Friend</font> <label class="table-total">...</label>
        </div>

        <div class="content-body">
            <table class="dynamicTable colVis table">
                <!-- Table heading -->
                <thead>
                    <tr>
                        <th class="sorting_desc" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="descending" aria-label="Contract No.: activate to sort column ascending">Contract No.</th>
                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Customer1: activate to sort column ascending">Customer #1</th>
                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Customer2: activate to sort column ascending">Suggest to</th>
                        <th class="sorting_desc" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="descending" aria-label="Issued by: activate to sort column ascending">Salesperson</th>
                        <th class="center sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="End Date: activate to sort column ascending">End Date</th>
                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1"  aria-label="Action: activate to sort column ascending"></th>
                    </tr>
                </thead>
                <!-- // Table heading END -->

                <!-- Table body -->
                <tbody>
                    <!-- Table row -->
                    <?php foreach($list_friend as $afriend): ?>
                        <tr>
                            <td class="text-black"><?php echo $afriend->fgf_contract_code1; ?></td>
                            <td class="text-black"><?php echo $afriend->pers_fname." ".$afriend->pers_lname; ?></td>
                            <?php
                            $getCus = $this->tb_customer_personal_info->get_detail_by_id($afriend->fgf_cus_id2);
                            $nameCus2 = $getCus->pers_fname." ".$getCus->pers_lname;
                            ?>
                            <td class="text-black"><?php echo $nameCus2; ?></td>
                            <?php
                            $this->load->model('tb_user_personal_info');
                            $getUser = $this->tb_user_personal_info->get_detail_personal($afriend->fgf_sale);
                            $nameUser = $getUser->user_pers_fname." ".$getUser->user_pers_lname;
                            ?>
                            <td class="text-black"><?php if ($afriend->fgf_sale) echo $nameUser; ?></td>
                            <td class="text-black center">
                                <?php //echo date('d/m/Y',strtotime($afriend->fgf_last_date)); ?>
                                <span style="display: none"><?php echo date('Y/m/d',strtotime($afriend->fgf_last_date))?></span><?php echo date('d/m/Y',strtotime($afriend->fgf_last_date))?>
                            </td>
                            <td class="text-black left">
                                <div>
                                    <?php if (strpos($permission->pm_quotation,'2') !== FALSE) { ?>
                                    <a class="view-button" href="<?php echo BASE_URL; ?>/fgf/report/<?php echo $afriend->fgf_id ;?>" target="_blank"><u>View</u></a>
                                    <?php } ?>
                                    <?php
                                    if ($afriend->fgf_status =='Approver Confirm') {
                                        if (strpos($permission->pm_booking,'1') !== FALSE) {
                                            if ($afriend->fgf_approver == NULL) { 
                                                if ($afriend->fgf_last_date < $afriend->fgf_date){ ?>
                                                    <label><font color="#cb4040"> EXPIRED</font></label>
                                                <?php } else { ?>
                                                    <a  href="#modal_confirm" class="modal-trigger" onclick="CheckApprover('<?php echo $afriend->fgf_contract_code1; ?>','<?php echo $afriend->fgf_id; ?>','<?php echo $nameCus2; ?>','<?php echo $afriend->pers_fname.' '.$afriend->pers_lname; ?>')" ><u>Confirm</u></a>
                                                <?php
                                                }
                                            }
                                        }
                                    }

                                    if ($afriend->fgf_status =='Confirmed') { ?>
                                        <label><font color="#8baf46"> SUCCESSFUL</font></label>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- // Table row END -->
                </tbody>
                <!-- // Table body END -->
            </table>
        </div>
    </div>
</div>

<div id="modal_confirm" class="modal">
    <div class="modal-content">
        <div class="title-head">FGF Confirmation</div>
        <form class="form-horizontal" role="form" action='<?php echo BASE_URL; ?>/fgf/confirm_approver' method="post" name='form' id='form'>
            <div class="customer-information">
                <div class="row">
                    <div class="col m6 form-padding">
                        <div class="title">Old Customer</div>
                            <input type="hidden" name='id' id="id" />
                        <input type="hidden" id="conid" name='conid'>
                        <div class="query-result oldCustomerName"></div>
                        <div class="title">Contract Number</div>
                        <div class="query-result newCustomerId"></div>
                        <div class="input-field oldCustomerPromotion">
                            <input type="checkbox" class="filled-in" id="one1" name="one"/>
                            <label for="one1">Give promotion to this customer</label>
                        </div>
                    </div>
                    <div class="col m6 form-padding border-left">
                        <div class="title">New Customer</div>
                        <div class="query-result newCustomerName"></div>
                        <input type="hidden" id="conid" name='conid'>
                        <div class="row">
                            <div class="title col l3">Building: </div>
                            <div class="input-field col l4"  style="margin: -20px 0px 0px 0px;">
                                <select class="form-select " id="building-confirm" name="building-confirm" required>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="title col l4">Unit Number: </div>
                            <div class="input-field col l5"  style="margin: -20px 0px -5px 0px;">
                                <input type="text" id="unit-cus2" name='unit-cus2' required="required"  title="Please enter unit number">
                            </div>
                        </div>
                        <div class="input-field newCustomerPromotion">
                            <input type="checkbox" class="filled-in" id="two1" name="two"/>
                            <label for="two1" style="margin-top: -40px;">Give promotion to this customer</label>
                        </div>
                        <img src="../assets/images/image/green_arrow.png" class="middle-arrow">
                    </div>
                </div>
            </div>
            <div class="form-action">
                <div class="input-field left-content cb-confirm">
                    <input type="checkbox" class="filled-in" name='ckconfirm' id='ckconfirm1'/>
                    <label for="ckconfirm1">Check box to confitm if the fee is transferred to the account correctly</label>
                </div>
                <div class="right-content text-right">
                    <button type="submit" class="waves-effect waves-light btn btn-submit"><i class="fa fa-check-circle"></i>Confirm</button>
                    <a href="<?php echo BASE_DOMAIN; ?>fgf/view" class="waves-effect waves-light btn btn-discard"><i class="fa fa-times"></i>Close</a>
                </div>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>

