<script>
        $(window).load(function() {
            $('#loading').remove();
            $('#dataTable').css('visibility', 'visible');
        });
    </script>
<div class="email_installment_view">
	
		<div id="menu" class="hidden-print hidden-xs">
			<?php
			if ($permission->pm_payment<1) {
				alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');		
			}
			?>
		</div>
			 <?php
				//$conid = $_GET['cid'];		
			?>

	<div class="content">
        
        <!-- Modal SMS -->
        <div class="modal fade" id="modal-composemsg" data-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
<!--                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                        <h3 class="modal-title" id="lblmessage">Sent Email</h3>
                    </div> 

                    <form class="form-horizontal" role="form" action='<?php echo BASE_DOMAIN; ?>email/sendmessage' method="post" name='form2' id='form2'>

                        <input type="hidden" value="email" name="msgtype" id="msgtype"/>
                        <input type="hidden" value="" name="cusID" id="cusID"/>
                        <input type="hidden" value="" name="bkCode" id="bkCode"/>
                        <input type="hidden" value="" name="ctCode" id="ctCode"/>
                        <input type="hidden" value="installment" name="doctype"/>

                        <!-- Modal body -->
                        <div class="modal-body padding-none">
                            <div class="bg-gray innerAll border-bottom">
                                <div class="innerLR">
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Installment</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="imCode" name='imCode' readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Customer</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="customername" name='customername' readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Due Date</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="dueDate" name='dueDate' readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label" id="typeMessage">Email</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="contact" name='contact' size="60">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="to" class="col-sm-3 control-label">Message</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <textarea class="form-control" cols="50" rows="3" id="message" name='message'></textarea>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- // Modal body END -->

                        <div class="innerAll text-center border-top">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i> Sent</button>
                            <a class="btn btn-default" data-dismiss="modal"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- // Modal END -->


        
        <div class="content-header">
            <font color="#78ad13">View Email Installment</font> <label class="table-total">...</label>
        </div>
<form class="form-horizontal" role="form" action='<?php echo BASE_URL; ?>/email/preview' method="post" name='form2' id='form2'>                
               
                <input type="hidden" value="email" name="msgtype" id="msgtype">
                <input type="hidden" value="" name="doccode" id="doccode"> 
                <input type="hidden" value='installment' name="doctype" id="doctype" >
<div class="innerAll spacing-x2" id="loading">
    <div class="widget widget-inverse">
        <div class="widget-head">
            <h2 class="heading">loading...</h2>
        </div>
    </div>
</div>	
<div class="innerAll spacing-x2" style="visibility: hidden;"  id="dataTable">
	<!-- Widget -->
		<div class="widget-body padding-bottom-none">
			<!-- Table -->
			
<!--			<input type="submit" class="btn btn-primary" value="Send All">-->
			
			
<table class="dynamicTable colVis table">

	<!-- Table heading -->
	<thead class="bg-gray">
		<tr>
			<th>Contract</th>
			<th>Installment</th>
			<th>Customer</th>	
			<th>Amount</th>
			<th>Due date</th>
			
			<th>Action</th>
           
		</tr>
	</thead>
	<!-- // Table heading END -->
	
	<!-- Table body -->
	<tbody>
		<!-- Table row -->
		
			<?php
				foreach($list_installment as $get){
					?>
					<tr>
						<td ><?php echo $get->im_contract_code; ?> </td>
						<td ><?php echo $get->im_code; ?> </td>
						<td ><?php echo $get->pers_fname." ".$get->pers_lname; ?> </td>
						<td ><?php echo number_format($get->im_fee_define,0)?> </td>
						<td ><?php echo date('d/m/Y',strtotime($get->im_duedate)); ?> </td>
						
						<td class="center">
								
									
							
                        <a href="#modal-composemsg" class="modal-trigger" 
                           onclick="Sentmessage(
                                    '<?=$get->ct_booking_code?>',
                                    '<?=$get->im_cus_id?>',
                                    '<?=$get->pers_fname.' '.$get->pers_lname;?>',
                                    '<?=$get->pers_email?>',
                                    'กรุณามาชำระค่างวดที่ <?=$get->im_installment_time?> เลขที่สัญญา <?=$get->im_contract_code?> ภายในวันที่ <?=date('d/m/Y',strtotime($get->im_duedate))?> \n ขออภัย หากท่านชำระแล้ว',
                                    '<?=date('d/m/Y',strtotime($get->im_duedate))?>',
                                    '<?=$get->im_contract_code?>',
                                    '<?=$get->im_code?>')">
                            <?php //echo image_asset('image/email.gif',NULL,NULL); ?>Email
                            </a>
                            <?php
                            echo  empty($get->email_installment_code)?'waitting':'sent'; 
                           ?>
						</td>
                        
					</tr>
				 <?php
				}
                
			?>
			
		<!-- // Table row END -->
	</tbody>
	<!-- // Table body END -->
	
</table>
           
<!-- // Table END -->

            <br>
		</div>
	<!-- // Widget END -->
	

	
</div>
    </form>
		</div>
		<!-- // Content END -->
		
		<div class="clearfix"></div>
		
	</div>
<script>
    $(document).ready(function(){
        $('.modal-trigger').leanModal();
      });
    function Sentmessage(bookno,custno,customer,contact,msg,dueDate,ctCode,imCode)
    { 
        $( "#bkCode" ).val(bookno);  
        $( "#ctCode" ).val(ctCode);  
        $( "#imCode" ).val(imCode);  
        $( "#cusID" ).val(custno);  
        $( "#customername" ).val(customer);  
        $( "#contact" ).val(contact);  
        $( "#message" ).val(msg);
        $('#dueDate').val(dueDate);
    }
</script>