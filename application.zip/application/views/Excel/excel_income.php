<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="income_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>

    <table class="table table-striped colVis" border="1" style="font-size:10pt">
        <thead class="bg-gray" style="font-weight: bold;">
            <tr>
                <td rowspan="3" style="vertical-align:middle;">ลำดับ</td>
                <td rowspan="3" style="vertical-align:middle;">ชั้น</td>
                <td rowspan="3" style="vertical-align:middle;">ตึก</td>
                <td rowspan="3" style="vertical-align:middle;">เลขที่</td>
                <td rowspan="3" style="vertical-align:middle;">ชื่อลูกค้า</td>
                <td rowspan="3" style="vertical-align:middle;">พื้นที่ขาย(ตรม.)</td>
                <td rowspan="3" style="vertical-align:middle;">ราคาตามสัญญา</td>
                <td colspan="6">การชำระเงิน</td>
                <td colspan="3">รายรับทั้งหมด</td>
            </tr>
            <tr>
                <td colspan="2">เงินจอง</td>
                <td colspan="2">สัญญา</td>
                <td colspan="2">เงินงวดดาวน์</td>
                <td rowspan="2" style="vertical-align:middle;">จำนวนเงินจริงที่ได้รับ</td>
                <td rowspan="2" style="vertical-align:middle;">ราคารวมตามสัญญา (จอง+สัญญา+ดาวน์)</td>
                <td rowspan="2" style="vertical-align:middle;">คงเหลือ</td>
            </tr>
            <tr>
                <td>จำนวนเงิน</td>
                <td>วันที่ชำระ</td>
                <td>จำนวนเงิน</td>
                <td>วันที่ชำระ</td>
                <td>งวดที่</td>
                <td>จำนวนเงิน</td>
            </tr>
        </thead>
        <tbody>
            <?php echo $html; ?>
                <tr>
                    <td colspan="13">ทั้งหมด</td>
                    <td><?php echo number_format($totalRealTotalAmount,2); ?></td>
                    <td><?php echo number_format($totalTotalDownPayment,2); ?></td>
                    <td><?php echo number_format($totalBalance,2); ?></td>
                </tr>
        </tbody>
    </table>
</BODY>

</HTML>