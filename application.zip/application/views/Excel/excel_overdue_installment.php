<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="overdue_installment_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>

    <table class="table table-striped colVis" border="1" style="font-size:10pt">
        <thead class="bg-gray" style="font-weight: bold;">
            <tr>
                <td rowspan="2" style="vertical-align:middle;">ลำดับ</td>
                <td rowspan="2" style="vertical-align:middle;">ชั้น</td>
                <td rowspan="2" style="vertical-align:middle;">ตึก</td>
                <td rowspan="2" style="vertical-align:middle;">เลขที่</td>
                <td rowspan="2" style="vertical-align:middle;">ชื่อลูกค้า</td>
                <td rowspan="2" style="vertical-align:middle;">พื้นที่ขาย</td>
                <td rowspan="2" style="vertical-align:middle;">ราคาตามสัญญา</td>
                <td colspan="3">การกำหนดชำระเงินดาวน์</td>
                <td colspan="2">ค้างชำระเงินดาวน์</td>
            </tr>
            <tr>
                <td>จำนวนเงิน</td>
                <td>จำนวนงวดตามสํญญา</td>
                <td>วันครบกำหนดชำระตามสัญญา</td>
                <td>จำนวนเงิน</td>
                <td>จำนวนงวด</td>
            </tr>
        </thead>
        <tbody>
            <?php echo $html; ?>
                <tr>
                    <td colspan="7">ทั้งหมด</td>
                    <td>
                        <?php echo number_format($totalInstallmentAmount,2); ?>
                    </td>
                    <td>-</td>
                    <td>-</td>
                    <td><?php echo number_format($totalDueInstallmentAmount,2); ?></td>
                    <td>-</td>
                </tr>
        </tbody>
    </table>
</BODY>

</HTML>