<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="DiaryReportIncome_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>
    <table class="table table-hover" border="1" style="font-size:10pt">
        <thead>
            <tr>
                <td colspan="8" align="center" bgcolor="#8baf46">
                    <font color="black"><b>Dialy Report รายรับของวันที่ <?php echo $this->dateformat->thaiDate(date('Y-m-d', strtotime($beginDate))); ?></b></font>
                </td>
            </tr>
            <tr>
                <th>No.</th>
                <th>Customer</th>
                <th>Building</th>
                <th>Unit Number</th>
                <th>รายการ</th>
                <th>ยอดที่ชำระ</th>
                <th>ค่าธรรมเนียม</th>
                <th>ยอดที่รับจริง</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $html; ?>
        </tbody>
    </table>
    <label style="text-align: left;">* หมายเหตุ กรณีที่ติดบัตรเครดิต จะแสดงค่าธรรมเนียมด้วย</label>
</BODY>

</HTML>