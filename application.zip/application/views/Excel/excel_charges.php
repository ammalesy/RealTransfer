<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="charges_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>

    <table class="table table-striped colVis" border="1" style="font-size:10pt">
        <thead class="bg-gray" style="font-weight: bold;text-align:center">
            <tr>
                <th style="text-align:center">ลำดับ</th>
                <th style="text-align:center">ตึก</th>
                <th style="text-align:center">เลขที่</th>
                <th style="text-align:center">คำนำหน้า</th>
                <th style="text-align:center">ชื่อลูกค้า</th>
                <th style="text-align:center">รายรับก่อนหักธรรมเนียม</th>
                <th style="text-align:center">ค่าธรรมเนียมธนาคาร</th>
                <th style="text-align:center">รายรับจริง</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $html; ?>
        </tbody>
    </table>
</BODY>

</HTML>