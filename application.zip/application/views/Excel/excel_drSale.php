<?php
header("Content-Type: application/vnd.ms-excel");
header('Content-Disposition: attachment; filename="DiaryReportSale_'.date('Y-m-d', strtotime($beginDate)).'.xls"');#ชื่อไฟล์
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=utf-8" />

</HEAD><BODY>

                <table class="table table-hover" border="1" style="font-size:10pt">
                    <thead>
                        <tr>
                            <td colspan="2" align="center" bgcolor="#8baf46">
                                <font color="black"><b>โครงการ</b></font>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>มูลค่าโครงการ(ล้านบาท)</th>
                            <td><?php echo number_format($totalAskPrice,2); ?> บาท</td>
                        </tr>
                        <tr>
                            <th>จำนวนห้องในโครงการ(ห้องชุด)</th>
                            <td><?php echo $totalUnitNumber; ?> ห้อง</td>
                        </tr>
                        <tr>
                            <th>พื้นที่ขายทั้งหมด(ตารางเมตร)</th>
                            <td><?php echo number_format($totalAreaSqm); ?>ตารางเมตร</td>
                        </tr>
                    </tbody>
                </table>
    <br>
                <table class="table table-hover" border="1" style="font-size:10pt">
                    <thead>
                        <tr>
                            <td colspan="2" align="center" bgcolor="#8baf46">
                                <font color="black"><b>รายงานขาย</b></font>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2"><b>ประจำวันที่ <?php echo $this->dateformat->thaiDate(date('Y-m-d', strtotime($beginDate))); ?></b></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>เปอร์เซ็นต์(มูลค่าขายหักส่วนลด)</th>
                            <td>(ใส่ข้อมูลที่นี่)</td>
                        </tr>
                        <tr>
                            <th>จำนวนห้องที่ขาย(ห้อง)</th>
                            <td><?php echo $countSoldDay; ?> ห้อง</td>
                        </tr>
                        <tr>
                            <th>จำนวนพื้นที่ขาย(ตารางเมตร)</th>
                            <td><?php echo $totalAreaSold; ?> ตารางเมตร</td>
                        </tr>
                        <tr>
                            <th>มูลค่าขาย(บาท)</th>
                            <td><?php echo number_format($totalAmountSold,2); ?> บาท</td>
                        </tr>
                        <tr>
                            <th>มูลค่าขายหักส่วนลด(บาท)</th>
                            <td><?php echo number_format($totalAmountDis,2); ?> บาท</td>
                        </tr>
                    </tbody>
                </table>
    <br>
                <table class="table table-hover" border="1" style="font-size:10pt" >
                    <tr>
                        <th bgcolor="#8baf46"><font color="black">Detail/Date</font></th>
                        <th bgcolor="#8baf46"><font color="black">Call-in</font></th>
                        <th bgcolor="#8baf46"><font color="black">Walk-in</font></th>
                        <th bgcolor="#8baf46"><font color="black">Booking</font></th>
                        <th bgcolor="#8baf46"><font color="black">Cancel</font></th>
                    </tr>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($beginDate)); ?></td>
                        <td><?php echo $countWalk; ?></td>
                        <td><?php echo $countCall; ?></td>
                        <td><?php echo $countBooking; ?></td>
                        <td><?php echo $countCancel; ?></td>
                    </tr>
                </table>
                <br>
                <table class="table table-hover" border="1" style="font-size:10pt">
                    <thead>
                        <tr>
                            <th bgcolor="#8baf46"><font color="black">Total unit</font></th>
                            <th bgcolor="#8baf46"><font color="black"><?php echo $totalUnitNumber; ?></font></th>
                            <th bgcolor="#8baf46"><font color="black">Units</font></th>
                        </tr>
                        <tr>
                            <td><b>Total Sold</b></td>
                            <td><b><?php echo $countSold; ?></b></td>
                            <td><b>Units</b></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $htmlM; ?>
                        
                    </tbody>
                </table>
                <br>
                <table class="table table-hover" border="1" style="font-size:10pt">
                    <thead>
                        <tr>
                            <td colspan="2" bgcolor="#8baf46" align="center"><font color="black"><b>รายการคงเหลือ</b></font></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>จำนวนห้องคงเหลือ(ห้อง)</td>
                            <td><?php echo $countAvai; ?> ห้อง</td>
                        </tr>
                        <tr>
                            <td>จำนวนพื้นที่คงเหลือ(ตารางเมตร)</td>
                            <td><?php echo $totalAreaAvai; ?> ตารางเมตร</td>
                        </tr>
                        <tr>
                            <td>มูลค่าขาย(บาท)</td>
                            <td><?php echo number_format($totalAmountAvai,2); ?> บาท</td>
                        </tr>
                    </tbody>
                </table>
</BODY>

</HTML>