   
<script>
    $(window).load(function(){
        $('#loading').remove();
        $('#dataTable').css('visibility','visible');
    });
</script>
    
 
<style>
    a {color:rgb(19, 46, 232);}
</style>

		<script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>

<div class="installment-view">
	<div class="content">

		<div class="content-header">
            <font color="#78ad13">View Installment</font> <label class="table-total">...</label>
    </div>

		<div class="content-body">

			<table class="dynamicTable colVis table">
				<!-- Table heading -->
				<thead>
					<tr>
						<th>Contract Number</th>
						<th>Customer</th>
			            <th>Unit Number</th>
			            <th class="center">Contact Date</th>
			            <th>Booking Number</th>
						<th>Action</th>
					</tr>
				</thead>
				<!-- // Table heading END -->
				
				<!-- Table body -->
				<tbody>
					<!-- Table row -->
					<?php foreach($list_installment as $installment):
			          	if($installment->ct_paid === 'yes') 
			  					{?>
									<tr <?= ($installment->ct_active == 'cancelled')?'style="color:#BBB"':'' ?>>
										<td><?php echo $installment->ct_code.(( $installment->ct_active == 'cancelled' )?'<br/>(Cancelled)':(($installment->ct_active === 'transferred')?'<br/>(<a onmouseover="Tip(\'Old Customer : <b>'.$installment->old_name.'</b><br/>Mobile : <b>'.$installment->old_mobile.'</b><br> Tel : <b>'.$installment->old_tel.'</b><br> Email : <b>'.$installment->old_email.'</b>\', SHADOW, true, SHADOWCOLOR, \'#cccccc\',BORDERCOLOR,\'#cccccc\')" onmouseout="UnTip()">Transferred</a>)':'')) ?></td>
										<td >
									 		<a href="#" onmouseover="Tip('Mobile :&nbsp;<b> <?php echo $installment->pers_mobile."</b><br> Tel :  ".
			                        $installment->pers_tel.
			                        '<br> Email :'.$installment->pers_email; ?>', SHADOW, true, SHADOWCOLOR, '#cccccc',BORDERCOLOR,'#cccccc')" 
			                           onmouseout="UnTip()"
			                                onclick="JavaScript:window.open('customer/editing/<?php echo $installment->cus_id; ?>');">    
			                                <?php echo $installment->pers_fname." ".$installment->pers_lname; ?> </a>
			               </td>
									<?php
										$building_name 	= $installment->building->building_name;
										$un_name 	= 	$installment->unit_number->un_name;
										$floor_name = $installment->unit_number->fl_name;
									?>
										<td ><?php echo $building_name; ?>&nbsp;<?php echo $un_name; ?> </td>
										<td class='center'><span style="display: none"><?php echo  date('Y/m/d',strtotime($installment->ct_date)); ?></span><?php echo  date('d/m/Y',strtotime($installment->ct_date)); ?> </td>
			              <td ><?php echo $installment->bk_booking_code; ?> </td>
										<td class="left">
											<div class="btn-group btn-group-xs ">
											<?php
								            if (strpos($permission->pm_payment,'1') !== false) {
												if ( $installment->ct_active !== 'cancel' ) {
											?>
                                                <a href="<?php echo BASE_DOMAIN; ?>installment/listInstallment/<?php echo $installment->ct_code; ?>"  ><font color="#0e7ccb">View</font></a>
                                                <!-- <a href="<?php echo BASE_DOMAIN; ?>installment/listInstallment/<?php echo $installment->ct_code; ?>" class="btn btn-default" ><i class="icon-play-fill"></i></a> -->
											<?php
												}
								            }
											?>
											<!--<a href="assign_del.php?act=del&uid=<?php echo $get['assign_id'];?>" onclick="return confirm('Cancel Assign User ?')" class="btn btn-danger"><i class="fa fa-times"></i></a>-->
				
											</div>
										</td>
									</tr>
			            <?php }endforeach; ?>
						
					<!-- // Table row END -->
				</tbody>
				<!-- // Table body END -->
				
			</table>
<!-- // Table END -->
<br/>

	<!-- // Widget END -->
	
</div>
		</div>
		<!-- // Content END -->
</div>
