<!-- <div class="modal fade" id="modal-composetr" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div align="center" id="lblconfirm" style="font-size:14px;padding-top:5px;padding-bottom:5px;font-weight:bolder;color:#6B8E23">Confirm Transfer Ownership</div>
            <form class="form-horizontal" role="form" action='<?php echo BASE_DOMAIN; ?>transfers/Adding/<?php echo $conid; ?>' method="post" name='form' id='form'>
                <div class="modal-body padding-none">
                    <div class="bg-gray innerAll border-bottom">
                        <div class="innerLR">
                            <input type="hidden" name='id' id="id" />
                            <div class="form-group">
                                <label for="to" class="col-sm-4 control-label">Contract Code</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo $conid; ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-4 control-label">Customer Name</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo $aInstallment->pers_fname." ".$aInstallment->pers_lname; ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-4 control-label">Transfer Ownership (THB)</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" value="<?php echo number_format($installment_detail->qt_unit_price - $installment_detail->qt_total_down_payment,2); ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div style='padding-left:10px'>
                        <input type='checkbox' class="checkbox-inline" style="width:20px; height:20px;" name='ckconfirm' id='ckconfirm' required="required" title="Please confirm check box">
                        <label for=ckconfirm> &nbsp;Check box to confirm if Approver confirms</label>
                    </div>

                </div>
                <div class="innerAll text-center border-top">
                    <input type="submit" class="btn btn-primary" value="Confirm">
                    <a class="btn btn-default" data-dismiss="modal"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                </div>
            </form>

        </div>
    </div>
</div> -->
<div class="modal fade" id="modal-composemsg">
    <div class="modal-dialog">
        <div class="modal-content">
            <div align="center" id="lblmessage" style="font-size:14px;padding-top:5px;padding-bottom:5px;font-weight:bolder"></div>

            <form class="form-horizontal" role="form" action='<?php echo BASE_DOMAIN; ?>sms/sendmessage' method="post" name='form2' id='form2'>

                <input type="hidden" value="" name="msgtype" id="msgtype">
                <input type="hidden" value="" name="custno" id="custno">


                <!-- Modal body -->
                <div class="modal-body padding-none">


                    <div class="bg-gray innerAll border-bottom">
                        <div class="innerLR">

                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Customer:</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="customername" name='customername' disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Receipt number:</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="docno" name='docno'>

                                    </div>
                                </div>
                            </div>



                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Installment Fee:</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="installmentfee" name='installmentfee' disabled>

                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Payment:</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="paymentamt" name='paymentamt' disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Email/Mobile:</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="contact" name='contact' size="60">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">default Message:</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="defaultmsg" name='defaultmsg' size="60">

                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>



                </div>
                <!-- // Modal body END -->

                <div class="innerAll text-center border-top">
                    <a href="" class="btn btn-default"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                    <input type="submit" class="btn btn-primary" value="Sent">
                </div>
            </form>

        </div>
    </div>
</div>





<div class="modal receipt-view-installment" id="modal-compose" data-backdrop="static">
                <div class="modal-content">
                    <div class="modal-head">
                        <div id="lblconfirm">
                            <div class="title-payment">Payment Confirmation</div>
                            <div for="to" class="rcvcode subtitle-payment"></div>
                        </div>
                    </div>
                    <form class="form-horizontal" role="form" action='<?php echo BASE_DOMAIN; ?>receipt/confirm_tranfer/<?=$conid?>' method="post" name='form' id='form'>
                        <div class="modal-customer">
                            <div class="title-customer" for="to">Customer Name</div>
                            <div class="name-customer" id='rcvcustomer'></div>
                        </div>
                        <div class="row modal-form">
                            <div class="col s6">
                                <div class="title-form form-left">Receipt Code</div>
                                <div class="detail-form form-left rcvcode">&nbsp;</div>
                            </div>
                            <div class="col s6">
                                <div class="title-form">Type</div>
                                <div class="detail-form rcvtype">&nbsp;</div>
                            </div>
                            <div class="col s6">
                                <div class="title-form form-left">Building</div>
                                <div class='detail-form form-left rcvbuilding'>&nbsp;</div>
                            </div>
                            <div class="col s6">
                                <div class="title-form">Unit Number</div>
                                <div class='detail-form rcvunit'>&nbsp;</div>
                            </div>
                        </div>
                        <div class="modal-foot">
                            <div class="input-field remark">
                                <textarea name='reason' id='reason' class="materialize-textarea"></textarea>
                                <label for="reason">Write your remark here</label>
                            </div>
                            <div class="row modal-checkbox">
                                <div class="col s7">
                                    <input type="checkbox" class="filled-in" id="ckconfirm" required="required" title="Please confirm check box"/>
                                    <label for="ckconfirm">Check box to confirm <br>if the fee is transferred to the account correctly</label>
                                </div>
                                <div class="col s5 modal-submit">
                                    <button class="btn waves-effect waves-light btn-submit" type="submit">Submit
                                        <i class="material-icons left">check_box</i>
                                    </button>
                                    <a class="waves-effect waves-light btn modal-close btn-cancel" ><i class="material-icons left">cancel</i>Cancel</a>
                                </div>
                            </div>
                        </div>
                        <input type='hidden' value="" id='rcvid' name='rcvid'>
                    </form>

                </div>
        </div>




<!--
<div class="modal fade" id="modal-compose" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div align="center" id="lblconfirm" style="font-size:14px;padding-top:5px;padding-bottom:5px;font-weight:bolder;color:#6B8E23">Confirm Transfer Bank</div>

            <form class="form-horizontal" role="form" action='<?php echo BASE_DOMAIN; ?>receipt/confirm_tranfer/<?=$conid?>' method="post" name='form' id='form'>

                <input type='hidden' value="" id='rcvid' name='rcvid'>

                
                <div class="modal-body padding-none">


                    <div class="bg-gray innerAll border-bottom">
                        <div class="innerLR">
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Receipt Code</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="rcvcode" name='rcvcode' disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Type</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="rcvtype" name='rcvtype' disabled>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Customer</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name='rcvcustomer' id='rcvcustomer' disabled>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Buiding</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name='rcvbuilding' id='rcvbuilding' disabled>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="to" class="col-sm-3 control-label">Unit Number</label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name='rcvunit' id='rcvunit' disabled>
                                    </div>
                                </div>
                            </div>


                            <div class="clearfix"></div>
                        </div>
                    </div>

                    <div class="innerAll inner-6x">
                        <textarea class="notebook border-none form-control padding-none" rows="4" cols='75' placeholder="Write your remark here" name='reason' id='reason'></textarea>
                        <div class="clearfix"></div>
                    </div>

                    <div style='padding-left:10px'>
                        <label>
                            <input type='checkbox' name='ckconfirm' class="checkbox-inline" style="width:20px; height:20px;" id='ckconfirm' required="required" title="Please confirm check box"> Check box to confirm if the fee is transferred to the account correctly</label>
                    </div>


                </div>

                <div class="innerAll text-center border-top">
                    <input type="submit" class="btn btn-primary" value="Confirm">
                    <a class="btn btn-default" data-dismiss="modal"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                </div>
            </form>

        </div>
    </div>
</div>
-->

<div id="modal_transfer" class="modal">
    <div class="modal-content">
        <div class="title-head">Confirm Transfer Ownership</div>
        <form class="form-horizontal no-margin" role="form" action='<?php echo BASE_DOMAIN; ?>transfers/Adding/<?php echo $conid; ?>' method="post" name='form' id='form'>
            <div class="customer-infomation">
                <div class="name-title title">Customer Name#1</div>
                <div class="name query-result nameTransferModal">
                    <?php echo $aInstallment->pers_fname." ".$aInstallment->pers_lname; ?>
                </div>
                <div class="left-content margin-top-20">
                    <div class="title">Contract</div>
                    <div class="query-result">
                        <?php echo $conid; ?>
                    </div>
                </div>
                <div class="left-content margin-top-20">
                    <div class="title">Transfer Ownership</div>
                    <div class="query-result-green">
                        <?php echo number_format($installment_detail->qt_unit_price - $installment_detail->qt_total_down_payment,2); ?> THB</div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="submit-action">
                <div class="input-field left-content cb-confirm">
                    <input type="checkbox" class="filled-in" name='ckconfirm' id='ckconfirm1' required />
                    <label for="ckconfirm1">Check box to confirm</label>
                </div>
                <div class="right-content text-right">
                    <button type="submit" class="waves-effect waves-light btn btn-submit"><i class="fa fa-check-circle"></i>Confirm</button>
                    <buutton class="waves-effect waves-light btn btn-discard"><i class="fa fa-times"></i>Close</button>
                </div>
                <div class="clearfix"></div>
            </div>
        </form>
    </div>
</div>
<div class="installment-list-view">
    <div class="content">
        <div class="content-header">
          <font color="#78ad13">Installment</font>
        </div>
        <div class="row">
          <div class="customer-details col l8">
            <div class="row">
              <div class="col l12">
                <div class="col l4"><span class="title">Customer Name</span><br><span class="detail-name"><?php echo $aInstallment->pers_fname." ".$aInstallment->pers_lname; ?></span></div>
                <div class="col l3">
                  <div class="row">
                    <div class="col l12"><span class="title">Telephone</span><br><span class="detail"><?php if(!empty($aInstallment->pers_mobile)) echo $aInstallment->pers_mobile; ?></span></div>
                    <div class="col l12"><span class="title">Contract No.</span><br><span class="detail"><?php echo $conid; ?></span></div>
                  </div>
                </div>
                <div class="col l5">
                  <div class="row">
                    <div class="col l12"><span class="title">Email</span><br><span class="detail"><?php if(!empty($aInstallment->pers_email)) echo $aInstallment->pers_email; else echo '-'; ?></span></div>
                    <div class="col l6"><span class="title">Building</span><br><span class="detail"><?php echo $building; ?></span></div>
                    <div class="col l6"><span class="title">Unit No.</span><br><span class="detail"><?php echo $unitname; ?></span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="installment-details col l4">
            <div class="row">
              <div class="col l12">
                <span class="title">Installment</span>
                <?php
                  foreach($list_installment as $payment) {
                    $maxInstallment++;
                    if ($payment->im_paid === 'yes') {
                      $currentInstallment++;
                    }
                  }
                ?>
                <span class="detail-installment"><?php if (!empty($currentInstallment)) echo $currentInstallment; else echo '0'; ?></span>
                <span class="detail-full-installment">/<?php echo $maxInstallment; ?></span>
              </div>
              <div class="col l12">
                <?php
                  if($getTransOwner->tr_status == null) {
                      if (strpos($permission->pm_transfer,'3') !== false) {
                        echo ('<a href="#modal_transfer" class="'.$disabled.' '.(!empty($disabled)?'':'modal-trigger waves-effect waves-light').' button-transfer  btn"><i class="material-icons left">check_circle</i>Make transfer ownership</a>');
                      }
                  } else if ($getTransOwner->tr_paid == 'no') {
                      if (strpos($permission->pm_transfer,'4') !== false) {
                        echo('<a href="'.BASE_DOMAIN.'transfers/maketempreceipt/'.$getTransOwner->tr_code.'/installmentList" class="button-transfer waves-effect waves-light btn"><i class="material-icons left">check_circle</i>Make temp receipt <br/> for transfer ownership</a>');
                      }
                  } else if ($getTransOwner->tr_paid == 'yes') {
                      if (strpos($permission->pm_transfer,'5') !== false) {
                          $getTempReceipt = $this->tb_receipt_temporary->get_by_transfer_ownership($getTransOwner->tr_code);
                          echo('<a target="_blank" href="'.BASE_DOMAIN.'receipt/report/th/'.$getTempReceipt->rc_code.'" class="button-transfer waves-effect waves-light btn"><i class="material-icons left">check_circle</i>View temp receipt <br/> for transfer ownership</a>');
                      }
                  }
                ?>
              </div>
            </div>
          </div>
        </div>

        <div class="content-body">
            <div class="table">
                <table class="dcTable colVis table">
                    <thead>
                        <tr>
                            <th>Installment name</th>
                            <th>Installment</th>
                            <th>Amount</th>
                            <th>Remaining</th>
                            <th>Due date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $num=0;
                        foreach($list_installment as $payment): ?>
                            <?php if(!($ctStatus != 'cancelled' && $payment->im_status == 'cancelled')): ?>
                                <tr>
                                    <td>
                                        Installment Fee
                                        <?php echo $payment->im_installment_time; ?>
                                    </td>
                                    <td>
                                        <?php echo $payment->im_code; ?>
                                    </td>
                                    <td align="right">
                                        <?php echo number_format($payment->im_amount, 2);?>
                                    </td>
                                    <td align="right">
                                        <?php echo number_format($payment->im_fee_define, 2);?>
                                    </td>
                                    <td>
                                        <?php echo  date('d/m/Y',strtotime($payment->im_duedate)); ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-xs ">
                                            <?php
                                            if($payment->im_status=='cancelled'){
                                                echo 'Cancelled';
                                            }else if ($payment->im_paid === 'no') {
                                                if(strpos($permission->pm_receipt,'3') !== false) {
                                        ?>
                                                <a class="button-make-temp-receipt" href="<?php echo BASE_DOMAIN; ?>installment/adding/<?php echo $payment->im_id?>"><u>Make Temp receipt</u></a>
                                                <?php   }
											}else{
                                                
                                          }
                                           if ($payment->im_fee_define != $payment->im_amount){
												if (strpos($permission->pm_receipt,'2') !== false) {
                                                $getReceipt = $this->tb_receipt_temporary->get_by_installment_id($payment->im_id);
                                                $getTempReceiptReport = $this->tb_receipt_temporary->get_temp_receipt_by_rc_installment_code($payment->im_code);
													?>
<!--                                                    <a class="brown-text" href="<?php echo BASE_DOMAIN; ?>receipt/report/th/<?php echo $getReceipt->rc_code; ?>" target="_blank"><u>Tempreceipt</u></a>-->
                                                   <a class="dropdown-button" href="#!" data-beloworigin="true" data-activates="temp_receipt_list<?php echo $num; ?>">Tempreceipt</a>
                                                        <ul id="temp_receipt_list<?php echo $num; ?>" class="dropdown-content collection">
                                                        <?php 
                                                                $no = 0;
//                                                                print_r($getTempReceiptReport);
                                                                foreach($getTempReceiptReport as $_getReceipt){
                                                                    $no = $no + 1;
                                                            ?>
                                                           <li><a href="<?php echo BASE_DOMAIN; ?>receipt/report/th/<?php echo $_getReceipt->rc_code; ?>"  target="_blank">Tempreceipt<?php echo $no?></a></li>
                                                            <?php
                                                                }
                                                            ?>
                                                          </ul>
                                                    <?php
												}
                                               if(strpos($permission->pm_receipt,'1') !== false) {
                                                    if($payment->rc_status !== 'off') {
                                                            $getTempReceiptReport = $this->tb_receipt_temporary->get_temp_receipt_by_rc_installment_code($payment->im_code);
													?>
                                                   <a class="dropdown-button" href="#!" data-beloworigin="true" data-activates="make_receipt<?php echo $num; ?>"><font color="#FF7F00">MakeReceipt</font></a>
                                                        <ul id="make_receipt<?php echo $num; ?>" class="dropdown-content collection">
                                                        <?php 
                                                                $no = 0;
                                                                foreach($getTempReceiptReport as $_getReceipt){
                                                                    $no = $no + 1;
                                                            ?>
                                                           <li><a class="blue-text darken-4" href="<?php echo BASE_DOMAIN; ?>receipt/adding/pmid/<?= $_getReceipt->rc_id;?>/4/<?=$conid?>"><font color="#FF7F00">MakeReceipt<?php echo $no?></font></a></li>
                                                            <?php
                                                                }
                                                            ?>
                                                          </ul>
                                                    <?php
                                                } else {
                                                        $getReceiptOf = $this->tb_receipt_offical->get_full_detail_by_temp($payment->rc_code);
                                                                        ?>
                                                                    <a class="orange-text" href="<?php echo BASE_DOMAIN; ?>receipt/report/th/<?php echo $getReceiptOf->rc_code;?>" target="_blank"><u>Receipt</u></a>
                                                                    <?php }
                                                }
                                           }
                                            $colour =  $payment->im_status == 'on' ? "color:green":"color:grey";
										?>
                                        </div>
                                        <!-- <?php
		                            if ($payment->pm_status !=='cancel')
		                            {
		                            ?>
		                            	<?php echo image_asset('image/email.gif',NULL,NULL); ?>
		                            	<?php echo image_asset('image/sms.gif',NULL,NULL); ?>
		                            <?php
		                            }
		                            ?> -->
                                        <font size='2'><span style='padding-left:5px;font-weight:normal;<?php echo $colour; ?>'><?php echo $payment->in_status=='cancel'?'canceled':''?></span></font>

                                    </td>
                                </tr>
                                <?php endif; ?>
                                    <?php $num++; endforeach; ?>
                                        
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<script>
    function CheckTranferMoney(rcvcode, rcvtype, customer, building, unit) {
        $('#ckconfirm').prop('checked', false)
        $('.rcvcode').text(rcvcode);
        $('.rcvtype').text(rcvtype);
        $('#rcvcustomer').text(customer);
        $('.rcvbuilding').text(building);
        $('.rcvunit').text(unit);
        $('#rcvid').val(rcvcode);
    }
    $(function() {
        $('.modal-trigger').leanModal();
        $('.btn-discard').on('click', function(event) {
            $('#modal_transfer').closeModal();
        });

        
        $("#form1").submit(function(event) {
            if ($('#ckconfirm').is(':checked')) $("#target").submit();
            else {
                alert('Check box to confirm if the fee is transferred to the account correctly');
                event.preventDefault();

            }

        });
        $("#form2").submit(function(event) {

            if ($("#docno").val() == '') {
                //$( "#docno" ).focus();
                event.preventDefault();
            } else if ($("#customername").val() == '') {
                //$( "#docno" ).focus();
                event.preventDefault();
            } else if ($("#contact").val() == '') {
                //$( "#docno" ).focus();
                event.preventDefault();
            } else if ($("#installmentfee").val == '') {
                //$( "#docno" ).focus();
                event.preventDefault();
            } else $("#target").submit();

        });

        function Sentmessage(msgtype, bookno, custno, customer, contact, duedate, installmentno, amt) {
            $("#msgtype").val(msgtype);
            $("#docno").val(bookno);
            $("#custno").val(custno);
            $("#customername").val(customer);
            $("#contact").val(contact);
            $("#defaultmsg").val(duedate);

            $("#installmentfee").val(installmentno);
            $("#paymentamt").val(amt);

            $("#lblmessage").text(msgtype == 'email' ? 'Sent Email' : 'Sent SMS Message');
        }
    });
    (function($) {
		$(function() {

$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      hover: true, // Activate on hover
      belowOrigin: true, // Displays dropdown below the button
      alignment: 'right' // Displays dropdown with edge aligned to the left of button
    }
  );

		}); // End Document Ready
})(jQuery); // End of jQuery name space
</script>
