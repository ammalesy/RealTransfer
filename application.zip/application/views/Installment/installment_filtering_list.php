 
<div id="content">
        
        <!-- Modal SMS -->
	<div class="modal fade" id="modal-composemsg">
		
		<div class="modal-dialog">
			<div class="modal-content">
	            <div align="center" id="lblmessage" style="font-size:14px;padding-top:5px;padding-bottom:5px;font-weight:bolder"></div>
				
				<form class="form-horizontal" role="form" action='<?php echo BASE_URL; ?>/sms/sendmessage' method="post" name='form2' id='form2'>                
	               
	                <input type="hidden" value="" name="msgtype" id="msgtype">
	                <input type="hidden" value="" name="custno" id="custno">               
				<!-- Modal body -->
				<div class="modal-body padding-none">
					
	                
						<div class="bg-gray innerAll border-bottom">
							<div class="innerLR">
								
	                            <div class="form-group">
									<label for="to" class="col-sm-3 control-label">Contract number:</label>
									<div class="col-sm-8">
										<div class="input-group">
											<input type="text" class="form-control" id="docno" name='docno' >
											
										</div>
									</div>
								</div>
								<div class="form-group">
									<label for="to" class="col-sm-3 control-label">Customer:</label>
									<div class="col-sm-8">
										<div class="input-group">
											<input type="text" class="form-control" id="customername" name='customername' disabled>
										</div>
									</div>
								</div>
	                            <div class="form-group">
									<label for="to" class="col-sm-3 control-label">Installment Fee:</label>
									<div class="col-sm-8">
										<div class="input-group">
											<input type="text" class="form-control" id="paymentamt" name='paymentamt' >
										</div>
									</div>
								</div>
	                            <div class="form-group">
									<label for="to" class="col-sm-3 control-label">Email/Mobile:</label>
									<div class="col-sm-8">
										<div class="input-group">
											<input type="text" class="form-control" id="contact" name='contact'  size="60">
										</div>
									</div>
								</div>
	                            <div class="form-group">
									<label for="to" class="col-sm-3 control-label">default Message:</label>
									<div class="col-sm-8">
										<div class="input-group">
											<input type="text" class="form-control" id="defaultmsg" name='defaultmsg' size="60">
											
										</div>
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>

						

				</div>
				<!-- // Modal body END -->

				<div class="innerAll text-center border-top">
					<a href="" class="btn btn-default"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
					<input type="submit" class="btn btn-primary" value="Sent">
				</div>
		       </form>
	            
			</div>
		</div>
		
	</div>
	<!-- // Modal END -->
		
	<div class="innerAll spacing-x2">

		<!-- Widget -->
		<div class="widget widget-inverse">
			<div class="widget-head">
				<h4 class="heading"> Filtering Installment Over Due Date
				<!-- <?php
					echo $payment->pers_fname." ".$payment->pers_fname;
				?> -->
				</h4>
			</div>
			<div class="widget-body padding-bottom-none">
				<!-- Table -->
				<a href="<?php echo BASE_URL; ?>/installment/view">
				<button class="btn btn-inverse"><i class="icon-book-shelf"></i> &nbsp;All </button>
				</a>
				<a href="<?php echo BASE_URL; ?>/installment/filtering_list">
				<button class="btn btn-inverse"><i class="icon-book-shelf"></i>&nbsp;Over Due Date </button>
				</a>
				
				<br/>
				<br/>
	<table class="dynamicTable colVis table">

		<!-- Table heading -->
		<thead class="bg-gray">
			<tr>
				<th>Contract No.</th>
				<th>Payment name</th>
				<th>Installment Number</th>
				<th>Customer</th>	
				<th>Amount</th>
				<th>Due date</th>
				<th>Receipt date</th>
				<th>Action</th>
			</tr>
		</thead>
		<!-- // Table heading END -->
		
		<!-- Table body -->
		<tbody>
			<!-- Table row -->
			
				<?php foreach($list_installment as $installment):
						?>
						<tr>
							<td ><?php echo $installment->im_contract_code; ?> </td>
							<td ><?php echo $installment->in_installment_name.' '.$installment->im_installment_time; ?> </td>
							<td ><?php echo $installment->in_receipt_id; ?> </td>
							<td ><?php echo $installment->pers_fname." ".$installment->pers_lname; ?> </td>
							<td ><?php echo $installment->in_fee_define; ?> </td>
							<td ><?php echo $installment->im_duedate; ?> </td>
							<td ><?php echo $installment->in_received_date; ?> </td>
							<td class="center">
									
										<div class="btn-group btn-group-xs ">
											<?php
												if ($installment->in_receipt_id=='Waiting') {
											
													if (strpos($permission->in_receipt,'1') !== false) {
														
														$flag = '/3';	
														if ($installment->in_installment_name=='Contract Fee') {
															$flag = '/2';	
														}
														?>
														
														
														<a href="<?php echo BASE_DOMAIN; ?>receipt/adding/pmid/<?php echo $installment->in_id.$flag; ?>" class="btn btn-inverse" ><i class="icon-play-fill"></i></a>
														<?php
													}
												}else{
												
													if (strpos($permission->pm_receipt,'2') !== false) {
														?>
														<a href="<?php echo BASE_DOMAIN; ?>receipt/report/th/<?php echo $installment->in_receipt_id; ?>" class="btn btn-inverse"  target="_blank"><i class="icon-cooking-pan"></i></a>
														<?php
													}
											
												}
											?>
										</div>
								
							</td>
						</tr>
					<?php endforeach; ?>
				
			<!-- // Table row END -->
		</tbody>
		<!-- // Table body END -->
		
	</table>
	<!-- // Table END -->


			</div>
		</div>
		<!-- // Widget END -->
		

		
	</div>
</div>
		<!-- // Content END -->


	<!-- Global -->
	
<script>
function Sentmessage(msgtype,bookno,custno,customer,contact,duedate,bkfee)
    {
      
      
       $( "#docno" ).val(bookno);  
       $( "#custno" ).val(custno);  
       $( "#customername" ).val(customer);  
       $( "#contact" ).val(contact);  
       $( "#defaultmsg" ).val(duedate);  
       $( "#lblmessage" ).text(msgtype=='email'?'Sent Email':'Sent SMS Message');  
       $( "#paymentamt" ).val(bkfee);   
      
    }
</script>