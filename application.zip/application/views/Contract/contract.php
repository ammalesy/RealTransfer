<div id="menu" class="hidden-print hidden-xs">
    <?php
    if ($permission->pm_contract<1) {
        alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen'); 
    }
    ?>
</div>
<div class="contract-view">
    <div class="content">
        <div class="content-header">
            <font color="#78ad13">View Contract</font> <label class="table-total">...</label>
        </div>
        <div class="content-body">
            <table class="dynamicTable colVis table">
                <thead>
                    <tr>
                        <th style="display: none;"></th>
                        <th style="display: none;"></th>
                        <th>Contract</th>
                        <th>Customer</th>
                        <th>Unit Number</th>
                        <th>Contact Date</th>
                        <th>Booking</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach($list_booking as $get): 
                        $cancelled = '';
                        if ( trim($get->ct_active) === 'cancelled' ) { $cancelled = 'style="color:#BBB"'; }
                    ?>
                        <tr <?=$cancelled?>>
                            <td style="display: none;"><?= $get->ct_code ?></td>
                            <td style="display: none;"><?= $get->mapping ?></td>
                            <td>
                                <?= (empty($get->mapping)?$get->ct_code:'<a href="#" onmouseover="Tip(\'Contract :&nbsp;<b>'.$get->ct_code.'</b>\', SHADOW, true, SHADOWCOLOR, \'#cccccc\',BORDERCOLOR,\'#cccccc\')" onmouseout="UnTip()">'.$get->mapping.'</a>') . (($get->ct_active ==='cancelled')?'<br/>(Cancelled)':'') . (($get->ct_active === 'transferred')?'<br/>(<a onmouseover="Tip(\'Old Customer : <b>'.$get->old_name.'</b><br/>Mobile : <b>'.$get->old_mobile.'</b><br> Tel : <b>'.$get->old_tel.'</b><br> Email : <b>'.$get->old_email.'</b>\', SHADOW, true, SHADOWCOLOR, \'#cccccc\',BORDERCOLOR,\'#cccccc\')" onmouseout="UnTip()">Transferred</a>)':''); ?>
                            </td>
                            <td>
                                <a class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Mobile :&nbsp; <?php echo $get->pers_mobile. " | Tel : ".$get->pers_tel. " | Email : ".$get->pers_email;  ?>" href="#" ><?php echo $get->pers_name; ?></a>
                            </td>
                            <td>
                                <?php echo $get->building_name; ?>&nbsp;<?php echo $get->un_name; ?>
                            </td>
                            <td class="left">
                                <span style="display: none"><?php echo date('Y/m/d',strtotime($get->ct_date)); ?></span><?php echo date('d/m/Y',strtotime($get->ct_date)); ?>
                            </td>
                            <td class="left">
                                <?php echo $get->bk_booking_code; ?>
                            </td>
                            <td class="left">
                                <div class="btn-group btn-group-xs ">
                                    <?php
                                    if ($get->ct_type == 'company') {
                                    	$route_th = 'niti';
                                    	$route_en = 'niti';
                                    } else {
                                    	$route_th = 'th';
                                    	$route_en = 'en';
                                    }
                                    ?>
                                    
                                    <?php
                                    if (strpos($permission->pm_contract,'2') !== false) {
                                    ?>    
                                    View: 
                                    <a href="<?= BASE_DOMAIN.'contract/report/'.$route_th.'/'.$get->ct_code; ?>" target="_blank"><font color="#0e7ccb">TH</font></a> / 
                                    <a href="<?=BASE_DOMAIN.'contract/report/'.$route_en.'/'.$get->ct_code; ?>" target="_blank"><font color="#0e7ccb">EN</font></a>&nbsp;&nbsp;&nbsp;
                                    <?php 
                                    }
                                    ?>
                                    
                                    <?php 
                                    if($get->ct_paid === 'no') { 
                                        if (strpos($permission->pm_receipt,'3') !== false && $get->ct_active !== 'cancelled') { ?>
                                            <a href="<?php echo BASE_DOMAIN; ?>contract/maketempreceipt/<?php echo $get->ct_code; ?>"><font color="#78ad13">Make Temp Receipt</font></a>&nbsp;&nbsp;&nbsp;
                                        <?php 
                                        }
                                    } else { 
                                        if (strpos($permission->pm_receipt,'2') !== false) {
                                            $getReceipt = $this->tb_receipt_temporary->get_by_contract($get->ct_code); 
                                    ?>
                                            <a href="<?php echo BASE_DOMAIN; ?>receipt/report/th/<?php echo $getReceipt->rc_code; ?>" target="_blank"><font color="#FF7F00">View Temp Receipt</font></a>
                                    <?php 
                                        }
                                    } ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- // Table row END -->
                </tbody>
                <!-- // Table body END -->
            </table>
            <!-- // Table END -->
        </div>
    </div>
</div>
<!-- // Content END -->
<script>
  $(document).ready(function(){
    $('.tooltipped').tooltip({delay: 50});
  });
</script>