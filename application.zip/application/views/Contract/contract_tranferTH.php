<?php 
$html = '
<style>
    span.under{
        border-bottom-width:1px; 
        border-bottom-style:solid; 
    }
    table.oneLine {
        border: 1px solid black;
        border-collapse: collapse;
    }
    td.under {
        border-bottom-width:1px; 
        border-bottom-style:solid; 
    }
    body {
        font-size:16px;
    }
    table { 
        border-spacing: 0px;
        border-collapse: collapse;
    }
    td.no-line {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #FFF #FFF #FFF;
    }
    td.line-right {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #000 #FFF #FFF;
    }
    td.right-under {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #000 #000 #FFF;
    }
    td.line-under {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #FFF #000 #FFF;
    }
</style>
<body>
    <table class="oneLine" width="100%"><tr><td align="center">
    แบบคำขอโอนสิทธิ หน้าที่ หนี้ และความรับผิด ตามสัญญาจะซื้อจะขายห้องชุด
    </tr></td></table>';
    $tranferDate = explode(' ',$this->dateformat->thaiDate(date('Y-m-d',strtotime($detail->tf_timestamp))));
$html .= '
    <table width="100%"><tr><td align="right">
    วันที่<span class="under"> '.$tranferDate[0].' </span>เดือน<span class="under"> '.$tranferDate[1].' </span>พ.ศ.<span class="under"> '.$tranferDate[3].' </span>
    </tr></td></table>
    <table width="100%">
        <tr>
            <td width="90px"><b>รายละเอียดผู้จะซื้อ:</b></td>
            <td class="under"> '.$oldCus->pers_prefix.' '.$oldCus->pers_fname.'&nbsp;&nbsp;'.$oldCus->pers_lname.'
            </td>
        </tr>
    </table>
    <table width="100%">
        <tr>
            <td width="90px"><b>รายละเอียดห้องชุด:</b></td>
            <td width="20px">โครงการ</td><td class="under" align="center"> '.$project->pj_name_th.' '.$project->pj_location_th.' </td>
            <td width="30px">ห้องชุดเลขที่</td><td class="under" align="center"> '.$unit->un_name.' </td>
            <td width="64px">( รหัสห้องชุด</td><td class="under" align="center"> '.$unit->unit_type_name.' </td>
            <td width="74px"> ) พื้นที่ประมาณ</td><td class="under" align="center"> '.number_format($unit->unit_type_area_sqm,2).' </td>
        </tr>
    </table>
    <table width="100%">
        <tr>
            <td width="79">ตารางเมตร ราคา</td><td class="under"  align="center"> '.number_format(str_replace(',','',$unit->pr_selling_sqm),2).' </td>
            <td width="146">บาท สัญญาจะซื้อจะขายห้อง ชุด</td><td class="under" align="center"> '.$detail->ct_code.' </td>
            <td width="54">ฉบับลงวันที่</td><td class="under" align="center"> '.$this->dateformat->thaiDate(date('Y-m-d',strtotime($detail->ct_date))).' </td>
        </tr>
    </table><br/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ด้วยผู้จะซื้อมีความประสงค์จะขอโอนสิทธิและหน้าที่ตามสัญญาจะซื้อจะขายห้องชุดดังกล่าวข้างต้นให้แก่
    <span class="under"><b>บุคคลตามที่ปรากฏชื่อใน ตารางด้านล่าง</b></span>("ผู้รับโอนสิทธิ") โดยข้าพเจ้าตกลงจะดำเนินการให้ผู้รับโอนสิทธิเข้าลงนามในบันทึกข้อตกลงโอนสิทธิ หน้าที่ หนี้ และความรับผิดรวมตลอดถึง บันทึกข้อตกลงอื่นๆ และ/หรือ เอกสาร,หนังสือแจ้งบอกกล่าวใดๆ ที่มีผลผูกพันข้าพเจ้าด้วยทั้งหมด และให้ผู้รับโอนสิทธิรับโอนสิทธิและหน้าที่ตามสัญญา จะซื้อจะขายห้องชุด และข้อตกลงอื่นๆ ต่อไปด้วยทุกประการ และในการโอนสิทธิดังกล่าว ข้าพเจ้าตกลงให้ถือเอาเงินค่าห้องชุที่ข้าพเจ้าได้ชำระไว้แก่บริษัทฯ และเป็นเงินส่วนหนึ่งของผู้รับโอนสิทธิที่ได้ชำระค่าห้องชุดต่อไปด้วย จึงใคร่ขอบริษัทฯ ท่านโปรดพิจารณาและให้ความยินยอมด้วยจักขอบพระคุณยิ่ง<br/><br/>
    <table class="oneLine" width="100%"><tr><td colspan="2">
        &nbsp;<span class="under"><b>รายละเอียดผู้รับโอนสิทธิ (ปรากฎตามสำเนาบัตรประชาชนและทะเบียนบ้าน หรือ สำเนาหนังสือรับรองนิติบุคคลอายุไม่เกิน 3 เดือน)</b></span>
        <table width="670" align="center">
            <tr>
                <td class="under"> '.$newCus->pers_prefix.' '.$newCus->pers_fname.'&nbsp;&nbsp;'.$newCus->pers_lname.' </td>';
$age = date('Y')-explode('-',$newCus->pers_dob)[0];
$nationality = $newCus->nationality == 'Thai'?'ไทย':$newCus->nationality;
$html .= '
                <td width="25">อายุ</td><td class="under" align="center"> '.(empty($newCus->pers_dob)?'-':$age).' </td>
                <td width="35">สัญชาติ</td>
                <td class="under" align="center"> '.$nationality.' </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="150"><span class="under"><b>ที่อยู่ที่ติดต่อได้</b></span> อาคาร/โครงการ</td>
                <td class="under" align="center"> - </td>
                <td width="20">ยูนิต</td>
                <td class="under" align="center"> - </td>
                <td width="18">ชั้น</td>
                <td class="under" align="center"> - </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td class="under"> '.$newCus->addr_cur_address.' </td>
                <td width="59">ตำบล/แขวง</td>
                <td class="under" align="center"> '.$newCus->addr_cur_sub_district.' </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="55">อำเภอ/เขต</td>
                <td class="under" align="center"> '.$newCus->addr_cur_district.' </td>
                <td width="35">จังหวัด</td>
                <td class="under" align="center"> '.$newCus->addr_cur_province.' </td>
                <td width="60">รหัสไปรษณีย์</td>
                <td class="under" align="center"> '.$newCus->addr_cur_post_code.' </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="60">เบอร์โทรศัพท์</td>
                <td class="under" align="center"> '.(empty($newCus->pers_tel)?'-':$newCus->pers_tel).' </td>
                <td width="50">เบอร์มือถือ</td>
                <td class="under" align="center"> '.(empty($newCus->pers_mobile)?'-':$newCus->pers_mobile).' </td>
                <td width="35">email</td>
                <td class="under" align="center"> '.(empty($newCus->pers_email)?'-':$newCus->pers_email).' </td>
            </tr>
        </table>
    </td></tr>
    <tr><td colspan="2" style="padding-left:5px">
        <b>ผู้จะซื้อต้องดำเนินการตามเงื่อนไขเพื่อการโอนสิทธิ พร้อมส่งมอบเอกสารให้แก่ผู้รับโอนสิทธิ <span class="under">ในวันที่ยื่นแบบคำขอโอนสิทธิฉบับนี้แก่บริษัทฯ</span> ดังต่อไปนี้</b>
    </td></tr>
    <tr>
        <td width="40" align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">1. สำเนาเอกสารตรวจรับมอบงานก่อสร้างห้องชุด<b>(defect list)</b> หรือ เอกสารรับมอบงาน/ห้องชุด พร้อมลงลายมือชื่อของผู้จะะซื้อและผู้รับโอนสิทธิให้ครบถ้วนทุกฝ่าย จำนวน<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>แผ่น<br/>
        (การตรวจรับมอบงานให้ยึดถือตามเอกสารดังกล่าวนี้เป็นสำคัญ หากผู้รับโอนสิทธิมีรายการแก้ไขเพิ่มเติมบริษัทฯ ขอสงวนสิทธิ์เก็บรายการเพิ่มเติมภายหลังโอนกรรมสิทธิ์)
        </td>
    </tr>
    <tr>
        <td align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">2. สำเนาหนังสือของผู้จะขายแจ้งกำหนดนัดโอนกรรมสิทธิ์ : นัดโอนกรรมสิทธิ์ในวันที่<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>เดือน<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>พ.ศ.<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> พร้อมลงลายมือชื่อของผู้จะซื้อ และผู้รับโอนสิทธิ ให้ครบถ้วนทุกฝ่าย
        </td>
    </tr>
    <tr>
        <td align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">3. สำเนาบัตรประชาชน และสำเนาทะเบียนบ้านของผู้รับโอนสิทธิ หรือ สำเนาหนังสือรับรองนิติบุคคล พร้อมรับรองสำเนาถูกต้อง
        </td>
    </tr>
    <tr><td colspan="2" style="padding-left:5px;height:30px">
    เอกสารสำคัญที่ผู้จะซื้อต้องส่งมอบให้แก่ผู้รับโอนสิทธิ<span class="under"> ในวันลงนามบันทึกข้อตกลงโอนสิทธิ</span>
    </td></tr>
    <tr>
        <td align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">1. สัญญาจะซื้อจะขายห้องชุด พร้อมบันทึกข้อตกลงแนบท้ายสัญญาทุกฉบับ
        </td>
    </tr>
    <tr>
        <td align="center" height="28"><input type="checkbox" /></td>
        <td style="padding-left:5px">2. ใบเสร็จ/หนักฐานการชำระเงินค่าห้องชุด(ถ้ามี):ผู้จะซื้อได้ชำระเงินไว้จนถึงวันที่<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
        </td>
    </tr>
    <tr>
        <td align="center" height="28"><input type="checkbox" /></td>
        <td style="padding-left:5px">3. เอกสารอื่นๆ(ถ้ามี)<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
        </td>
    </tr>
    <tr>
        <td colspan="2" style="padding-left:5px"><b><span class="under">เงื่อนไขการชำระเงิน</span>:</b> ผู้จะซื้อขอรับรองว่า ได้ชำระเงินไว้แก่บริษัทฯแล้ว วันที่<span class="under"> '.$this->dateformat->thaiDate(date('Y-m-d',strtotime($lastReceipt->rc_temporary_date))).' </span>เป็นเงินทั้งสิ้นจำนวน<span class="under"> '.number_format($lastReceipt->rc_total_amount,2).' </span>บาท โดยผู้รับโอนสิทธิรับทราบแล้ว และตกลงจะชำระเงินตามเงื่นในสัญญาจะซื้อจะขายต่อไป</td>
    </tr>
    <tr><td colspan="2">
        <table width="680" border="1" class="oneLine"><tr>
            <td class="line-right">
                <b>ผู้จะซื้อ</b><br/>
                (ลงชื่อ)<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br/>
                วันที่<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            </td>
            <td class="no-line">
                <b>ผู้รับโอนสิทธิ</b><br/>
                (ลงชื่อ)<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br/>
                วันที่<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            </td>
        </tr></table>
    </td></tr>
    <tr><td colspan="2" style="padding-left:5px">
        <b>ส่วนนี้สำหรับบริษัทฯ</b>
    </td></tr>
    <tr><td colspan="2" style="padding-left:5px">
        <span class="under"><b>เงื่อนไขสำคัญในการพิจารณาอนุมัติการโอนสิทธิเป็นดังนี้</b></span><br/>
        1. ในการโอนสิทธิ และหน้าที่ตามสัญญาจะซื้อจะขายห้องชุดข้างต้นจะมีผลต่อเมื่อผู้จะซื้อ และผู้รับโอนสิทธิได้ลงนามบันทึกข้อตกลงโอนสิทธิฯ กับบริษัทฯ เรียบร้อยแล้ว<br/>
        2. แบบคำขอฉบับนี้เป็นเพียงการแจ้งความประสงค์ของผู้จะซื้อแต่ฝ่ายเดียวเท่านั้น ยังไม่ถือเป็นการโอนสิทธิ
    </td></tr>
    <tr><td colspan="2">
        <table width="680" border="1" class="oneLine">
            <tr>
                <td rowspan="2" class="right-under" align="right" style="vertical-align: text-top;padding-right:10px"><b>เจ้าหน้าที่</b></td>
                <td class="right-under"></td>
                <td class="right-under" align="right" style="vertical-align: text-top;padding-right:10px"><b>อนุมัติโดย</b></td>
                <td class="line-under"></td>
            </tr>
            <tr>
                <td class="right-under" align="center">Sale/CS</td>
                <td class="right-under"></td>
                <td class="line-under" align="center">VP Sale and Leasing Management</td>
            </tr>
            <tr>
                <td class="line-right" align="right" height="25" style="padding-right:10px">วันที่</td>
                <td class="line-right" style="padding-left:10px">
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                </td>
                <td class="line-right" align="right" style="padding-right:10px">วันที่</td>
                <td class="no-line" style="padding-left:10px">
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                </td>
            </tr>
        </table>
    </td></tr></table>
</body>';

include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");



// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>