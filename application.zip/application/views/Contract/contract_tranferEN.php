<?php 
$html = '
<style>
    span.under{
        border-bottom-width:1px; 
        border-bottom-style:solid; 
    }
    table.oneLine {
        border: 1px solid black;
        border-collapse: collapse;
    }
    td.under {
        border-bottom-width:1px; 
        border-bottom-style:solid; 
    }
    body {
        font-size:15px;
    }
    table { 
        border-spacing: 0px;
        border-collapse: collapse;
    }
    td.no-line {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #FFF #FFF #FFF;
    }
    td.line-right {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #000 #FFF #FFF;
    }
    td.right-under {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #000 #000 #FFF;
    }
    td.line-under {
        border: 1px solid black;
        border-collapse: collapse;
        border-bottom-width:1px;
        border-top-width:1px;
        border-left-width:1px;
        border-right-width:1px;
        border-color: #FFF #FFF #000 #FFF;
    }
</style>
<body>
    <table class="oneLine" width="100%"><tr><td align="center">
    Application Form for Assignment of Rights, Obligations, Debts and Liabilities under the Condominium Sale and Purchase Agreement
    </tr></td></table>
    <table width="100%"><tr><td align="right">
    Date<span class="under"> '.date('d F Y',strtotime($detail->tf_timestamp)).' </span>
    </tr></td></table>
    <table width="100%">
        <tr>
            <td width="110px"><b>Details of Purchaser:</b></td>
            <td class="under"> '.$oldCus->pers_prefix.' '.$oldCus->pers_fname.'&nbsp;&nbsp;'.$oldCus->pers_lname.'
            </td>
        </tr>
    </table>
    <table width="100%">
        <tr>
            <td width="83px"><b>Derail of Seller:</b></td>
            <td class="under" align="center"> '.$project->pj_name.' '.$project->pj_location.' '.$project->pj_type.' </td>
            <td width="50px">, Unit No.</td><td class="under" align="center"> '.$unit->un_name.' </td>
            <td width="54px">(Unit Code</td><td class="under" align="center"> '.$unit->unit_type_name.' </td>
            <td width="95px">) having an area of </td><td class="under" align="center"> '.number_format($unit->unit_type_area_sqm,2).' </td>
        </tr>
    </table>
    <table width="100%">
        <tr>
            <td width="70">approximately</td><td class="under"  align="center"> '.number_format(str_replace(',','',$unit->pr_selling_sqm),2).' </td>
            <td width="218">Baht/Sq.m. Sale and Purchase Agreement No.</td><td class="under" align="center"> '.$detail->ct_code.' </td>
            <td width="45">dated on</td><td class="under" align="center"> '.date('d F Y',strtotime($detail->ct_date)).' </td>
        </tr>
    </table>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Due to the Purchaser’s wish to assign rights and obligations under the above said Condominium Sale and Purchase Agreement to
    <span class="under"><b>specified in the box below</b></span>(the “Assignee”), we agree to take any act to have the Assignee to sign in the Memorandum of Agreements of Assignment of Rights, Obligations, Debts and Liability under the Condominium Sale and Purchase Agreement, as well as, all of the other memorandums and/or any document and notice that are binding us, also, any act to have the Assignee to accept all rights and obligations under the Condominium Sale and Purchase Agreement and other agreements. In addition, for such assignment, we agree the all payments for the unit price we had made to the Company shall be a part of the Assignee’s monies paid for the unit price. We wish you consider and approve the assignment.Very kind of you.<br/>
    <table class="oneLine" width="100%"><tr><td colspan="2">
        &nbsp;<span class="under"><b>Details of Assignee (as per copies of I.D. card and house registration book, or a copy of certificate of incorporation issued not over 3 months)</b></span>
        <table width="670" align="center">
            <tr>
                <td class="under"> '.$newCus->pers_prefix.' '.$newCus->pers_fname.'&nbsp;&nbsp;'.$newCus->pers_lname.' </td>';
$age = date('Y')-explode('-',$newCus->pers_dob)[0];
$nationality = $newCus->nationality;
$html .= '
                <td width="25">Age</td><td class="under" align="center"> '.(empty($newCus->pers_dob)?'-':$age).' </td>
                <td width="35">Nationality</td>
                <td class="under" align="center"> '.$nationality.' </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="210"><span class="under"><b>Contacting Address</b></span> Building/Condominium</td>
                <td class="under" align="center"> - </td>
                <td width="20">Unit</td>
                <td class="under" align="center"> - </td>
                <td width="18">floor</td>
                <td class="under" align="center"> - </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="55">House No.</td>
                <td class="under"> '.$newCus->addr_cur_address.' </td>
                <td width="59">Tambon/Sub-district</td>
                <td class="under" align="center"> '.$newCus->addr_cur_sub_district.' </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="55">Amphur/District</td>
                <td class="under" align="center"> '.$newCus->addr_cur_district.' </td>
                <td width="35">Province</td>
                <td class="under" align="center"> '.$newCus->addr_cur_province.' </td>
                <td width="62">Postal Code</td>
                <td class="under" align="center"> '.$newCus->addr_cur_post_code.' </td>
            </tr>
        </table>
        <table width="670" align="center">
            <tr>
                <td width="20">Tel.</td>
                <td class="under" align="center"> '.(empty($newCus->pers_tel)?'-':$newCus->pers_tel).' </td>
                <td width="36">Mobile</td>
                <td class="under" align="center"> '.(empty($newCus->pers_mobile)?'-':$newCus->pers_mobile).' </td>
                <td width="35">email</td>
                <td class="under" align="center"> '.(empty($newCus->pers_email)?'-':$newCus->pers_email).' </td>
            </tr>
        </table>
    </td></tr>
    <tr><td colspan="2" style="padding-left:5px">
        <b>The Purchaser shall comply with conditions of assignment of rights, together with, on the date of submitting the Application Form of Assignment to the Company, deliver the following documents:</b>
    </td></tr>
    <tr>
        <td width="40" align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">1. A copy of <b>defect list</b> or of certificate of acceptance set signatures of both the Purchaser and the Assignee<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>sheet<br/>
        (An investigation for acceptance shall be principally based on such documents. If the Assignee wishes to amend any of the list or certificate, the Company reserves the right to keep the amended list or certificate after the transfer of ownership.)
        </td>
    </tr>
    <tr>
        <td align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px;padding-right:25px">2. A copy of the Seller’s notice specifying the transfer date : the date of<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>, with signatures of the Purchaser and the Assignee
        </td>
    </tr>
    <tr>
        <td align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">3. True certified copies of I.D. card and house registration book of the Assignee or a true certified copy of certification of incorporation
        </td>
    </tr>
    <tr><td colspan="2" style="padding-left:5px;height:30px">
    <b>Key Documents mandatorily submitted by the Purchaser to the Assignee on the date of signing the Memorandum of Agreements of Assignment of Rights</b>
    </td></tr>
    <tr>
        <td align="center"><input type="checkbox" /></td>
        <td style="padding-left:5px">1. The Condominium Sale and Purchase Agreement and all Memorandum of Agreements attached to the Agreement
        </td>
    </tr>
    <tr>
        <td align="center" height="28"><input type="checkbox" /></td>
        <td style="padding-left:5px">2. Receipts/evidences of payment of unit price(if any): the Purchaser have made payments until the date of<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
        </td>
    </tr>
    <tr>
        <td align="center" height="28"><input type="checkbox" /></td>
        <td style="padding-left:5px">3. Other documents (if any)<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
        </td>
    </tr>
    <tr>
        <td colspan="2" style="padding-left:5px"><b><span class="under">Terms of payment</span>:</b> The Purchaser attests that the payment was made to the Company on the date of<span class="under"> '.date('d F Y',strtotime($lastReceipt->rc_temporary_date)).' </span>amounting to<span class="under"> '.number_format($lastReceipt->rc_total_amount,2).' </span>Baht and the Assignee has acknowledged and agrees to continually make a payment under the terms and conditions of the Condominium Sale and Purchase Agreement.</td>
    </tr>
    <tr><td colspan="2">
        <table width="680" border="1" class="oneLine"><tr>
            <td class="line-right">
                <b>Purchaser</b><br/>
                (Sign)<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br/>
                Date<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            </td>
            <td class="no-line">
                <b>Assignee</b><br/>
                (Sign)<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br/>
                Date<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            </td>
        </tr></table>
    </td></tr>
    <tr><td colspan="2" style="padding-left:5px">
        <b>This part is for the Company only.</b>
    </td></tr>
    <tr><td colspan="2" style="padding-left:5px">
        <span class="under"><b>Principal conditions in considering to approve the assignment of rights are as follows.</b></span><br/>
        1.   For assignment of rights and obligations under the above said Condominium Sale and Purchase Agreement shall be effective once the Purchaser and the Assignee has duly signed and entered into the Memorandum of Agreements of Assignment of Rights with the Company.<br/>
2.   This application form is only a notification of an ex parte desire of the Purchaser, but is not deemed to be the assignment of rights.

    </td></tr>
    <tr><td colspan="2">
        <table width="680" border="1" class="oneLine">
            <tr>
                <td rowspan="2" class="right-under" align="right" style="vertical-align: text-top;padding-right:10px"><b>Officer</b></td>
                <td class="right-under"></td>
                <td class="right-under" align="right" style="vertical-align: text-top;padding-right:10px"><b>Approved by</b></td>
                <td class="line-under"></td>
            </tr>
            <tr>
                <td class="right-under" align="center">Sale/CS</td>
                <td class="right-under"></td>
                <td class="line-under" align="center">VP Sale and Leasing Management</td>
            </tr>
            <tr>
                <td class="line-right" align="right" height="25" style="padding-right:10px">Date</td>
                <td class="line-right" style="padding-left:10px">
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                </td>
                <td class="line-right" align="right" style="padding-right:10px">Date</td>
                <td class="no-line" style="padding-left:10px">
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/
                    <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                </td>
            </tr>
        </table>
    </td></tr></table>
</body>';

include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");



// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>