<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}
table.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}
.ninety     { image-orientation: 90deg }

</style>

<pageheader name="MyHeader1" content-left="" content-center="" content-right="Contract Letter No. '.$id.' Sheets {PAGENO} of {nbpg}" header-style="font-size: 10pt; font-weight: bold; color: #000000;" line="on" />

<!--หน้าปก-->
<br>
<br>
<table border="0" width="750px">
    <tr>
        <td colspan="7" align="center"><img src="'.$projectImage.'" style="width:180px;"></td>
    </tr>
    
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">The Condominium Sale and Purchase Agreement</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">'.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">CONDOMINIUM</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">UNIT NUMBER</td>
    </tr>
    <tr>
        <td colspan="7" align="center">
            <table>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" align="center">'.$un_name.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="font-size:22pt" width="50px">FLOOR</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$Floorname.'</td>
        <td style="font-size:22pt" width="50px">TYPE</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$room_type_name.'</td>
        <td style="font-size:22pt" width="50px">AREA</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$unit_type_area_sqm.'</td>
        <td style="font-size:22pt" width="50px">Sq.m.</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    
   
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">FOR THIS EDITION</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">SELLER</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:12pt">'.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:11pt">'.$companyName.' '.$ownerAddr.'.</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="550px"></td>
                    <td style="font-size:12pt;" width="50px">Inspector</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.$nameSale.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="590px"></td>
                    <td style="font-size:12pt;" width="10px">Date</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.date('d F Y', strtotime($contractDate)).'</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<!--หน้าปก-->
<!--หน้าปก-->
<br>
<br>
<table border="0" width="750px">
    <tr>
        <td colspan="7" align="center"><img src="'.$projectImage.'" style="width:180px;"></td>
    </tr>
    
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">The Condominium Sale and Purchase Agreement</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">'.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">CONDOMINIUM</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">UNIT NUMBER</td>
    </tr>
    <tr>
        <td colspan="7" align="center">
            <table>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" align="center">'.$un_name.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="font-size:22pt" width="50px">FLOOR</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$Floorname.'</td>
        <td style="font-size:22pt" width="50px">TYPE</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$room_type_name.'</td>
        <td style="font-size:22pt" width="50px">AREA</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$unit_type_area_sqm.'</td>
        <td style="font-size:22pt" width="50px">Sq.m.</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    
   
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">FOR THIS EDITION</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">PURCHASER</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:12pt">'.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:11pt">'.$companyName.' '.$ownerAddr.'.</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="550px"></td>
                    <td style="font-size:12pt;" width="50px">Inspector</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.$nameSale.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="590px"></td>
                    <td style="font-size:12pt;" width="10px">Date</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.date('d F Y', strtotime($contractDate)).'</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<!--หน้าปก-->

<pagebreak resetpagenum="1" value="off"></pagebreak>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<table border="1" align="center" width="700px">
    <tr>
        <td width="500px" align="center">
            <table border="0">
                <tr>
                    <td width="350px" align="center" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;">'.$pj_name.'</td>
                    <td width="50px">UNIT NUMBER</td>
                    <td width="80px" align="center" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;">'.$un_name.'</td>
                </tr>
            </table>
            <table>
                <tr>
                    <td >Customer <span class="under">'.$nameCus.'</span></td>
                    
                </tr>
            </table>
            <table align="center">
                <tr>
                    <td>Seller <span class="under">'.$nameSale.'</span></td>
                </tr>
            </table>
            <table align="center">
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    
</table>
<pagebreak resetpagenum="1" ></pagebreak>
<setpageheader name="MyHeader1" value="on" show-this-page="1" />
<table width="700" border="0" align="center"  cellspacing="0">
    <tr>
        <td align="center"><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
	<tr>
		<td align="center"><h5>The Condominium Sale and Purchase Agreement</h5></td>
	</tr>
	<tr>
		<td align="center"><h5>'.$pj_name.'</h5></td>
	</tr>
</table>
<br>
<pre class="tab">THIS AGREEMENT is made at a sale office of '.$pj_name.' '.$projectAddr.' on the <span class="under">'.(date('d F Y', strtotime($lastContractDate))).'</span>, by and between <b>'.$companyName.'</b> by '.$ownerName.', an Attorney-in-Fact(s) acting for the Company under the Power of Attorney dated on '.(date('d F Y', strtotime($ownerDate))).', a Thai national, residing/having its office at No '.$ownerAddr.', hereinafter in this Agreement referred to as the “Seller” of the one part; and</pre>
<pre class="tab">'.$cusDetail.'</pre>
<pre>hereinafter referred to as the <b>“Purchaser”</b> of the other part.</pre>
<p class="tab">Both parties do hereby agree to terms and conditions as follows:
<pre class="tab"><b>Section 1.  Warranty of the Seller</b></pre></p>
<p class="tab">1.1  The Seller attests that it is the legitimate owner of the land where the Condominium is located under the title deed No. '.$landLocation.' '.$projectAddr.' in the amount of '.$landArea.' Sq.wah, which is</p>
<p class="tab"><input type="checkbox"/> mortgaged in flavor of <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/ under the registered preferential right in flavour of<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>for securing the mortgaged debt / the preferential debt of <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>Baht</p>
<p class="tab"><input type="checkbox" checked="checked"/> free and clear of any mortgage / preferential right</p>
<p class="tab">1.2  The Seller attests that the condominium and its unit is owned by the Seller and such building is</p>
<p class="tab"><input type="checkbox"/> , together with the said land, mortgaged in flavor of <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/ under the registered preferential right in flavour of <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> for the same amount of the mortgaged debt / the preferential debt specified in Section 1.1
<p class="tab"><input type="checkbox" checked="checked"/> free and clear of any mortgage / preferential right</p>
<p class="tab">1.3  The Seller has already obtained the License of building construction from the District Official under the law of building control, as per the License No. <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> dated on <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>. Now, the condominium, or has submitted the application for the License with the District Official under Section 39 of the Building Control Act B.E. 2522 (1979)</p>
<p class="tab"><input type="checkbox" checked="checked"/> is during the construction. Once the construction is completed, the completed building will be registered as a condominium.</p>
<p class="tab"><input type="checkbox"/> has been completed in construction and during registering as condominium.</p>

<pre class="tab"><b>Section 2.  Terms of Sale and Purchase</b></pre>
<pre class="tab">2.1  The Seller agrees to sell and the Purchaser agrees to purchase the unit of the '.$pj_name.' for <span class="under"> 1 </span> unit(s) as follows.</pre>
<pre class="tab2">2.1.1 The unit No. <span class="under"> '.$un_name.' </span> Floor <span class="under"> '.$Floorname.' </span> of which the area is <span class="under"> '.$unit_type_area_sqm.' </span> Sq.m.
<pre class="tab">2.2  Apart from the unit specified in Section 2.1, the common properties that the Purchaser is entitled to use with other owners of the other units are as follows:</pre>
<pre class="tab2">2.2.1  Properties which are the Common Property under the Condominium Act B.E. 2522 (1979) and its Amendment.</pre>
<pre class="tab2">2.2.2  The land where the Condominium is located in the amount of '.$landArea.' . and </pre>
<pre class="tab2">2.2.3  Accommodations to which the Purchaser will be entitled and which the Seller is under an obligation to register such accommodations to be the common properties, as per the Exhibit attached herein.</pre>
<br/>
<pre class="tab"><b>Section 3.  Sale Price</b></pre>
<pre class="tab">3.1 The Purchaser and the Seller agree to purchase and sale, respectively, the unit specified in Section 2. for  1  unit(s) at the rate of <span class="under">'.number_format(floatval(str_replace(',', '', $pr_selling_sqm)),2).'</span> Baht per Sq.m. (<span class="under">'.$Currency->bahtEng(floatval(str_replace(',', '', $pr_selling_sqm))).'</span>)  the total price of <span class="under">'.number_format($qt_unit_price,2).'</span> Baht (<span class="under">'.$Currency->bahtEng($qt_unit_price).'</span>)</pre>
<pre class="tab">3.2  In the case where the construction of the condominium has not yet completed, and then it is obvious, after the completion of the construction, that the area is more or less than what is specified in the Agreement, the Parties agree that the proportionate price, either an increase or a decrease, shall be calculated upon the rate specified in Section 3.1 and the total price, as specified in Section 3.1, and the amount, to be paid under Section 4.2, shall then be added or deducted by the said proportionate price.</pre>
<br />
<pre class="tab"><b>Section 4.  Payment and Transfer of Ownership</b></pre>
<pre class="tab">4.1  The Parties agree to treat the payment made by the Purchaser on the reservation date, the <span class="under"> '.(date('d F Y', strtotime($bookingDate))).'</span>, in the amount of <span class="under">'.number_format($BookingFee,2).'</span> Baht (<span calss="under">'.$Currency->bahtEng($BookingFee).'</span>) the payment on the contracting date of this Agreement in the amount of  <span class="under">'.number_format($ContractFee,2).'</span> Baht (<span class="under">'.$Currency->bahtEng($ContractFee).'</span>) and any amount paid to the Seller sum in the amount of <span class="under"> '.number_format($BookingFee+$ContractFee ,2) .' </span> Baht (<span class="under">'.$Currency->bahtEng($BookingFee+$ContractFee).'</span>), as part-payment upon the total price of the unit determined in Section 3.1.</pre>
<pre class="tab" align="left">4.2  The Purchaser to make the remaining stage payments in the amount of <span class="under">'.number_format($qt_unit_price-($BookingFee+$ContractFee),2).'</span> Baht
(<span class="under">'.$Currency->bahtEng($qt_unit_price-($BookingFee+$ContractFee)).'</span>) by the following time frame.</pre>

'.$htmlTotalDownMonth.'

<pre class="tab">4.3  For the last installment, the Purchaser shall make a payment to the Seller at the Seller’s domicile, as specified elsewhere in this Agreement. In the case where there is a change in domicile, the applicable domicile shall be where the Seller will notify to be the place of payment in writing. After receiving such payment, the Seller shall issue documentary evidence signed by the Seller or by a person receiving such payment for the Purchaser.</pre>
<pre class="tab">4.4  the Seller shall ensure to complete the Condominium and to transfer ownership in the unit to the Purchaser within the '. (date('d F Y', strtotime($projectDate))) .'. For the transfer of ownership, the Seller shall notify the date of such transfer at least 30 days prior to the notified date.</pre>
<pre class="tab">The Purchaser shall agree to accept the transfer of ownership in the unit only if the Seller has completed the construction of the condominium and the unit with regard to the Agreement. If the Purchaser notifies his/her/its wish to accept the transfer prior to the date the Seller specifies in the first paragraph, the Seller shall transfer the ownership to the Purchaser within 7 days from the date when the Purchaser’s notification is received.</pre>
<pre class="tab">4.5  During the execution period of this Agreement, the Purchaser may assign his/her/its rights herein to any third party upon a written notice served to the Seller. In this regard, the Seller shall waive all rights to claim for any additional cost or payment and shall take any necessary arrangement for the assignee to be assigned all rights and obligations.</pre>
<br>
<pre class="tab"><b>Section 5.  Construction of Building</b></pre>
<pre class="tab">5.1  The Purchaser agrees that if the Seller has been forced to amend a drawing, a plan and details of the condominium and the unit, including the common property, for an compliance with the government regulations as to a permission to construct, or for any reason the Seller deems appropriate. The Purchaser agrees to immediately provide consent to such amendment, regardless of an advance notice served to the Purchaser, and agrees that the Seller shall not be deemed as a party who breaches the Agreement.</pre>
<pre class="tab">5.2  For features of the unit and materials and things used to construct and to be fixed with the unit, the Seller shall construct by following the drawing and by using the materials and things in accordance with a type, size, kind, and quality specified in the drawing, the plan, and the Exhibits of the drawing of the unit certified by the Official, and in accordance with the standard determined under the governing laws.</pre>
<pre class="tab">5.3  Features, brand, type, model, quality, size, and colour of the materials, floor, wall, ceiling, roof, any sanitary ware, door, window, and things equipped to window shall be up to standards of each said product.</pre>
<pre class="tab">5.4  If the Seller cannot obtain the specified materials from the market, the Seller may obtain the other materials of which quality is better than or equal to the materials specified in this Agreement for using in the construction. For this, the Seller shall not be deemed as a party who breaches the Agreement.</pre>
<pre class="tab">5.5  Prior to the date of transfer, the ownership in the unit shall be possessed by the Seller and the Purchaser has no right to take any action against the unit unless is provided a written consent by the Seller.</pre>
<pre class="tab">5.6  In the case that the construction is suspended by any cause which is not resulting from the Seller’s false, the Purchaser shall provide consent to the Seller to extend the construction period specified in this Agreement, however, such extension shall not be longer than the period of such suspension. For the extension, the Seller shall give the Purchaser an advance notice clarifying the cause and related evidence within 7 days after such cause is passed. If the Seller fails to do so, the Seller shall be deemed to waive the right to extend. Notwithstanding to the abovesaid clause, the extension shall not be longer than 1 year.</pre>
<pre class="tab">5.7  The Seller shall be responsible for installing utility meter in the common properties and a certain separated meter in the unit.</pre>
<pre class="tab">For the certain separated meter in the unit, the Seller shall be responsible for submitting a request of installation. The Seller shall pay for costs and fees of such installation in the first place. After the Seller transfer the ownership in the unit, as well as changing the name of owner of the meter to be the Purchaser, the Seller shall then charge the Purchase for such costs and fees.</pre>
<br>
<pre class="tab"><b>Section 6.  Costs of Registration of Transfer of Ownership</b></pre>
<pre class="tab">Costs of income tax, specific business tax and stamp duty incurring from the transfer of ownership in the unit shall be paid by the Seller, whereas the fees of registration of rights and juristic acts relevant to the unit shall be equally paid by both the Purchaser and the Seller.</pre>
<br>
<pre class="tab"><b>Section 7.  Fines, Interest for Default and Rescission</b></pre>
<pre class="tab">7.1 In the case that the Purchaser is in default of making payment for any of what is specified in Section 4, the Purchaser agrees for the Seller to demand the interest for default at the rate of 7.5% per annum on the remaining amount. The remaining amount shall not be more than 10% of the total unit price specified hereunder.</pre>
<pre class="tab">7.2 In the case the Purchaser is in default of making payment for the amount which is agreed to be paid before the transfer date, the Seller may rescind the Agreement upon the following circumstances:</pre>
<pre class="tab2">7.2.1 Default of making an payment at once, if it is agreed so.</pre>
<pre class="tab2">7.2.2 Default of 3 successive payments, if the agreed stage payments are up to 24 instalments. or</pre>
<pre class="tab2">7.2.3 Default of making payments totally amounting to 12.5% of such amount, if the agreed stage payments are less than 24 instalments.</pre>
<pre class="tab2">Prior to rescission of the Agreement, the Seller shall serve the Purchaser a written notice requesting the Purchaser to pay the remaining amount within 30 days from the date of receiving the notice. If the Purchaser ignores performing the request under the notice, it shall be deemed that the Purchaser is in default of this Agreement and the Seller may immediately confiscate the deposit and the whole amount of any other payment paid by the Purchaser.</pre>
<pre class="tab">7.3  In the case the Seller does not transfer the ownership in the unit to the Purchaser within the time specified in Section 4, the Seller shall provide the Purchase consent of the following: </pre>
<pre class="tab2">7.3.1  The Seller agrees for the Purchaser to rescind the Agreement and to be returned the whole amount paid by the Purchaser with the interest of 7.5% per annum, and such undertakings shall not affect the right to claim any other damages.</pre>
<pre class="tab2">7.3.2  In the case the Purchaser does not exercise the right of rescission under Section 7.3.1, the Seller shall entitle the Purchaser to a charge of fines at the rate of 0.01% of the unit price under this Agreement, but totally amounting shall not be more than 10% of the unit price. After the fines is amounting to 10% of the unit price and the Purchaser deems that the Seller cannot perform the Agreement, the Purchaser may rescind the Agreement.</pre>
<pre class="tab2">7.3.3  In the case where the Seller cannot complete the condominium due to force majeure, the Seller shall return the Purchaser the whole amount paid by the Purchaser with the interest at the highest rate of the interest rate for the saving account of Krung Thai Bank (PLC), calculated from the date of receiving such payment from the Purchaser without prejudicing the seller’s right to claim any other damages. However, all of the monies paid by the Seller shall be brought to deduct from the interest to be paid by the Seller.</pre>
<br>
<pre class="tab"><b>Section 8.  Liability for Defect</b></pre>
<pre class="tab">8.1  The Seller shall be liable for any damages causing from any defect in the condominium and the unit upon the following conditions:</pre>
<pre class="tab2">8.1.1  For the structure and things, composite things fixed permanently to the condominium that is an immovable property, the condition of time period of at least 5 years since the date of registration of condominium.</pre>
<pre class="tab2">8.1.2  For any component things, excepts things under Section 8.1.1, the condition of time period of at least 2 year since the date of registration of condominium.</pre>
<pre class="tab">8.2  The Seller shall fix the defect in the condominium within 30 days from the date when the Purchaser or the condominium juristic person, if a case may be, notifies in writing of such defect, excepts the case that it is necessary to fix such defect in urgent. For the case of urgent need, the Seller shall fixed the defect as soon as the notification is received. If the Seller does not fix such defect, the Purchaser or the condominium juristic person, if the case may be, may fix it by himself/herself/itself or may have the defect fixed by third persons at the Purchaser’s expenses, and the Seller shall compensate for any damages occurring from fixing such defect.</pre>
<br>
<pre class="tab"><b>Section 9.  Notification</b></pre>
<pre class="tab">Any notification under this Agreement shall be made in writing and shall be served to the another party in accordance with the address above specified or other address that a party notifies in writing to the another party. In the case that the Seller is a notifying party, the notification shall be served via registered post. By doing so, it is deemed that another party is informed and acknowledges the on the receiving date or is deemed to receive such notice.</pre>
<pre class="tab">If any party re-habits, such party shall notify another party in writing.</pre>
<br>
<pre class="tab"><b>Section 10.  Exhibits</b></pre>
<pre class="tab">The Parties agree that, as parts of this Agreement, this Agreement shall include the following Exhibits with signatures of both parties:</pre>
<pre class="tab">10.1 A copy of Certification of Incorporation and a copy of Power of Attorney providing authority to act for the Seller.</pre>
<pre class="tab">10.2  A copy of Land Title Deed.</pre>
<pre class="tab">10.3  A copy of Building Construction, Modification and Removal License (Form Orr.1) or a copy of License to certify Building Construction, Modification and Removal (Form Orr.6) under the laws of Building Control.</pre>
<pre class="tab">10.4  A drawing of the condominium and evidences of registration of condominium. and</pre>
<pre class="tab">10.5  details of the unit, the personal properties, the common properties, the accommodations, and the advertising, both contents and pictures of advertising.</pre>
<pre class="tab">In the event of any inconsistency between the provisions of the Exhibits and this Agreement, the provisions of this Agreement shall prevail.</pre>

<pre class="tab">This Agreement has been executed in duplicate originals. Both parties have read and understand through all of the Agreement and agree that the Agreement is correct as well as conveying their intents and wishes completely.</pre>
<pre class="tab">IN WITNESS WHEREOF each undersigned party sets its signature and seal (if any) hereto before the witnesses and each party holds one original.</pre>';
//if($cusNum > 1)
//    $html .= '<pagebreak>';
$html .= '
<br><br>
<table border="0" width="100%">';
$fontSize = $cusNum*15;
for($i=0;$i<$cusNum;$i++) $sign .= '<tr><td collspan="7">&nbsp;</td></tr>';
$sign .= '
    <tr>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Purchaser</td>
		<td width="10%"></td>
		<td width="5%" align="right">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;" align="center"></td>
		<td width="10%">Seller</td>
	</tr>';
for($j=0;$j<$cusNum;$j++) {
    $sign .= '
	<tr>
		'.($j==0?'<td rowspan="'.$cusNum.'" align="right" style="font-size:'.$fontSize.'pt;">(</td>':'').'
		<td align="center" '.($j==$cusNum-1?'style="border-bottom-width:1px; border-bottom-style:solid;"':'').'>'.$nameCusLicenses[$j].($j<$cusNum-1?' and':'').'</td>
		'.($j==0?'<td rowspan="'.$cusNum.'" align="left" style="font-size:'.$fontSize.'pt;">)</td>':'').'
		<td></td>
		<td align="right">'.($j==0?'(':'').'</td>
		<td align="center" '.($j==0?'style="border-bottom-width:1px; border-bottom-style:solid;"':'').'>'.($j==0?$companyName:'').'</td>
		<td align="left">'.($j==0?')':'').'</td>
	</tr>';
}
$html .= $sign.'
    <tr>
        <td><br><br><br></td>
    </tr>
    <tr>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Witness</td>
		<td width="10%"></td>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Witness</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
	</tr>
</table>

<pagebreak resetpagenum="1"></pagebreak>

<table align="center">
    <tr>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td align="center"><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <th align="center">Sale Promotion</th>
    </tr>
    <tr>
        <th align="center">'.$pj_name.', the unit No. '.$un_name.' Floor '.$Floorname.'</th>
    </tr>
</table>
<table align="center">
    <tr>
        <th align="center"><span class="under">'.$nameCus.' (The Purchaser)</span></th>
    </tr>
</table>
<br/>
'.$tablePromotion.'
<table>
    <tr>
        <td style="font-size:11pt;"><b>Conditions</b> The prices offered herein are promotion prices or special discounts. Therefore, the Purchaser cannot assign his/her/its rights under the Sale and Purchase Agreement until '.(date('d F Y', strtotime($deadProDate))).'</td>
    </tr>
</table>
<br><br>
<table border="0" width="100%">';
$html .= $sign.'
    <tr>
        <td><br><br><br></td>
    </tr>
    <tr>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Witness</td>
		<td width="10%"></td>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Witness</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
	</tr>
</table>

<pagebreak resetpagenum="1"></pagebreak>
<table width="700" border="0" align="center"  cellspacing="0">
    <tr>
        <td align="center" ><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
	<tr>
		<td align="center" ><h5>Memorandum of Agreement Attached to Sale and Purchase Agreement</h5></td>
	</tr>
    <tr>
		<td align="center" ><h5>'.$pj_name.'</h5></td>
	</tr>
</table>
<br>
<pre class="tab">THIS MEMORANDUM OF AGREEMENT is made at the sale office of '.$pj_name.' located at '.$projectAddr.', on the date of <span class="under">'.(date('d F Y', strtotime($lastContractDate))).'</span>, by and between </pre>
<pre class="tab">A. '.$companyName.' by '.$ownerName.', an Attorney-in-fact acting for the Company under the Power of Attorney dated on '.(date('d F Y', strtotime($ownerDate))).', a Thai national, residing/having its office at No. '.$ownerAddr.', hereinafter in this Agreement referred to as the “Seller” of the one part. and</pre>
<pre class="tab">B. '.$cusDetail.'</pre>
<pre>hereinafter referred to as the <b>“Purchaser”</b> of the other part.</pre>
<table width="100%"><tr><td align="center">RECITAL</td></tr></table>
<pre class="tab">WHEREAS the Purchaser and the Seller have made and entered into the Condominium Sale and Purchase Agreement for the unit of the '.$pj_name.' for <span class="under"> 1 </span> unit(s), the Unit No.'.$un_name.' (unit code '.$unit_type_name.' ) Floor '.$Floorname.' Building '.$building_name.', having an area (including its balcony/ spaces for installing its compressor of air conditioner/ internal and external spaces of the unit that are deemed to be personal property/ other spaces connecting with the unit, according to an agreement of transfer of ownership in the unit) of '.$unit_type_area_sqm.' Sq.m., with regard to the Condominium Sale and Purchase Agreement for units of the '.$pj_name.', the Agreement No. '.$id.' dated on '.$ctDate.' hereinafter referred to as the “Condominium Sale and Purchase Agreement”.</pre>
<pre class="tab">WHEREAS after entering into the Agreement, the Parties is desirous of making further agreements as to sale and purchase matters as a supplement to the agreed terms of the Condominium Sale and Purchase Agreement in order to cover details of the terms and conditions agreed by the Parties.</pre>
<br/>NOW AND THEREFORE, both Parties do hereby agree as follows:
<pre><b>1. <span class="under">Conditions and Method of Payment</span></b></pre>
<pre class="tab">1.1 In the case that the Purchaser is a person who has no permanent domicile or domicile available for contacting in Thailand, a person or an entity holding any other nationality, excepts Thai, or is an alien entity according to the laws of condominium, to make any payment to the Seller under the Condominium Sale and Purchase Agreement and this Memorandum (together called the “Sale Contract”), the Purchaser shall make a payment by a method of electronic transfer of money, available to immediately withdraw, to the Seller’s bank account that the Seller determines and informs the Purchaser at least 2 business days prior to the due date of each instalment.</pre>
<pre class="tab2">Such payment shall be made at the amount of principal added up by a VAT and any other taxes, and shall be paid in full without rights to object, offset or deduct such amount by any of monies. If the Purchaser bears the burden of withholding the certain amount out of the said payment for purposes of taxes or any expense (such as costs of money transfer), an amount equal to the withholding amount shall be added up to the said payment in order that, after withholding, the payment shall be made to the Seller in full amount.</pre>
<pre class="tab2">In addition, in the case that the Purchaser is an entity holding any other nationality, excepts Thai or is within the scope of the alien entity according to the laws of condominium, the payment shall be made in foreign currency, any currency other than Thai Baht, at the amount that, when exchanged into Thai Baht, an amount received from the exchange shall cover the whole amount the Purchaser shall pay to the Seller under this Agreement. If the payment amount, deducted by the cost of exchange and any other relevant cost, is less than the amount to be paid under this Agreement, the Purchaser shall bear an obligation to immediately pay the remaining amount to the Seller. Moreover, for such payment for the price of the agreed unit, the Purchaser shall comply with all procedures and methods of transfer of foreign currency set by the Seller for the purpose of purchasing such unit.</pre>
<pre class="tab">1.2 In determining the transfer date to be specified by the Seller under the Condominium Sale and Purchase Agreement, Section 4.4, paragraph 1 or paragraph 2, as a case may be, both Parties agree that all of the remaining amounts unpaid by the Purchaser, regardless of a due date of those amounts, shall become due on such transfer date. In this regard, the Purchaser shall take a registration procedures to accept the transfer of ownership in the unit from the Seller and shall make a whole payment for the sale price of the agreed unit, monies according to Section 3.1.1 (1) and (2) of this Memorandum, any other monies specified in the Sale Contract and other costs relevant to the registration of the transfer to the Seller on such transfer date. In further, the Seller shall transfer the ownership in the unit to the Purchaser once the Purchaser makes the payment for the sale price of the unit and follows all conditions under the Sale Contract.</pre>
<pre><b>2. <span class="under">Condominium and Units completed by Complying With the Agreement</span></b></pre>
<pre class="tab">The Seller agrees to complete the construction of the condominium and units in accordance with the Condominium Sale and Purchase Agreement within the time period of transfer of ownership specified in the Condominium Sale and Purchase Agreement, Section 4.4, paragraph 1. Once the construction is completed with regard to the details specified in the Condominium Sale and Purchase Agreement within such specified time period, the Purchaser and the Seller agree to make a registration of transfer of ownership in the unit and pay the remaining sale price and any other monies incurring from the transfer, as specified in the Sale Contract, to the Seller. Otherwise, in the case where the construction is completed prior to the transfer date determined in the Condominium Sale and Purchase Agreement, Section 4.4, paragraph 1 and the Purchaser wishes to accept the transfer before the specified date, both Parties agree that the remaining amounts the Purchaser has not paid, regardless of a due date of those amounts, shall become due on such transfer date. In this regard, the Purchaser shall take a registration procedures to accept the transfer of ownership in the unit from the Seller and shall make a whole payment for the sale price of the agreed unit, other monies according to Section 3.1.1 (1) and (2) of this Memorandum and any other costs relevant to with the registration of transfer to the Seller on such transfer date. In which case, the Purchaser may give consent in writing to the Seller to fix any defect(s), as the case maybe, after the registration. In further, the Seller shall transfer the ownership in the unit to the Purchaser once the Purchaser makes the payment for the sale price of the unit and follows all conditions under the Sale Contract. In further, the Seller shall transfer the ownership in the unit to the Purchaser, provided that, the Purchaser makes the payment for the sale price of the unit and follows all conditions under the Sale Contract.</pre>
<pre class="tab">If any defect exists after the transfer of ownership, the Seller shall fix such defect within a specific time period under the Condominium Sale and Purchase Agreement.</pre>
<pre><b>3. <span class="under">Condominium Juristic Person, Sinking Funds and Common Expenses</span></b></pre>
<pre class="tab">3.1 The Purchaser acknowledges and understands that the units under the Condominium Sale and Purchase Agreement that are of the being sold condominium shall be registered as condominium and the condominium juristic person shall be set for managing the common properties and the usage of the unit in the condominium to accord with the regulations and laws, the Purchaser shall agree to be bound by the following acts:</pre>
<pre class="tab2">3.1.1 To strictly comply with rules and regulations of the condominium juristic person in using the personal properties and the common properties, as well as, obligations under the laws of condominium, and, as a joint owner of the common properties, to share payments for costs of the common management fee, maintenance, fix of the common properties to the said condominium juristic person ,or the Seller, if the Seller paid such costs, with regard to the following terms.</pre>
<pre class="tab2">(1)  to pay to the sinking funds for reserving for management and maintenance of the common properties based on an area of the agreed unit (including balcony/ spaces for installing its compressor of air conditioner/ internal and external spaces of the unit that are deemed to be personal property/ other spaces connecting with the unit), according to an agreement of transfer of ownership in the unit, at the rate of………………………Baht per Sq.m. (……………………………………) by paying at once on the date of transfer of ownership in the agreed unit in order to deposit into the condominium juristic person’s account opened with a bank or an another financial institution for usage. and</pre>
<pre class="tab2">(2) to pay for the common expenses based on the area of the agreed unit (including balcony/ spaces for installing its compressor of air conditioner/ internal and external spaces of the unit that are deemed to be personal property/ other spaces connecting with the unit), according to an agreement of transfer of ownership in the unit, at the rate of………………………Baht per Sq.m. (……………………………………) by an annual payment made in advance, however, such rate and expenses may be alternative due to the facts and determination of the condominium juristic person with regard to the laws of condominium.</pre>
<pre><b>4. Others</b></pre>
<pre class="tab">This Memorandum of Agreement is governed and construed by the laws of Kingdom of Thailand. If there is an English-translated version of this Memorandum, both Parties shall construe and execute Thai version.</pre>
<pre class="tab">This Agreement has been executed in duplicate originals. Both parties have read and understand through all of the Agreement and agree that the Agreement is correct as well as conveying their intents and wishes completely.</pre>
<pre class="tab">IN WITNESS WHEREOF each undersigned party sets its signature and seal (if any) hereto before the witnesses and each party holds one original.</pre>



<br/>
<br><br>
<table border="0" width="100%">';
$html .= $sign.'
    <tr>
        <td><br><br><br></td>
    </tr>
    <tr>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Witness</td>
		<td width="10%"></td>
		<td width="5%">Sign</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">Witness</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
	</tr>
</table>
<pagebreak resetpagenum="1"></pagebreak>
<table width="100%" height="100%">
    <tr>
        <td align="center" valign="middle"><img src="'.$unitPlanImg.'" style="height:90px;" class="ninety" width="752px"></td>
    </tr>
</table>
<pagebreak resetpagenum="1"></pagebreak>
<table width="100%" height="100%">
    <tr>
        <td align="center" valign="middle"><img src="'.$floorPlanImg.'" style="height:90px;" class="ninety" width="752px"></td>
    </tr>
</table>


';

include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");



// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>