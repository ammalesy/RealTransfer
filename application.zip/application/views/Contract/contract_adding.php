<!--contract-->
        <script type="text/javascript">
            function cusCheckbegin(custno, fullname) {
                $('#cus-id').val(custno);
                $('#user_fullname').val(fullname);
            }

            function cusCheck1() {
                $('#cus-id').val('0');
            }

            function cusCheck2() {
                $('#cus-id2').val('0');
            }

            function cusCheck3() {
                $('#cus-id3').val('0');
            }

            function cusCheck4() {
                $('#cus-id4').val('0');
            }

        </script>
<div class="make-contract-form">
    <div class="content">
        <div class="content-header">
           <? 
            $from=$_GET["from"];
            if ($from == "over")
            {
            ?>
                <a href="<?php echo BASE_DOMAIN; ?>overdue/booking" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <?
            }
            else
            {
            ?>
                <a href="<?php echo BASE_DOMAIN; ?>booking/view" class="ic-back"><?php echo image_asset('image/back.png',NULL,array('title'=>'Back')); ?></a>
            <?
            }
            ?>
            
            <span class="title-header">Make Contract</span>
            <input type="radio" class="people filled-in" id="people" name="TypeCon" value="people" <?=($type==='people' || empty($type))?'checked="checked"':''?>/>
            <label for="people">บุคคลทั่วไป</label>
            <!-- <input type="radio" class="company filled-in" id="company" name="TypeCon" value="people" <?=($type==='company')?'checked="checked"':''?> disabled="disabled"/>
            <label for="company">นิติบุคคล</label> -->
        </div>
        <form class="form-horizontal" id="validateSubmitForm" method="post" autocomplete="off" action="<?php echo BASE_URL; ?>/contract/record/<?php echo $bookCode; ?>">
            <div class="customer-detail">
                <div class="row">
                    <div class="col l4 title-info">Customer Detail</div>
                    <div class="col l8 form-info">
                        <div class="quotation-number left-content show-detail">
                            Quotation Number : <span class="query-result"><?php echo $quoCode; ?></span>
                        </div>
                        <div class="booking-number right-content show-detail">
                            Booking Number : <span class="query-result"><?php echo $bookCode; ?></span>
                        </div>
                        <input type="hidden" name="Paymentmonth" value="<?=$TotalDownMonth?>" />
                        <?php
                            $comma = '';
                            $allCus = '';
                            foreach($list_customer as $customer):
                                $allCus .= $comma.'{value: "'.$customer->cus_id.'",label: "'.$customer->fullname.'"}';
                                if($comma==='') $comma = ',';
                            endforeach;
                            $allCus = '['. $allCus . ']';
                        ?>
                        <div class="input-field left-content">
                            <input id="user_fullname" type="text" class="validate" name="user_fullname1" value="<?=$cusList[0]?>" onkeypress="JavaScript:cusCheck1();">
                            <label for="user_fullname">Customer Name #1</label>
                            <input type="hidden" name='cusid[]' id="cus-id" value="" />
                        </div>
                        <div class="input-field right-content">
                            <input id="user_fullname2" type="text" class="validate" name="user_fullname1" value="<?=$cusList[1]?>" onkeypress="JavaScript:cusCheck2();">
                            <label for="user_fullname2">Customer Name #2</label>
                            <input type="hidden" name='cusid[]' id="cus-id2" value="" />
                        </div>
                        <div class="input-field left-content">
                            <input id="user_fullname3" type="text" class="validate" name="user_fullname1" value="<?=$cusList[2]?>" onkeypress="JavaScript:cusCheck3();">
                            <label for="user_fullname3">Customer Name #3</label>
                            <input type="hidden" name='cusid[]' id="cus-id3" value="" />
                        </div>
                        <div class="input-field right-content">
                            <input id="user_fullname4" type="text" class="validate" name="user_fullname1" value="<?=$cusList[3]?>" onkeypress="JavaScript:cusCheck4();">
                            <label for="user_fullname4">Customer Name #4</label>
                            <input type="hidden" name='cusid[]' id="cus-id4" value="" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="quotation-detail">
                <div class="row">
                    <div class="col l4 title-info">Quotation & Booking Detail</div>
                    <div class="col l8 form-info">
                        <div class="left-content margin-bottom-30 show-detail">
                            Quotation Number : <span class="query-result"><?php echo $quoCode; ?></span>
                        </div>
                        <div class="right-content margin-bottom-30 show-detail">
                            Date : <span class="query-result"><?php echo $todayQuo; ?></span>
                        </div>
                        <div class="left-content show-detail">
                            Unit Number : <span class="query-result"><?php echo $un_name; ?></span>
                        </div>
                        <div class="right-content show-detail">
                            Direction : <span class="query-result"><?php echo $un_direction; ?></span>
                        </div>
                        <div class="left-content show-detail">
                            Building : <span class="query-result"><?php echo $building_name; ?></span>
                        </div>
                        <div class="right-content show-detail">
                            Area : <span class="query-result"><?php echo $unit_type_area_sqm; ?> Sq.m.</span>
                        </div>
                        <div class="left-content show-detail">
                            Unit Type : <span class="query-result"><?php echo $unit_type_name; ?></span>
                        </div>
                        <div class="right-content show-detail">
                            Price per sq.m. : <span class="query-result"><?php echo number_format(floatval(str_replace(',', '', str_replace('.', '', $pr_selling_sqm))),2)?>&nbsp;Baht</span>
                        </div>
                        <div class="left-content show-detail">
                            Room Type : <span class="query-result"><?php echo $room_type_name?></span>
                        </div>
                        <div class="right-content show-detail">
                            Total Unit Price : <span class="query-result total-price"><?php echo number_format(floatval(str_replace(',', '', str_replace('.', '', $pr_asking_price))),2)?>&nbsp;Baht</span>
                        </div>
                    </div>
                </div>
                <div class="row promotion-detail">
                    <div class="col l4 title-info">Promotion</div>
                    <div class="col l8 form-info">
                        <div class="current-promotion">
                            Current Promotion : 
                            <ul>
<!--
                                <li>Gift voucher power buy มูลค่า 70,000 บาท</li>
                                <li>Gift voucher power buy มูลค่า 70,000 บาท</li>
                                <li>Gift voucher power buy มูลค่า 70,000 บาท</li>
-->
                                <?php foreach($list_promotion as $promotion) { ?>
                                         <li> <?= $promotion-> pm_name; ?> </li>
                                <?php } ?>
                            </ul> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="payment-schedule bg-gray">
                <div class="row">
                    <div class="col l4 title-info">Payment Schedule</div>
                    <div class="col l8 form-info">
                        <div class="payment-schedule-content left">
                            Unit Resevation (เงินจอง) <span class="payment-price"><?php echo number_format($BookingFee ,2) . ' THB'; ?></span>
                        </div>
                        <div class="payment-schedule-content left padding-top">
                            Signing Contract (เงินทำสัญญา) <span class="payment-price"><?php echo number_format($ContractFee ,2) . ' THB'; ?></span>
                        </div>
                        <div class="payment-schedule-content left padding-top">
                            Resevation and Signing Contract installment (เงินจอง + เงินทำสัญญา) <span class="payment-price"><?php echo number_format($BookingFee+$ContractFee, 2) . ' THB'; ?></span>
                        </div>
                        <div class="payment-schedule-content left padding-top">
                            Installment Fee : Down Payment <?php echo $qtDetail->qt_total_months;?> months (ผ่อนดาวน์  <?php echo $qtDetail->qt_total_months?> เดือน)  <span class="payment-price"><?php echo number_format($qtDetail->qt_avg_installment ,2) . ' THB/Month'; ?></span>
                        </div>
                        <div class="payment-schedule-content left padding-top">
                            Total Installment Fee <span class="payment-price"><?php echo number_format($qtDetail->qt_avg_installment*$qtDetail->qt_total_months,2) . ' THB'; ?></span>
                        </div>
                        <div class="payment-schedule-content left padding-top border-none">
                            Total of Down Payment <span class="payment-price"><?php echo number_format($qtDetail->qt_total_down_payment,2) . ' THB'; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tranfer-of-ownership bg-blue">
                <div class="row">
                    <div class="col l4 title-info">&nbsp;</div>
                    <div class="col l8 form-info">
                        <div class="tranfer left">
                            Tranfer of  Ownership (โอนกรรมสิทธ์) <span class="payment-price"><?php echo number_format($TransferPayment,2) . ' THB'; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="submit-actions">
                <button type="submit" class="waves-effect waves-light btn btn-submit"><i class="fa fa-check-circle"></i> Submit</button>
                <a href="<?php echo BASE_DOMAIN.'booking/view'; ?>" class="waves-effect waves-light btn btn-discard"><i class="fa fa-times"></i> Discard</a>
<!--            </div>-->

<?php if (!empty($qtDetail->qt_avg_installment)) {
} else {
$qtArr = (array)$qtDetail;
for($i=1;$i<=20;$i++):
    if(!empty($qtArr['qt_installment'.$i])) {
        $arr   = explode('-',$qtArr['qt_months_installment'.$i]);
        $month = ($arr[0]===$arr[1])?$arr[0]:$qtArr['qt_months_installment'.$i];
    $down  = $arr[1]-$arr[0]+1;
    echo '
    <tr>
        <td width="517px"><font size="2">Installment Fee : Down Payment '.$month.' months (ผ่อนดาวน์  '.$down.' เดือน) </font></td>
        <td width="150px" align="right"><font size="2">'.number_format($qtArr['qt_installment'.$i] ,2).'</font></td>
        <td width="90px"><font size="2">&nbsp;Baht/Month</font></td>
    </tr>';
    }
endfor;
                                                
echo '
<tr>
    <td width="517px"><font size="2">Total Installment Fee  </font></td>
    <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_total_down_payment-$qtDetail->qt_booking_fee-$qtDetail->qt_contract_fee ,2).'</font></td>
    <td width="90px"><font size="2">&nbsp;Baht </font></td>
</tr>
<tr>
    <td colspa="3"><br></td>
</tr>
<tr>
    <td width="517px"><font size="2">Total of Down Payment </font></td>
    <td width="150px" align="right"><font size="2">'.number_format($qtDetail->qt_total_down_payment,2).'</font></td>
    <td width="90px"><font size="2">&nbsp;Baht</font></td>
</tr>';
} ?>
                <input type="hidden" value="<?php echo $room_type_id; ?>"  id="referredroomtype" name="referredroomtype">        
                <input type="hidden" value="<?php echo $creditcontent; ?>"  id="promotioncredit" name="promotioncredit"> 
                <input type="hidden" name="projectid" value="<?=$Project?>" />
                <input type="hidden" name="buildingid" value="<?=$Building?>" />
                <input type="hidden" name="unitnumber" value="<?=$un_name?>" />
                <input type="hidden" name="unitnumberid" value="<?=$Number?>" />
                <input type="hidden" name="contractfee" value="<?=$ContractFee?>" />
                <input type="hidden" name="Balloon" value="<?=$Balloon?>" />
                <input type="hidden" name="BalloonFee" value="<?=$BalloonFee?>" />
                <input type="hidden" name="InstallmentFee" value="<?=$InstallmentFee?>" />
                <input type="hidden" name="BalloonMonth" value="<?=$BalloonMonthText?>" />
            </div>
        </form>
    </div>
</div>    
    
		
<div class="clearfix"></div>
    
<script type="text/javascript">
    

    $('#tbcreditoption').css('display','none');
jQuery(':checkbox[type="checkbox"]').each(function() 
    {        
       if ($(this).is(":checked")) 
       {
         if ( $(this).val() == 'CrCard' ) $('#tbcreditoption').css('display','block');
       }      
    });        
    

jQuery(':checkbox[type="checkbox"]').click(function(){
    var stop=true;
    jQuery(':checkbox[type="checkbox"]').each(function() 
    {        
       if ($(this).is(":checked")) 
       {
         if ( $(this).val() == 'CrCard' ) stop=false;
       }      
    });        
    $('#tbcreditoption').css('display',stop==false?'block':'none');
   });
    $(function() { 

	//ถ้าใช้งานจริง ส่วนนี้จะถูกเขียนขึ้น เป็นไฟล์ .js เมื่อมีการเพิ่ม/แก้ไข ข้อมูลสมาชิก 
	var autoCompleteData = <?php echo $allCus?>;
//	var autoCompleteData2 = <?php echo $allCus2?>;
//	var autoCompleteData3 = <?php echo $allCus3?>;
//    var autoCompleteData4 = <?php echo $allCus4?>;
	//--

	if(!autoCompleteData) var autoCompleteData = new Array();
	$( "#user_fullname" ).autocomplete({
	  minLength: 3,
	  source: autoCompleteData,
	  focus: function( event, ui ) {
          $( "#user_fullname" ).val( ui.item.label );
          $( "#cus-id" ).val( ui.item.value );
          return false;
	  },
	  select: function( event, ui ) {
		$( "#user_fullname" ).val( ui.item.label );
		$( "#cus-id" ).val( ui.item.value );
		return false;
	  }
	})
	.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	  return $( "<li>" )
		.append( "<a>" + item.label + "</a>" )
		.appendTo( ul );
	};
	
//	if(!autoCompleteData2) var autoCompleteData2 = new Array();
	$( "#user_fullname2" ).autocomplete({
	  minLength: 3,
	  source: autoCompleteData,
	  focus: function( event, ui ) {
		$( "#user_fullname2" ).val( ui.item.label );
		$( "#cus-id2" ).val( ui.item.value );
		return false;
	  },
	  select: function( event, ui ) {
		$( "#user_fullname2" ).val( ui.item.label );
		$( "#cus-id2" ).val( ui.item.value );
		return false;
	  }
	})
	.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	  return $( "<li>" )
		.append( "<a>" + item.label + "</a>" )
		.appendTo( ul );
	};
	
//	if(!autoCompleteData3) var autoCompleteData3 = new Array();
	$( "#user_fullname3" ).autocomplete({
	  minLength: 3,
	  source: autoCompleteData,
	  focus: function( event, ui ) {
		$( "#user_fullname3" ).val( ui.item.label );
		$( "#cus-id3" ).val( ui.item.value );
		return false;
	  },
	  select: function( event, ui ) {
		$( "#user_fullname3" ).val( ui.item.label );
		$( "#cus-id3" ).val( ui.item.value );
		return false;
	  }
	})
	.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	  return $( "<li>" )
		.append( "<a>" + item.label + "</a>" )
		.appendTo( ul );
	};
    
//	if(!autoCompleteData4) var autoCompleteData4 = new Array();
	$( "#user_fullname4" ).autocomplete({
	  minLength: 3,
	  source: autoCompleteData,
	  focus: function( event, ui ) {
		$( "#user_fullname4" ).val( ui.item.label );
		$( "#cus-id4" ).val( ui.item.value );
		return false;
	  },
	  select: function( event, ui ) {
		$( "#user_fullname4" ).val( ui.item.label );
		$( "#cus-id4" ).val( ui.item.value );
		return false;
	  }
	})
	.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	  return $( "<li>" )
		.append( "<a>" + item.label + "</a>" )
		.appendTo( ul );
	};
	});

   function ChooseAuthorize(value)
   {
       $('#authorize').val(value);
    } 
    cusCheckbegin('<?php echo $bookCust?>','<?php echo $bookby?>');
</script>
