<?php 
$html = '
<style>
.tablefone{
  font-size:12pt;
}
.classTable{
  border-bottom-width:1px; 
  border-bottom-style:solid;
}
.classTable2{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
}
.classTable3{
  border-bottom-width:1px; 
  border-bottom-style:solid; 
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.classTable5{
  
  border-left-width:1px;
  border-left-style:solid;
}
.classTable6{
  border-left-width:1px;
  border-left-style:solid;
  border-right-width:1px; 
  border-right-style:solid;
}
.text{
	line-height: 180%;
	text-align:initial;
	
}
span.under{
	border-bottom-width:1px; 
  	border-bottom-style:solid; 
}
.footer{
 	position:fixed;
    bottom:0;
}
.formatText {
    text-align: left;
}

.alignNormal{
    text-align: normal; 
}
table.oneLine{
    border: 1px solid black;
    border-collapse: collapse;
}
.ninety     { image-orientation: 90deg }

</style>

<pageheader name="MyHeader1" content-left="" content-center="" content-right="สัญญาเลขที่ '.$id.' แผ่นที่ {PAGENO} จาก {nbpg}" header-style="font-size: 10pt; font-weight: bold; color: #000000;" line="on" />

<!--หน้าปก-->
<br>
<br>
<table border="0" width="750px">
    <tr>
        <td colspan="7" align="center"><img src="'.$projectImage.'" style="width:180px;"></td>
    </tr>
    
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">สัญญาจะซื้อจะขายห้องชุด</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">โครงการ '.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">CONDOMINIUM</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">ห้องชุดเลขที่</td>
    </tr>
    <tr>
        <td colspan="7" align="center">
            <table>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" align="center">'.$un_name.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="font-size:22pt" width="50px">ชั้นที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$Floorname.'</td>
        <td style="font-size:22pt" width="50px">แบบ</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$room_type_name.'</td>
        <td style="font-size:22pt" width="50px">พื้นที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$unit_type_area_sqm.'</td>
        <td style="font-size:22pt" width="50px">ตรม.</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    
   
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">ฉบับนี้สำหรับ</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">ผู้จะขาย</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:12pt">โครงการ '.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:12pt">'.$companyName.' '.$ownerAddr.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="550px"></td>
                    <td style="font-size:12pt;" width="50px">ผู้ตรวจสอบ</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.$nameSale.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="590px"></td>
                    <td style="font-size:12pt;" width="10px">วันที่</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($contractDate))).'</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<!--หน้าปก-->
<!--หน้าปก-->
<br>
<br>
<table border="0" width="750px">
    <tr>
        <td colspan="7" align="center"><img src="'.$projectImage.'" style="width:180px;"></td>
    </tr>
    
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">สัญญาจะซื้อจะขายห้องชุด</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:22pt">โครงการ '.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">CONDOMINIUM</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">ห้องชุดเลขที่</td>
    </tr>
    <tr>
        <td colspan="7" align="center">
            <table>
                <tr>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" align="center">'.$un_name.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td style="font-size:22pt" width="50px">ชั้นที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$Floorname.'</td>
        <td style="font-size:22pt" width="50px">แบบ</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$room_type_name.'</td>
        <td style="font-size:22pt" width="50px">พื้นที่</td>
        <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:30pt;" width="183px" align="center">'.$unit_type_area_sqm.'</td>
        <td style="font-size:22pt" width="50px">ตรม.</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    
   
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">ฉบับนี้สำหรับ</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:30pt">ผู้จะซื้อ</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
     <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:12pt">โครงการ '.$pj_name.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center" style="font-size:12pt">'.$companyName.' '.$ownerAddr.'</td>
    </tr>
    <tr>
        <td colspan="7" align="center">&nbsp;</td>
    </tr>
    
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="550px"></td>
                    <td style="font-size:12pt;" width="50px">ผู้ตรวจสอบ</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.$nameSale.'</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="7">
            <table border="0" align="right" width="750px">
                <tr>
                    <td  width="590px"></td>
                    <td style="font-size:12pt;" width="10px">วันที่</td>
                    <td style="border-bottom-width:1px; border-bottom-style:solid; font-size:12pt;" width="150px">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($contractDate))).'</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<!--หน้าปก-->

<pagebreak resetpagenum="1" value="off"></pagebreak>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<table border="1" align="center" width="700px">
    <tr>
        <td width="500px">
            <table border="0" width="500px">
                <tr>
                    <td width="20px">โครงการ</td>
                    <td width="350px" align="center" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;">'.$pj_name.'</td>
                    <td width="50px">ห้องชุดเลขที่</td>
                    <td width="80px" align="center" style="border-bottom-width:1px; border-bottom-style:solid; font-size:18pt;">'.$un_name.'</td>
                </tr>
            </table>
            <table align="center">
                <tr>
                    <td >ลูกค้า <span class="under">'.$nameCus.'</span></td>
                    
                </tr>
            </table>
            <table align="center">
                <tr>
                    <td>พนักงานขาย <span class="under">'.$nameSale.'</span></td>
                </tr>
            </table>
            <table align="center">
                <tr>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
    
</table>
<pagebreak resetpagenum="1" ></pagebreak>
<setpageheader name="MyHeader1" value="on" show-this-page="1" />
<table width="700" border="0" align="center"  cellspacing="0">
    <tr>
        <td align="center"><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
	<tr>
		<td align="center"><h5>สัญญาจะซื้อจะขายห้องชุด</h5></td>
	</tr>
	<tr>
		<td align="center"><h5>โครงการอาคารชุด '.$pj_name.'</h5></td>
	</tr>
</table>
<br>
<pre class="tab">สัญญาฉบับนี้ทำขึ้น ณ สำนักงานขายโครงการอาคารชุด '.$pj_name.' '.$projectAddr.' เมื่อวันที่ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($lastContractDate))).'</span> ระหว่าง <b>'.$companyName.'</b> โดย '.$ownerName.' ผู้รับมอบอำนาจกระทำการแทนบริษัทฯ ปรากฏตามหนังสือมอบอำนาจลงวันที่ '.$this->dateformat->thaiDate(date('Y-m-d', strtotime($ownerDate))).' สัญชาติ ไทย ที่อยู่/ที่ตั้งสำนักงาน '.$ownerAddr.' ซึ่งต่อไปในสัญญานี้เรียกว่า “ ผู้จะขาย” ฝ่ายหนึ่ง กับ</pre>
'.$cusDetail.'
<pre>ซึ่งต่อไปสัญญานี้เรียกว่า <b>“ผู้จะซื้อ”</b> อีกฝ่ายหนึ่ง</pre>
<br/>
<p class="tab">คู่สัญญาทั้งสองฝ่ายตกลงทำสัญญาต่อกัน โดยมีข้อความดังต่อไปนี้</p>
<P class="tab"><b>ข้อ 1. คำรับรองของผู้ขาย</b></p>
<p class="tab">1.1 ผู้จะขายรับรองว่า ผู้จะขายเป็นผู้มีกรรมสิทธิ์ในที่ดินซึ่งเป็นที่ตั้งของอาคารชุดตามโฉนดที่ดิน '.$landLocation.' '.$projectAddr.' เนื้อที่ประมาณ '.$landArea.' โดยที่ดินแปลงดังกล่าว</p>
<p class="tab"><input type="checkbox"/> ได้จำนองไว้กับ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> / ได้จดทะเบียนบุริมสิทธิในที่ดินให้แก่ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> โดยที่ดินแปลงดังกล่าวเป็นประกันหนี้จำนอง / หนี้บุริมสิทธิจำนวนเงิน <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> บาท</p>
<p class="tab"><input type="checkbox" checked="checked"/> ไม่มีจำนอง / ไม่มีบุริมสิทธิ</p>
<p class="tab">1.2  ผู้จะขายรับรองว่า อาคารชุดและห้องชุด เป็นกรรมสิทธิ์ของผู้จะขาย โดยอาคารดังกล่าว</p>
<p class="tab"><input type="checkbox"/> มีการจำนองรวมอยู่กับที่ดิน ไว้กับ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> / ได้จดทะเบียนบุริมสิทธิในอาคารรวมกับที่ดิน ให้แก่ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> โดยจำนวนเงิน ที่ประกันหนี้จำนอง/หนี้บุริมสิทธิเท่ากับจำนวนเงินตามข้อ 1.1
<p class="tab"><input type="checkbox" checked="checked"/> ไม่มีจำนอง / ไม่มีบุริมสิทธิ</p>
<p class="tab">1.3 ผู้จะขายได้รับใบอนุญาตให้ก่อสร้างอาคารจากเจ้าพนักงานท้องถิ่นตามกฎหมายว่าด้วยการควบคุมอาคารเรียบร้อยแล้ว ตามใบอนุญาตเลขที่ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> ลงวันที่ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> ขณะนี้ อาคารชุด หรือได้ขออนุญาตก่อสร้างไว้กับ เจ้าพนักงานท้องถิ่นตามมาตรา 39 ทวิ แห่ง พระราชบัญญัติควบคุมอาคาร พ.ศ. 2522</p>
<p class="tab"><input type="checkbox" checked="checked"/> อยู่ในระหว่างการก่อสร้าง เมื่อได้ก่อสร้างแล้วเสร็จจะนำไปจดทะเบียนเป็นอาคารชุด</p>
<p class="tab"><input type="checkbox"/> ได้ก่อสร้างเสร็จแล้ว อยู่ในระหว่างการนำไปจดทะเบียนอาคารชุด</p>

<pre class="tab"><b>ข้อ 2. ข้อตกลงจะซื้อจะขาย</b></pre>
<pre class="tab">2.1 ผู้จะขายตกลงจะขาย และผู้จะซื้อตกลงจะซื้อห้องชุดในอาคารชุด '.$pj_name.' จำนวน <span class="under"> 1 </span> ห้องชุดดังนี้</pre>
<pre class="tab2">2.1.1 ห้องชุดเลขที่ <span class="under"> '.$un_name.' </span> ชั้นที่ <span class="under"> '.$Floorname.' </span> เนื้อที่ <span class="under"> '.$unit_type_area_sqm.' </span> ตารางเมตร
<pre class="tab">2.2 นอกจากกรรมสิทธิ์ในห้องชุดตามข้อ 2.1 แล้วยังรวมถึง ทรัพย์ส่วนกลาง ซึ่งผู้จะซื้อมีสิทธิ ใช้สอยร่วมกันกับเจ้าของ ห้องชุดอื่นๆ ดังต่อไปนี้</pre>
<pre class="tab2">2.2.1  ทรัพย์ตามที่พระราชบัญญัติอาคารชุด พ.ศ. 2522  และที่แก้ไขเพิ่มเติมกำหนดให้ถือว่าเป็นทรัพย์ ส่วนกลาง</pre>
<pre class="tab2">2.2.2  ที่ดินที่ตั้งอาคารชุดประมาณ '.$landArea.'</pre>
<pre class="tab2">2.2.3  สิ่งอำนวยความสะดวกต่างๆ ที่ผู้จะซื้อจะได้รับ โดยผู้จะขายมีความผูกพันที่จะต้อง นำไปจดทะเบียนเป็นทรัพย์ ส่วนกลางมีรายละเอียดปรากฏตามเอกสารแนบท้ายสัญญา</pre>
<br/>
<pre class="tab"><b>ข้อ 3. ราคาจะซื้อจะขาย</b></pre>
<pre class="tab">3.1 ผู้จะซื้อและผู้จะขายตกลงจะซื้อจะขายห้องชุดตามข้อ 2. จำนวน  1  ห้องชุด  ในราคาตารางเมตรละ <span class="under">'.number_format(floatval(str_replace(',', '', $pr_selling_sqm)),2).'</span> บาท (<span class="under">'.$Currency->bahtThai(floatval(str_replace(',', '', $pr_selling_sqm))).'</span>)  รวมเป็นเงินทั้งสิ้น <span class="under">'.number_format($qt_unit_price,2).'</span> บาท (<span class="under">'.$Currency->bahtThai($qt_unit_price).'</span>)</pre>
<pre class="tab">3.2 ในกรณีที่อาคารชุดยังดำเนินการก่อสร้างไม่แล้วเสร็จ ต่อมาเมื่อมีการก่อสร้างแล้วเสร็จปรากฏว่า มีเนื้อที่ห้องชุดเพิ่มขึ้น หรือลดลงจากจำนวนที่ระบุไว้ในสัญญา คู่สัญญาตกลงคิดราคาห้องชุดส่วนที่เพิ่มขึ้นหรือลดลงใน ราคาต่อหน่วยตามที่กำหนดในข้อ 3.1 และให้นำราคาห้องชุดในส่วนที่เพิ่มขึ้นหรือลดลงไปเพิ่มหรือลดลงจากราคา ห้องชุดตามข้อ 3.1 และจำนวนเงินที่ต้องชำระตามข้อ 4.2 ต่อไป</pre>
<br />
<pre class="tab"><b>ข้อ 4. การชำระเงินและการโอนกรรมสิทธิ์</b></pre>
<pre class="tab">4.1 คู่สัญญาตกลงให้ถือเอาเงินที่ผู้จะซื้อได้ชำระไว้ในวันที่จอง เมื่อวันที่ <span class="under"> '.$this->dateformat->thaiDate(date('Y-m-d', strtotime($bookingDate))).'</span> จำนวน <span class="under">'.number_format($BookingFee,2).'</span> บาท (<span calss="under">'.$Currency->bahtThai($BookingFee).'</span>) และเงินที่ผู้จะซื้อได้ชำระในวันทำสัญญานี้ จำนวน <span class="under">'.number_format($ContractFee,2).'</span> บาท (<span class="under">'.$Currency->bahtThai($ContractFee).'</span>) รวมเงินที่ ผู้จะซื้อได้ชำระให้แก่ผู้จะขายไปแล้วทั้งสิ้น จำนวน <span class="under"> '.number_format($BookingFee+$ContractFee ,2) .' </span> บาท (<span class="under">'.$Currency->bahtThai($BookingFee+$ContractFee).'</span>) เป็นการชำระราคาค่าห้องชุดตามข้อ 3.1 ส่วนหนึ่ง</pre>
<pre class="tab" align="left">4.2 ผู้จะซื้อตกลงชำระค่าห้องชุดที่เหลือ จำนวน <span class="under">'.number_format($qt_unit_price-($BookingFee+$ContractFee),2).'</span> บาท
(<span class="under">'.$Currency->bahtThai($qt_unit_price-($BookingFee+$ContractFee)).'</span>) โดยแบ่งชำระเป็นงวด ๆ ดังนี้</pre>
'.$htmlTotalDownMonth.' 
<pre class="tab">4.3 ในการชำระเงินค่าห้องชุด ผู้จะซื้อจะต้องนำไปชำระให้แก่ผู้จะขาย ณ ภูมิลำเนาของ ผู้จะขายที่ปรากฏในสัญญานี้ หากมีการเปลี่ยนแปลงภูมิลำเนาให้ถือเอาภูมิลำเนาที่ผู้จะขายได้แจ้งให้ทราบเป็นหนังสือเป็นที่ชำระ และผู้จะขายต้องออกหลักฐานเป็น หนังสือลงลายมือชื่อผู้จะขายหรือผู้รับเงินให้แก่ผู้จะซื้อ</pre>
<pre class="tab">4.4 ผู้จะขายรับรองว่าจะดำเนินโครงการอาคารชุดให้แล้วเสร็จ พร้อมที่จะโอนกรรมสิทธิ์ในห้องชุดให้แก่ผู้จะซื้อภายในวันที่ '. $this->dateformat->thaiDate(date('Y-m-d', strtotime($projectDate))) .' โดยผู้จะขายจะแจ้งกำหนดวันจดทะเบียนโอนกรรมสิทธิ์ในห้องชุดให้ผู้จะซื้อทราบล่วงหน้าไม่น้อยกว่า 30 (สามสิบ) วัน</pre>
<pre class="tab">ผู้จะซื้อจะรับโอนกรรมสิทธิ์ในห้องชุดต่อเมื่อผู้จะขายได้ก่อสร้างอาคารและห้องชุดถูกต้องครบถ้วนตามสัญญาแล้ว ในกรณีที่ผู้จะซื้อแจ้งความประสงค์เป็นหนังสือว่าจะขอรับโอนกรรมสิทธิ์ก่อนเวลาที่ผู้จะขายกำหนดตามวรรคแรก ผู้จะขายจะไปดำเนิน การโอนกรรมสิทธิ์ให้แก่ผู้จะซื้อภายใน 7 (เจ็ด) วันนับแต่วันที่ได้รับแจ้งจากผู้จะซื้อ</pre>
<pre class="tab">4.5  ในระหว่างที่สัญญานี้มีผลใช้บังคับ ผู้จะซื้อมีสิทธิโอนสิทธิตามสัญญานี้ให้บุคคลอื่นโดยบอกกล่าวเป็นหนังสือแก่ผู้จะขาย โดยผู้จะขายตกลงจะไม่เรียกร้องค่าใช้จ่ายใดๆ เพิ่มขึ้น  ทั้งนี้ ผู้จะขายจะต้องจัดให้ผู้รับโอนได้รับโอนไปซึ่งสิทธิและหน้าที่</pre>
<br>
<pre class="tab"><b>ข้อ 5.  การก่อสร้างอาคาร</b></pre>
<pre class="tab">5.1  ผู้จะซื้อตกลงว่า หากผู้จะขายมีความจำเป็นต้องแก้ไขเปลี่ยนแปลงแบบแปลน แผนผัง และรายละเอียดของอาคารชุด และห้องชุด รวมถึงทรัพย์สินส่วนกลาง เพื่อให้เป็นไปตามข้อกำหนดของทางราชการในการอนุญาตให้ดำเนินการก่อสร้าง หรือตามความ เหมาะสมของผู้จะขาย ผู้จะซื้อตกลงยินยอมให้ ผู้จะขายดำเนินการแก้ไขเปลี่ยนแปลงดังกล่าวได้ทันที โดยไม่ต้องแจ้งให้ผู้จะซื้อทราบ และไม่ถือว่าผู้จะขายเป็นฝ่ายผิดสัญญา</pre>
<pre class="tab">5.2  ลักษณะของห้องชุด วัสดุและอุปกรณ์ที่ใช้ในการก่อสร้างและประกอบเป็นห้องชุด ผู้จะขายจะต้องสร้างตามแบบแปลน และใช้วัสดุอุปกรณ์ตามชนิด ขนาด ประเภท และคุณภาพ ตามแผนผังแบบแปลนและรายการประกอบแบบแปลนของห้องชุดที่ได้รับ อนุญาตจากพนักงานเจ้าหน้าที่ และต้องมีมาตรฐานไม่ต่ำกว่ามาตรฐานที่กำหนดไว้ตามกฎหมาย</pre>
<pre class="tab">5.3  ลักษณะ ยี่ห้อ ชนิด รุ่น คุณภาพ ขนาด สีของวัสดุ ผิวพื้น ผิวผนัง ผิวเพดาน หลังคา สุขภัณฑ์ต่างๆ ประตู หน้าต่าง และอุปกรณ์ประกอบหน้าต่างตามมาตรฐานของผลิตภัณฑ์นั้นๆ</pre>
<pre class="tab">5.4  หากผู้จะขายไม่สามารถหาวัสดุตามที่กำหนดไว้จากท้องตลาดได้ ผู้จะขายจะใช้วัสดุที่มีคุณภาพดีกว่าหรือเทียบเท่ากับ วัสดุที่ระบุไว้ในสัญญานี้ มาใช้ทำการก่อสร้างแทนก็ได้ โดยไม่ถือว่าผู้จะขายผิดสัญญา</pre>
<pre class="tab">5.5  ก่อนจดทะเบียนโอนกรรมสิทธิ์ห้องชุด กรรมสิทธิ์ห้องชุดยังเป็นของผู้จะขาย ผู้จะซื้อไม่มีสิทธิดำเนินการใดๆ ในห้องชุด ทั้งสิ้น เว้นแต่จะได้รับความยินยอมเป็นหนังสือจากผู้จะขาย</pre>
<pre class="tab">5.6  ในกรณีที่การก่อสร้างต้องหยุดชะงักลงโดยมิใช่ความผิดของผู้จะขาย ผู้จะซื้อยินยอมให้ผู้จะขายขยายระยะเวลาก่อสร้าง ตามสัญญาออกไปได้ แต่ไม่เกินระยะเวลาที่การก่อสร้างต้องหยุดชะงัก โดยผู้จะขายต้องแจ้งเหตุดังกล่าวพร้อมพยานหลักฐานเป็นหนังสือ ให้ผู้จะซื้อทราบภายใน 7 (เจ็ด) วันนับแต่เหตุนั้นได้สิ้นสุดลง หากผู้จะขายไม่ได้ทำการแจ้งดังกล่าวให้ถือว่า ผู้จะขายได้สละสิทธิ์การ ขยายเวลาทำการก่อสร้างออกไป ระยะเวลาที่ผู้จะขายขอขยายนั้นจะขอขยายเกินหนึ่งปีไม่ได้</pre>
<pre class="tab">5.7  ผู้จะขายเป็นผู้ดำเนินการติดตั้งมาตรวัดปริมาตร และปริมาณการใช้สาธารณูปโภคทั้งในส่วนกลางและส่วนที่แยกต่อภาย ในห้องชุด</pre>
<pre class="tab">สำหรับมาตราวัดในส่วนที่แยกต่อภายในห้องชุด ผู้จะขายจะเป็นผู้ดำเนินการขอติดตั้ง โดยผู้จะขายจะชำระค่าธรรมเนียม และค่าใช้จ่ายในการติดตั้งไปก่อน และเมื่อผู้จะขายได้โอนกรรมสิทธิ์ห้องชุดให้แก่ ผู้จะซื้อ พร้อมทั้งได้โอนมาตรวัดให้เป็นชื่อของ ผู้จะซื้อแล้ว ผู้จะขายจะเรียกเก็บค่าธรรมเนียมและค่าใช้จ่ายดังกล่าวจากผู้จะซื้อต่อไป</pre>
<br>
<pre class="tab"><b>ข้อ 6.  ค่าใช้จ่ายในการจดทะเบียนโอนกรรมสิทธิ์</b></pre>
<pre class="tab">ค่าภาษีเงินได้ ค่าภาษีธุรกิจเฉพาะ และค่าอากรแสตมป์ ในการโอนกรรมสิทธิ์ห้องชุดผู้จะขายเป็นผู้จ่าย ส่วนค่าธรรมเนียม ในการจดทะเบียนสิทธิและนิติกรรมในห้องชุด ผู้จะซื้อและผู้จะขายตกลงออกกันคนละครึ่ง</pre>
<br>
<pre class="tab"><b>ข้อ 7.  เบี้ยปรับ ดอกเบี้ยผิดนัด และการบอกเลิกสัญญา</b></pre>
<pre class="tab">7.1 หากผู้จะซื้อผิดนัดการชำระเงินตามที่กำหนดไว้ในข้อ 4. ผู้จะซื้อยินยอมให้ผู้จะขายเรียกดอกเบี้ยผิดนัดในอัตราร้อยละ 7.5 (เจ็ดจุดห้า) ต่อปี ของจำนวนเงินที่ค้างชำระแต่รวมกันแล้วต้องไม่เกินร้อยละ 10 (สิบ) ของราคาห้องชุดที่ได้ทำสัญญาจะซื้อจะขาย</pre>
<pre class="tab">7.2 ในกรณีผู้จะซื้อผิดนัดชำระราคาที่ตกลงให้ชำระก่อนการโอนกรรมสิทธิ์ ผู้จะขายมีสิทธิบอกเลิกสัญญาได้ ดังนี้</pre>
<pre class="tab2">7.2.1 ผิดนัดชำระราคาดังกล่าวในกรณีตกลงชำระกันงวดเดียว</pre>
<pre class="tab2">7.2.2 ผิดนัดชำระราคาดังกล่าวสามงวดติดต่อกัน ในกรณีตกลงชำระกันตั้งแต่ 24 (ยี่สิบสี่) งวดขึ้นไป</pre>
<pre class="tab2">7.2.3 ผิดนัดชำระราคาในอัตราร้อยละ 12.5 (สิบสองจุดห้า) ของจำนวนราคาดังกล่าวในกรณีตกลงชำระกันน้อยกว่า 24 (ยี่สิบสี่) งวด</pre>
<pre class="tab2">ก่อนบอกเลิกสัญญา ผู้จะขายต้องมีหนังสือบอกกล่าวแจ้งผู้จะซื้อให้นำเงินที่ค้างมาชำระภายในเวลาไม่น้อยกว่า 30 (สามสิบ) วันนับแต่วันที่ผู้จะซื้อได้รับหนังสือ และผู้จะซื้อเพิกเฉยเสีย ไม่ปฏิบัติตามหนังสือบอกกล่าวนั้น ให้ถือว่าผู้จะซื้อผิดสัญญา ผู้จะขายมีสิทธิริบเงินมัดจำหรือเงินอื่นใดที่ผู้จะซื้อได้ชำระให้มาแล้วทั้งหมดได้ทันที</pre>
<pre class="tab">7.3  หากผู้จะขายไม่โอนกรรมสิทธิ์ในห้องชุดให้แก่ผู้จะซื้อภายในกำหนดเวลาตามข้อ 4. จะขายยินยอมให้ผู้จะซื้อดำเนินการ ดังนี้ </pre>
<pre class="tab2">7.3.1  ให้ผู้จะซื้อมีสิทธิบอกเลิกสัญญาโดยผู้จะขายยินยอมคืนเงินที่ผู้จะซื้อได้ชำระไปแล้วทั้งหมดพร้อมดอกเบี้ย ในอัตรา ร้อยละ 7.5 (เจ็ดจุดห้า) ต่อปี และไม่เป็นการตัดสิทธิผู้จะซื้อที่จะฟ้องเรียกร้องค่าเสียหายอย่างอื่น</pre>
<pre class="tab2">7.3.2  ในกรณีที่ผู้จะซื้อไม่ใช้สิทธิบอกเลิกสัญญาตามข้อ 7.3.1 ผู้จะขายยินยอมให้ผู้จะซื้อปรับเป็นรายวันในอัตราร้อยละ 0.01 (ศูนย์จุดศูนย์หนึ่ง) ของราคาห้องชุดที่ได้ทำสัญญาจะซื้อจะขาย แต่รวมกันแล้วไม่เกินร้อยละ 10 (สิบ) แต่หากผู้จะซื้อ ได้ใช้สิทธิในการปรับครบร้อยละ 10 (สิบ) ของราคาห้องชุดแล้ว และผู้จะซื้อเห็นว่าผู้จะขายไม่อาจปฏิบัติตามสัญญาต่อไปได้ ให้ผู้จะซื้อมีสิทธิบอกเลิกสัญญาได้</pre>
<pre class="tab2">7.3.3  ในกรณีผู้จะขายไม่สามารถดำเนินโครงการอาคารชุดต่อไปได้ เนื่องจากเหตุสุดวิสัย ผู้จะขายยินยอมคืนเงินที่ ผู้จะซื้อได้ชำระไปแล้วทั้งหมดพร้อมดอกเบี้ยในอัตราดอกเบี้ยสูงสุดประเภทเงินฝากประจำของธนาคารกรุงไทย จำกัด (มหาชน) นับแต่ วันที่ได้รับเงินจากผู้จะซื้อ ทั้งนี้ ไม่เป็นการตัดสิทธิผู้จะซื้อที่เรียกค่าเสียหายอย่างอื่น แต่ถ้าผู้จะขายได้ใช้เงินดังกล่าวไปเป็นจำนวนเท่าใด ผู้จะขายมีสิทธิหักเงินที่ใช้ไปออกจากดอกเบี้ยที่ต้องใช้คืนได้</pre>
<br>
<pre class="tab"><b>ข้อ 8.  ความรับผิดในความชำรุดบกพร่อง</b></pre>
<pre class="tab">8.1  ผู้จะขายต้องรับผิดเพื่อความเสียหายใดๆ ที่เกิดขึ้น เนื่องจากความชำรุดบกพร่องของอาคารชุดหรือห้องชุด ในกรณี ดังต่อไปนี้</pre>
<pre class="tab2">8.1.1  กรณีที่เป็นโครงสร้างและอุปกรณ์อันเป็นส่วนประกอบอาคารที่เป็นอสังหาริมทรัพย์ในระยะเวลาไม่น้อยกว่า 5 (ห้า) ปีนับแต่วันจดทะเบียนอาคารชุด</pre>
<pre class="tab2">8.1.2  กรณีส่วนควบอื่น นอกจากกรณีตามข้อ 8.1.1 ในระยะเวลาไม่น้อยกว่า 2 (สอง) ปี นับแต่วันจดทะเบียนอาคารชุด</pre>
<pre class="tab">8.2  ผู้จะขายต้องแก้ไขความชำรุดบกพร่องของอาคารชุดที่เกิดขึ้นภายใน 30 (สามสิบ) วันนับแต่วันที่ผู้จะซื้อหรือนิติ บุคคลอาคารชุด แล้วแต่กรณี ได้แจ้งเป็นหนังสือให้ทราบถึงความชำรุดบกพร่องนั้น เว้นแต่ในกรณีที่ความชำรุดบกพร่องนั้น เป็นเรื่อง ที่จำเป็นต้องดำเนินการแก้ไขโดยเร่งด่วน ผู้จะขายต้องดำเนินการแก้ไขในทันทีที่ได้รับแจ้ง หากผู้จะขายไม่ดำเนินการแก้ไขความชำรุด บกพร่องดังกล่าวข้างต้น ผู้จะซื้อหรือนิติบุคคลอาคารชุด แล้วแต่กรณี มีสิทธิดำเนินการแก้ไขเองหรือจะให้บุคคลภายนอกแก้ไขให้ก็ได้ โดยผู้จะขายยินยอมชดใช้ค่าเสียหายและค่าใช้จ่ายในการดำเนินการแก้ไขความชำรุดบกพร่องดังกล่าว</pre>
<br>
<pre class="tab"><b>ข้อ 9.  คำบอกกล่าว</b></pre>
<pre class="tab">การบอกกล่าวใดๆ ตามสัญญานี้ให้ทำเป็นหนังสือ และแจ้งไปยังคู่สัญญาอีกฝ่ายหนึ่งตามที่อยู่ข้างต้น หรือที่อยู่อื่นตาม ที่คู่สัญญาฝ่ายใดฝ่ายหนึ่งจะได้แจ้งเป็นหนังสือให้อีกฝ่ายหนึ่งทราบ ในกรณีผู้จะขายเป็นผู้แจ้ง ให้แจ้งโดยไปรษณีย์ลงทะเบียนตอบรับ และให้ถือว่าคู่สัญญาฝ่ายที่รับแจ้งได้รับทราบตั้งแต่วันที่ได้รับหรือถือว่าได้รับหนังสือดังกล่าว</pre>
<pre class="tab">เมื่อคู่สัญญาฝ่ายใดย้ายที่อยู่ ต้องแจ้งให้อีกฝ่ายหนึ่งทราบเป็นหนังสือ</pre>
<br>
<pre class="tab"><b>ข้อ 10.  เอกสารแนบท้ายสัญญา</b></pre>
<pre class="tab">คู่สัญญาตกลงให้ถือว่าเอกสารต่างๆ แนบท้ายสัญญาซึ่งคู่สัญญาได้ลงนามกำกับไว้ทุกๆ หน้าดังต่อไปนี้ เป็นส่วนหนึ่งของ สัญญาด้วย</pre>
<pre class="tab">10.1 สำเนาหนังสือรับรองการจดทะเบียนนิติบุคคล และสำเนาหนังสือมอบอำนาจให้กระทำการแทนผู้จะขาย</pre>
<pre class="tab">10.2  สำเนาโฉนดที่ดิน</pre>
<pre class="tab">10.3  สำเนาใบอนุญาตก่อสร้าง ดัดแปลงอาคาร หรือรื้อถอนอาคาร (แบบ อ.1) หรือสำเนาใบอนุญาตรับรองการก่อสร้าง ดัดแปลงอาคาร หรือเคลื่อนย้ายอาคาร (แบบ อ.6) ตามกฎหมายว่าด้วยการควบคุมอาคาร</pre>
<pre class="tab">10.4  แผนผังอาคารชุด และหลักฐานการจดทะเบียนอาคารชุด</pre>
<pre class="tab">10.5  รายละเอียดเกี่ยวกับห้องชุด ทรัพย์ส่วนบุคคล ทรัพย์ส่วนกลาง สิ่งอำนวยความสะดวก สื่อโฆษณาทั้งข้อความและ ภาพโฆษณา</pre>
<pre class="tab">ในกรณีที่ข้อความในเอกสารแนบท้ายสัญญาขัดหรือแย้งกับข้อความในสัญญานี้ให้ใช้ข้อความในสัญญานี้บังคับ</pre>
<br>
<pre class="tab">สัญญานี้ทำขึ้นเป็น 2 (สอง) ฉบับมีข้อความถูกต้องตรงกัน คู่สัญญาได้อ่านและเข้าใจข้อความในสัญญาโดยตลอดดี แล้วจึงลงลาย มือชื่อพร้อมทั้งประทับตรา (ถ้ามี) ไว้เป็นสำคัญต่อหน้าพยาน และเก็บไว้ฝ่ายละหนึ่งฉบับ</pre>';
if($cusNum > 1)
    $html .= '<pagebreak>';
$html .= '
<br><br>
<table border="0" width="100%">';
$fontSize = $cusNum*15;
for($i=0;$i<$cusNum;$i++) $sign .= '<tr><td collspan="7">&nbsp;</td></tr>';
$sign .= '
    <tr>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">ผู้จะซื้อ</td>
		<td width="10%"></td>
		<td width="5%" align="right">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;" align="center"></td>
		<td width="10%">ผู้จะขาย</td>
	</tr>';
for($j=0;$j<$cusNum;$j++) {
    $sign .= '
	<tr>
		'.($j==0?'<td rowspan="'.$cusNum.'" align="right" style="font-size:'.$fontSize.'pt;">(</td>':'').'
		<td align="center" '.($j==$cusNum-1?'style="border-bottom-width:1px; border-bottom-style:solid;"':'').'>'.$nameCusLicenses[$j].($j<$cusNum-1?' และ':'').'</td>
		'.($j==0?'<td rowspan="'.$cusNum.'" align="left" style="font-size:'.$fontSize.'pt;">)</td>':'').'
		<td></td>
		<td align="right">'.($j==0?'(':'').'</td>
		<td align="center" '.($j==0?'style="border-bottom-width:1px; border-bottom-style:solid;"':'').'>'.($j==0?$companyName:'').'</td>
		<td align="left">'.($j==0?')':'').'</td>
	</tr>';
}
$html .= $sign.'
    <tr>
        <td><br><br><br></td>
    </tr>
    <tr>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พยาน</td>
		<td width="10%"></td>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พยาน</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
	</tr>
</table>

<pagebreak resetpagenum="1"></pagebreak>

<table align="center">
    <tr>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td align="center"><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <th align="center">รายการส่งเสริมการขาย</th>
    </tr>
    <tr>
        <th align="center">'.$pj_name.', ห้องชุดเลขที่ '.$un_name.' ชั้นที่ '.$Floorname.'</th>
    </tr>
</table>
<table align="center">
    <tr>
        <th align="center"><span class="under">'.$nameCus.' ("ผู้จะซื้อ")</span></th>
    </tr>
</table>
<br/>
'.$tablePromotion.'
<table>
    <tr>
        <td style="font-size:11pt;">เงื่อนไข: ราคาที่เสนอตามใบเสนอราคานี้ เป็นราคาโปรโมชั่นหรือส่วนลดพิเศษ ดังนั้นผู้ซื้อจะโอนสิทธิตามสัญญาจะซื้อจะขายไม่ได้จนถึงวันที่ '.$this->dateformat->thaiDate(date('Y-m-d', strtotime($deadProDate))).'</td>
    </tr>
</table>
<br><br>
<table border="0" width="100%">
    '.$sign.'
    <tr>
        <td><br><br><br></td>
    </tr>
    <tr>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พยาน</td>
		<td width="10%"></td>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พยาน</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
	</tr>
</table>

<pagebreak resetpagenum="1"></pagebreak>
<table width="700" border="0" align="center"  cellspacing="0">
    <tr>
        <td align="center" ><img src="'.$projectImage.'" style="height:90px;"></td>
    </tr>
	<tr>
		<td align="center" ><h5>บันทึกข้อตกลงแนบท้ายสัญญาจะซื้อจะขายห้องชุด</h5></td>
	</tr>
    <tr>
		<td align="center" ><h5>โครงการ'.$pj_name.'</h5></td>
	</tr>
</table>
<br>
<pre class="tab">บันทึกข้อตกลงฉบับนี้ทำขึ้น ณ สำนักงานขายโครงการอาคารชุด '.$pj_name.' ตั้งอยู่ที่ '.$projectAddr.' เมื่อวันที่ <span class="under">'.$this->dateformat->thaiDate(date('Y-m-d', strtotime($lastContractDate))).'</span> ระหว่าง</pre>
<pre class="tab">'.$companyName.' โดย  '.$ownerName.' ผู้รับมอบอำนาจกระทำการแทนบริษัทฯ ปรากฏตามหนังสือมอบอำนาจลงวันที่ '.$this->dateformat->thaiDate(date('Y-m-d', strtotime($ownerDate))).' ที่ตั้งสำนักงาน '.$ownerAddr.' ซึ่งต่อไปในสัญญานี้เรียกว่า “ผู้จะขาย” ฝ่ายหนึ่ง กับ</pre>
'.$cusDetail.'
<pre>ซึ่งต่อไปสัญญานี้เรียกว่า <b>“ผู้จะซื้อ”</b> อีกฝ่ายหนึ่ง</pre>
<pre class="tab">โดยผู้จะซื้อและผู้จะขายได้เข้าทำสัญญาจะซื้อจะขายห้องชุด ในอาคารชุด '.$pj_name.' จำนวน <span class="under"> 1 </span> ห้อง ได้แก่ ห้องชุดเลขที่ '.$un_name.' (รหัสห้องชุด '.$unit_type_name.' ) ชั้นที่ '.$Floorname.' อาคาร '.$building_name.' เนื้อที่ (รวมพื้นที่ระเบียง / พื้นที่ที่จัดให้มีไว้สำหรับวาง คอมเพรสเซอร์ของเครื่องปรับอากาศของห้องชุด / พื้นที่ทรัพย์ส่วนบุคคลทั้งภายในและภายนอกห้องชุด / พื้นที่อื่นๆ ที่ต่อเนื่องกับ ห้องชุด ตามที่ปรากฏในหนังสือกรรมสิทธิ์ห้องชุด) ประมาณ '.$unit_type_area_sqm.' ตารางเมตร ปรากฎรายละเอียดตามสัญญาจะซื้อจะขายห้องชุดใน โครงการอาคารชุด '.$pj_name.' สัญญาเลขที่ '.$id.' ฉบับวันที่ '.$ctDate.' ซึ่งต่อไปจะเรียกว่า “สัญญาจะซื้อจะขายห้องชุด” </pre>
<pre class="tab">โดยที่หลังจากการทำสัญญาจะซื้อจะขายห้องชุดแล้ว คู่สัญญาประสงค์จะทำข้อตกลงที่เกี่ยวข้องกับการจะซื้อจะขายเพิ่มเติม จากที่ได้ตกลงไว้ในสัญญาจะซื้อจะขายห้องชุด เพื่อให้ครอบคลุมรายละเอียดข้อกำหนดและเงื่อนไขที่ผู้จะขายและผู้จะซื้อได้ตกลงกันไว้</pre>
<pre>คู่สัญญาทั้งสองฝ่ายตกลงทำบันทึกข้อตกลงฉบับนี้ขึ้นมีข้อความดังต่อไปนี้</pre>
<pre><b>1. เงื่อนไข และวิธีการชำระราคา</b></pre>
<pre class="tab">1.1 ในกรณีที่ผู้จะซื้อเป็นบุคคลที่ ไม่มีถิ่นที่อยู่ถาวร หรือภูมิลำเนาที่ติดต่อได้ในประเทศไทย หรือเป็นบุคคลหรือนิติบุคคลที่ ไม่ได้ถือสัญชาติไทย หรือ เป็นนิติบุคคลที่ถือว่าเป็นนิติบุคคลต่างด้าวตามกฎหมายอาคารชุด ในการชำระเงินใดๆ ให้แก่ผู้จะขายตาม สัญญาจะซื้อจะขายห้องชุดและบันทึกนี้ (รวมเรียกว่า “สัญญาขาย”) ผู้จะซื้อตกลงจะชำระโดยโอนเงินผ่านระบบอิเล็คทรอนิคส์แบบ ที่สามารถเบิกถอนได้ทันทีมายังบัญชีธนาคารของผู้จะขาย ตามที่ผู้จะขายได้กำหนดและแจ้งให้ผู้จะซื้อทราบล่วงหน้าอย่างน้อย 2 (สอง) วันทำการ ก่อนถึงกำหนดชำระเงินในแต่ละคราว</pre>
<pre class="tab2">การชำระเงินดังกล่าวจะต้องชำระโดยบวกเพิ่มภาษีมูลค่าเพิ่ม หรือภาษีอื่นใดที่เกี่ยวข้องทั้งปวง และต้องชำระเต็มตาม จำนวนโดยไม่มีการโต้แย้งคัดค้าน หักกลบลบหนี้ หรือ หักจำนวนเงินใดๆ ออกจากจำนวนเงินดังกล่าว ในกรณีที่ผู้จะซื้อมีหน้าที่ ที่ต้องหักเงินที่ต้องชำระนั้นไว้ไม่ว่าเพื่อชำระเป็นค่าภาษี หรือค่าใช้จ่ายใดๆ ก็ตาม (เช่น ค่าใช้จ่ายในการโอนเงิน) จำนวนเงินที่ผู้จะซื้อ ต้องชำระดังกล่าวจะต้องบวกเพิ่มขึ้นอีกเพื่อให้หลังจากที่ได้มีการหักเงินดังกล่าวออกแล้ว จำนวนเงินที่ต้องชำระให้แก่ผู้จะขาย ต้องครบถ้วนไม่เปลี่ยนแปลง</pre>
<pre class="tab2">นอกจากนี้ในกรณีที่ผู้จะซื้อเป็นบุคคลหรือนิติบุคคลที่ไม่ได้ถือสัญชาติไทย หรือ เป็นนิติบุคคลที่ถือว่าเป็นนิติบุคคล ต่างด้าวตามกฎหมายอาคารชุด เงินที่จะโอนมายังบัญชีธนาคารต้องเป็นสกุลเงินตราต่างประเทศ สกุลเงินใดก็ได้ที่ไม่ใช่ สกุลเงินบาท ซึ่งจำนวนเงินดังกล่าวต้องเพียงพอที่จะแลกเปลี่ยนเงินบาทได้ตามจำนวนที่ผู้จะซื้อต้องชำระให้แก่ผู้จะขายตามสัญญานี้ ทั้งนี้ หากภาย หลังการหักชำระค่าใช้จ่ายในการแลกเปลี่ยนเงินตรา และค่าใช้จ่ายอื่นใดที่เกี่ยวข้องทั้งปวงแล้ว จำนวนเงินที่โอนมามีจำนวนน้อยกว่า จำนวนเงินบาทที่ต้องชำระตามสัญญานี้ ผู้จะซื้อยังคงต้องรับผิดชำระเงินส่วนที่ขาดแก่ผู้จะขายให้ครบถ้วนในทันที นอกจากนี้ การชำระ ราคาห้องชุดที่จะซื้อจะขายดังกล่าวนี้ ผู้จะซื้อต้องปฏิบัติตามขั้นตอนและวิธีการโอนเงินตราต่างประเทศเพื่อวัตถุประสงค์ในการซื้อห้อง ชุดที่จะซื้อจะขายตามที่ผู้จะขายกำหนดทุกประการ</pre>
<pre class="tab">1.2 ในวันกำหนดโอนกรรมสิทธิ์ที่ผู้จะขายแจ้งตามข้อ 4.4 วรรคหนึ่งของสัญญาจะซื้อจะขายห้องชุด หรือวันกำหนดโอน กรรมสิทธิ์ตามข้อ 4.4 วรรคสองของสัญญาจะซื้อจะขายห้องชุด ตามแต่กรณี คู่สัญญาตกลงให้ถือว่าจำนวนเงินทุกจำนวนที่ผู้จะซื้อ ยังมิได้ชำระ ไม่ว่าจะถึงกำหนดชำระหรือไม่ก็ตามเป็นอันถึงกำหนดชำระทุกจำนวนในวันดังกล่าว โดยผู้จะซื้อตกลงไปดำเนินการ จดทะเบียนรับโอนกรรมสิทธิ์ห้องชุดจากผู้จะขายพร้อมทั้งชำระราคาซื้อขายห้องชุดที่จะซื้อขายรวมถึงชำระเงินตาม ข้อ 3.1.1 (1) และ (2) ของบันทึกข้อตกลงนี้ ตลอดจนเงินอื่นใดที่กำหนดไว้ในสัญญาขาย และค่าใช้จ่ายอื่นๆ ที่เกี่ยวข้อในการจดทะเบียนโอนกรรมสิทธิ์ให้ แก่ผู้จะขายให้ครบถ้วนในวันโอนกรรมสิทธิ์ดังกล่าวนี้ด้วย ทั้งนี้ ผู้จะขายจะดำเนินการโอนกรรมสิทธิ์ห้องชุดให้แก่ผู้จะซื้อต่อเมื่อผู้จะซื้อ ได้ชำระราคาซื้อขายห้องชุดและปฏิบัติถูกต้องตามเงื่อนไขที่กำหนดในสัญญาขายครบถ้วนแล้ว</pre>
<pre><b>2. อาคารชุดและห้องชุดแล้วเสร็จถูกต้องตามสัญญา</b></pre>
<pre class="tab">ผู้จะขายตกลงจะก่อสร้างอาคารชุดและห้องชุดให้แล้วเสร็จถูกต้องครบถ้วนตามรายละเอียดที่ระบุในสัญญาจะซื้อจะขายห้อง ชุดภายในกำหนดเวลาในการโอนกรรมสิทธิ์ห้องชุดที่ระบุในข้อ 4.4 วรรคหนึ่งของสัญญาจะซื้อจะขายห้องชุด และเมื่อการก่อสร้างอาคาร ชุดและห้องชุดแล้วเสร็จถูกต้องครบถ้วนตามรายละเอียดที่ระบุในสัญญาจะซื้อจะขายภายในกำหนดเวลาดังกล่าวแล้ว ผู้จะซื้อและผู้จะขาย ตกลงจะไปดำเนินการจดทะเบียนโอนกรรมสิทธิ์ห้องชุดและชำระราคาซื้อขายที่เหลืออยู่ ตลอดจนจำนวนเงินอื่นใดในการโอนกรรมสิทธิ์ ตามที่ระบุในสัญญาขายให้แก่ผู้จะขายให้ครบถ้วน หรือ ในกรณีที่กำหนดการก่อสร้างอาคารชุดแล้วเสร็จก่อนกำหนดการโอนกรรมสิทธิ์ที่ กำหนดไว้ในข้อ 4.4 วรรคหนึ่งของสัญญาจะซื้อจะขายห้องชุด หากผู้จะซื้อประสงค์และตกลงกำหนดวันนัดโอนกรรมสิทธิ์ก่อนกำหนด คู่สัญญาตกลงให้ถือว่าจำนวนเงินที่ผู้จะซื้อยังมิได้ชำระ ไม่ว่าจะถึงกำหนดชำระหรือก็ตามเป็นอันถึงกำหนดชำระทั้งหมดในวันโอน กรรมสิทธิ์ดังกล่าว โดยผู้จะซื้อตกลงไปดำเนินการจดทะเบียนรับโอนกรรมสิทธิ์ห้องชุดจากผู้จะขายพร้อมทั้งชำระราคาซื้อขายห้องชุด และเงินอื่นๆ ตามที่ระบุไว้ในข้อ 3.1.1 (1) และ (2) ของบันทึกข้อตกลงนี้ ตลอดจนค่าใช้จ่ายอื่นๆ ที่เกี่ยวข้องในการจดทะเบียนโอน กรรมสิทธิ์ให้แก่ผู้จะขายให้ครบถ้วน ในวันโอนกรรมสิทธิ์ด้วย โดยผู้จะซื้ออาจยินยอมเป็นลายลักษณ์อักษรให้ผู้จะขายเข้าดำเนินการ ซ่อมแซมความชำรุดบกพร่องเล็กน้อยภายหลังการโอนกรรมสิทธิ์ก็ได้ ทั้งนี้ผู้จะขายจะดำเนินการโอนกรรมสิทธิ์ห้องชุดให้แก่ผู้จะซื้อต่อ เมื่อผู้จะซื้อได้ชำระราคาซื้อขายห้องชุดและปฏิบัติถูกต้องตามเงื่อนไขที่กำหนดในสัญญาขายครบถ้วนแล้วเท่านั้น</pre>
<pre class="tab">ทั้งนี้ หากมีความชำรุดบกพร่องเกิดขึ้นหลังการโอนกรรมสิทธิ์แล้ว ผู้จะขายต้องดำเนินการซ่อมแซมความชำรุดบกพร่อง ดังกล่าวให้แล้วเสร็จตามกำหนดระยะเวลาตามที่ระบุในสัญญาจะซื้อจะขายทุกประการ</pre>
<pre><b>3. นิติบุคคลอาคารชุด เงินกองทุน และค่าใช้จ่ายทรัพย์ส่วนกลาง</b></pre>
<pre class="tab">3.1 ผู้จะซื้อรับทราบและเข้าใจดีว่า ห้องชุดตามสัญญาจะซื้อจะขายห้องชุดอยู่ในโครงการที่จะขายจะจดทะเบียนเป็นอาคารชุด และจะได้มีการจัดตั้งนิติบุคคลอาคารชุดเพื่อดูแลจัดการทรัพย์สินส่วนกลางและการใช้ ห้องชุดในโครงการตามข้อบังคับและตามกฎหมาย ดังนั้น หลังจากที่ผู้จะซื้อได้รับโอนกรรมสิทธิ์ห้องชุดที่จะซื้อขายเรียบร้อยแล้ว ผู้จะซื้อตกลงยินยอมผูกพันตนดังต่อไปนี้</pre>
<pre class="tab2">3.1.1 ปฏิบัติตามกฎระเบียบข้อบังคับของนิติบุคคลอาคารชุดในการใช้ห้องชุดทรัพย์ส่วนบุคคล และทรัพย์ส่วนกลางโดย เคร่งครัดรวมทั้งจะปฏิบัติตามหลักเกณฑ์เงื่อนไขแห่งกฎหมายว่าด้วยอาคารชุด และผู้จะซื้อในฐานะเจ้าของร่วมในทรัพย์ส่วนกลางตกลง ยินยอมร่วมเฉลี่ยชำระเงินค่าใช้จ่ายที่เกิดจากการบริการและการจัดการ ดูแล บำรุงรักษา ซ่อมแซมอาคารชุด และทรัพย์ส่วนกลางให้แก่นิติ บุคคล อาคารชุดที่จะได้จัดตั้งขึ้น หรือผู้จะขายในได้ชำระค่าใช้จ่ายดังกล่าวไปแล้ว ตามรายละเอียดดังนี้</pre>
<pre class="tab2">(1) ชำระเงินเข้ากองทุนเพื่อใช้สำรองในการบริหารและการดูแลรักษาทรัพย์ส่วนกลางจ่ายตามพื้นที่ของห้องชุดที่จะซื้อจะ ขาย (รวมพื้นที่ระเบียง / พื้นที่ที่จัดให้มีไว้สำหรับวางคอมเพรสเซอร์ของเครื่องปรับอากาศของห้องชุด / พื้นที่ทรัพย์ส่วนบุคคลทั้งภายใน และภายนอกห้องชุด / พื้นที่อื่นๆ  ที่ต่อเนื่องกับห้องชุด) ตามที่ปรากฏในหนังสือแสดงกรรมสิทธิ์ห้องชุด ในอัตราตารางเมตรละ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;'.$coffers.'&nbsp;&nbsp;&nbsp;&nbsp;</span> บาท (<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;'.$Currency->bahtThai($coffers).'&nbsp;&nbsp;&nbsp;&nbsp;</span>) โดยชำระเพียงหนึ่งครั้งในวันโอนกรรมสิทธิ์ห้องชุดที่จะซื้อขายเพื่อนำเข้า บัญชีเงินฝากของนิติบุคคลอาคารชุดที่ทำไว้กับ ธนาคารหรือสถาบันการเงินสำหรับใช้จ่ายต่อไป </pre>
<pre class="tab2">(2) ชำระค่าใช้จ่ายทรัพย์ส่วนกลางจ่ายตามพื้นที่ของห้องชุดที่จะซื้อจะขาย (รวมพื้นที่ระเบียง/พื้นที่ที่จัดให้มีไว้สำหรับวาง คอมเพรสเซอร์ของเครื่องปรับอากาศของห้องชุด/พื้นที่ทรัพย์ส่วนบุคคลทั้งภายในและภายนอกห้องชุด/พื้นที่อื่นๆ ที่ต่อเนื่องกับห้องชุด) ตามที่ปรากฏในหนังสือแสดงกรรมสิทธิ์ห้องชุด ในอัตราเดือนละ <span class="under">&nbsp;&nbsp;&nbsp;&nbsp;'.$amenities.'&nbsp;&nbsp;&nbsp;&nbsp;</span> บาท (<span class="under">&nbsp;&nbsp;&nbsp;&nbsp;'.$Currency->bahtThai($amenities).'&nbsp;&nbsp;&nbsp;&nbsp;</span>) ต่อตารางเมตร โดยชำระล่วงหน้าปีละ 1(หนึ่ง) ครั้ง อัตราและจำนวนเงินค่าใช้จ่ายนี้อาจมีการเปลี่ยนแปลงได้ตามความเป็นจริงและตามที่นิติบุคคลอาคาร ชุดจะกำหนด ทั้งนี้ ภายใต้กฎหมายว่าด้วยอาคารชุด</pre>
<pre><b>4. ข้อตกลงอื่น</b></pre>
<pre class="tab">บันทึกข้อตกลงนี้ให้ใช้บังคับและตีความตามกฎหมายแห่งราชอาณาจักรไทย และในกรณีที่ได้มีการทำคำแปลภาษาอังกฤษของ บันทึกข้อตกลงนี้ คู่สัญญาทั้งสองฝ่ายตกลงให้การตีความ และบังคับเป็นไปตามบันทึกข้อตกลงฉบับภาษาไทย</pre>
<pre class="tab">บันทึกข้อตกลงนี้ทำขึ้นเป็นสองฉบับมีข้อความถูกต้องตรงกัน คู่สัญญาได้อ่านและเข้าใจข้อความในสัญญาโดยตลอดแล้วเห็น ว่าถูกต้องตรงตามความประสงค์ จึงลงลายมือชื่อพร้อมทั้งประทับตรา (ถ้ามี) ไว้เป็นสำคัญต่อหน้าพยาน และต่างเก็บไว้ฝ่ายละหนึ่งฉบับ</pre>



<br/>
<br><br>
<table border="0" width="100%">
    '.$sign.'
    <tr>
        <td><br><br><br></td>
    </tr>
    <tr>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พยาน</td>
		<td width="10%"></td>
		<td width="5%">ลงชื่อ</td>
		<td width="30%" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td width="10%">พยาน</td>
	</tr>
	<tr>
	<td></td>
	</tr>
	<tr>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
		<td></td>
		<td align="right">(</td>
		<td align="center" style="border-bottom-width:1px; border-bottom-style:solid;"></td>
		<td align="left">)</td>
	</tr>
</table>
<pagebreak resetpagenum="1"></pagebreak>
<table width="100%" height="100%">
    <tr>
        <td align="center" valign="middle"><img src="'.$unitPlanImg.'" style="height:90px;" class="ninety" width="752px"></td>
    </tr>
</table>
<pagebreak resetpagenum="1"></pagebreak>
<table width="100%" height="100%">
    <tr>
        <td align="center" valign="middle"><img src="'.$floorPlanImg.'" style="height:90px;" class="ninety" width="752px"></td>
    </tr>
</table>


';?>

    <?php


include("application/third_party/MPDF/mpdf.php");
$nameFile = "$conid.pdf";
$mpdf=new mPDF('UTF-8'); 
$mpdf->SetAutoFont();
$mpdf->SetDisplayMode('fullpage');
//$mpdf->setHeader("สัญญาเลขที่ $id แผ่นที่ {PAGENO} จาก {nbpg}");



// LOAD a stylesheet
$stylesheet = file_get_contents('application/third_party/MPDF/mpdfstyleA4.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output($nameFile,'I');

exit;

?>