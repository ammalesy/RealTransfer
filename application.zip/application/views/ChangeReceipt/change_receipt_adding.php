<div class="change-receipt-payment">
    <div id="menu" class="hidden-print hidden-xs">
        <?php
            include "application/views/menu_left.php";
            if (strpos($permission->pm_receipt,'6') === false) {
                alert_redirect('โปรดตรวจสอบสิทธิ การใช้งาน','/authen');	
            }
        ?>
    </div>

    <div class="content" align='center'>
        <div class="innerAll spacing-x2">
            <!-- Form -->
            <form method="post" action="<?= BASE_DOMAIN; ?>changereceipt/changing">
                <input type="hidden" name="unit" value="<?=$unit ?>"/>
                <input type="hidden" name="reason" value="<?=$reason ?>"/>
                <!-- Widget -->
                <div class="widget widget-inverse">
                    <!-- Widget heading -->
                    <div class="widget-head">
                        <h4 class="heading">Change Receipt</h4>
                    </div>
                    <!-- // Widget heading END -->
                    <div class="widget-body" style="padding-left:0px;padding-right:0px;padding-bottom:0px;padding-top:0px;">
                        <table border="0" width="100%">
                            <tr>
                                <td>
                                    <div class="widget-body">
                                        <table border="0" cellspacing='2px' cellpadding='2px' width="100%" style="border:0px solid #F7F7F3">
                                            <tr>
                                                <td style="width:100px">
                                                    <label class="control-label" for="User">Customer</label>
                                                </td>
                                                <td width="170px">
                                                    <input id="user_fullname" class="form-control" disabled="disabled" value="<?=$fullName?>" required="required" />
                                                </td>
                                                <td></td>
                                                <td width="145px">
                                                    <label class="radio">
                                                        <input type="radio" class="radio" name="Payfor" disabled="disabled" value="Booking Fee" <?=$payFor=='Booking Fee' ? 'checked': '' ?>/> &nbsp;Booking fee</label>
                                                </td>
                                                <td width="175px">
                                                    <input id="Booking" name="Booking" disabled="disabled" class="form-control" placeholder="Booking Number" style='width:170px' value="<?=$bkCode ?>" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <label class="control-label" for="User">Receipt No.</label>
                                                </td>
                                                <td>
                                                    <input name="rcCode" readonly class="form-control" placeholder="Receipt Number" value="<?=$rcCode ?>" />
                                                </td>
                                                <td></td>
                                                <td>
                                                    <label class="radio">
                                                        <input type="radio" class="radio" name="Payfor" disabled="disabled" value="Contract Fee" <?=$payFor=='Contract Fee' ? 'checked': '' ?>/>&nbsp;Contract fee</label>
                                                </td>
                                                <td>
                                                    <input id="contract" name="contract" disabled="disabled" class="form-control" placeholder="Contract Number" style='width:170px' value="<?=$ctCode ?>" />
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>
                                                    <label class="radio">
                                                        <input type="radio" class="radio" name="Payfor" disabled="disabled" value="Installment Fee" <?=$payFor=='Installment Fee' ? 'checked': '' ?>/>&nbsp;Installment fee</label>
                                                </td>
                                                <td>
                                                    <input name="InstallmentTime" disabled="disabled" class="form-control" id="InstallmentCode" placeholder="Installment Number" style='width:170px' value="<?=$imCode ?>" />
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    </td>
                            </tr>
                            <!--                            <tr><td colspan="5" style='padding-top:30px'></td></tr>-->
                            <tr>
                                <td colspan="5">
                                    <input type="hidden" name="building" value="<?=$building?>" />
                                    <?php 
                                        $data['definefee'] = $definefee;
                                        $data['allCus'] = $allCus;
                                        $data['banklist'] = $banklist;
                                        $data['credittypelist'] = $credittypelist;
                                        $data['action'] = FALSE;
//                                        $data['submit'] = 'Submit';
//                                        $data['cancel'] = 'installment/listInstallment/'.$ctCode;
                                        if(strpos($permission->pm_receipt,'4') !== false) {
                                            $data['receipt'] = 'yes';
                                            $data['receiptList'] = $receiptList;
                                        }
                                        $this->load->view("form_payment", $data); 
                                    ?>
                                </td>
                            </tr>
                        </table>
                        <!-- // Form actions END -->
                        <div class="form-actions" align="center">
<!--                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#confirm"><i class="fa fa-check-circle"></i> Confirm</button>-->
                            <button type="submit" class="btn btn-primary" id="btSubmit"><i class="fa fa-check-circle"></i> Submit</button>
                            <a href="<?= BASE_DOMAIN; ?>changereceipt">
                                <button type="button" class="btn btn-default"><i class="fa fa-times"></i> Cancel</button>
                            </a>
                        </div>
                        <br/>
                    </div>
                    <!-- // Widget END -->
                </div>
                <!--
                <div class="modal fade" id="confirm" data-backdrop="static">

                    <div class="modal-dialog">
                        <div class="modal-content">

                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h3 class="modal-title">Confirm</h3>
                            </div>

                            <div class="modal-body padding-none">

                                <div class="bg-gray innerAll border-bottom">
                                    <textarea class="border-none form-control padding-none" style="background-color:#f2f2f2;width:100%" rows="5" placeholder="Write your Reason change receipt here..." name="reason" required></textarea>
                                </div>

                            </div>

                            <div class="innerAll border-top" style="text-align:left">
                                <label ><input type='checkbox' class="checkbox-inline" style="width:20px; height:20px;" required="required" title="Please confirm check box"> Check box to confirm</label>
                                <br/>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary" id="btSubmit"><i class="fa fa-check-circle"></i> Submit</button>
                                    <a data-dismiss="modal" class="btn btn-default"><i class="fa fa-fw icon-crossing"></i> Cancel</a>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                </div>
-->
            </form>
            <!-- // Form END -->
        </div>
    </div>
</div>

    <!-- // Content END -->

    <div class="clearfix"></div>
    <!-- // Sidebar menu & content wrapper END -->


    <!-- Global -->
    <script>
        var basePath = '',
            commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
            rootPath = '<?php echo BASE_DOMAIN; ?>',
            DEV = false,
            componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

        var primaryColor = '#cb4040',
            dangerColor = '#b55151',
            infoColor = '#466baf',
            successColor = '#8baf46',
            warningColor = '#ab7a4b',
            inverseColor = '#45484d';

        var themerPrimaryColor = primaryColor;
    </script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/lib/jquery.inputmask.bundle.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/custom/inputmask.user.js"></script>
    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/jquery-ui-1.10.2.custom.css" />

    <script src="<?php echo BASE_DOMAIN; ?>assets/js/jquery-ui-1.10.2.custom.min.js"></script>
    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/themes/js/allCusData.js"></script>
</body>

</html>