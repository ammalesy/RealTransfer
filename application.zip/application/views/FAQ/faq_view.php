<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $title; ?>
    </title>

    <!-- Meta -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

    <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/admin/module.admin.page.tables.min.css" />

    <script src="<?= BASE_DOMAIN; ?>assets/components/library/jquery/jquery.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/library/jquery/jquery-migrate.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/library/modernizr/modernizr.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/plugins/less-js/less.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/charts/flot/assets/lib/excanvas.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/plugins/browser/ie/ie.prototype.polyfill.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/library/jquery-ui/js/jquery-ui.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/plugins/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js?v=v1.2.3"></script>

    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/js/jquery.dataTables.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/TableTools/media/js/TableTools.min.js"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/lib/extras/ColVis/media/js/ColVis.min.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/DT_bootstrap.js?v=v1.2.3"></script>
    <script src="<?= BASE_DOMAIN; ?>assets/components/modules/admin/tables/datatables/assets/custom/js/datatables.init.js?v=v1.2.3"></script>

    <script>
        $(window).load(function () {
            $('#loading').remove();
            $('#dataTable').css('visibility', 'visible');
        });
    </script>
</head>

<body>

    <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/js/tooltip/wz_tooltip.js"></script>
    <div class="navbar navbar-fixed-top navbar-primary main" role="navigation">
        <?php
			include "application/views/menu_top.php";
			?>
    </div>

    <div id="menu" class="hidden-print hidden-xs">
        <?php include "application/views/menu_left.php"; ?>
    </div>


    <div id="content">

        <div class="innerAll spacing-x2" id="loading">
            <div class="widget widget-inverse">
                <div class="widget-head">
                    <h2 class="heading">loading...</h2>
                </div>
            </div>
        </div>
        <div class="innerAll spacing-x2" style="visibility: hidden;" id="dataTable">


            <!-- Widget -->
            <div class="widget widget-inverse">
                <div class="widget-head">
                    <h4 class="heading">FAQ</h4>
                </div>
                <div class="widget-body padding-bottom-none">
                    <?php if (strpos(' '.$permission->pm_faq,'1')): ?>
                    <div class="row">
                        <a class="btn btn-inverse" href="<?= BASE_DOMAIN ?>FAQ/update">Update</a>
                    </div>
                    <br/>
                    <?php endif; ?>
                    <?php foreach($list as $index => $row): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <label style="font-size:15px"><?= ($index+1).'.'.$row->fq_question ?></label>
                            <div class="row">
                                <div class="col-md-11" style="padding-left:40px">
                                    <label><?= $row->fq_answer ?></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br/>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- // Widget END -->



        </div>
    </div>
    <!-- // Content END -->

    <div class="clearfix"></div>
    <!-- // Sidebar menu & content wrapper END -->

    <div id="footer" class="hidden-print"></div>
    <!-- // Footer END -->


    <!-- // Main Container Fluid END -->




    <!-- Global -->
    <script>
        var basePath = '',
            commonPath = '<?php echo BASE_DOMAIN; ?>assets/',
            rootPath = '<?php echo BASE_DOMAIN; ?>',
            DEV = false,
            componentsPath = '<?php echo BASE_DOMAIN; ?>assets/components/';

        var primaryColor = '#cb4040',
            dangerColor = '#b55151',
            infoColor = '#466baf',
            successColor = '#8baf46',
            warningColor = '#ab7a4b',
            inverseColor = '#45484d';

        var themerPrimaryColor = primaryColor;
    </script>

    <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>
    <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
</body>

</html>