
        

        <script src="<?php echo BASE_DOMAIN; ?>assets/components/library/bootstrap/js/bootstrap.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/nicescroll/jquery.nicescroll.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/breakpoints/breakpoints.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/animations.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/fuelux-checkbox/fuelux-checkbox.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/lib/js/bootstrap-select.js?v=v1.2.3"></script>
<!--
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-select/assets/custom/js/bootstrap-select.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/tables/classic/assets/js/tables-classic.init.js?v=v1.2.3"></script>
-->
<!--        <script src="<?php echo BASE_DOMAIN; ?>assets/components/plugins/holder/holder.js?v=v1.2.3"></script>-->
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.main.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/sidebar.collapse.init.js?v=v1.2.3"></script>
<!--        <script src="<?php echo BASE_DOMAIN; ?>assets/components/helpers/themer/assets/plugins/cookie/jquery.cookie.js?v=v1.2.3"></script>-->
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/core.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/core/js/realcrm.js"></script>

<!--
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-switch/assets/lib/js/bootstrap-switch.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-switch/assets/custom/js/bootstrap-switch.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/uniform/assets/lib/js/jquery.uniform.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/uniform/assets/custom/js/uniform.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/modals/assets/js/bootbox.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/modals/assets/js/modals.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/notifications/gritter/assets/lib/js/jquery.gritter.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/notifications/gritter/assets/custom/js/gritter.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/editors/wysihtml5/assets/lib/js/wysihtml5-0.3.0_rc2.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/editors/wysihtml5/assets/lib/js/bootstrap-wysihtml5-0.0.2.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/editors/wysihtml5/assets/custom/wysihtml5.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/wizards/assets/lib/jquery.bootstrap.wizard.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/wizards/assets/custom/js/form-wizards.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/jasny-fileupload/assets/js/bootstrap-fileupload.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/button-states/button-loading/assets/js/button-loading.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/select2/assets/lib/js/select2.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/select2/assets/custom/js/select2.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/custom/inputmask.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-datepicker/assets/lib/js/bootstrap-datepicker.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-datepicker/assets/custom/js/bootstrap-datepicker.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-timepicker/assets/lib/js/bootstrap-timepicker.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/bootstrap-timepicker/assets/custom/js/bootstrap-timepicker.init.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/colorpicker-farbtastic/assets/js/farbtastic.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/colorpicker-farbtastic/assets/js/colorpicker-farbtastic.init.js?v=v1.2.3"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>   
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/lib/jquery.inputmask.bundle.min.js?v=v1.2.3"></script>
        <script src="<?php echo BASE_DOMAIN; ?>assets/components/modules/admin/forms/elements/inputmask/assets/custom/inputmask.user.js"></script>
        <link rel="stylesheet" href="<?php echo BASE_DOMAIN; ?>assets/css/jquery-ui-1.10.2.custom.css" />
        <script src="<?php echo BASE_DOMAIN; ?>assets/js/jquery-ui-1.10.2.custom.min.js"></script>
        <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/themes/js/allCusData.js"></script>	
-->
        <!--Import jQuery before materialize.js-->
<!--        <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>-->
        <script type="text/javascript" src="<?php echo BASE_DOMAIN; ?>assets/components/library/materialize/js/materialize.min.js"></script>
    </body> 
</html>
