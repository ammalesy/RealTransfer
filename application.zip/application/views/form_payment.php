<script>
        function setReceiptAmount(that)
        {
            console.log("welurtydirhg");
            var index = 0;
            $('.selectReceipt').each(function(){
                var val = $(this).val().split(',');
                $('.receiptID:eq('+index+')').val(val[0]);
                $('.Receiptamount:eq('+index+')').val(val[1]);
                givethechange_Receipt('<?=$definefee?>');
                index++;
            });
            console.log(<?=$definefee?>);
        }
</script>

<?php 
$opCardBank = '';
foreach($banklist as $bank) {
    $opCardBank .= '<option value="'.$bank->b_id.'">'.$bank->bank_name_th.'</option>';
}

$opCardType = '';
foreach($credittypelist as $type) {
    $opCardType .= '<option value="'.$type->ct_id.'">'.$type->ct_name.'</option>';
}

$opM = '<option value="" disabled selected>MM</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option>';

$opY = '';
for($y = date('Y'); $y <= (date('Y') + 7) ;$y++) {
    $opY .= '<option value="'.$y.'">'.$y.'</option>';
}

$display = '';
if(empty($confirm)) {
    $display = 'display:none;';
}

$opBankAccount = '';
if(!empty($bankAccount)) {
    foreach ($bankAccount as $account) {
        $opBankAccount .= '<option value="'.$account->ba_id.'">'.$account->ba_name.' '.$account->ba_number.'</option>';
    }
}
?>

<div class="payment-form">
    <?php 
    if(!empty($receipt)) { 
    ?>
        <div class="payment-detail">
            <?php 
            if ($installment_paid == 'yes') { 
            ?>
                <div class="row">
                    <div class="col l12">
                        <input type="checkbox" class="filled-in cash" id="divide" value="divide" name="divide"/>
                        <label for="divide" style="font-size: 15px; font-weight: 500; color: #8bbd2c;"> Partial Payment (Please check box if this installment is not paid in full amount)</label>
                    </div>
                </div>
                <br/>
            <?php
            } 
            ?>
            <div class="row">
                <div class="col l4 title-info"><?=empty($paymentTitle)?'Payment from cancelled receipt':$paymentTitle;?></div>
                <div class="col l8 form-info">
                    <div class="receipt">
                        <input type="checkbox" class="filled-in" id="PaidReceipt" value="Receipt" />
                        <label for="PaidReceipt">receipt</label>
                        <!-- <span class="receipt-title">receipt</span> -->
                        <input type="button" id="rcAdd" value="+" onclick="RcAddRow();receiptAutocomplete();" disabled="true" style=" width: 25px; font-size: 15px;">
                        <input type="button" id="rcDel" value="-" onclick="RcRemoveRow();" disabled="true" style=" width: 25px; font-size: 15px; font-weight: bold;">
                        <div class="receipt-code-1 row">
                            <div class="cb-receipt">
                                <!-- <input type="checkbox" class="filled-in" id="PaidReceipt" checked="checked" />
                                <label for="PaidReceipt"></label> -->
                            </div>
                            <div class="receipt-code">
                                <div class="input-field">
                                    <input type="hidden" id="receiptID" class="receiptID" name="receiptID[]">
                                    <input id="receiptCode" class="receiptCode" type="text" class="validate"  onchange="setReceiptAmount(this);">
                                    <label for="receiptCode">Receipt Code</label>
                                </div>
                            </div>
                            <div class="receipt-amount">
                                <div class="input-field">
                                    <input id="receiptAmount" type="text" class="validate Receiptamount black-text" name="Receiptamount[]" readonly>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="rcGroup"></div>
                        <script type="text/javascript">
                            var rcList = '';
                            rcList += '<div class="receipt-code-1 row rcList" style="display:none">';
                                rcList += '<div class="cb-receipt"></div>';
                                rcList += '<div class="receipt-code">';
                                    rcList += '<div class="input-field">';
                                        rcList += '<input type="hidden" id="receiptID" class="receiptID" name="receiptID[]">';
                                        rcList += '<input id="receiptCode" class="receiptCode" type="text" class="validate">';
                                        rcList += '<label for="receiptCode">Receipt Code</label>';
                                    rcList += '</div>';
                                rcList += '</div>';
                                rcList += '<div class="receipt-amount">';
                                    rcList += '<div class="input-field">';
                                        rcList += '<input id="receiptAmount" type="text" class="validate Receiptamount" name="Receiptamount[]" disabled>';
                                        rcList += '<label for="receiptAmount">Amount</label>';
                                    rcList += '</div>';
                                rcList += '</div>';
                            rcList += '</div>';
                        </script>
                        <!-- <div class="receipt-code-2 row">
                            <div class="cb-receipt">
                                <input type="checkbox" class="filled-in" id="cb-receipt-2" />
                                <label for="cb-receipt-2"></label>
                            </div>
                            <div class="receipt-code">
                                <div class="input-field receipt_code">
                                    <input id="receipt_code" type="text" class="validate" disabled>
                                    <label for="receipt_code">Receipt Code</label>
                                </div>
                            </div>
                            <div class="receipt-amount">
                                <div class="input-field amount">
                                    <input id="amount" type="text" class="validate" disabled>
                                    <label for="amount">Amount</label>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    <?php 
    } 
    ?>
    <div class="payment-method">
        <div class="row">
            <div class="col l4 title-info">Payment Method</div>
            <div class="col l8 form-info">
                <div class="row cash-payment">
                    <div class="cb-receipt cb-cash">
                        <input type="checkbox" class="filled-in cash" id="PaidCash" name="Type[]" value="Cash" />
                        <label for="PaidCash">Cash</label>
                        <input type="hidden" name="pmCash" id="pmCash" class="pmCash" value="" />
                    </div>
                    <div class="input-field cash-amount right-content">
                        <input id="Cashamount" type="text" class="validate" name="Cashamount" onkeyup="givethechange_Cash(<?= $definefee ?>, this.value)">
                        <label for="Cashamount">Amount</label>
                    </div>
                    <div class="input-field bank-account left-content margin-bottom-30" style="<?=$display?>">
                        <select name="cashToAccount" id="cashToAccount" disabled>
                            <option value="" disabled selected>Select Bank Account</option>
                            <?=$opBankAccount?>
                        </select>
                    </div>
                </div>
            <?php if(!empty($credit->cc_number)): ?>
                <div class="row">
                    <input type="checkbox" class="filled-in" id="OldCredit" style="margin-top:3px" />
                    <label for="OldCredit">Use Old Credit Card</label>
                </div>
            <?php endif; ?>
                <div class="row credit-payment">
                   
                    <div class="cb-credit-card">
                        <input type="checkbox" class="filled-in credit-card" id="PaidCredit" name="Type[]" value="CrCard"/>
                        <label for="PaidCredit">Credit Card</label>
                        <input type="hidden" name="pmCard[]" class="pmCard" value="" />
						
						<input name="btnAdd" type="button" id="btnAdd" value="+" onclick="CreateNewRow();" style=" width: 25px; font-size: 15px;">
                    	<input name="btnDel" type="button" id="btnDel" value="-" onclick="RemoveRow();" style=" width: 25px; font-size:15px; font-weight: bold;">
                    </div>
                    <div class="input-field card-holder-name left-content">
                        <input id="CardHolder" type="text" class="validate CardHolder" name="CardHolder[]">
                        <label for="CardHolder" id="LBCardHolder">Card Holder Name</label>
                    </div>
                    <div class="input-field credit-type CardType right-content">
                        <select name="CardType[]" id="CardType" class="CardType" style="display:none">
                            <option value="" disabled selected>Credit Type</option>
                            <?=$opCardType?>
                        </select>
                    </div>
                    <div class="input-field credit-card-number left-content">
                        <input id="Cardno" type="text" class="validate Cardno" name="Cardno[]" maxlength="16">
                        <label for="Cardno" id="LBCardno">Credit Card Number</label>
                    </div>
                    <div class="input-field cvv right-content">
                        <input id="ApproveCode" type="text" class="validate ApproveCode" name="ApproveCode[]">
                        <label for="ApproveCode">Approve Code</label>
                    </div>
                    <div class="input-field bank left-content">
                        <select name="CardBank[]" id="CardBank" class="CardBank">
                            <option value="" selected>Bank</option>
                            <?=$opCardBank?>
                        </select>
                    </div>
                    <div class="input-field row expire right-content">
                        <label>Expire: </label>
                        <div class="col l10 offset-l2">
                            <select name= "expiremonth[]" id="expiremonth" class="expiremonth">
                                <?=$opM?>
                            </select>
                            <span class="slash">/</span>
                            <select name="expireyear[]" id="expireyear" class="expireyear">
                                <option value="" disabled selected>YY</option>
                                <?=$opY?>
                            </select>
                        </div>
                    </div>
                    <div class="clearfix"></div>
					<div class="input-field bank-account left-content" style="<?=$display?>">
                        <select name="cardToAccount[]" id="cardToAccount" class="cardToAccount" disabled>
                            <option value="" disabled selected>Select Bank Account</option>
                            <?=$opBankAccount?>
                        </select>
                    </div>
                    <div class="input-field right-content" style="<?=$display?>">
                        <input type="text" class="validate cardFee" id="cardFee" name="cardFee[]" disabled>
                        <label for="cardFee">Credit Fee</label>
					</div>
                    <div class="left-content blank"></div>
                    <div class="input-field amount-payment right-content margin-bottom-30">
                        <input id="Cardamount" type="text" class="validate Cardamount" id="Cardamount" name="Cardamount[]" onkeyup="givethechange_Credit(<?= $definefee ?>)">
                        <label for="Cardamount">Amount</label>
                    </div>
					<div class="credit-group"></div>
<!--						-->
					<script>
						var creditList = '';
						creditList += '<div class="credit-list">';
							
							creditList += '<div class="input-field card-holder-name left-content">';
								creditList += '<input id="CardHolder" type="text" class="validate CardHolder" name="CardHolder[]" id="CardHolder">';
								creditList += '<label for="CardHolder">Card Holder Name</label>';
							creditList += '</div>';
							creditList += '<div class="input-field credit-type right-content">';
								creditList += '<select name="CardType[]" id="CardType" class="CardType" style="display:none">';
									creditList += '<option value="" disabled selected>Credit Type</option>';
									creditList += '<?=$opCardType?>';
								creditList += '</select>';
							creditList += '</div>';
							creditList += '<div class="input-field credit-card-number left-content">';
								creditList += '<input id="Cardno" type="text" class="validate Cardno" name="Cardno[]" id="Cardno" maxlength="16">';
								creditList += '<label for="Cardno">Credit Card Number</label>';
							creditList += '</div>';
							creditList += '<div class="input-field cvv right-content">';
								creditList += '<input id="ApproveCode" type="text" class="validate ApproveCode" name="ApproveCode[]">';
								creditList += '<label for="ApproveCode">Approve Code</label>';
							creditList += '</div>';
							creditList += '<div class="input-field bank left-content">';
								creditList += '<select name="CardBank[]" id="CardBank" class="CardBank">';
									creditList += '<option value="" selected>Bank</option>';
									creditList += '<?=$opCardBank?>';
								creditList += '</select>';
							creditList += '</div>';
							creditList += '<div class="input-field row expire right-content">';
								creditList += '<label>Expire: </label>';
								creditList += '<div class="col l10 offset-l2">';
									creditList += '<select name= "expiremonth[]" id="expiremonth" class="expiremonth">';
										creditList += '<?=$opM?>';
									creditList += '</select>';
									creditList += '<span class="slash">/</span>';
									creditList += '<select name="expireyear[]" id="expireyear" class="expireyear">';
										creditList += '<option value="" disabled selected>YY</option>';
										creditList += '<?=$opY?>';
									creditList += '</select>';
								creditList += '</div>';
							creditList += '</div>';
							creditList += '<div class="clearfix"></div>';
							creditList += '<div class="input-field bank-account left-content" style="<?=$display?>">';
								creditList += '<select name="cardToAccount[]" id="" class="cardToAccount" disabled>';
									creditList += '<option value="" disabled selected>Select Bank Account</option>';
									creditList += '<?=$opBankAccount?>';
								creditList += '</select>';
							creditList += '</div>';
							creditList += '<div class="input-field right-content" style="<?=$display?>">';
								creditList += '<input type="text" class="validate cardFee" id="" name="cardFee[]" disabled>';
								creditList += '<label for="">Credit Fee</label>';
							creditList += '</div>';
                            creditList += '<div class="left-content blank"></div>';
							creditList += '<div class="input-field amount-payment right-content margin-bottom-30">';
								creditList += '<input id="Cardamount" type="text" class="validate Cardamount" id="Cardamount" name="Cardamount[]" onkeyup="givethechange_Credit(<?= $definefee ?>)">';
								creditList += '<label for="Cardamount">Amount</label>';
							creditList += '</div>';
						creditList += '</div>';
					</script>
<!--						-->
                    
                </div>
                <div class="row other other-payment">
                    <div class="cb-other">
                        <input type="checkbox" class="filled-in credit-card" id="PaidOther" name="Type[]" value="Other"/>
                        <label for="PaidOther">Other</label>
                    </div>
                    <!-- <div class="input-field pay-by left-content">
                        <input id="OtherBy" type="text" class="validate" name="OtherBy" >
                        <label for="OtherBy">Pay by</label>
                    </div> -->
                    <div class="input-field pay-by left-content">
                        <select id="OtherBy" name="OtherBy" required class="validate">
                            <option value="" disabled >Choose your pay by</option>
                            <option value="Check" selected>Cheque</option>
                            <option value="Transfer">Transfer</option>
                            <option value="Other">Other</option>
                        </select>
                        <label>Pay by</label>
                    </div>
                    <div class="input-field cheque-number right-content">
                        <input id="cheque-number" type="text" class="validate" name="CheckNo">
                        <label for="cheque-number">Cheque Number</label>
                    </div>
                    <div class="input-field bank-other left-content">
                        <select id="CheckBank" name="CheckBank">
                            <option value="" disabled selected>Bank</option>
                            <?=$opCardBank?>
                        </select>
                    </div>
                    <div class="input-field date_of_birth right-content">
                        <div class="row col-row">
                            <label class="date-title">Issue Date: </label>
                            <input type="hidden" id="CheckDate" name="CheckDate"/>
                            <div class="col l8 offset-l4">
                                <select class="form-date" id="otherd" name="dd" value="<?=$dobArr[2] ?>" onchange="FucCheckDate()">
                                    <option value="" disabled selected></option>
                                    <?php for ($i=1; $i<32; $i++): ?>
                                    <option value="<?=$i?>"><?= strlen($i)<2?'0'.$i:$i ?></option>
                                    <?php endfor; ?>
                                </select>
                                <span class="slash">/</span>
                                <select class="form-date" type="number" id="otherm" name="mm" value="<?=$dobArr[1] ?>" onchange="FucCheckDate()">
                                    <option value="" disabled selected></option>
                                    <?php for ($i=1; $i<13; $i++): ?>
                                    <option value="<?=$i?>"><?= strlen($i)<2?'0'.$i:$i ?></option>
                                    <?php endfor; ?>
                                </select>
                                <span class="slash">/</span>
                                <select class="form-date" type="number" id="othery" name="yyyy" min="2000" max="9999" value="<?=$dobArr[0] ?>" onchange="FucCheckDate()">
                                    <option value="" disabled selected></option>
                                    <?php for ($i=2000; $i<=Date('Y'); $i++): ?>
                                    <option value="<?=$i?>"><?= strlen($i)<2?'0'.$i:$i ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="input-field bank-account left-content" style="<?=$display?>">
                        <select name="otherToAccount" id="otherToAccount" disabled>
                            <option value="" disabled selected>Select Bank Account</option>
                            <?=$opBankAccount?>
                        </select>
                    </div>
                    <div class="input-field amount-payment right-content">
                        <input id="Otheramount" type="text" class="validate" name="Otheramount" onkeyup="givethechange_Other(<?= $definefee ?>, this.value)">
                        <label for="Otheramount">Amount</label>
                    </div>
                </div>
            </div>
        </div>
        <?php if($MakeOff = 'yes') { ?>
            <div class="row">
                <div class="paid-amount-remain">
                    <div class="remain">
                        <span class="title">Remain</span>
                        <span class="amount" id="BalanceMoney" name="BalanceMoney">-<?php echo $definefee; ?></span><span class="currency">THB</span>
                        <input type="hidden" name="balance" id="balance"/>
                    </div>
                    <div class="paid-amount">
                        <span class="title">Paid Amount</span>
                        <span class="amount"><?php echo $definefee; ?></span><span class="currency">THB</span>
                        <input type="hidden" name="definefee" value='<?php echo $definefee; ?>' />
                    </div>
                </div>
            </div>
        <?php }else{ ?>
            <div class="row">
                <div class="paid-amount-remain">
                    <div class="remain">
                        <span class="title">Remain</span>
                        <span class="amount" id="BalanceMoney" name="BalanceMoney">-<?php echo $definefee; ?></span><span class="currency">THB</span>
                        <input type="hidden" name="balance" id="balance"/>
                    </div>
                    <div class="paid-amount">
                        <span class="title">Paid Amount</span>
                        <span class="amount"><?php echo $definefee; ?></span><span class="currency">THB</span>
                        <input type="hidden" name="definefee" value='<?php echo $definefee; ?>' />
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    <?php if($action !== FALSE) { ?>
    <div class="submit-form">
        <div class="row">
            <div class="col l4">&nbsp;</div>
            <div class="col l8">
                <div class="row">
                    <div class="col l5">
                        <div class="input-field">
                            <input id="note" type="text" class="validate" name="Remark">
                            <label for="note">Note (Shown in Temporary Receipt)</label>
                        </div>
                    </div>
                    <div class="col l7 submit">
                        <button type="submit" class="waves-effect waves-light btn btn-save"><i class="fa fa-check-circle"></i><?=$submit?></button>
                        <a href="<?php echo BASE_DOMAIN.$cancel;?>" class="waves-effect waves-light btn btn-discard"><i class="fa fa-times"></i>Discard</a>
                    </div>
                </div>  
            </div>
        </div>
    </div>
    <?php } ?>
</div>


<script src='<?php echo BASE_DOMAIN; ?>assets/js/givethechange.js'></script>
<script type="text/javascript">
    <?php if(!empty($receipt)) { ?>
    <?php 
    $rcData = '';

    foreach($receiptList as $receipt) {
        // if ($receipt->rc_status == 'cancelled') {
        
            $rcData .= (empty($rcData)?'':',').'{value: "'.$receipt->rc_id.'",label: "'.$receipt->rc_code.'",price: "'.$receipt->rc_total_amount.'"}';
        // }
    } ?>
    $(function() {
        //receiptAutocomplete();
    });
    function receiptAutocomplete() {
        var receiptData = [<?= $rcData ?>];
        if(!receiptData) var receiptData = new Array();
        $( ".receiptCode" ).each(function (id, val) {
            $( ".receiptCode:eq("+id+")" ).autocomplete({
                minLength: 1,
                source: receiptData,
                focus: function( event, ui ) {
                    $( ".receiptCode:eq("+id+")" ).val( ui.item.label );
                    $( ".receiptID:eq("+id+")" ).val( ui.item.value );
                    $( ".receiptAmount:eq("+id+")" ).val( ui.item.price );
                    givethechange_Receipt(<?= $definefee ?>);
                    return false;
                }, select: function( event, ui ) {
                    $( ".receiptCode:eq("+id+")" ).val( ui.item.label );
                    $( ".receiptID:eq("+id+")" ).val( ui.item.value );
                    $( ".receiptAmount:eq("+id+")" ).val( ui.item.price );
                    givethechange_Receipt(<?= $definefee ?>);
                    return false;
                }
            });
        });
    }
    <?php } ?>
    // $('#cb-receipt-1').on('change', function(event) {
    //     if ($('#cb-receipt-1').prop('checked')) {
    //         $('.receipt-code-1').find("input[type='text']").removeAttr('disabled');  
    //     } else {
    //         $('.receipt-code-1').find("input[type='text']").attr('disabled', 'disabled');;
    //     }
    // });

    // $('#cb-receipt-2').on('change', function(event) {
    //     if ($('#cb-receipt-2').prop('checked')) {
    //         $('.receipt-code-2').find("input[type='text']").removeAttr('disabled');  
    //     } else {
    //         $('.receipt-code-2').find("input[type='text']").attr('disabled', 'disabled');;
    //     }
    // });

    // $('.cash').on('change', function(event) {
    //     if ($('.cash').prop('checked')) {
    //         $('.cash-payment').find("input[type='text']").removeAttr('disabled');  
    //     } else {
    //         $('.cash-payment').find("input[type='text']").attr('disabled', 'disabled');;
    //     }
    // });

    // $('.credit-card').on('change', function(event) {
    //     if ($('.credit-card').prop('checked')) {
    //         $('.credit-payment').find("input[type='text']").removeAttr('disabled');  
    //     } else {
    //         $('.credit-payment').find("input[type='text']").attr('disabled', 'disabled');;
    //     }
    // });

    // $('.other').on('change', function(event) {
    //     if ($('.other').prop('checked')) {
    //         $('.other-payment').find("input[type='text']").removeAttr('disabled');  
    //     } else {
    //         $('.other-payment').find("input[type='text']").attr('disabled', 'disabled');;
    //     }
    // });

    function FucCheckDate () {
        var d = $('#otherd').val();
        var m = $('#otherm').val();
        var y = $('#othery').val();
        if (d != null &&
            m != null &&
            y != null) {
			var date = y + '-' + m + '-' + d;
			console.log("success!!"+date);
            $('#CheckDate').val(y + '-' + m + '-' + d);
        } else {
            $('#CheckDate').val('');
        }
    }

    $(".selectReceipt").select2();
    <?php if(!$edit): ?>
	console.log("not edit");
    givethechange_Cash('<?=$definefee?>',$('#Cashamount').val());
    $('#Cashamount').prop('disabled', true);
    $('#Cardamount').prop('disabled', true);
    $('#btnAdd').prop('disabled', true);
    $('#btnDel').prop('disabled', true);
    $('#CardBank').prop('disabled', true);
    $('#Cardno').prop('disabled', true);
    $('#CardType').prop('disabled', true);
    $('#ApproveCode').prop('disabled', true);
    $('#expiremonth').prop('disabled', true);
    $('#expireyear').prop('disabled', true);
    $('#CardHolder').prop('disabled', true);
    $('#OtherBy').prop('disabled', true);
    $('#Otheramount').prop('disabled', true);
    
	$('#cheque-number').prop('disabled', true);
	$('#CheckBank').prop('disabled', true);
	$('#otherd').prop('disabled', true);
	$('#otherm').prop('disabled', true);
	$('#othery').prop('disabled', true);
	
    $('#receiptCode').prop('disabled', true);
    $('#receiptAmount').prop('disabled', true);
	
    <?php endif; ?>
        
    <?php if(!empty($credit->cc_number)): ?>
    $('#OldCredit').click(function() {
        if($('#OldCredit').prop('checked')) {
            $('#PaidCredit').prop('checked', true);
            ClickCredit();
            $('#CardBank').val("<?= $credit->cc_bank ?>");
            $('#Cardno').val("<?= $this->encrypt->decode($credit->cc_number) ?>");
            $('.CardType').val("<?= $credit->cc_type ?>");
            <?php $expire = explode('/',$credit->cc_expire); ?>
            $('#expiremonth').val("<?= $expire[0]; ?>");
            $('#expireyear').val("<?= $expire[1]; ?>");
            $('#CardHolder').val("<?= $credit->cc_holder ?>");
            $('#CardType').material_select(function () {
                $('input.select-dropdown').trigger('close');
            });
            $('#CardBank').material_select(function () {
                $('input.select-dropdown').trigger('close');
            });
            $('#expiremonth').material_select(function () {
                $('input.select-dropdown').trigger('close');
            });
            $('#expireyear').material_select(function () {
                $('input.select-dropdown').trigger('close');
            });
            $('#LBCardHolder').addClass('active');
            $('#LBCardno').addClass('active');
            fixSelect ();
        }else {
            $('#PaidCredit').prop('checked', false);
            ClickCredit();
        }
    });
    <?php endif; ?>
    
    
    
    $('#PaidReceipt').click(function(){

        var checked = $('#PaidReceipt').prop('checked');
        $('#receiptCode').prop('disabled', !checked);
        $('#rcAdd').prop('disabled', !checked);
        $('#rcDel').prop('disabled', !checked);
        $('#receiptCode').val('');
        $('#receiptID').val('');
        $('#receiptAmount').val('');
        while (rcCount > 0) {
            $('.rcList:eq('+(--rcCount)+')').remove();
        }
        // $('#receiptAmount').prop('disabled', !checked);

        // if($('#PaidReceipt').prop('checked')) {
        //     $('#selectReceipt').prop('disabled', false);
        //     $('#rcAdd').prop('disabled', false);
        //     $('#rcDel').prop('disabled', false);
        // }else {
        //     $('#selectReceipt').prop('disabled', true);
        //     $('#selectReceipt').select2('val', '');
        //     $('#rcAdd').prop('disabled', true);
        //     $('#rcDel').prop('disabled', true);
        //     var intLine = parseInt($('#rcCount').val());
        //     while(intLine > 0){
        //         RcRemoveRow();
        //         intLine = parseInt($('#rcCount').val());
        //     }
             givethechange_Receipt('<?=$definefee?>');
        // }
    });
    
    $('#PaidCash').click(function(){
        if($('#PaidCash').prop('checked')) {
            $('#Cashamount').prop('disabled', false);
            $('#Cashamount').prop('required', true);
            $('#cashToAccount').prop('disabled', false);
        }else {
            $('#Cashamount').prop('required', false);
            $('#Cashamount').prop('disabled', true);
            $('#Cashamount').val("");
            $('#cashToAccount').prop('disabled', true);
            givethechange_Cash('<?=$definefee?>',0);
        }
    });
    
    $('#PaidCredit').click(function() {
        ClickCredit();
    });
    
    function ClickCredit() {
        // console.log($('#PaidCredit').prop('checked'));

        var checked = $('#PaidCredit').prop('checked');
        $('#Cardamount').prop('disabled', !checked);
        $('#Cardamount').prop('required', checked);
        $('#btnAdd').prop('disabled', !checked);
        $('#btnDel').prop('disabled', !checked);
        $('#CardBank').prop('disabled', !checked);
        $('#CardBank').val("");
        $('#CardBank').material_select(function () {
            $('input.select-dropdown').trigger('close');
        });
        $('#Cardno').prop('disabled', !checked);
        $('#CardType').prop('disabled', !checked);
        $('#CardType').val("");
        $('#CardType').material_select(function () {
            $('input.select-dropdown').trigger('close');
        });
        $('#ApproveCode').prop('disabled', !checked);
        $('#expiremonth').prop('disabled', !checked);
        $('#expiremonth').val("");
        $('#expiremonth').material_select(function () {
            $('input.select-dropdown').trigger('close');
        });
        $('#expireyear').prop('disabled', !checked);
        $('#expireyear').val("");
        $('#expireyear').material_select(function () {
            $('input.select-dropdown').trigger('close');
        });
        $('#CardHolder').prop('disabled', !checked);
        $('#cardToAccount').prop('disabled', !checked);
        $('#cardFee').prop('disabled', !checked);
        fixSelect ();
        if (!checked) {
            <?php if(!empty($credit->cc_number)): ?>
            $('#OldCredit').prop('checked', false);
            <?php endif; ?>

            $('#Cardamount').val("");
            $('#Cardno').val("");
            $('#ApproveCode').val("");
            $('#CardHolder').val("");
			
            while(countCredit > 0){
                RemoveRow();
            }
            givethechange_Credit('<?=$definefee?>');
        }

        // if($('#PaidCredit').prop('checked')) {
        //     $('#Cardamount').prop('disabled', false);
        //     $('#Cardamount').prop('required', true);
        //     $('#btnAdd').prop('disabled', false);
        //     $('#btnDel').prop('disabled', false);
        //     $('#CardBank').prop('disabled', false);
        //     $('#Cardno').prop('disabled', false);
        //     $('#CardType').prop('disabled', false);
        //     $('#ApproveCode').prop('disabled', false);
        //     $('#expiremonth').prop('disabled', false);
        //     $('#expireyear').prop('disabled', false);
        //     $('#CardHolder').prop('disabled', false);
        //     $('#cardToAccount').prop('disabled', false);
        //     $('#cardFee').prop('disabled', false);
        // }else {
        //     <?php if(!empty($credit->cc_number)): ?>
        //     $('#OldCredit').prop('checked', false);
        //     <?php endif; ?>
        //     $('#Cardamount').prop('required', false);
        //     $('#Cardamount').prop('disabled', true); $('#Cardamount').val("");
        //     $('#btnAdd').prop('disabled', true);
        //     $('#btnDel').prop('disabled', true);
        //     $('#CardBank').prop('disabled', true); $('#CardBank').val("");
        //     $('#Cardno').prop('disabled', true); $('#Cardno').val("");
        //     $('#CardType').prop('disabled', true); $('#CardType').val("");
        //     $('#ApproveCode').prop('disabled', true); $('#ApproveCode').val("");
        //     $('#expiremonth').prop('disabled', true); $('#expiremonth').val("");
        //     $('#expireyear').prop('disabled', true); $('#expireyear').val("");
        //     $('#CardHolder').prop('disabled', true); $('#CardHolder').val("");
        //     $('#cardToAccount').prop('disabled', true);
        //     $('#cardFee').prop('disabled', true);
        //     var intLine = parseInt($('#hdnMaxLine').val());
        //     while(intLine > 0){
        //         RemoveRow();
        //         intLine = parseInt($('#hdnMaxLine').val());
        //     }
        //     givethechange_Credit('<?=$definefee?>');
        // }
    }
    
    $('#PaidOther').click(function(){
        if($('#PaidOther').prop('checked')) {
            $('#OtherBy').prop('disabled', false);
            $('#Otheramount').prop('disabled', false);
            $('#Otheramount').prop('required', true);
            $('#otherToAccount').prop('disabled', false);
			
			$('#otherd').prop('disabled', false);
			$('#otherm').prop('disabled', false);
			$('#othery').prop('disabled', false);
			$('#cheque-number').prop('disabled', false);
			$('#CheckBank').prop('disabled', false);
        }else {
            $('#OtherBy').prop('disabled', true);
            $('#OtherBy').val("");
            $(".cheque-number").hide();
            $(".bank-other").hide();
            $(".date_of_birth").hide();
            $('#Otheramount').prop('required', false);
            $('#Otheramount').prop('disabled', true);
            $('#Otheramount').val("");
            $('#otherToAccount').prop('disabled', true);
			$('#otherd').prop('disabled', true);
			$('#otherm').prop('disabled', true);
			$('#othery').prop('disabled', true);
			$('#cheque-number').prop('disabled', true);
			$('#CheckBank').prop('disabled', true);
			
            givethechange_Other('<?=$definefee?>',0);
//            if(check) {
//                var delRow = parseInt($('#hdnMaxLine').val()) + 15;
//                var theTable = document.all.tbpayment;
//                var theTableBody = theTable.tBodies[0];
//                theTableBody.deleteRow(delRow);
//                theTableBody.deleteRow(delRow);
//                theTableBody.deleteRow(delRow);
//                check = false;
//            }
        }
		
		$('select').material_select(function () {
            $('input.select-dropdown').trigger('close');
        });
        fixSelect ();
    });
    
    var rcCount = 0;
    function RcAddRow() {
        $('.rcGroup').append(rcList);
        $('.rcList:eq('+(rcCount++)+')').slideDown( "slow" );
    }

    function RcRemoveRow() {
        if (rcCount > 0) $('.rcList:eq('+(--rcCount)+')').slideUp( "slow", function () {
                $('.rcList:eq('+(rcCount)+')').remove();
                givethechange_Receipt(<?= $definefee ?>);
            });
    }

    // function RcAddRow()
    // {
    //     var rc = parseInt($('#rcCount').val());
    //     var row = rc + 5;
    //     var theTable = document.all.tbpayment;
    //     var newRow = theTable.insertRow(row);
    //     newRow.innerHTML = '<td></td><td><label for="cashToAccount" class="checkbox">Receipt Code</label></td><td><select class="form-control selectReceipt" id="selectReceipt" style="width:250px" onchange="setReceiptAmount(this)"><option id="" value="">--- Receipt Code ---</option><?php foreach($receiptList as $receipt): ?><option value="<?=$receipt->rc_id.','.$receipt->rc_total_amount ?>"><?=$receipt->rc_code?></option><?php endforeach; ?></select><input type="hidden" class="receiptID" name="receiptID[]" id="receiptID"/></td><td align="right"><label for="Receiptamount" class="checkbox" style="padding-right:5px"> Amount</label></td><td><input  class="form-control Receiptamount" placeholder="Digit 0-9" style="width: 170px"  id="Receiptamount" name="Receiptamount[]"></td><td></td>';
    //     $('#rcCount').val(rc+1);
    // }
    
    // function RcRemoveRow()
    // {
    //     var rc = parseInt($('#rcCount').val());
    //     if(rc > 0) {
    //         var row = rc + 4;
    //         var theTable = document.all.tbpayment
    //         var theTableBody = theTable.tBodies[0];
    //         theTableBody.deleteRow(row);
    //         $('#rcCount').val(rc-1);
    //     }
    // }
    
//    function CreateNewRow()
//	{
//        var row = 16;
//        var MaxLine = parseInt($('#hdnMaxLine').val());
//		var intLine = MaxLine + parseInt($('#rcCount').val());
//        
//        var theTable = document.all.tbpayment;
//        <?php 
//        for($i=0;$i<9;$i++){
//            echo "var newRow = theTable.insertRow(row+intLine+".$i.");\n";
//            if($i == 7) {
//                echo "newRow.className = 'creditFee'\n";
//                echo empty($confirm)?"newRow.style.display = 'none'\n":"";
//            }if($i == 8) {
//                echo "newRow.className = 'cardTo'\n";
//                echo empty($confirm)?"newRow.style.display = 'none'\n":"";
//            }
//            echo "newRow.innerHTML = '".$rowCredit[$i]."';\n";
//        }
//        ?>
//        
//		$('#hdnMaxLine').val(MaxLine+9);
//	}
	
	var countCredit = 0;
	function CreateNewRow () {
		$('.credit-group').append(creditList);
        // $('.credit-list:eq('+(countCredit++)+')').slideDown("slow", function() {

        // });
        $('select').material_select(function () {
            $('input.select-dropdown').trigger('close');
        });
        fixSelect ();
        countCredit++;
	}
	
	function RemoveRow () {
		if(countCredit > 0) {
            // $('.credit-list:eq('+(--countCredit)+')').slideUp("slow", function() {
            //     $('.credit-list:eq('+(countCredit)+')').remove();
            //     givethechange_Credit('<?=$definefee?>');
            // });
            $('.credit-list:eq('+(--countCredit)+')').remove();
            givethechange_Credit('<?=$definefee?>');
        }
	}
	
//	function RemoveRow()
//	{
//        var row = 16;
//        var MaxLine = parseInt($('#hdnMaxLine').val());
//        var rc = parseInt($('#rcCount').val());
//		var intLine = MaxLine + rc;
//        
//		if(intLine > 0)
//		{
//            var delrow = row + intLine - 1;
//            theTable = (document.all) ? document.all.tbpayment : 
//            document.getElementById("tbpayment")
//            theTableBody = theTable.tBodies[0];
//            for(var i=8;i>=0;i--) {
//                theTableBody.deleteRow(delrow);
//                delrow--;
//                intLine--;
//            }
//            $('#hdnMaxLine').val(intLine-rc) ;
//		}	
//	}
    
   $('#OtherBy').change(function(){
    console.log($(this).val()+"Val");
       if($(this).val() == 'Check') {
           $(".cheque-number").show();
           $(".bank-other").show();
           $(".date_of_birth").show();
       }else if($(this).val() != 'Check') {
           $(".cheque-number").hide();
           $(".bank-other").hide();
           $(".date_of_birth").hide();
       }
   });
    
		
    $( "form" ).submit(function( event ) {
        var receipt_amount = 0;
        var cash_amount   = 0;
        var crcard_amount = 0;
        var other_amount  = 0;
        var flag_other = false;
        var flag_card  = false;    
        var toAccount = true;
        $('input[type="checkbox"]').each(function() {
            if ($(this).is(":checked")) {
                if ( $(this).val() == 'Receipt' )
                {
                    for(var i = 0; i < $('.selectReceipt').length; i++) {
                        if($('.receiptID:eq('+i+')').val() == '') {
                            alert("Please select receipt.");
                            $('.selectReceipt:eq('+i+')').focus();
                            event.preventDefault();
                            toAccount = false;
                            return toAccount;
                        }
                        for(var j = i+1; j < $('.selectReceipt').length; j++) {
                            if($('.selectReceipt:eq('+i+')').val() === $('.selectReceipt:eq('+j+')').val()) {
                                alert("Receipt Already.");
                                $('.selectReceipt:eq('+j+')').focus();
                                event.preventDefault();
                                toAccount = false;
                                return toAccount;
                            }
                        }
                    }
                    $('.Receiptamount').each(function() {
                        receipt_amount += $(this).val()!=''?parseInt($(this).val()):0;
                    });
                }
                else if ( $(this).val() == 'Cash' )
                {
                    if($('#Cashamount').val() <= 0)
                    {
                        $('#Cashamount').focus();
                        event.preventDefault();
                        return false;
                    }
                    cash_amount = $('#Cashamount').val()!=''?$('#Cashamount').val():0;
                    <?php if($confirm) { ?>
                    
                    if($('#cashToAccount').val() == null) {
                        alert('Please select Cash account.');
                        $('#cashToAccount').focus();
                        event.preventDefault();
                        toAccount = false;
                        return toAccount;
                    }
                    <?php } ?>
                }
                else if ( $(this).val() == 'CrCard' )
                {
					<?php if($confirm) { ?>
					$('.cardToAccount').each(function(index) {
						var fee = ($('.cardFee:eq('+index+')').val().trim()=='')?-1:parseInt($('.cardFee:eq('+index+')').val());
//						console.log($('.cardToAccount:eq('+index+')').is('select'));
						if($('.cardToAccount:eq('+index+')').val() == '' && $('.cardToAccount:eq('+index+')').is('select')) {
							alert('Please select Credit account.');
							$('.cardToAccount:eq('+index+')').focus();
							event.preventDefault();
							toAccount = false;
							return toAccount;
						}else if( fee < 0) {
							alert('Please enter Credit fee.');
							$('.cardFee:eq('+index+')').focus();
							event.preventDefault();
							toAccount = false;
							return toAccount;
						}
					});
					<?php } ?>
					
                    crcard_amount = 0;
                    $('input[name="Cardamount[]"]').each(function(index){
                        if($('.Cardamount:eq('+index+')').val() <= 0)
                        {
                            $('.Cardamount:eq('+index+')').focus();
                            event.preventDefault();
                            return false;
                        }
                        
                        
                        if ( $('.CardBank')[index].value != ''  && 
                             $('.Cardno')[index].value != '' &&
                             $('.expiremonth')[index].value != '' &&
                             $('.expireyear')[index].value != '' &&
                             $('.CardHolder')[index].value != '' &&
                             $('.CardType')[index].value != '' &&
                             $('.ApproveCode')[index].value != '')
                        {
                             crcard_amount += $(this).val()!=''?parseInt($(this).val()):0;
                        }else flag_card = true;
                    });

                }
                else if ( $(this).val() == 'Other' )
                {
                    <?php if($confirm) { ?>
                    if($('#otherToAccount').val() == '' && toAccount) {
                        alert('Please select Other account.');
                        $('#otherToAccount').focus();
                        event.preventDefault();
                        toAccount = false;
                        return toAccount;
                    }
                    <?php } ?>
                    if ( $('#OtherBy').val() != ''  && 
                         $('#Otheramount').val() != '' &&
                         $('#OtherBy').val() != 'Check' )
                        {
                            other_amount = $('#Otheramount').val()!=''?$('#Otheramount').val():0; 
                        }
                    else if($('#CheckBank').val() != '' && $('#CheckNo').val() != '' && $('#CheckDate').val() != '' && $('#OtherBy').val() == 'Check') {
                        other_amount = $('#Otheramount').val()!=''?$('#Otheramount').val():0; 
                    }else flag_other = true;
                }
            }
        });  
      
      
        if ( flag_card ) {
           alert('Credit Card payment information is not Complete');
           $('input[name="Cardamount[]"]').each(function(index){
               if ( $(".CardBank:eq("+index+")").val()=='' ) {
                   $(".CardBank:eq("+index+")").focus();
                   event.preventDefault(); 
                   return false;
               }else if ( $(".Cardno:eq("+index+")").val().length  < 16 ) {
                   $(".Cardno:eq("+index+")").focus();
                   event.preventDefault(); 
                   return false;
               }else if ( $(".CardType:eq("+index+")").val() == '')  {
                   $(".CardType:eq("+index+")").focus();
                   event.preventDefault(); 
                   return false;
               }else if ( $(".ApproveCode:eq("+index+")").val() == '') {
                   $(".ApproveCode:eq("+index+")").focus();
                   event.preventDefault(); 
                   return false;
               }else if ( $(".expiremonth:eq("+index+")").val() == '' ) {
                   $(".expiremonth:eq("+index+")").focus
                   event.preventDefault(); 
                   return false;
               }else if ( $(".expireyear:eq("+index+")").val()  == '' ) {
                   $(".expireyear:eq("+index+")").focus();
                   event.preventDefault(); 
                   return false;
               }else if ( $(".Cardamount:eq("+index+")").val() == '' ) {
                   $(".Cardamount:eq("+index+")").focus();   
                   event.preventDefault(); 
                   return false;
               }else if ( $(".CardHolder:eq("+index+")").val() == '' ) {
                   $(".CardHolder:eq("+index+")").focus();
                   event.preventDefault(); 
                   return false;
               }
           });
        }
        else if ( flag_other ) {
            
            if($("#OtherBy").val() == 'Check'){
                if($('#CheckBank').val() == '') $("#CheckBank").focus();
                else if($('#CheckNo').val() == '') $("#CheckNo").focus();
                else if($('#CheckDate').val() == '') $("#CheckDate").focus();
                alert('Check  payment information is not Complete');
                event.preventDefault(); 
                exit();
            }else if ( $("#OtherBy").val() =='' ) $("#OtherBy").focus();
            else if ( $("#Otheramount").val()=='' )   $("#Otheramount").focus();
            
            alert('Other  payment information is not Complete');
            event.preventDefault(); 
        }
        else if(toAccount){
            var amt = parseInt(receipt_amount)+parseInt(cash_amount)+parseInt(crcard_amount)+parseInt(other_amount);
            console.log("amt" + amt);
           if ( (amt == <?php echo (empty($definefee)?0:$definefee); ?>) || ($('#divide').prop('checked')) ){ 
               $( "#target" ).submit();
           } else  { 
              alert('paid not balance');
              event.preventDefault();
           }
           
        }
        
            
  });
        

    $('#Cashamount').keypress(function(e) {
        var a = [];
        var k = e.which;

        for (i = 48; i < 58; i++)
            a.push(i);

        if (!(a.indexOf(k)>=0))
            e.preventDefault();    
    });

    $('#Cardno').keypress(function(e) {
        var a = [];
        var k = e.which;

        for (i = 48; i < 58; i++)
            a.push(i);

        if (!(a.indexOf(k)>=0))
            e.preventDefault();
    });

    $('#Cardamount').keypress(function(e) {
        var a = [];
        var k = e.which;

        for (i = 48; i < 58; i++)
            a.push(i);

        if (!(a.indexOf(k)>=0))
            e.preventDefault();    
    });

    $('#Otheramount').keypress(function(e) {
        var a = [];
        var k = e.which;

        for (i = 48; i < 58; i++)
            a.push(i);

        if (!(a.indexOf(k)>=0))
            e.preventDefault();    
    });
    
    function BankOther() {
        $( '.CardBank' ).each( function(index){
            if($(this).val() === '0' && $( '.BankOther:eq('+index+')' ).html() === '') {
                var html = '<table width="100%"><tr><td align="right">';
                html += '<label for="BankName" class="checkbox" style="padding-right:5px"> Bank Name</label>';
                html += '</td><td width="170">';
                html += '<input name="BankName[]" class="form-control Cardno" style="width: 170px" placeholder="">';
                html += '</td></tr></table>';
                $( '.BankOther:eq('+index+')' ).html(html);
            }else if($(this).val() !== '0')
                $( '.BankOther:eq('+index+')' ).html('');
        });
    }
    
</script>